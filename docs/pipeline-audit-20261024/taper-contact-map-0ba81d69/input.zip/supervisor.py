import fcntl,hashlib,json,os,pathlib,subprocess,time
r=pathlib.Path(__file__).parent;s={'id':r.name,'compute':'google','publication_eligible':False,'qualification_complete':False,'status':'queued'}
def save():
 p=r/'state.tmp.json';p.write_text(json.dumps(s,indent=2));p.replace(r/'state.json')
assert os.environ.get('COLAB_RELEASE_TAG');save()
lease=pathlib.Path('/content/esports-trellis2/gpu-lease/inference.lock');lease.parent.mkdir(parents=True,exist_ok=True)
with lease.open('a+') as lock:
 try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 except BlockingIOError:s.update(status='waiting_resources');save();raise SystemExit()
 try:
  i=json.loads(pathlib.Path('/content/teamfight-preparation/installation.json').read_text());assert i['status']=='installed_unqualified' and i['profile']=='t4-fp32'
  s.update(status='running',runtime_id=i['runtime_id'],environment_sha256=i['environment_sha256'],started_unix=time.time());save()
  with (r/'review.log').open('ab') as log:p=subprocess.run(['/content/teamfight-preparation/venv/bin/python','-u',str(r/'tools/diagnose_collision_influences.py'),str(r)],stdout=log,stderr=subprocess.STDOUT,timeout=1200)
  s['exit_code']=p.returncode;report=r/'output/report.json';d=json.loads(report.read_text()) if report.exists() else {}
  if p.returncode or d.get('status')!='diagnostic_complete':raise RuntimeError(d.get('error','Contact map incomplete; inspect retained log'))
  s.update(status='completed',report_sha256=hashlib.sha256(report.read_bytes()).hexdigest())
 except Exception as error:s.update(status='failed',error=f'{type(error).__name__}: {error}')
 finally:s['completed_unix']=time.time();save()
