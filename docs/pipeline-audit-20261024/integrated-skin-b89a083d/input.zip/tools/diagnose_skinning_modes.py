"""Colab-only causal check of linear versus volume-preserving skin evaluation.

Blender preserve-volume is NOT portable glTF skinning. No candidate is exported
or qualified by this diagnostic; a useful result would need a portable correction.
"""
import json
import math
import os
from pathlib import Path
import sys
import time

import bpy
from mathutils import Quaternion, Vector
from review_generated_rig import load, surface
from review_collision_weight_candidate import digest, reset_pose, surface_roundtrip, TARGETS
from mesh_validation import collision_summary, rest_keys
from asset_pipeline.edge_deformation import edge_deformation


def main(root):
    if not os.environ.get('COLAB_RELEASE_TAG') or not root.is_relative_to('/content/teamfight-preparation/reviews'):
        raise RuntimeError('Google Colab is required for skinning mode diagnosis')
    plan=json.loads((root/'plan.json').read_text())
    for name,expected in plan['files'].items():
        if digest(root/name)!=expected:raise ValueError('Frozen input changed: '+name)
    baseline=json.loads((root/'baseline-report.json').read_text());mapping=baseline['bone_map']
    candidate=json.loads((root/'candidate-report.json').read_text());expected_rows=candidate.get('reloaded_poses',candidate.get('poses'))
    expected={(p['joint'],p['degrees']):p['self_intersections'] for p in expected_rows}
    output=root/'output';output.mkdir(exist_ok=False)
    report={'id':plan['id'],'compute':'google','method':'linear-versus-preserve-volume-v1',
        'source_sha256':baseline['source_sha256'],'rig_sha256':plan['parent_candidate_sha256'],
        'parent_candidate_id':plan['parent_candidate_id'],'publication_eligible':False,'qualification_complete':False,
        'started_unix':time.time(),'variants':[]}
    try:
        rigs,meshes=load(root/'candidate.glb');reset_pose(rigs[0]);original,faces,regions=surface(meshes);keys=rest_keys(original)
        for label,volume in [('linear_baseline',False),('preserve_volume_diagnostic',True)]:
            rigs,meshes=load(root/'candidate.glb');rig=rigs[0];reset_pose(rig)
            for obj in meshes:
                modifiers=[m for m in obj.modifiers if m.type=='ARMATURE']
                if len(modifiers)!=1:raise ValueError('Expected one armature modifier')
                modifiers[0].use_deform_preserve_volume=volume
            rest,current_faces,_=surface(meshes)
            if current_faces!=faces:raise ValueError('Skinning mode changed topology')
            row={'name':label,'poses':[],'rest_surface_comparison':surface_roundtrip(original,rest)};report['variants'].append(row)
            if row['rest_surface_comparison']['max_nearest_distance_m']>1e-6:raise ValueError('Mode changed bind surface')
            for role,child in TARGETS.items():
                bone=rig.pose.bones[mapping[role]]
                start=rig.matrix_world@bone.bone.head_local;end=rig.matrix_world@rig.data.bones[mapping[child]].head_local
                desired=Vector((0,1 if role.startswith('Calf') else -1,0))
                axis=(bone.bone.matrix_local.to_3x3().inverted()@rig.matrix_world.to_3x3().inverted()@(end-start).normalized().cross(desired).normalized()).normalized()
                for degrees in (45,90):
                    reset_pose(rig);bone.rotation_mode='QUATERNION';bone.rotation_quaternion=Quaternion(axis,math.radians(degrees));bpy.context.scene.frame_set(0)
                    posed,posed_faces,_=surface(meshes)
                    if posed_faces!=faces:raise ValueError('Mode changed posed topology')
                    count=collision_summary(posed,faces,keys,regions)
                    if not volume and count['self_intersections']!=expected[(role,degrees)]:raise ValueError('Canonical baseline reproduction failed')
                    row['poses'].append({'joint':role,'degrees':degrees,**count,
                        'parent_intersections':expected[(role,degrees)],'delta_vs_parent':count['self_intersections']-expected[(role,degrees)],
                        'edge_deformation':edge_deformation(original,posed,faces)})
                    (output/'progress.json').write_text(json.dumps(report,indent=2))
            reset_pose(rig)
        report['status']='diagnostic_complete'
        report['scope']='Blender evaluation-mode isolation on an exact registered mesh/rig with fixed weights and rest collision keys. Preserve-volume is not standard glTF/Babylon skinning; no candidate, exported fix, game-animation or qualification claim.'
    except Exception as error:
        report.update(status='failed',error=f'{type(error).__name__}: {error}');raise
    finally:
        report['completed_unix']=time.time();(output/'report.json').write_text(json.dumps(report,indent=2))


if __name__=='__main__':main(Path(sys.argv[1]).resolve())
