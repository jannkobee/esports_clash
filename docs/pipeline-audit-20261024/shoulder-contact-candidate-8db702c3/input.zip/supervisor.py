import fcntl,hashlib,json,os,pathlib,subprocess,time
r=pathlib.Path(__file__).parent;s={'id':r.name,'compute':'google','publication_eligible':False,'qualification_complete':False,'status':'queued'}
def save():
 p=r/'state.tmp.json';p.write_text(json.dumps(s,indent=2));p.replace(r/'state.json')
assert os.environ.get('COLAB_RELEASE_TAG');save()
lease=pathlib.Path('/content/esports-trellis2/gpu-lease/inference.lock');lease.parent.mkdir(parents=True,exist_ok=True)
with lease.open('a+') as lock:
 try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 except BlockingIOError:s.update(status='waiting_resources');save();raise SystemExit()
 try:
  i=json.loads(pathlib.Path('/content/teamfight-preparation/installation.json').read_text());assert i['status']=='installed_unqualified' and i['profile']=='t4-fp32'
  s.update(status='running',runtime_id=i['runtime_id'],environment_sha256=i['environment_sha256'],started_unix=time.time());save()
  python='/content/teamfight-preparation/venv/bin/python'
  stages=[('contact-contract-checks',[python,'-m','unittest','discover','-s',str(r/'tools'),'-p','test_contact_patch_mask.py','-v']),
   ('repair-study',[python,'-u',str(r/'tools/review_shoulder_contact_candidate.py'),str(r)])]
  for stage,command in stages:
   s['stage']=stage;save()
   with (r/(stage+'.log')).open('ab') as log:p=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=1200)
   s['exit_code']=p.returncode;save()
   if p.returncode:raise RuntimeError(stage+' exited '+str(p.returncode))
  report=r/'output/report.json';d=json.loads(report.read_text())
  if d['status']!='review_required':raise RuntimeError(d.get('error','Incomplete shoulder study'))
  s.update(status='completed',report_sha256=hashlib.sha256(report.read_bytes()).hexdigest())
 except Exception as error:s.update(status='failed',error=f'{type(error).__name__}: {error}')
 finally:s['completed_unix']=time.time();save()
