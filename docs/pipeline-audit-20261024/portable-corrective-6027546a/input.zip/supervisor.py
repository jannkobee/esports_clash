import fcntl,hashlib,json,os,pathlib,subprocess,time
r=pathlib.Path(__file__).parent;s={'id':r.name,'compute':'google','publication_eligible':False,'qualification_complete':False,'status':'queued'}
def save():
 p=r/'state.tmp.json';p.write_text(json.dumps(s,indent=2));p.replace(r/'state.json')
assert os.environ.get('COLAB_RELEASE_TAG');save()
lease=pathlib.Path('/content/esports-trellis2/gpu-lease/inference.lock');lease.parent.mkdir(parents=True,exist_ok=True)
with lease.open('a+') as lock:
 try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 except BlockingIOError:s.update(status='waiting_resources');save();raise SystemExit()
 try:
  i=json.loads(pathlib.Path('/content/teamfight-preparation/installation.json').read_text());assert i['status']=='installed_unqualified' and i['profile']=='t4-fp32' and i['environment_sha256']=='73928306c86dae9ce21c8fe672abffcebdbb4ee2a654fa3a194a6f466ee8d105'
  s.update(status='running',stage='portable-corrective-bake',runtime_id=i['runtime_id'],environment_sha256=i['environment_sha256'],started_unix=time.time());save()
  with (r/'corrective-bake.log').open('ab') as log:
   p=subprocess.run(['/content/teamfight-preparation/venv/bin/python','-u',str(r/'tools/bake_pose_corrective_candidate.py'),str(r)],stdout=log,stderr=subprocess.STDOUT,timeout=1800)
  s['exit_code']=p.returncode;save()
  if p.returncode:raise RuntimeError('Corrective bake exited '+str(p.returncode))
  report=r/'output/report.json';d=json.loads(report.read_text());assert d['status']=='review_required'
  s.update(status='completed',report_sha256=hashlib.sha256(report.read_bytes()).hexdigest())
 except Exception as error:s.update(status='failed',error=f'{type(error).__name__}: {error}')
 finally:s['completed_unix']=time.time();save()
