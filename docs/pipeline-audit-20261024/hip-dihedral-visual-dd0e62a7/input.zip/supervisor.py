import fcntl,hashlib,json,os,pathlib,subprocess,time
r=pathlib.Path(__file__).parent
state={'id':r.name,'compute':'google','publication_eligible':False,'qualification_complete':False,'status':'queued'}
def save():
 p=r/'state.tmp.json';p.write_text(json.dumps(state,indent=2));p.replace(r/'state.json')
save()
assert os.environ.get('COLAB_RELEASE_TAG')
lease=pathlib.Path('/content/esports-trellis2/gpu-lease/inference.lock');lease.parent.mkdir(parents=True,exist_ok=True)
with lease.open('a+') as lock:
 try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 except BlockingIOError:state.update(status='waiting_resources');save();raise SystemExit()
 try:
  installed=json.loads(pathlib.Path('/content/teamfight-preparation/installation.json').read_text())
  assert installed['status']=='installed_unqualified' and installed['profile']=='t4-fp32'
  inspector=pathlib.Path('/content/teamfight-inspection/installation.json')
  browser_install=json.loads(inspector.read_text())
  assert browser_install['status']=='installed' and browser_install['playwright']=='1.55.0'
  assert pathlib.Path('/content/teamfight-inspection/venv/bin/python').is_file()
  state['inspector_installation_sha256']=hashlib.sha256(inspector.read_bytes()).hexdigest()
  state.update(status='running',runtime_id=installed['runtime_id'],environment_sha256=installed['environment_sha256'],started_unix=time.time());save()
  stages=[('diagnostic-export','/content/teamfight-preparation/venv/bin/python','export_candidate_inspection_bends.py'),('babylon-render','/content/teamfight-inspection/venv/bin/python','render_candidate_comparison_colab.py')]
  if json.loads((r/'plan.json').read_text()).get('mode')=='joint-details':stages=stages[1:]
  for stage,python,script in stages:
   state['stage']=stage;save()
   with (r/(stage+'.log')).open('ab') as log:
    process=subprocess.run([python,'-u',str(r/'tools'/script),str(r)],stdout=log,stderr=subprocess.STDOUT,timeout=1200,env={**os.environ,'PLAYWRIGHT_BROWSERS_PATH':'/content/teamfight-inspection/browsers'})
   state['exit_code']=process.returncode;save()
   if process.returncode:raise RuntimeError(stage+' exited '+str(process.returncode))
  report=r/'visual-report.json';data=json.loads(report.read_text())
  if data['status']!='rendered_for_review':raise RuntimeError('Visual render incomplete')
  state.update(status='completed',report_sha256=hashlib.sha256(report.read_bytes()).hexdigest())
 except Exception as error:state.update(status='failed',error=f'{type(error).__name__}: {error}')
 finally:state['completed_unix']=time.time();save()
