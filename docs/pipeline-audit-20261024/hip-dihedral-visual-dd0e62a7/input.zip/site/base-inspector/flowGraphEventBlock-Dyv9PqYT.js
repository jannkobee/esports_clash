import { t as e } from "./flowGraphAsyncExecutionBlock-y06fnRVP.js";
//#region node_modules/@babylonjs/core/FlowGraph/flowGraphEventBlock.js
var t = class extends e {
	constructor(e) {
		super(e), this.initPriority = 0, this.type = "NoTrigger", this._unregisterSignalInput("in");
	}
	deserialize(e) {
		let t = { ...e };
		t.signalInputs = (e.signalInputs ?? []).filter((e) => e.name !== "in"), super.deserialize(t);
	}
	get eventKey() {
		return this.config?.eventKey ?? this.type;
	}
	_execute(e) {
		e._notifyExecuteNode(this), this.done._activateSignal(e), this.out._activateSignal(e);
	}
	_startPendingTasks(e) {
		e._getExecutionVariable(this, "_initialized", !1) && (this._cancelPendingTasks(e), this._resetAfterCanceled(e)), this._preparePendingTasks(e), e._addPendingBlock(this), e._setExecutionVariable(this, "_initialized", !0);
	}
};
//#endregion
export { t };
