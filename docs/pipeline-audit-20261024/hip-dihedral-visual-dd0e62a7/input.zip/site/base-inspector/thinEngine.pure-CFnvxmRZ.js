import { d as e } from "./math.scalar.functions-D7lyzZPV.js";
import { t } from "./internalTexture-QUW4uXxg.js";
import { t as n } from "./logger-DQIzSR_y.js";
import { i as r } from "./domManagement-BZa7OPDn.js";
import { a as i, c as a, d as o, f as s, h as c, i as l, l as u, m as d, n as f, o as p, p as m, r as h, s as g, t as _, u as v } from "./abstractEngine.pure-C608BZav.js";
import { g as y, h as b, n as x } from "./tools.functions-DEecYKlu.js";
//#region node_modules/@babylonjs/core/Materials/drawWrapper.functions.js
function S(e) {
	return e.getPipelineContext === void 0;
}
//#endregion
//#region node_modules/@babylonjs/core/Engines/WebGL/webGLShaderProcessors.js
var C = class {
	constructor() {
		this.shaderLanguage = 0;
	}
	postProcessor(e, t, n, r, i) {
		return i.drawBuffersExtensionDisabled && (e = e.replace(/#extension.+GL_EXT_draw_buffers.+(enable|require)/g, "")), e;
	}
}, w = /(flat\s)?\s*varying\s*.*/, T = class {
	constructor() {
		this.shaderLanguage = 0;
	}
	attributeProcessor(e) {
		return e.replace("attribute", "in");
	}
	varyingCheck(e, t) {
		return w.test(e);
	}
	varyingProcessor(e, t) {
		return e.replace("varying", t ? "in" : "out");
	}
	postProcessor(e, t, n) {
		let r = e.search(/#extension.+GL_EXT_draw_buffers.+require/) !== -1;
		if (e = e.replace(/#extension.+(GL_OVR_multiview2|GL_OES_standard_derivatives|GL_EXT_shader_texture_lod|GL_EXT_frag_depth|GL_EXT_draw_buffers).+(enable|require)/g, ""), e = e.replace(/texture2D\s*\(/g, "texture("), n) {
			let n = e.search(/layout *\(location *= *0\) *out/g) !== -1, i = t.indexOf("#define DUAL_SOURCE_BLENDING") !== -1, a = i ? "layout(location = 0, index = 0) out vec4 glFragColor;\nlayout(location = 0, index = 1) out vec4 glFragColor2;\n" : "layout(location = 0) out vec4 glFragColor;\n";
			i && (e = "#extension GL_EXT_blend_func_extended : require\n" + e), e = e.replace(/texture2DLodEXT\s*\(/g, "textureLod("), e = e.replace(/textureCubeLodEXT\s*\(/g, "textureLod("), e = e.replace(/textureCube\s*\(/g, "texture("), e = e.replace(/gl_FragDepthEXT/g, "gl_FragDepth"), e = e.replace(/gl_FragColor/g, "glFragColor"), e = e.replace(/gl_FragData/g, "glFragData"), e = e.replace(/void\s+?main\s*\(/g, (r || n ? "" : a) + "void main(");
		} else if (t.indexOf("#define VERTEXOUTPUT_INVARIANT") >= 0 && (e = "invariant gl_Position;\n" + e), t.indexOf("#define MULTIVIEW") !== -1) return "#extension GL_OVR_multiview2 : require\nlayout (num_views = 2) in;\n" + e;
		return e;
	}
}, E = class e {
	get underlyingResource() {
		return null;
	}
	constructor() {
		this.references = 0, this.capacity = 0, this.is32Bits = !1, this.uniqueId = e._Counter++;
	}
};
E._Counter = 0;
//#endregion
//#region node_modules/@babylonjs/core/Meshes/WebGL/webGLDataBuffer.js
var D = class extends E {
	constructor(e) {
		super(), this._buffer = e;
	}
	get underlyingResource() {
		return this._buffer;
	}
}, O = class {
	get underlyingResource() {
		return this._webGLTexture;
	}
	constructor(e = null, t) {
		if (this._MSAARenderBuffers = null, this._context = t, !e && (e = t.createTexture(), !e)) throw Error("Unable to create webGL texture");
		this.set(e);
	}
	setUsage() {}
	set(e) {
		this._webGLTexture = e;
	}
	reset() {
		this._webGLTexture = null, this._MSAARenderBuffers = null;
	}
	addMSAARenderBuffer(e) {
		this._MSAARenderBuffers ||= [], this._MSAARenderBuffers.push(e);
	}
	releaseMSAARenderBuffers() {
		if (this._MSAARenderBuffers) {
			for (let e of this._MSAARenderBuffers) this._context.deleteRenderbuffer(e);
			this._MSAARenderBuffers = null;
		}
	}
	getMSAARenderBuffer(e = 0) {
		return this._MSAARenderBuffers?.[e] ?? null;
	}
	release() {
		this.releaseMSAARenderBuffers(), this._webGLTexture && this._context.deleteTexture(this._webGLTexture), this.reset();
	}
};
//#endregion
//#region node_modules/@babylonjs/core/Materials/Textures/textureHelper.functions.js
function k(e) {
	return e === 13 || e === 14 || e === 15 || e === 16 || e === 17 || e === 18 || e === 19;
}
function A(e) {
	return e === 8 || e === 9 || e === 10 || e === 11;
}
function j(e) {
	return e === 0 || e === 5 || e === 7 || e === 11;
}
function M(e) {
	return e === 13 || e === 17 || e === 18 || e === 19;
}
//#endregion
//#region node_modules/@babylonjs/core/Engines/thinEngine.pure.js
var N = /* @__PURE__ */ e({ ThinEngine: () => F }), P = class {}, F = class e extends _ {
	get name() {
		return this._name;
	}
	set name(e) {
		this._name = e;
	}
	get version() {
		return this._webGLVersion;
	}
	static get ShadersRepository() {
		return h.ShadersRepository;
	}
	static set ShadersRepository(e) {
		h.ShadersRepository = e;
	}
	get supportsUniformBuffers() {
		return this.webGLVersion > 1 && !this.disableUniformBuffers;
	}
	get needPOTTextures() {
		return this._webGLVersion < 2 || this.forcePOTTextures;
	}
	get _supportsHardwareTextureRescaling() {
		return !1;
	}
	snapshotRenderingReset() {
		this.snapshotRendering = !1;
	}
	constructor(t, r, i, a) {
		if (i ||= {}, super(r ?? i.antialias, i, a), this._name = "WebGL", this.forcePOTTextures = !1, this.validateShaderPrograms = !1, this.disableUniformBuffers = !1, this._webGLVersion = 1, this._integerMRTAttachmentsMask = 0, this._vertexAttribArraysEnabled = [], this._uintIndicesCurrentlySet = !1, this._currentBoundBuffer = [], this._currentFramebuffer = null, this._dummyFramebuffer = null, this._currentBufferPointers = [], this._currentInstanceLocations = [], this._currentInstanceBuffers = [], this._cachedVertexBuffersSetInstanceDivisors = !1, this._vaoRecordInProgress = !1, this._mustWipeVertexAttributes = !1, this._nextFreeTextureSlots = [], this._maxSimultaneousTextures = 0, this._maxMSAASamplesOverride = null, this._unpackFlipYCached = null, this.enableUnpackFlipYCached = !0, this._boundUniforms = {}, !t) return;
		let o;
		if (t.getContext) {
			if (o = t, i.preserveDrawingBuffer === void 0 && (i.preserveDrawingBuffer = !1), i.xrCompatible === void 0 && (i.xrCompatible = !1), navigator && navigator.userAgent) {
				this._setupMobileChecks();
				let t = navigator.userAgent;
				for (let n of e.ExceptionList) {
					let e = n.key, r = n.targets;
					if (new RegExp(e).test(t)) {
						if (n.capture && n.captureConstraint) {
							let e = n.capture, r = n.captureConstraint, i = new RegExp(e).exec(t);
							if (i && i.length > 0 && parseInt(i[i.length - 1]) >= r) continue;
						}
						for (let e of r) switch (e) {
							case "uniformBuffer":
								this.disableUniformBuffers = !0;
								break;
							case "vao":
								this.disableVertexArrayObjects = !0;
								break;
							case "antialias":
								i.antialias = !1;
								break;
							case "maxMSAASamples": this._maxMSAASamplesOverride = 1;
						}
					}
				}
			}
			if (this._doNotHandleContextLost ? this._onContextLost = () => {
				d(this._gl);
			} : (this._onContextLost = (e) => {
				e.preventDefault(), this._contextWasLost = !0, d(this._gl), n.Warn("WebGL context lost."), this.onContextLostObservable.notifyObservers(this);
			}, this._onContextRestored = () => {
				this._restoreEngineAfterContextLost(() => this._initGLContext());
			}, o.addEventListener("webglcontextrestored", this._onContextRestored, !1), i.powerPreference = i.powerPreference || "high-performance"), o.addEventListener("webglcontextlost", this._onContextLost, !1), this._badDesktopOS && (i.xrCompatible = !1), !i.disableWebGL2Support) try {
				this._gl = o.getContext("webgl2", i) || o.getContext("experimental-webgl2", i), this._gl && (this._webGLVersion = 2, this._shaderPlatformName = "WEBGL2", this._gl.deleteQuery || (this._webGLVersion = 1, this._shaderPlatformName = "WEBGL1"));
			} catch {}
			if (!this._gl) {
				if (!o) throw Error("The provided canvas is null or undefined.");
				try {
					this._gl = o.getContext("webgl", i) || o.getContext("experimental-webgl", i);
				} catch (e) {
					throw Error("WebGL not supported", { cause: e });
				}
			}
			if (!this._gl) throw Error("WebGL not supported");
		} else {
			this._gl = t, o = this._gl.canvas, this._gl.renderbufferStorageMultisample ? (this._webGLVersion = 2, this._shaderPlatformName = "WEBGL2") : this._shaderPlatformName = "WEBGL1";
			let e = this._gl.getContextAttributes();
			e && (i.stencil = e.stencil);
		}
		this._sharedInit(o), this._gl.pixelStorei(this._gl.UNPACK_COLORSPACE_CONVERSION_WEBGL, this._gl.NONE), i.useHighPrecisionFloats !== void 0 && (this._highPrecisionShadersAllowed = i.useHighPrecisionFloats), this.resize(), this._initGLContext(), this._initFeatures();
		for (let e = 0; e < this._caps.maxVertexAttribs; e++) this._currentBufferPointers[e] = new P();
		this._shaderProcessor = this.webGLVersion > 1 ? new T() : new C();
		let s = `Babylon.js v${e.Version}`;
		n.Log(s + ` - ${this.description}`), this._renderingCanvas && this._renderingCanvas.setAttribute && this._renderingCanvas.setAttribute("data-engine", s);
		let l = c(this._gl);
		l.validateShaderPrograms = this.validateShaderPrograms, l.parallelShaderCompile = this._caps.parallelShaderCompile;
	}
	_clearEmptyResources() {
		this._dummyFramebuffer = null, super._clearEmptyResources();
	}
	_getShaderProcessingContext(e) {
		return null;
	}
	areAllEffectsReady() {
		for (let e in this._compiledEffects) if (!this._compiledEffects[e].isReady()) return !1;
		return !0;
	}
	_initGLContext() {
		this._caps = {
			maxTexturesImageUnits: this._gl.getParameter(this._gl.MAX_TEXTURE_IMAGE_UNITS),
			maxCombinedTexturesImageUnits: this._gl.getParameter(this._gl.MAX_COMBINED_TEXTURE_IMAGE_UNITS),
			maxVertexTextureImageUnits: this._gl.getParameter(this._gl.MAX_VERTEX_TEXTURE_IMAGE_UNITS),
			maxTextureSize: this._gl.getParameter(this._gl.MAX_TEXTURE_SIZE),
			maxSamples: this._webGLVersion > 1 ? this._gl.getParameter(this._gl.MAX_SAMPLES) : 1,
			maxCubemapTextureSize: this._gl.getParameter(this._gl.MAX_CUBE_MAP_TEXTURE_SIZE),
			maxRenderTextureSize: this._gl.getParameter(this._gl.MAX_RENDERBUFFER_SIZE),
			maxVertexAttribs: this._gl.getParameter(this._gl.MAX_VERTEX_ATTRIBS),
			maxVaryingVectors: this._gl.getParameter(this._gl.MAX_VARYING_VECTORS),
			maxFragmentUniformVectors: this._gl.getParameter(this._gl.MAX_FRAGMENT_UNIFORM_VECTORS),
			maxVertexUniformVectors: this._gl.getParameter(this._gl.MAX_VERTEX_UNIFORM_VECTORS),
			shaderFloatPrecision: 0,
			parallelShaderCompile: this._gl.getExtension("KHR_parallel_shader_compile") || void 0,
			standardDerivatives: this._webGLVersion > 1 || this._gl.getExtension("OES_standard_derivatives") !== null,
			maxAnisotropy: 1,
			astc: this._gl.getExtension("WEBGL_compressed_texture_astc") || this._gl.getExtension("WEBKIT_WEBGL_compressed_texture_astc"),
			bptc: this._gl.getExtension("EXT_texture_compression_bptc") || this._gl.getExtension("WEBKIT_EXT_texture_compression_bptc"),
			s3tc: this._gl.getExtension("WEBGL_compressed_texture_s3tc") || this._gl.getExtension("WEBKIT_WEBGL_compressed_texture_s3tc"),
			s3tc_srgb: this._gl.getExtension("WEBGL_compressed_texture_s3tc_srgb") || this._gl.getExtension("WEBKIT_WEBGL_compressed_texture_s3tc_srgb"),
			pvrtc: this._gl.getExtension("WEBGL_compressed_texture_pvrtc") || this._gl.getExtension("WEBKIT_WEBGL_compressed_texture_pvrtc"),
			etc1: this._gl.getExtension("WEBGL_compressed_texture_etc1") || this._gl.getExtension("WEBKIT_WEBGL_compressed_texture_etc1"),
			etc2: this._gl.getExtension("WEBGL_compressed_texture_etc") || this._gl.getExtension("WEBKIT_WEBGL_compressed_texture_etc") || this._gl.getExtension("WEBGL_compressed_texture_es3_0"),
			textureAnisotropicFilterExtension: this._gl.getExtension("EXT_texture_filter_anisotropic") || this._gl.getExtension("WEBKIT_EXT_texture_filter_anisotropic") || this._gl.getExtension("MOZ_EXT_texture_filter_anisotropic"),
			uintIndices: this._webGLVersion > 1 || this._gl.getExtension("OES_element_index_uint") !== null,
			fragmentDepthSupported: this._webGLVersion > 1 || this._gl.getExtension("EXT_frag_depth") !== null,
			highPrecisionShaderSupported: !1,
			timerQuery: this._gl.getExtension("EXT_disjoint_timer_query_webgl2") || this._gl.getExtension("EXT_disjoint_timer_query"),
			supportOcclusionQuery: this._webGLVersion > 1,
			canUseTimestampForTimerQuery: !1,
			drawBuffersExtension: !1,
			maxMSAASamples: 1,
			colorBufferFloat: !!(this._webGLVersion > 1 && this._gl.getExtension("EXT_color_buffer_float")),
			blendFloat: this._gl.getExtension("EXT_float_blend") !== null,
			supportFloatTexturesResolve: !1,
			rg11b10ufColorRenderable: !1,
			colorBufferHalfFloat: !!(this._webGLVersion > 1 && this._gl.getExtension("EXT_color_buffer_half_float")),
			textureFloat: !!(this._webGLVersion > 1 || this._gl.getExtension("OES_texture_float")),
			textureHalfFloat: !!(this._webGLVersion > 1 || this._gl.getExtension("OES_texture_half_float")),
			textureHalfFloatRender: !1,
			textureFloatLinearFiltering: !1,
			textureFloatRender: !1,
			textureHalfFloatLinearFiltering: !1,
			vertexArrayObject: !1,
			instancedArrays: !1,
			textureLOD: !!(this._webGLVersion > 1 || this._gl.getExtension("EXT_shader_texture_lod")),
			texelFetch: this._webGLVersion !== 1,
			blendMinMax: !1,
			multiview: this._gl.getExtension("OVR_multiview2"),
			oculusMultiview: this._gl.getExtension("OCULUS_multiview"),
			depthTextureExtension: !1,
			canUseGLInstanceID: this._webGLVersion > 1,
			canUseGLVertexID: this._webGLVersion > 1,
			supportComputeShaders: !1,
			supportSRGBBuffers: !1,
			supportTransformFeedbacks: this._webGLVersion > 1,
			textureMaxLevel: this._webGLVersion > 1,
			texture2DArrayMaxLayerCount: this._webGLVersion > 1 ? this._gl.getParameter(this._gl.MAX_ARRAY_TEXTURE_LAYERS) : 128,
			disableMorphTargetTexture: !1,
			textureNorm16: !!this._gl.getExtension("EXT_texture_norm16"),
			blendParametersPerTarget: !1,
			dualSourceBlending: !1,
			supportReadWriteStorageTextures: !1
		}, this._caps.supportFloatTexturesResolve = this._caps.colorBufferFloat, this._caps.rg11b10ufColorRenderable = this._caps.colorBufferFloat, this._glVersion = this._gl.getParameter(this._gl.VERSION);
		let e = this._gl.getExtension("WEBGL_debug_renderer_info");
		e != null && (this._glRenderer = this._gl.getParameter(e.UNMASKED_RENDERER_WEBGL), this._glVendor = this._gl.getParameter(e.UNMASKED_VENDOR_WEBGL)), this._glVendor ||= this._gl.getParameter(this._gl.VENDOR) || "Unknown vendor", this._glRenderer ||= this._gl.getParameter(this._gl.RENDERER) || "Unknown renderer", this._gl.HALF_FLOAT_OES !== 36193 && (this._gl.HALF_FLOAT_OES = 36193), this._gl.RGBA16F !== 34842 && (this._gl.RGBA16F = 34842), this._gl.RGBA32F !== 34836 && (this._gl.RGBA32F = 34836), this._gl.DEPTH24_STENCIL8 !== 35056 && (this._gl.DEPTH24_STENCIL8 = 35056), this._caps.timerQuery && (this._webGLVersion === 1 && (this._gl.getQuery = this._caps.timerQuery.getQueryEXT.bind(this._caps.timerQuery)), this._caps.canUseTimestampForTimerQuery = (this._gl.getQuery(this._caps.timerQuery.TIMESTAMP_EXT, this._caps.timerQuery.QUERY_COUNTER_BITS_EXT) ?? 0) > 0), this._caps.maxAnisotropy = this._caps.textureAnisotropicFilterExtension ? this._gl.getParameter(this._caps.textureAnisotropicFilterExtension.MAX_TEXTURE_MAX_ANISOTROPY_EXT) : 0, this._caps.textureFloatLinearFiltering = !!(this._caps.textureFloat && this._gl.getExtension("OES_texture_float_linear")), this._caps.textureFloatRender = !!(this._caps.textureFloat && this._canRenderToFloatFramebuffer()), this._caps.textureHalfFloatLinearFiltering = !!(this._webGLVersion > 1 || this._caps.textureHalfFloat && this._gl.getExtension("OES_texture_half_float_linear")), this._caps.textureNorm16 && (this._gl.R16_EXT = 33322, this._gl.RG16_EXT = 33324, this._gl.RGB16_EXT = 32852, this._gl.RGBA16_EXT = 32859, this._gl.R16_SNORM_EXT = 36760, this._gl.RG16_SNORM_EXT = 36761, this._gl.RGB16_SNORM_EXT = 36762, this._gl.RGBA16_SNORM_EXT = 36763);
		let t = this._gl.getExtension("OES_draw_buffers_indexed");
		if (this._caps.blendParametersPerTarget = !!t, this._alphaState = new f(this._caps.blendParametersPerTarget), t && (this._gl.blendEquationSeparateIndexed = t.blendEquationSeparateiOES.bind(t), this._gl.blendEquationIndexed = t.blendEquationiOES.bind(t), this._gl.blendFuncSeparateIndexed = t.blendFuncSeparateiOES.bind(t), this._gl.blendFuncIndexed = t.blendFunciOES.bind(t), this._gl.colorMaskIndexed = t.colorMaskiOES.bind(t), this._gl.disableIndexed = t.disableiOES.bind(t), this._gl.enableIndexed = t.enableiOES.bind(t)), this._caps.dualSourceBlending = !!this._gl.getExtension("WEBGL_blend_func_extended"), this._caps.astc && (this._gl.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR = this._caps.astc.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR, this._gl.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR = this._caps.astc.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR, this._gl.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR = this._caps.astc.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR, this._gl.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR = this._caps.astc.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR, this._gl.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR = this._caps.astc.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR, this._gl.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR = this._caps.astc.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR, this._gl.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR = this._caps.astc.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR, this._gl.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR = this._caps.astc.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR, this._gl.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR = this._caps.astc.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR, this._gl.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR = this._caps.astc.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR, this._gl.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR = this._caps.astc.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR, this._gl.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR = this._caps.astc.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR, this._gl.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR = this._caps.astc.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR, this._gl.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR = this._caps.astc.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR), this._caps.bptc && (this._gl.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT = this._caps.bptc.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT), this._caps.s3tc_srgb && (this._gl.COMPRESSED_SRGB_S3TC_DXT1_EXT = this._caps.s3tc_srgb.COMPRESSED_SRGB_S3TC_DXT1_EXT, this._gl.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT = this._caps.s3tc_srgb.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT, this._gl.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT = this._caps.s3tc_srgb.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT), this._caps.etc2 && (this._gl.COMPRESSED_SRGB8_ETC2 = this._caps.etc2.COMPRESSED_SRGB8_ETC2, this._gl.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC = this._caps.etc2.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC), this._webGLVersion > 1 && this._gl.HALF_FLOAT_OES !== 5131 && (this._gl.HALF_FLOAT_OES = 5131), this._caps.textureHalfFloatRender = this._caps.textureHalfFloat && this._canRenderToHalfFloatFramebuffer(), this._webGLVersion > 1) this._caps.drawBuffersExtension = !0, this._caps.maxMSAASamples = this._maxMSAASamplesOverride === null ? this._gl.getParameter(this._gl.MAX_SAMPLES) : this._maxMSAASamplesOverride, this._caps.maxDrawBuffers = this._gl.getParameter(this._gl.MAX_DRAW_BUFFERS);
		else {
			let e = this._gl.getExtension("WEBGL_draw_buffers");
			if (e !== null) {
				this._caps.drawBuffersExtension = !0, this._gl.drawBuffers = e.drawBuffersWEBGL.bind(e), this._caps.maxDrawBuffers = this._gl.getParameter(e.MAX_DRAW_BUFFERS_WEBGL), this._gl.DRAW_FRAMEBUFFER = this._gl.FRAMEBUFFER;
				for (let t = 0; t < 16; t++) this._gl["COLOR_ATTACHMENT" + t + "_WEBGL"] = e["COLOR_ATTACHMENT" + t + "_WEBGL"];
			}
		}
		if (this._webGLVersion > 1) this._caps.depthTextureExtension = !0;
		else {
			let e = this._gl.getExtension("WEBGL_depth_texture");
			e != null && (this._caps.depthTextureExtension = !0, this._gl.UNSIGNED_INT_24_8 = e.UNSIGNED_INT_24_8_WEBGL);
		}
		if (this.disableVertexArrayObjects) this._caps.vertexArrayObject = !1;
		else if (this._webGLVersion > 1) this._caps.vertexArrayObject = !0;
		else {
			let e = this._gl.getExtension("OES_vertex_array_object");
			e != null && (this._caps.vertexArrayObject = !0, this._gl.createVertexArray = e.createVertexArrayOES.bind(e), this._gl.bindVertexArray = e.bindVertexArrayOES.bind(e), this._gl.deleteVertexArray = e.deleteVertexArrayOES.bind(e));
		}
		if (this._webGLVersion > 1) this._caps.instancedArrays = !0;
		else {
			let e = this._gl.getExtension("ANGLE_instanced_arrays");
			e == null ? this._caps.instancedArrays = !1 : (this._caps.instancedArrays = !0, this._gl.drawArraysInstanced = e.drawArraysInstancedANGLE.bind(e), this._gl.drawElementsInstanced = e.drawElementsInstancedANGLE.bind(e), this._gl.vertexAttribDivisor = e.vertexAttribDivisorANGLE.bind(e));
		}
		if (this._gl.getShaderPrecisionFormat) {
			let e = this._gl.getShaderPrecisionFormat(this._gl.VERTEX_SHADER, this._gl.HIGH_FLOAT), t = this._gl.getShaderPrecisionFormat(this._gl.FRAGMENT_SHADER, this._gl.HIGH_FLOAT);
			if (e && t && (this._caps.highPrecisionShaderSupported = e.precision !== 0 && t.precision !== 0, this._caps.shaderFloatPrecision = Math.min(e.precision, t.precision)), !this._shouldUseHighPrecisionShader) {
				let e = this._gl.getShaderPrecisionFormat(this._gl.VERTEX_SHADER, this._gl.MEDIUM_FLOAT), t = this._gl.getShaderPrecisionFormat(this._gl.FRAGMENT_SHADER, this._gl.MEDIUM_FLOAT);
				e && t && (this._caps.shaderFloatPrecision = Math.min(e.precision, t.precision));
			}
			this._caps.shaderFloatPrecision < 10 && (this._caps.shaderFloatPrecision = 10);
		}
		if (this._webGLVersion > 1) this._caps.blendMinMax = !0;
		else {
			let e = this._gl.getExtension("EXT_blend_minmax");
			e != null && (this._caps.blendMinMax = !0, this._gl.MAX = e.MAX_EXT, this._gl.MIN = e.MIN_EXT);
		}
		if (!this._caps.supportSRGBBuffers) {
			if (this._webGLVersion > 1) this._caps.supportSRGBBuffers = !0, this._glSRGBExtensionValues = {
				SRGB: WebGL2RenderingContext.SRGB,
				SRGB8: WebGL2RenderingContext.SRGB8,
				SRGB8_ALPHA8: WebGL2RenderingContext.SRGB8_ALPHA8
			};
			else {
				let e = this._gl.getExtension("EXT_sRGB");
				e != null && (this._caps.supportSRGBBuffers = !0, this._glSRGBExtensionValues = {
					SRGB: e.SRGB_EXT,
					SRGB8: e.SRGB_ALPHA_EXT,
					SRGB8_ALPHA8: e.SRGB_ALPHA_EXT
				});
			}
			if (this._creationOptions) {
				let e = this._creationOptions.forceSRGBBufferSupportState;
				e !== void 0 && (this._caps.supportSRGBBuffers = this._caps.supportSRGBBuffers && e);
			}
		}
		this._depthCullingState.depthTest = !0, this._depthCullingState.depthFunc = this.useReverseDepthBuffer ? this._gl.GEQUAL : this._gl.LEQUAL, this._depthCullingState.depthMask = !0, this._maxSimultaneousTextures = this._caps.maxCombinedTexturesImageUnits;
		for (let e = 0; e < this._maxSimultaneousTextures; e++) this._nextFreeTextureSlots.push(e);
		this._glRenderer === "Mali-G72" && (this._caps.disableMorphTargetTexture = !0);
	}
	_initFeatures() {
		this._features = {
			forceBitmapOverHTMLImageElement: typeof HTMLImageElement > "u",
			supportRenderAndCopyToLodForFloatTextures: this._webGLVersion !== 1,
			supportDepthStencilTexture: this._webGLVersion !== 1,
			supportShadowSamplers: this._webGLVersion !== 1,
			uniformBufferHardCheckMatrix: !1,
			allowTexturePrefiltering: this._webGLVersion !== 1,
			trackUbosInFrame: !1,
			checkUbosContentBeforeUpload: !1,
			supportCSM: this._webGLVersion !== 1,
			basisNeedsPOT: this._webGLVersion === 1,
			support3DTextures: this._webGLVersion !== 1,
			needTypeSuffixInShaderConstants: this._webGLVersion !== 1,
			supportMSAA: this._webGLVersion !== 1,
			supportSSAO2: this._webGLVersion !== 1,
			supportIBLShadows: this._webGLVersion !== 1,
			supportExtendedTextureFormats: this._webGLVersion !== 1,
			supportSwitchCaseInShader: this._webGLVersion !== 1,
			supportSyncTextureRead: !0,
			needsInvertingBitmap: !0,
			useUBOBindingCache: !0,
			needShaderCodeInlining: !1,
			needToAlwaysBindUniformBuffers: !1,
			supportRenderPasses: !1,
			supportSpriteInstancing: !0,
			forceVertexBufferStrideAndOffsetMultiple4Bytes: !1,
			_checkNonFloatVertexBuffersDontRecreatePipelineContext: !1
		};
	}
	get webGLVersion() {
		return this._webGLVersion;
	}
	getClassName() {
		return "ThinEngine";
	}
	_prepareWorkingCanvas() {
		if (this._workingCanvas) return;
		this._workingCanvas = this.createCanvas(1, 1);
		let e = this._workingCanvas.getContext("2d");
		e && (this._workingContext = e);
	}
	getInfo() {
		return this.getGlInfo();
	}
	getGlInfo() {
		return {
			vendor: this._glVendor,
			renderer: this._glRenderer,
			version: this._glVersion
		};
	}
	extractDriverInfo() {
		let e = this.getGlInfo();
		return e && e.renderer ? e.renderer : "";
	}
	getRenderWidth(e = !1) {
		return !e && this._currentRenderTarget ? this._currentRenderTarget.width : this._framebufferDimensionsObject ? this._framebufferDimensionsObject.framebufferWidth : this._gl.drawingBufferWidth;
	}
	getRenderHeight(e = !1) {
		return !e && this._currentRenderTarget ? this._currentRenderTarget.height : this._framebufferDimensionsObject ? this._framebufferDimensionsObject.framebufferHeight : this._gl.drawingBufferHeight;
	}
	clear(t, n, r, i = !1, a = 0) {
		let o = this.stencilStateComposer.useStencilGlobalOnly;
		this.stencilStateComposer.useStencilGlobalOnly = !0, this.applyStates(), this.stencilStateComposer.useStencilGlobalOnly = o;
		let s = 0;
		if (n && t) {
			let n = !0;
			if (this._currentRenderTarget) {
				let r = this._currentRenderTarget.texture?.format;
				if (r !== void 0 && A(r)) {
					let r = this._currentRenderTarget.texture?.type;
					r !== void 0 && j(r) ? (e._TempClearColorUint32[0] = t.r * 255, e._TempClearColorUint32[1] = t.g * 255, e._TempClearColorUint32[2] = t.b * 255, e._TempClearColorUint32[3] = t.a * 255, this._gl.clearBufferuiv(this._gl.COLOR, 0, e._TempClearColorUint32), n = !1) : (e._TempClearColorInt32[0] = t.r * 255, e._TempClearColorInt32[1] = t.g * 255, e._TempClearColorInt32[2] = t.b * 255, e._TempClearColorInt32[3] = t.a * 255, this._gl.clearBufferiv(this._gl.COLOR, 0, e._TempClearColorInt32), n = !1);
				}
			}
			n && (this._gl.clearColor(t.r, t.g, t.b, t.a === void 0 ? 1 : t.a), s |= this._gl.COLOR_BUFFER_BIT);
		}
		r && (this.useReverseDepthBuffer ? (this._depthCullingState.depthFunc = this._gl.GEQUAL, this._gl.clearDepth(0)) : this._gl.clearDepth(1), s |= this._gl.DEPTH_BUFFER_BIT), i && (this._gl.clearStencil(a), s |= this._gl.STENCIL_BUFFER_BIT), this._gl.clear(s);
	}
	_clearColorAttachment(t, n, r, i) {
		if (A(r)) {
			let r = j(i), a = r ? e._TempClearColorUint32 : e._TempClearColorInt32;
			a[0] = n.r, a[1] = n.g, a[2] = n.b, a[3] = n.a, r ? this._gl.clearBufferuiv(this._gl.COLOR, t, a) : this._gl.clearBufferiv(this._gl.COLOR, t, a);
		} else e._TempClearColorFloat32[0] = n.r, e._TempClearColorFloat32[1] = n.g, e._TempClearColorFloat32[2] = n.b, e._TempClearColorFloat32[3] = n.a, this._gl.clearBufferfv(this._gl.COLOR, t, e._TempClearColorFloat32);
	}
	_viewport(e, t, n, r) {
		(e !== this._viewportCached.x || t !== this._viewportCached.y || n !== this._viewportCached.z || r !== this._viewportCached.w) && (this._viewportCached.x = e, this._viewportCached.y = t, this._viewportCached.z = n, this._viewportCached.w = r, this._gl.viewport(e, t, n, r));
	}
	endFrame() {
		super.endFrame(), this._badOS && this.flushFramebuffer();
	}
	get performanceMonitor() {
		throw Error("Not Supported by ThinEngine");
	}
	bindFramebuffer(e, t = 0, r, i, a, o = 0, s = 0) {
		let c = e;
		this._currentRenderTarget && this._resolveAndGenerateMipMapsFramebuffer(this._currentRenderTarget), this._currentRenderTarget = e, this._integerMRTAttachmentsMask = !e.isMulti && e.texture && A(e.texture.format) ? 1 : 0, this._bindUnboundFramebuffer(c._framebuffer);
		let l = this._gl;
		e.isMulti || (e.is2DArray || e.is3D ? (l.framebufferTextureLayer(l.FRAMEBUFFER, l.COLOR_ATTACHMENT0, e.texture._hardwareTexture?.underlyingResource, o, s), c._currentLOD = o) : e.isCube ? l.framebufferTexture2D(l.FRAMEBUFFER, l.COLOR_ATTACHMENT0, l.TEXTURE_CUBE_MAP_POSITIVE_X + t, e.texture._hardwareTexture?.underlyingResource, o) : c._currentLOD !== o && (l.framebufferTexture2D(l.FRAMEBUFFER, l.COLOR_ATTACHMENT0, l.TEXTURE_2D, e.texture._hardwareTexture?.underlyingResource, o), c._currentLOD = o));
		let u = e._depthStencilTexture;
		if (u) {
			e.is3D && (e.texture.width !== u.width || e.texture.height !== u.height || e.texture.depth !== u.depth) && n.Warn("Depth/Stencil attachment for 3D target must have same dimensions as color attachment");
			let r = e._depthStencilTextureWithStencil ? l.DEPTH_STENCIL_ATTACHMENT : l.DEPTH_ATTACHMENT;
			e.is2DArray || e.is3D ? l.framebufferTextureLayer(l.FRAMEBUFFER, r, u._hardwareTexture?.underlyingResource, o, s) : e.isCube ? l.framebufferTexture2D(l.FRAMEBUFFER, r, l.TEXTURE_CUBE_MAP_POSITIVE_X + t, u._hardwareTexture?.underlyingResource, o) : l.framebufferTexture2D(l.FRAMEBUFFER, r, l.TEXTURE_2D, u._hardwareTexture?.underlyingResource, o);
		}
		c._MSAAFramebuffer && this._bindUnboundFramebuffer(c._MSAAFramebuffer), this._cachedViewport && !a ? this.setViewport(this._cachedViewport, r, i) : (r || (r = e.width, o && (r /= 2 ** o)), i || (i = e.height, o && (i /= 2 ** o)), this._viewport(0, 0, r, i)), this.wipeCaches();
	}
	setStateCullFaceType(e, t) {
		let n = this.cullBackFaces ?? e ?? !0 ? this._gl.BACK : this._gl.FRONT;
		(this._depthCullingState.cullFace !== n || t) && (this._depthCullingState.cullFace = n);
	}
	setState(e, t = 0, n, r = !1, i, a, o = 0) {
		(this._depthCullingState.cull !== e || n) && (this._depthCullingState.cull = e), this.setStateCullFaceType(i, n), this.setZOffset(t), this.setZOffsetUnits(o);
		let s = r ? this._gl.CW : this._gl.CCW;
		(this._depthCullingState.frontFace !== s || n) && (this._depthCullingState.frontFace = s), this._stencilStateComposer.stencilMaterial = a;
	}
	_resolveAndGenerateMipMapsFramebuffer(e, t = !1) {
		e.disableAutomaticMSAAResolve || (e.isMulti ? this.resolveMultiFramebuffer(e) : this.resolveFramebuffer(e)), t || (e.isMulti ? this.generateMipMapsMultiFramebuffer(e) : this.generateMipMapsFramebuffer(e));
	}
	_bindUnboundFramebuffer(e) {
		this._currentFramebuffer !== e && (this._gl.bindFramebuffer(this._gl.FRAMEBUFFER, e), this._currentFramebuffer = e);
	}
	_currentFrameBufferIsDefaultFrameBuffer() {
		return this._currentFramebuffer === null;
	}
	generateMipmaps(e) {
		let t = this._getTextureTarget(e);
		this._bindTextureDirectly(t, e, !0), this._gl.generateMipmap(t), this._bindTextureDirectly(t, null);
	}
	unBindFramebuffer(e, t, n) {
		let r = e;
		this._currentRenderTarget = null, this._integerMRTAttachmentsMask = 0, this._resolveAndGenerateMipMapsFramebuffer(e, t), n && (r._MSAAFramebuffer && this._bindUnboundFramebuffer(r._framebuffer), n()), this._bindUnboundFramebuffer(null);
	}
	generateMipMapsFramebuffer(e) {
		!e.isMulti && e.texture?.generateMipMaps && !e.isCube && this.generateMipmaps(e.texture);
	}
	resolveFramebuffer(e) {
		let t = e, n = this._gl;
		if (!t._MSAAFramebuffer || t.isMulti) return;
		let r = t.resolveMSAAColors ? n.COLOR_BUFFER_BIT : 0;
		r |= t._generateDepthBuffer && t.resolveMSAADepth ? n.DEPTH_BUFFER_BIT : 0, r |= t._generateStencilBuffer && t.resolveMSAAStencil ? n.STENCIL_BUFFER_BIT : 0, n.bindFramebuffer(n.READ_FRAMEBUFFER, t._MSAAFramebuffer), n.bindFramebuffer(n.DRAW_FRAMEBUFFER, t._framebuffer), n.blitFramebuffer(0, 0, e.width, e.height, 0, 0, e.width, e.height, r, n.NEAREST);
	}
	flushFramebuffer() {
		this._gl.flush();
	}
	restoreDefaultFramebuffer() {
		this._currentRenderTarget ? this.unBindFramebuffer(this._currentRenderTarget) : this._bindUnboundFramebuffer(null), this._cachedViewport && this.setViewport(this._cachedViewport), this.wipeCaches();
	}
	_resetVertexBufferBinding() {
		this.bindArrayBuffer(null), this._cachedVertexBuffers = null;
	}
	createVertexBuffer(e, t, n) {
		return this._createVertexBuffer(e, this._gl.STATIC_DRAW);
	}
	_createVertexBuffer(e, t) {
		let n = this._gl.createBuffer();
		if (!n) throw Error("Unable to create vertex buffer");
		let r = new D(n);
		return this.bindArrayBuffer(r), typeof e == "number" ? (this._gl.bufferData(this._gl.ARRAY_BUFFER, new Uint8Array(e), t), r.capacity = e) : e instanceof Array ? (this._gl.bufferData(this._gl.ARRAY_BUFFER, new Float32Array(e), t), r.capacity = e.length * 4) : (this._gl.bufferData(this._gl.ARRAY_BUFFER, e, t), r.capacity = e.byteLength), this._resetVertexBufferBinding(), r.references = 1, r;
	}
	createDynamicVertexBuffer(e, t) {
		return this._createVertexBuffer(e, this._gl.DYNAMIC_DRAW);
	}
	_resetIndexBufferBinding() {
		this.bindIndexBuffer(null), this._cachedIndexBuffer = null;
	}
	createIndexBuffer(e, t, n) {
		let r = this._gl.createBuffer(), i = new D(r);
		if (!r) throw Error("Unable to create index buffer");
		this.bindIndexBuffer(i);
		let a = this._normalizeIndexData(e);
		return this._gl.bufferData(this._gl.ELEMENT_ARRAY_BUFFER, a, t ? this._gl.DYNAMIC_DRAW : this._gl.STATIC_DRAW), this._resetIndexBufferBinding(), i.references = 1, i.is32Bits = a.BYTES_PER_ELEMENT === 4, i;
	}
	_normalizeIndexData(e) {
		if (e.BYTES_PER_ELEMENT === 2) return e;
		if (this._caps.uintIndices) {
			if (e instanceof Uint32Array) return e;
			for (let t = 0; t < e.length; t++) if (e[t] >= 65535) return new Uint32Array(e);
			return new Uint16Array(e);
		}
		return new Uint16Array(e);
	}
	bindArrayBuffer(e) {
		this._vaoRecordInProgress || this._unbindVertexArrayObject(), this._bindBuffer(e, this._gl.ARRAY_BUFFER);
	}
	bindUniformBlock(e, t, n) {
		let r = e.program, i = this._gl.getUniformBlockIndex(r, t);
		this._gl.uniformBlockBinding(r, i, n);
	}
	bindIndexBuffer(e) {
		this._vaoRecordInProgress || this._unbindVertexArrayObject(), this._bindBuffer(e, this._gl.ELEMENT_ARRAY_BUFFER);
	}
	_bindBuffer(e, t) {
		(this._vaoRecordInProgress || this._currentBoundBuffer[t] !== e) && (this._gl.bindBuffer(t, e ? e.underlyingResource : null), this._currentBoundBuffer[t] = e);
	}
	updateArrayBuffer(e) {
		this._gl.bufferSubData(this._gl.ARRAY_BUFFER, 0, e);
	}
	_vertexAttribPointer(e, t, n, r, i, a, o) {
		let s = this._currentBufferPointers[t];
		if (!s) return;
		let c = !1;
		s.active ? (s.buffer !== e && (s.buffer = e, c = !0), s.size !== n && (s.size = n, c = !0), s.type !== r && (s.type = r, c = !0), s.normalized !== i && (s.normalized = i, c = !0), s.stride !== a && (s.stride = a, c = !0), s.offset !== o && (s.offset = o, c = !0)) : (c = !0, s.active = !0, s.index = t, s.size = n, s.type = r, s.normalized = i, s.stride = a, s.offset = o, s.buffer = e), (c || this._vaoRecordInProgress) && (this.bindArrayBuffer(e), r === this._gl.UNSIGNED_INT || r === this._gl.INT ? this._gl.vertexAttribIPointer(t, n, r, a, o) : this._gl.vertexAttribPointer(t, n, r, i, a, o));
	}
	_bindIndexBufferWithCache(e) {
		e != null && this._cachedIndexBuffer !== e && (this._cachedIndexBuffer = e, this.bindIndexBuffer(e), this._uintIndicesCurrentlySet = e.is32Bits);
	}
	_bindVertexBuffersAttributes(e, t, n) {
		let r = t.getAttributesNames();
		this._vaoRecordInProgress || this._unbindVertexArrayObject(), this.unbindAllAttributes();
		for (let i = 0; i < r.length; i++) {
			let a = t.getAttributeLocation(i);
			if (a >= 0) {
				let t = r[i], o = null;
				if (n && (o = n[t]), o ||= e[t], !o) continue;
				this._gl.enableVertexAttribArray(a), this._vaoRecordInProgress || (this._vertexAttribArraysEnabled[a] = !0);
				let s = o.getBuffer();
				s && (this._vertexAttribPointer(s, a, o.getSize(), o.type, o.normalized, o.byteStride, o.byteOffset), o.getIsInstanced() && (this._gl.vertexAttribDivisor(a, o.getInstanceDivisor()), this._vaoRecordInProgress || (this._currentInstanceLocations.push(a), this._currentInstanceBuffers.push(s), this._cachedVertexBuffersSetInstanceDivisors = !0)));
			}
		}
	}
	recordVertexArrayObject(e, t, n, r) {
		let i = this._gl.createVertexArray();
		if (!i) throw Error("Unable to create VAO");
		return this._vaoRecordInProgress = !0, this._gl.bindVertexArray(i), this._mustWipeVertexAttributes = !0, this._bindVertexBuffersAttributes(e, n, r), this.bindIndexBuffer(t), this._vaoRecordInProgress = !1, this._gl.bindVertexArray(null), i;
	}
	bindVertexArrayObject(e, t) {
		this._cachedVertexArrayObject !== e && (this._cachedVertexArrayObject = e, this._gl.bindVertexArray(e), this._cachedVertexBuffers = null, this._cachedIndexBuffer = null, this._uintIndicesCurrentlySet = t != null && t.is32Bits, this._mustWipeVertexAttributes = !0);
	}
	bindBuffersDirectly(e, t, n, r, i) {
		if (this._cachedVertexBuffers !== e || this._cachedEffectForVertexBuffers !== i) {
			this._cachedVertexBuffers = e, this._cachedEffectForVertexBuffers = i;
			let t = i.getAttributesCount();
			this._unbindVertexArrayObject(), this.unbindAllAttributes();
			let a = 0;
			for (let o = 0; o < t; o++) if (o < n.length) {
				let t = i.getAttributeLocation(o);
				t >= 0 && (this._gl.enableVertexAttribArray(t), this._vertexAttribArraysEnabled[t] = !0, this._vertexAttribPointer(e, t, n[o], this._gl.FLOAT, !1, r, a)), a += n[o] * 4;
			}
		}
		this._bindIndexBufferWithCache(t);
	}
	_unbindVertexArrayObject() {
		this._cachedVertexArrayObject && (this._cachedVertexArrayObject = null, this._gl.bindVertexArray(null));
	}
	bindBuffers(e, t, n, r) {
		(this._cachedVertexBuffers !== e || this._cachedEffectForVertexBuffers !== n) && (this._cachedVertexBuffers = e, this._cachedEffectForVertexBuffers = n, this._bindVertexBuffersAttributes(e, n, r)), this._bindIndexBufferWithCache(t);
	}
	unbindInstanceAttributes() {
		let e;
		for (let t = 0, n = this._currentInstanceLocations.length; t < n; t++) {
			let n = this._currentInstanceBuffers[t];
			e != n && n.references && (e = n, this.bindArrayBuffer(n));
			let r = this._currentInstanceLocations[t];
			this._gl.vertexAttribDivisor(r, 0);
		}
		this._currentInstanceBuffers.length = 0, this._currentInstanceLocations.length = 0, this._cachedVertexBuffersSetInstanceDivisors && (this._cachedVertexBuffersSetInstanceDivisors = !1, this._cachedVertexBuffers = null);
	}
	releaseVertexArrayObject(e) {
		this._gl.deleteVertexArray(e);
	}
	_releaseBuffer(e) {
		return e.references--, e.references === 0 && (this._deleteBuffer(e), !0);
	}
	_deleteBuffer(e) {
		this._gl.deleteBuffer(e.underlyingResource);
	}
	updateAndBindInstancesBuffer(e, t, n) {
		if (this.bindArrayBuffer(e), t && this._gl.bufferSubData(this._gl.ARRAY_BUFFER, 0, t), n[0].index !== void 0) this.bindInstancesBuffer(e, n, !0);
		else for (let t = 0; t < 4; t++) {
			let r = n[t];
			this._vertexAttribArraysEnabled[r] || (this._gl.enableVertexAttribArray(r), this._vertexAttribArraysEnabled[r] = !0), this._vertexAttribPointer(e, r, 4, this._gl.FLOAT, !1, 64, t * 16), this._gl.vertexAttribDivisor(r, 1), this._currentInstanceLocations.push(r), this._currentInstanceBuffers.push(e);
		}
	}
	bindInstancesBuffer(e, t, n = !0) {
		this.bindArrayBuffer(e);
		let r = 0;
		if (n) for (let e = 0; e < t.length; e++) {
			let n = t[e];
			r += n.attributeSize * 4;
		}
		for (let n = 0; n < t.length; n++) {
			let i = t[n];
			i.index === void 0 && (i.index = this._currentEffect.getAttributeLocationByName(i.attributeName)), !(i.index < 0) && (this._vertexAttribArraysEnabled[i.index] || (this._gl.enableVertexAttribArray(i.index), this._vertexAttribArraysEnabled[i.index] = !0), this._vertexAttribPointer(e, i.index, i.attributeSize, i.attributeType || this._gl.FLOAT, i.normalized || !1, r, i.offset), this._gl.vertexAttribDivisor(i.index, i.divisor === void 0 ? 1 : i.divisor), this._currentInstanceLocations.push(i.index), this._currentInstanceBuffers.push(e));
		}
	}
	disableInstanceAttributeByName(e) {
		if (!this._currentEffect) return;
		let t = this._currentEffect.getAttributeLocationByName(e);
		this.disableInstanceAttribute(t);
	}
	disableInstanceAttribute(e) {
		let t = !1, n;
		for (; (n = this._currentInstanceLocations.indexOf(e)) !== -1;) this._currentInstanceLocations.splice(n, 1), this._currentInstanceBuffers.splice(n, 1), t = !0;
		t && (this._gl.vertexAttribDivisor(e, 0), this.disableAttributeByIndex(e));
	}
	disableAttributeByIndex(e) {
		this._gl.disableVertexAttribArray(e), this._vertexAttribArraysEnabled[e] = !1, this._currentBufferPointers[e].active = !1;
	}
	draw(e, t, n, r) {
		this.drawElementsType(+!e, t, n, r);
	}
	drawPointClouds(e, t, n) {
		this.drawArraysType(2, e, t, n);
	}
	drawUnIndexed(e, t, n, r) {
		this.drawArraysType(+!e, t, n, r);
	}
	drawElementsType(e, t, n, r) {
		this.applyStates(), this._reportDrawCall();
		let i = this._drawMode(e), a = this._uintIndicesCurrentlySet ? this._gl.UNSIGNED_INT : this._gl.UNSIGNED_SHORT, o = this._uintIndicesCurrentlySet ? 4 : 2;
		r ? this._gl.drawElementsInstanced(i, n, a, t * o, r) : this._gl.drawElements(i, n, a, t * o);
	}
	drawArraysType(e, t, n, r) {
		this.applyStates(), this._reportDrawCall();
		let i = this._drawMode(e);
		r ? this._gl.drawArraysInstanced(i, t, n, r) : this._gl.drawArrays(i, t, n);
	}
	_drawMode(e) {
		switch (e) {
			case 0: return this._gl.TRIANGLES;
			case 2: return this._gl.POINTS;
			case 1: return this._gl.LINES;
			case 3: return this._gl.POINTS;
			case 4: return this._gl.LINES;
			case 5: return this._gl.LINE_LOOP;
			case 6: return this._gl.LINE_STRIP;
			case 7: return this._gl.TRIANGLE_STRIP;
			case 8: return this._gl.TRIANGLE_FAN;
			default: return this._gl.TRIANGLES;
		}
	}
	_releaseEffect(e) {
		this._compiledEffects[e._key] && delete this._compiledEffects[e._key];
		let t = e.getPipelineContext();
		t && this._deletePipelineContext(t);
	}
	_deletePipelineContext(e) {
		let t = e;
		t && t.program && (t.program.__SPECTOR_rebuildProgram = null, l(t), this._gl && (this._currentProgram === t.program && this._setProgram(null), this._gl.deleteProgram(t.program)));
	}
	_getGlobalDefines(e) {
		return y(e, this.isNDCHalfZRange, this.useReverseDepthBuffer, this.useExactSrgbConversions);
	}
	createEffect(e, t, n, r, i, a, o, s, l, u = 0, d) {
		let f = typeof e == "string" ? e : e.vertexToken || e.vertexSource || e.vertexElement || e.vertex, p = typeof e == "string" ? e : e.fragmentToken || e.fragmentSource || e.fragmentElement || e.fragment, m = this._getGlobalDefines(), g = t.attributes !== void 0, _ = i ?? t.defines ?? "";
		m && (_ += m);
		let v = f + "+" + p + "@" + _;
		if (this._compiledEffects[v]) {
			let e = this._compiledEffects[v];
			return o && e.isReady() && o(e), e._refCount++, e;
		}
		this._gl && c(this._gl);
		let y = new h(e, t, g ? this : n, r, this, i, a, o, s, l, v, t.shaderLanguage ?? u, t.extraInitializationsAsync ?? d);
		return this._compiledEffects[v] = y, y;
	}
	_getShaderSource(e) {
		return this._gl.getShaderSource(e);
	}
	createRawShaderProgram(e, t, n, r, i = null) {
		let a = c(this._gl);
		return a._contextWasLost = this._contextWasLost, a.validateShaderPrograms = this.validateShaderPrograms, s(e, t, n, r || this._gl, i);
	}
	createShaderProgram(e, t, n, r, i, a = null) {
		this.onBeforeShaderCompilationObservable.notifyObservers(this);
		let o = c(this._gl);
		o._contextWasLost = this._contextWasLost, o.validateShaderPrograms = this.validateShaderPrograms;
		let s = m(e, t, n, r, i || this._gl, a);
		return this.onAfterShaderCompilationObservable.notifyObservers(this), s;
	}
	inlineShaderCode(e) {
		return e;
	}
	createPipelineContext(e) {
		if (this._gl) {
			let e = c(this._gl);
			e.parallelShaderCompile = this._caps.parallelShaderCompile;
		}
		let t = o(this._gl, e);
		return t.engine = this, t;
	}
	createMaterialContext() {}
	createDrawContext() {}
	_finalizePipelineContext(e) {
		return g(e, this._gl, this.validateShaderPrograms);
	}
	_preparePipelineContextAsync(e, t, n, r, i, a, o, s, l, d, f) {
		let p = c(this._gl);
		return p._contextWasLost = this._contextWasLost, p.validateShaderPrograms = this.validateShaderPrograms, p._createShaderProgramInjection = this._createShaderProgram.bind(this), p.createRawShaderProgramInjection = this.createRawShaderProgram.bind(this), p.createShaderProgramInjection = this.createShaderProgram.bind(this), p.loadFileInjection = this._loadFile.bind(this), u(e, t, n, r, i, a, o, s, l, d, f);
	}
	_createShaderProgram(e, t, n, r, a = null) {
		return i(e, t, n, r, a);
	}
	_isRenderingStateCompiled(e) {
		return !this._isDisposed && a(e, this._gl, this.validateShaderPrograms);
	}
	_executeWhenRenderingStateIsCompiled(e, t) {
		p(e, t);
	}
	getUniforms(e, t) {
		let n = [], r = e;
		for (let e = 0; e < t.length; e++) n.push(this._gl.getUniformLocation(r.program, t[e]));
		return n;
	}
	getAttributes(e, t) {
		let n = [], r = e;
		for (let e = 0; e < t.length; e++) try {
			n.push(this._gl.getAttribLocation(r.program, t[e]));
		} catch {
			n.push(-1);
		}
		return n;
	}
	enableEffect(e) {
		e = e !== null && S(e) ? e.effect : e, e && e !== this._currentEffect && (this._stencilStateComposer.stencilMaterial = void 0, this.bindSamplers(e), this._currentEffect = e, e.onBind && e.onBind(e), e._onBindObservable && e._onBindObservable.notifyObservers(e));
	}
	setInt(e, t) {
		return e ? (this._gl.uniform1i(e, t), !0) : !1;
	}
	setInt2(e, t, n) {
		return e ? (this._gl.uniform2i(e, t, n), !0) : !1;
	}
	setInt3(e, t, n, r) {
		return e ? (this._gl.uniform3i(e, t, n, r), !0) : !1;
	}
	setInt4(e, t, n, r, i) {
		return e ? (this._gl.uniform4i(e, t, n, r, i), !0) : !1;
	}
	setIntArray(e, t) {
		return e ? (this._gl.uniform1iv(e, t), !0) : !1;
	}
	setIntArray2(e, t) {
		return !e || t.length % 2 != 0 ? !1 : (this._gl.uniform2iv(e, t), !0);
	}
	setIntArray3(e, t) {
		return !e || t.length % 3 != 0 ? !1 : (this._gl.uniform3iv(e, t), !0);
	}
	setIntArray4(e, t) {
		return !e || t.length % 4 != 0 ? !1 : (this._gl.uniform4iv(e, t), !0);
	}
	setUInt(e, t) {
		return e ? (this._gl.uniform1ui(e, t), !0) : !1;
	}
	setUInt2(e, t, n) {
		return e ? (this._gl.uniform2ui(e, t, n), !0) : !1;
	}
	setUInt3(e, t, n, r) {
		return e ? (this._gl.uniform3ui(e, t, n, r), !0) : !1;
	}
	setUInt4(e, t, n, r, i) {
		return e ? (this._gl.uniform4ui(e, t, n, r, i), !0) : !1;
	}
	setUIntArray(e, t) {
		return e ? (this._gl.uniform1uiv(e, t), !0) : !1;
	}
	setUIntArray2(e, t) {
		return !e || t.length % 2 != 0 ? !1 : (this._gl.uniform2uiv(e, t), !0);
	}
	setUIntArray3(e, t) {
		return !e || t.length % 3 != 0 ? !1 : (this._gl.uniform3uiv(e, t), !0);
	}
	setUIntArray4(e, t) {
		return !e || t.length % 4 != 0 ? !1 : (this._gl.uniform4uiv(e, t), !0);
	}
	setArray(e, t) {
		return !e || t.length < 1 ? !1 : (this._gl.uniform1fv(e, t), !0);
	}
	setArray2(e, t) {
		return !e || t.length % 2 != 0 ? !1 : (this._gl.uniform2fv(e, t), !0);
	}
	setArray3(e, t) {
		return !e || t.length % 3 != 0 ? !1 : (this._gl.uniform3fv(e, t), !0);
	}
	setArray4(e, t) {
		return !e || t.length % 4 != 0 ? !1 : (this._gl.uniform4fv(e, t), !0);
	}
	setMatrices(e, t) {
		return e ? (this._gl.uniformMatrix4fv(e, !1, t), !0) : !1;
	}
	setMatrix3x3(e, t) {
		return e ? (this._gl.uniformMatrix3fv(e, !1, t), !0) : !1;
	}
	setMatrix2x2(e, t) {
		return e ? (this._gl.uniformMatrix2fv(e, !1, t), !0) : !1;
	}
	setFloat(e, t) {
		return e ? (this._gl.uniform1f(e, t), !0) : !1;
	}
	setFloat2(e, t, n) {
		return e ? (this._gl.uniform2f(e, t, n), !0) : !1;
	}
	setFloat3(e, t, n, r) {
		return e ? (this._gl.uniform3f(e, t, n, r), !0) : !1;
	}
	setFloat4(e, t, n, r, i) {
		return e ? (this._gl.uniform4f(e, t, n, r, i), !0) : !1;
	}
	_applyColorWriteState() {
		if (this._colorWriteChanged) {
			this._colorWriteChanged = !1;
			let e = this._colorWrite;
			this._gl.colorMask(e, e, e, e);
		}
	}
	applyStates() {
		this._depthCullingState.apply(this._gl), this._stencilStateComposer.apply(this._gl), this._alphaState.apply(this._gl, this._currentRenderTarget && this._currentRenderTarget.textures ? this._currentRenderTarget.textures.length : 1, this._integerMRTAttachmentsMask), this._applyColorWriteState();
	}
	wipeCaches(e) {
		(!this.preventCacheWipeBetweenFrames || e) && (this._currentEffect = null, this._viewportCached.x = 0, this._viewportCached.y = 0, this._viewportCached.z = 0, this._viewportCached.w = 0, this._unbindVertexArrayObject(), e && (this._currentProgram = null, this.resetTextureCache(), this._stencilStateComposer.reset(), this._depthCullingState.reset(), this._depthCullingState.depthFunc = this._gl.LEQUAL, this._alphaState.reset(), this._resetAlphaMode(), this._colorWrite = !0, this._colorWriteChanged = !0, this._unpackFlipYCached = null, this._gl.pixelStorei(this._gl.UNPACK_COLORSPACE_CONVERSION_WEBGL, this._gl.NONE), this._gl.pixelStorei(this._gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, 0), this._mustWipeVertexAttributes = !0, this.unbindAllAttributes()), this._resetVertexBufferBinding(), this._cachedIndexBuffer = null, this._cachedEffectForVertexBuffers = null, this.bindIndexBuffer(null));
	}
	_getSamplingParameters(e, t) {
		let n = this._gl, r = n.NEAREST, i = n.NEAREST, a = !1;
		switch (e) {
			case 11:
				r = n.LINEAR, i = t ? n.LINEAR_MIPMAP_NEAREST : n.LINEAR;
				break;
			case 3:
				r = n.LINEAR, a = !0, i = t ? n.LINEAR_MIPMAP_LINEAR : n.LINEAR;
				break;
			case 8:
				a = !0, r = n.NEAREST, i = t ? n.NEAREST_MIPMAP_LINEAR : n.NEAREST;
				break;
			case 4:
				r = n.NEAREST, i = t ? n.NEAREST_MIPMAP_NEAREST : n.NEAREST;
				break;
			case 5:
				r = n.NEAREST, i = t ? n.LINEAR_MIPMAP_NEAREST : n.LINEAR;
				break;
			case 6:
				a = !0, r = n.NEAREST, i = t ? n.LINEAR_MIPMAP_LINEAR : n.LINEAR;
				break;
			case 7:
				r = n.NEAREST, i = n.LINEAR;
				break;
			case 1:
				r = n.NEAREST, i = n.NEAREST;
				break;
			case 9:
				r = n.LINEAR, i = t ? n.NEAREST_MIPMAP_NEAREST : n.NEAREST;
				break;
			case 10:
				a = !0, r = n.LINEAR, i = t ? n.NEAREST_MIPMAP_LINEAR : n.NEAREST;
				break;
			case 2:
				r = n.LINEAR, i = n.LINEAR;
				break;
			case 12: r = n.LINEAR, i = n.NEAREST;
		}
		return {
			min: i,
			mag: r,
			hasMipMaps: a
		};
	}
	_createTexture() {
		let e = this._gl.createTexture();
		if (!e) throw Error("Unable to create texture");
		return e;
	}
	_createHardwareTexture() {
		return new O(this._createTexture(), this._gl);
	}
	_createInternalTexture(e, r, i = !0, a = 0) {
		let o, s = !1, c = 0, l = 3, u = 5, d = !1, f = 1, p, m = !1, h = 0, g = !1;
		r !== void 0 && typeof r == "object" ? (o = !!r.generateMipMaps, s = !!r.createMipMaps, c = r.type === void 0 ? 0 : r.type, l = r.samplingMode === void 0 ? 3 : r.samplingMode, u = r.format === void 0 ? 5 : r.format, d = r.useSRGBBuffer !== void 0 && r.useSRGBBuffer, f = r.samples ?? 1, p = r.label, m = !!r.createMSAATexture, h = r.comparisonFunction || 0, g = !!r.isCube) : o = !!r, d &&= this._caps.supportSRGBBuffers && (this.webGLVersion > 1 || this.isWebGPU), (c === 1 && !this._caps.textureFloatLinearFiltering || c === 2 && !this._caps.textureHalfFloatLinearFiltering) && (l = 1), c === 1 && !this._caps.textureFloat && (c = 0, n.Warn("Float textures are not supported. Type forced to TEXTURETYPE_UNSIGNED_BYTE"));
		let _ = k(u), v = M(u), y = this._gl, b = new t(this, a), x = e.width || e, S = e.height || e, C = e.depth || 0, w = e.layers || 0, T = this._getSamplingParameters(l, (o || s) && !_), E = w === 0 ? C === 0 ? g ? y.TEXTURE_CUBE_MAP : y.TEXTURE_2D : y.TEXTURE_3D : y.TEXTURE_2D_ARRAY, D = _ ? this._getInternalFormatFromDepthTextureFormat(u, !0, v) : this._getRGBABufferInternalSizedFormat(c, u, d), O = _ ? v ? y.DEPTH_STENCIL : y.DEPTH_COMPONENT : this._getInternalFormat(u), A = _ ? this._getWebGLTextureTypeFromDepthTextureFormat(u) : this._getWebGLTextureType(c);
		if (this._bindTextureDirectly(E, b), w !== 0) b.is2DArray = !0, y.texImage3D(E, 0, D, x, S, w, 0, O, A, null);
		else if (C !== 0) b.is3D = !0, y.texImage3D(E, 0, D, x, S, C, 0, O, A, null);
		else if (g) {
			b.isCube = !0;
			for (let e = 0; e < 6; e++) y.texImage2D(y.TEXTURE_CUBE_MAP_POSITIVE_X + e, 0, D, x, S, 0, O, A, null);
		} else y.texImage2D(E, 0, D, x, S, 0, O, A, null);
		if (y.texParameteri(E, y.TEXTURE_MAG_FILTER, T.mag), y.texParameteri(E, y.TEXTURE_MIN_FILTER, T.min), y.texParameteri(E, y.TEXTURE_WRAP_S, y.CLAMP_TO_EDGE), y.texParameteri(E, y.TEXTURE_WRAP_T, y.CLAMP_TO_EDGE), _ && this.webGLVersion > 1 && (h === 0 ? (y.texParameteri(E, y.TEXTURE_COMPARE_FUNC, 515), y.texParameteri(E, y.TEXTURE_COMPARE_MODE, y.NONE)) : (y.texParameteri(E, y.TEXTURE_COMPARE_FUNC, h), y.texParameteri(E, y.TEXTURE_COMPARE_MODE, y.COMPARE_REF_TO_TEXTURE))), (o || s) && this._gl.generateMipmap(E), this._bindTextureDirectly(E, null), b._useSRGBBuffer = d, b.baseWidth = x, b.baseHeight = S, b.width = x, b.height = S, b.depth = w || C, b.isReady = !0, b.samples = f, b.generateMipMaps = o, b.samplingMode = l, b.type = c, b.format = u, b.label = p, b.comparisonFunction = h, this._internalTexturesCache.push(b), m) {
			let e;
			if (e = k(b.format) ? this._setupFramebufferDepthAttachments(M(b.format), b.format !== 19, b.width, b.height, f, b.format, !0) : this._createRenderBuffer(b.width, b.height, f, -1, this._getRGBABufferInternalSizedFormat(b.type, b.format, b._useSRGBBuffer), -1), !e) throw Error("Unable to create render buffer");
			b._autoMSAAManagement = !0;
			let t = b._hardwareTexture;
			t ||= b._hardwareTexture = this._createHardwareTexture(), t.addMSAARenderBuffer(e);
		}
		return b;
	}
	_getUseSRGBBuffer(e, t) {
		return e && this._caps.supportSRGBBuffers && (this.webGLVersion > 1 || t);
	}
	createTexture(e, n, r, i, a = 3, o = null, s = null, c = null, l = null, u = null, d = null, f, p, m, h) {
		return this._createTextureBase(e, n, r, i, a, o, s, (...e) => this._prepareWebGLTexture(...e, u), (e, n, r, a, o, s) => {
			let c = this._gl, l = r.width === e && r.height === n;
			o._creationFlags = m ?? 0;
			let u = this._getTexImageParametersForCreateTexture(o.format, o._useSRGBBuffer);
			if (l) return c.texImage2D(c.TEXTURE_2D, 0, u.internalFormat, u.format, u.type, r), !1;
			let d = this._caps.maxTextureSize;
			if (r.width > d || r.height > d || !this._supportsHardwareTextureRescaling) return this._prepareWorkingCanvas(), !this._workingCanvas || !this._workingContext || (this._workingCanvas.width = e, this._workingCanvas.height = n, this._workingContext.drawImage(r, 0, 0, r.width, r.height, 0, 0, e, n), c.texImage2D(c.TEXTURE_2D, 0, u.internalFormat, u.format, u.type, this._workingCanvas), o.width = e, o.height = n), !1;
			{
				let e = new t(this, 2);
				this._bindTextureDirectly(c.TEXTURE_2D, e, !0), c.texImage2D(c.TEXTURE_2D, 0, u.internalFormat, u.format, u.type, r), this._rescaleTexture(e, o, i, u.format, () => {
					this._releaseTexture(e), this._bindTextureDirectly(c.TEXTURE_2D, o, !0), s();
				});
			}
			return !0;
		}, c, l, u, d, f, p, h);
	}
	_getTexImageParametersForCreateTexture(e, t) {
		let n, r;
		return this.webGLVersion === 1 ? (n = this._getInternalFormat(e, t), r = n) : (n = this._getInternalFormat(e, !1), r = this._getRGBABufferInternalSizedFormat(0, e, t)), {
			internalFormat: r,
			format: n,
			type: this._gl.UNSIGNED_BYTE
		};
	}
	_rescaleTexture(e, t, n, r, i) {}
	_unpackFlipY(e) {
		this._unpackFlipYCached !== e && (this._gl.pixelStorei(this._gl.UNPACK_FLIP_Y_WEBGL, +!!e), this.enableUnpackFlipYCached && (this._unpackFlipYCached = e));
	}
	_getUnpackAlignement() {
		return this._gl.getParameter(this._gl.UNPACK_ALIGNMENT);
	}
	_getTextureTarget(e) {
		return e.isCube ? this._gl.TEXTURE_CUBE_MAP : e.is3D ? this._gl.TEXTURE_3D : e.is2DArray || e.isMultiview ? this._gl.TEXTURE_2D_ARRAY : this._gl.TEXTURE_2D;
	}
	updateTextureSamplingMode(e, t, n = !1) {
		let r = this._getTextureTarget(t), i = this._getSamplingParameters(e, t.useMipMaps || n);
		this._setTextureParameterInteger(r, this._gl.TEXTURE_MAG_FILTER, i.mag, t), this._setTextureParameterInteger(r, this._gl.TEXTURE_MIN_FILTER, i.min), n && i.hasMipMaps && (t.generateMipMaps = !0, this._gl.generateMipmap(r)), this._bindTextureDirectly(r, null), t.samplingMode = e;
	}
	updateTextureDimensions(e, t, n, r = 1) {}
	updateTextureWrappingMode(e, t, n = null, r = null) {
		let i = this._getTextureTarget(e);
		t !== null && (this._setTextureParameterInteger(i, this._gl.TEXTURE_WRAP_S, this._getTextureWrapMode(t), e), e._cachedWrapU = t), n !== null && (this._setTextureParameterInteger(i, this._gl.TEXTURE_WRAP_T, this._getTextureWrapMode(n), e), e._cachedWrapV = n), (e.is2DArray || e.is3D) && r !== null && (this._setTextureParameterInteger(i, this._gl.TEXTURE_WRAP_R, this._getTextureWrapMode(r), e), e._cachedWrapR = r), this._bindTextureDirectly(i, null);
	}
	_uploadCompressedDataToTextureDirectly(e, t, n, r, i, a = 0, o = 0) {
		let s = this._gl, c = s.TEXTURE_2D;
		if (e.isCube && (c = s.TEXTURE_CUBE_MAP_POSITIVE_X + a), e._useSRGBBuffer) switch (t) {
			case 37492:
			case 36196:
				this._caps.etc2 ? t = s.COMPRESSED_SRGB8_ETC2 : e._useSRGBBuffer = !1;
				break;
			case 37496:
				this._caps.etc2 ? t = s.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC : e._useSRGBBuffer = !1;
				break;
			case 36492:
				t = s.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT;
				break;
			case 37808:
				t = s.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR;
				break;
			case 37809:
				t = s.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR;
				break;
			case 37810:
				t = s.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR;
				break;
			case 37811:
				t = s.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR;
				break;
			case 37812:
				t = s.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR;
				break;
			case 37813:
				t = s.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR;
				break;
			case 37814:
				t = s.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR;
				break;
			case 37815:
				t = s.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR;
				break;
			case 37816:
				t = s.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR;
				break;
			case 37817:
				t = s.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR;
				break;
			case 37818:
				t = s.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR;
				break;
			case 37819:
				t = s.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR;
				break;
			case 37820:
				t = s.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR;
				break;
			case 37821:
				t = s.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR;
				break;
			case 33776:
				this._caps.s3tc_srgb ? t = s.COMPRESSED_SRGB_S3TC_DXT1_EXT : e._useSRGBBuffer = !1;
				break;
			case 33777:
				this._caps.s3tc_srgb ? t = s.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT : e._useSRGBBuffer = !1;
				break;
			case 33779:
				this._caps.s3tc_srgb ? t = s.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT : e._useSRGBBuffer = !1;
				break;
			default: e._useSRGBBuffer = !1;
		}
		if (e.generateMipMaps) {
			let a = e._hardwareTexture;
			a.memoryAllocated ||= (s.texStorage2D(e.isCube ? s.TEXTURE_CUBE_MAP : s.TEXTURE_2D, Math.floor(Math.log2(Math.max(n, r))) + 1, t, e.width, e.height), !0), this._gl.compressedTexSubImage2D(c, o, 0, 0, n, r, t, i);
		} else this._gl.compressedTexImage2D(c, o, t, n, r, 0, i);
	}
	_uploadDataToTextureDirectly(e, t, n = 0, r = 0, i, a = !1) {
		let o = this._gl, s = this._getWebGLTextureType(e.type), c = this._getInternalFormat(e.format), l = i === void 0 ? this._getRGBABufferInternalSizedFormat(e.type, e.format, e._useSRGBBuffer) : this._getInternalFormat(i, e._useSRGBBuffer);
		this._unpackFlipY(e.invertY);
		let u = o.TEXTURE_2D;
		e.isCube && (u = o.TEXTURE_CUBE_MAP_POSITIVE_X + n);
		let d = Math.round(Math.log(e.width) * Math.LOG2E), f = Math.round(Math.log(e.height) * Math.LOG2E), p = a ? e.width : 2 ** Math.max(d - r, 0), m = a ? e.height : 2 ** Math.max(f - r, 0);
		o.texImage2D(u, r, l, p, m, 0, c, s, t);
	}
	updateTextureData(e, t, n, r, i, a, o = 0, s = 0, c = !1) {
		let l = this._gl, u = this._getWebGLTextureType(e.type), d = this._getInternalFormat(e.format);
		this._unpackFlipY(e.invertY);
		let f = l.TEXTURE_2D, p = l.TEXTURE_2D;
		e.isCube && (p = l.TEXTURE_CUBE_MAP_POSITIVE_X + o, f = l.TEXTURE_CUBE_MAP), this._bindTextureDirectly(f, e, !0), l.texSubImage2D(p, s, n, r, i, a, d, u, t), c && this._gl.generateMipmap(p), this._bindTextureDirectly(f, null);
	}
	_uploadArrayBufferViewToTexture(e, t, n = 0, r = 0) {
		let i = this._gl, a = e.isCube ? i.TEXTURE_CUBE_MAP : i.TEXTURE_2D;
		this._bindTextureDirectly(a, e, !0), this._uploadDataToTextureDirectly(e, t, n, r), this._bindTextureDirectly(a, null, !0);
	}
	_prepareWebGLTextureContinuation(e, t, n, r, i) {
		let a = this._gl;
		if (!a) return;
		let o = this._getSamplingParameters(i, !n);
		a.texParameteri(a.TEXTURE_2D, a.TEXTURE_MAG_FILTER, o.mag), a.texParameteri(a.TEXTURE_2D, a.TEXTURE_MIN_FILTER, o.min), !n && !r && a.generateMipmap(a.TEXTURE_2D), this._bindTextureDirectly(a.TEXTURE_2D, null), t && t.removePendingData(e), e.onLoadedObservable.notifyObservers(e), e.onLoadedObservable.clear();
	}
	_prepareWebGLTexture(e, t, n, r, i, a, o, s, c, l) {
		let u = this.getCaps().maxTextureSize, d = Math.min(u, this.needPOTTextures ? x(r.width, u) : r.width), f = Math.min(u, this.needPOTTextures ? x(r.height, u) : r.height), p = this._gl;
		p && (e._hardwareTexture ? (this._bindTextureDirectly(p.TEXTURE_2D, e, !0), this._unpackFlipY(i === void 0 || !!i), e.baseWidth = r.width, e.baseHeight = r.height, e.width = d, e.height = f, e.isReady = !0, e.type = e.type === -1 ? 0 : e.type, e.format = e.format === -1 ? l ?? (t === ".jpg" && !e._useSRGBBuffer ? 4 : 5) : e.format, !s(d, f, r, t, e, () => {
			this._prepareWebGLTextureContinuation(e, n, a, o, c);
		}) && this._prepareWebGLTextureContinuation(e, n, a, o, c)) : n && n.removePendingData(e));
	}
	_getInternalFormatFromDepthTextureFormat(e, t, n) {
		let r = this._gl;
		if (!t) return r.STENCIL_INDEX8;
		let i = n ? r.DEPTH_STENCIL : r.DEPTH_COMPONENT;
		return this.webGLVersion > 1 ? e === 15 ? i = r.DEPTH_COMPONENT16 : e === 16 ? i = r.DEPTH_COMPONENT24 : e === 17 || e === 13 ? i = n ? r.DEPTH24_STENCIL8 : r.DEPTH_COMPONENT24 : e === 14 ? i = r.DEPTH_COMPONENT32F : e === 18 && (i = n ? r.DEPTH32F_STENCIL8 : r.DEPTH_COMPONENT32F) : i = r.DEPTH_COMPONENT16, i;
	}
	_getWebGLTextureTypeFromDepthTextureFormat(e) {
		let t = this._gl, n = t.UNSIGNED_INT;
		return e === 15 ? n = t.UNSIGNED_SHORT : e === 17 || e === 13 ? n = t.UNSIGNED_INT_24_8 : e === 14 ? n = t.FLOAT : e === 18 ? n = t.FLOAT_32_UNSIGNED_INT_24_8_REV : e === 19 && (n = t.UNSIGNED_BYTE), n;
	}
	_setupFramebufferDepthAttachments(e, t, n, r, i = 1, a, o = !1) {
		let s = this._gl;
		a ??= e ? 13 : 14;
		let c = this._getInternalFormatFromDepthTextureFormat(a, t, e);
		return e && t ? this._createRenderBuffer(n, r, i, s.DEPTH_STENCIL, c, o ? -1 : s.DEPTH_STENCIL_ATTACHMENT) : t ? this._createRenderBuffer(n, r, i, c, c, o ? -1 : s.DEPTH_ATTACHMENT) : e ? this._createRenderBuffer(n, r, i, c, c, o ? -1 : s.STENCIL_ATTACHMENT) : null;
	}
	_createRenderBuffer(e, t, n, r, i, a, o = !0) {
		let s = this._gl.createRenderbuffer();
		return this._updateRenderBuffer(s, e, t, n, r, i, a, o);
	}
	_updateRenderBuffer(e, t, n, r, i, a, o, s = !0) {
		let c = this._gl;
		return c.bindRenderbuffer(c.RENDERBUFFER, e), r > 1 && c.renderbufferStorageMultisample ? c.renderbufferStorageMultisample(c.RENDERBUFFER, r, a, t, n) : c.renderbufferStorage(c.RENDERBUFFER, i, t, n), o !== -1 && c.framebufferRenderbuffer(c.FRAMEBUFFER, o, c.RENDERBUFFER, e), s && c.bindRenderbuffer(c.RENDERBUFFER, null), e;
	}
	_releaseTexture(e) {
		this._deleteTexture(e._hardwareTexture), this.unbindAllTextures();
		let t = this._internalTexturesCache.indexOf(e);
		t !== -1 && this._internalTexturesCache.splice(t, 1), e._lodTextureHigh && e._lodTextureHigh.dispose(), e._lodTextureMid && e._lodTextureMid.dispose(), e._lodTextureLow && e._lodTextureLow.dispose(), e._irradianceTexture && e._irradianceTexture.dispose();
	}
	_deleteTexture(e) {
		e?.release();
	}
	_setProgram(e) {
		this._currentProgram !== e && (v(e, this._gl), this._currentProgram = e);
	}
	bindSamplers(e) {
		let t = e.getPipelineContext();
		this._setProgram(t.program);
		let n = e.getSamplers();
		for (let t = 0; t < n.length; t++) {
			let r = e.getUniform(n[t]);
			r && (this._boundUniforms[t] = r);
		}
		this._currentEffect = null;
	}
	_activateCurrentTexture() {
		this._currentTextureChannel !== this._activeChannel && (this._gl.activeTexture(this._gl.TEXTURE0 + this._activeChannel), this._currentTextureChannel = this._activeChannel);
	}
	_bindTextureDirectly(e, t, r = !1, i = !1) {
		let a = !1, o = t && t._associatedChannel > -1;
		if (r && o && (this._activeChannel = t._associatedChannel), this._boundTexturesCache[this._activeChannel] !== t || i) {
			if (this._activateCurrentTexture(), t && t.isMultiview) throw n.Error([
				"_bindTextureDirectly called with a multiview texture!",
				e,
				t
			]), "_bindTextureDirectly called with a multiview texture!";
			this._gl.bindTexture(e, t?._hardwareTexture?.underlyingResource ?? null), this._boundTexturesCache[this._activeChannel] = t, t && (t._associatedChannel = this._activeChannel);
		} else r && (a = !0, this._activateCurrentTexture());
		return o && !r && this._bindSamplerUniformToChannel(t._associatedChannel, this._activeChannel), a;
	}
	_bindTexture(e, t, n) {
		if (e === void 0) return;
		t && (t._associatedChannel = e), this._activeChannel = e;
		let r = t ? this._getTextureTarget(t) : this._gl.TEXTURE_2D;
		this._bindTextureDirectly(r, t);
	}
	unbindAllTextures() {
		for (let e = 0; e < this._maxSimultaneousTextures; e++) this._activeChannel = e, this._bindTextureDirectly(this._gl.TEXTURE_2D, null), this._bindTextureDirectly(this._gl.TEXTURE_CUBE_MAP, null), this.webGLVersion > 1 && (this._bindTextureDirectly(this._gl.TEXTURE_3D, null), this._bindTextureDirectly(this._gl.TEXTURE_2D_ARRAY, null));
	}
	setTexture(e, t, n, r) {
		e !== void 0 && (t && (this._boundUniforms[e] = t), this._setTexture(e, n));
	}
	_bindSamplerUniformToChannel(e, t) {
		let n = this._boundUniforms[e];
		n && n._currentState !== t && (this._gl.uniform1i(n, t), n._currentState = t);
	}
	_getTextureWrapMode(e) {
		switch (e) {
			case 1: return this._gl.REPEAT;
			case 0: return this._gl.CLAMP_TO_EDGE;
			case 2: return this._gl.MIRRORED_REPEAT;
		}
		return this._gl.REPEAT;
	}
	_setTexture(e, t, n = !1, r = !1, i = "") {
		if (!t) return this._boundTexturesCache[e] != null && (this._activeChannel = e, this._bindTextureDirectly(this._gl.TEXTURE_2D, null), this._bindTextureDirectly(this._gl.TEXTURE_CUBE_MAP, null), this.webGLVersion > 1 && (this._bindTextureDirectly(this._gl.TEXTURE_3D, null), this._bindTextureDirectly(this._gl.TEXTURE_2D_ARRAY, null))), !1;
		if (t.video) {
			this._activeChannel = e;
			let n = t.getInternalTexture();
			n && (n._associatedChannel = e), t.update();
		} else if (t.delayLoadState === 4) return t.delayLoad(), !1;
		let a;
		a = r ? t.depthStencilTexture : t.isReady() ? t.getInternalTexture() : t.isCube ? this.emptyCubeTexture : t.is3D ? this.emptyTexture3D : t.is2DArray ? this.emptyTexture2DArray : this.emptyTexture, !n && a && (a._associatedChannel = e);
		let o = !0;
		this._boundTexturesCache[e] === a && (n || this._bindSamplerUniformToChannel(a._associatedChannel, e), o = !1), this._activeChannel = e;
		let s = this._getTextureTarget(a);
		if (o && this._bindTextureDirectly(s, a, n), a && !a.isMultiview) {
			if (a.isCube && a._cachedCoordinatesMode !== t.coordinatesMode) {
				a._cachedCoordinatesMode = t.coordinatesMode;
				let e = +(t.coordinatesMode !== 3 && t.coordinatesMode !== 5);
				t.wrapU = e, t.wrapV = e;
			}
			a._cachedWrapU !== t.wrapU && (a._cachedWrapU = t.wrapU, this._setTextureParameterInteger(s, this._gl.TEXTURE_WRAP_S, this._getTextureWrapMode(t.wrapU), a)), a._cachedWrapV !== t.wrapV && (a._cachedWrapV = t.wrapV, this._setTextureParameterInteger(s, this._gl.TEXTURE_WRAP_T, this._getTextureWrapMode(t.wrapV), a)), a.is3D && a._cachedWrapR !== t.wrapR && (a._cachedWrapR = t.wrapR, this._setTextureParameterInteger(s, this._gl.TEXTURE_WRAP_R, this._getTextureWrapMode(t.wrapR), a)), this._setAnisotropicLevel(s, a, t.anisotropicFilteringLevel);
		}
		return !0;
	}
	setTextureArray(e, t, n, r) {
		if (e !== void 0 && t) {
			(!this._textureUnits || this._textureUnits.length !== n.length) && (this._textureUnits = new Int32Array(n.length));
			for (let t = 0; t < n.length; t++) {
				let r = n[t].getInternalTexture();
				r ? (this._textureUnits[t] = e + t, r._associatedChannel = e + t) : this._textureUnits[t] = -1;
			}
			this._gl.uniform1iv(t, this._textureUnits);
			for (let e = 0; e < n.length; e++) this._setTexture(this._textureUnits[e], n[e], !0);
		}
	}
	_setAnisotropicLevel(e, t, n) {
		let r = this._caps.textureAnisotropicFilterExtension;
		t.samplingMode !== 11 && t.samplingMode !== 3 && t.samplingMode !== 2 && (n = 1), r && t._cachedAnisotropicFilteringLevel !== n && (this._setTextureParameterFloat(e, r.TEXTURE_MAX_ANISOTROPY_EXT, Math.min(n, this._caps.maxAnisotropy), t), t._cachedAnisotropicFilteringLevel = n);
	}
	_setTextureParameterFloat(e, t, n, r) {
		this._bindTextureDirectly(e, r, !0, !0), this._gl.texParameterf(e, t, n);
	}
	_setTextureParameterInteger(e, t, n, r) {
		r && this._bindTextureDirectly(e, r, !0, !0), this._gl.texParameteri(e, t, n);
	}
	unbindAllAttributes() {
		if (this._mustWipeVertexAttributes) {
			this._mustWipeVertexAttributes = !1;
			for (let e = 0; e < this._caps.maxVertexAttribs; e++) this.disableAttributeByIndex(e);
		} else for (let e = 0, t = this._vertexAttribArraysEnabled.length; e < t; e++) e >= this._caps.maxVertexAttribs || !this._vertexAttribArraysEnabled[e] || this.disableAttributeByIndex(e);
	}
	releaseEffects() {
		this._compiledEffects = {}, this.onReleaseEffectsObservable.notifyObservers(this);
	}
	dispose() {
		r() && this._renderingCanvas && (this._renderingCanvas.removeEventListener("webglcontextlost", this._onContextLost), this._onContextRestored && this._renderingCanvas.removeEventListener("webglcontextrestored", this._onContextRestored)), super.dispose(), this._dummyFramebuffer && this._gl.deleteFramebuffer(this._dummyFramebuffer), this.unbindAllAttributes(), this._boundUniforms = {}, this._workingCanvas = null, this._workingContext = null, this._currentBufferPointers.length = 0, this._currentProgram = null, this._creationOptions.loseContextOnDispose && this._gl.getExtension("WEBGL_lose_context")?.loseContext(), d(this._gl);
	}
	attachContextLostEvent(e) {
		this._renderingCanvas && this._renderingCanvas.addEventListener("webglcontextlost", e, !1);
	}
	attachContextRestoredEvent(e) {
		this._renderingCanvas && this._renderingCanvas.addEventListener("webglcontextrestored", e, !1);
	}
	getError() {
		return this._gl.getError();
	}
	_canRenderToFloatFramebuffer() {
		return this._webGLVersion > 1 ? this._caps.colorBufferFloat : this._canRenderToFramebuffer(1);
	}
	_canRenderToHalfFloatFramebuffer() {
		return this._webGLVersion > 1 ? this._caps.colorBufferFloat : this._canRenderToFramebuffer(2);
	}
	_canRenderToFramebuffer(e) {
		let t = this._gl;
		for (; t.getError() !== t.NO_ERROR;);
		let n = !0, r = t.createTexture();
		t.bindTexture(t.TEXTURE_2D, r), t.texImage2D(t.TEXTURE_2D, 0, this._getRGBABufferInternalSizedFormat(e), 1, 1, 0, t.RGBA, this._getWebGLTextureType(e), null), t.texParameteri(t.TEXTURE_2D, t.TEXTURE_MIN_FILTER, t.NEAREST), t.texParameteri(t.TEXTURE_2D, t.TEXTURE_MAG_FILTER, t.NEAREST);
		let i = t.createFramebuffer();
		t.bindFramebuffer(t.FRAMEBUFFER, i), t.framebufferTexture2D(t.FRAMEBUFFER, t.COLOR_ATTACHMENT0, t.TEXTURE_2D, r, 0);
		let a = t.checkFramebufferStatus(t.FRAMEBUFFER);
		if (n &&= a === t.FRAMEBUFFER_COMPLETE, n &&= t.getError() === t.NO_ERROR, n && (t.clear(t.COLOR_BUFFER_BIT), n &&= t.getError() === t.NO_ERROR), n) {
			t.bindFramebuffer(t.FRAMEBUFFER, null);
			let e = t.RGBA, r = t.UNSIGNED_BYTE, i = /* @__PURE__ */ new Uint8Array(4);
			t.readPixels(0, 0, 1, 1, e, r, i), n &&= t.getError() === t.NO_ERROR;
		}
		for (t.deleteTexture(r), t.deleteFramebuffer(i), t.bindFramebuffer(t.FRAMEBUFFER, null); !n && t.getError() !== t.NO_ERROR;);
		return n;
	}
	_getWebGLTextureType(e) {
		if (this._webGLVersion === 1) {
			switch (e) {
				case 1: return this._gl.FLOAT;
				case 2: return this._gl.HALF_FLOAT_OES;
				case 0: return this._gl.UNSIGNED_BYTE;
				case 8: return this._gl.UNSIGNED_SHORT_4_4_4_4;
				case 9: return this._gl.UNSIGNED_SHORT_5_5_5_1;
				case 10: return this._gl.UNSIGNED_SHORT_5_6_5;
			}
			return this._gl.UNSIGNED_BYTE;
		}
		switch (e) {
			case 3: return this._gl.BYTE;
			case 0: return this._gl.UNSIGNED_BYTE;
			case 4: return this._gl.SHORT;
			case 5: return this._gl.UNSIGNED_SHORT;
			case 6: return this._gl.INT;
			case 7: return this._gl.UNSIGNED_INT;
			case 1: return this._gl.FLOAT;
			case 2: return this._gl.HALF_FLOAT;
			case 8: return this._gl.UNSIGNED_SHORT_4_4_4_4;
			case 9: return this._gl.UNSIGNED_SHORT_5_5_5_1;
			case 10: return this._gl.UNSIGNED_SHORT_5_6_5;
			case 11: return this._gl.UNSIGNED_INT_2_10_10_10_REV;
			case 12: return this._gl.UNSIGNED_INT_24_8;
			case 13: return this._gl.UNSIGNED_INT_10F_11F_11F_REV;
			case 14: return this._gl.UNSIGNED_INT_5_9_9_9_REV;
			case 15: return this._gl.FLOAT_32_UNSIGNED_INT_24_8_REV;
		}
		return this._gl.UNSIGNED_BYTE;
	}
	_getInternalFormat(e, t = !1) {
		let n = t ? this._glSRGBExtensionValues.SRGB8_ALPHA8 : this._gl.RGBA;
		switch (e) {
			case 0:
				n = this._gl.ALPHA;
				break;
			case 1:
				n = this._gl.LUMINANCE;
				break;
			case 2:
				n = this._gl.LUMINANCE_ALPHA;
				break;
			case 6:
			case 33322:
			case 36760:
				n = this._gl.RED;
				break;
			case 7:
			case 33324:
			case 36761:
				n = this._gl.RG;
				break;
			case 4:
			case 32852:
			case 36762:
				n = t ? this._glSRGBExtensionValues.SRGB : this._gl.RGB;
				break;
			case 5:
			case 32859:
			case 36763: n = t ? this._glSRGBExtensionValues.SRGB8_ALPHA8 : this._gl.RGBA;
		}
		if (this._webGLVersion > 1) switch (e) {
			case 8:
				n = this._gl.RED_INTEGER;
				break;
			case 9:
				n = this._gl.RG_INTEGER;
				break;
			case 10:
				n = this._gl.RGB_INTEGER;
				break;
			case 11: n = this._gl.RGBA_INTEGER;
		}
		return n;
	}
	_getRGBABufferInternalSizedFormat(e, t, n = !1) {
		if (this._webGLVersion === 1) {
			if (t !== void 0) switch (t) {
				case 0: return this._gl.ALPHA;
				case 1: return this._gl.LUMINANCE;
				case 2: return this._gl.LUMINANCE_ALPHA;
				case 4: return n ? this._glSRGBExtensionValues.SRGB : this._gl.RGB;
			}
			return this._gl.RGBA;
		}
		switch (e) {
			case 3: switch (t) {
				case 6: return this._gl.R8_SNORM;
				case 7: return this._gl.RG8_SNORM;
				case 4: return this._gl.RGB8_SNORM;
				case 8: return this._gl.R8I;
				case 9: return this._gl.RG8I;
				case 10: return this._gl.RGB8I;
				case 11: return this._gl.RGBA8I;
				default: return this._gl.RGBA8_SNORM;
			}
			case 0: switch (t) {
				case 6: return this._gl.R8;
				case 7: return this._gl.RG8;
				case 4: return n ? this._glSRGBExtensionValues.SRGB8 : this._gl.RGB8;
				case 5: return n ? this._glSRGBExtensionValues.SRGB8_ALPHA8 : this._gl.RGBA8;
				case 8: return this._gl.R8UI;
				case 9: return this._gl.RG8UI;
				case 10: return this._gl.RGB8UI;
				case 11: return this._gl.RGBA8UI;
				case 0: return this._gl.ALPHA;
				case 1: return this._gl.LUMINANCE;
				case 2: return this._gl.LUMINANCE_ALPHA;
				default: return this._gl.RGBA8;
			}
			case 4: switch (t) {
				case 8: return this._gl.R16I;
				case 36760: return this._gl.R16_SNORM_EXT;
				case 36761: return this._gl.RG16_SNORM_EXT;
				case 36762: return this._gl.RGB16_SNORM_EXT;
				case 36763: return this._gl.RGBA16_SNORM_EXT;
				case 9: return this._gl.RG16I;
				case 10: return this._gl.RGB16I;
				case 11: return this._gl.RGBA16I;
				default: return this._gl.RGBA16I;
			}
			case 5: switch (t) {
				case 8: return this._gl.R16UI;
				case 33322: return this._gl.R16_EXT;
				case 33324: return this._gl.RG16_EXT;
				case 32852: return this._gl.RGB16_EXT;
				case 32859: return this._gl.RGBA16_EXT;
				case 9: return this._gl.RG16UI;
				case 10: return this._gl.RGB16UI;
				case 11: return this._gl.RGBA16UI;
				default: return this._gl.RGBA16UI;
			}
			case 6: switch (t) {
				case 8: return this._gl.R32I;
				case 9: return this._gl.RG32I;
				case 10: return this._gl.RGB32I;
				case 11: return this._gl.RGBA32I;
				default: return this._gl.RGBA32I;
			}
			case 7: switch (t) {
				case 8: return this._gl.R32UI;
				case 9: return this._gl.RG32UI;
				case 10: return this._gl.RGB32UI;
				case 11: return this._gl.RGBA32UI;
				default: return this._gl.RGBA32UI;
			}
			case 1: switch (t) {
				case 6: return this._gl.R32F;
				case 7: return this._gl.RG32F;
				case 4: return this._gl.RGB32F;
				case 5: return this._gl.RGBA32F;
				default: return this._gl.RGBA32F;
			}
			case 2: switch (t) {
				case 6: return this._gl.R16F;
				case 7: return this._gl.RG16F;
				case 4: return this._gl.RGB16F;
				case 5: return this._gl.RGBA16F;
				default: return this._gl.RGBA16F;
			}
			case 10: return this._gl.RGB565;
			case 13: return this._gl.R11F_G11F_B10F;
			case 14: return this._gl.RGB9_E5;
			case 8: return this._gl.RGBA4;
			case 9: return this._gl.RGB5_A1;
			case 11: switch (t) {
				case 5: return this._gl.RGB10_A2;
				case 11: return this._gl.RGB10_A2UI;
				default: return this._gl.RGB10_A2;
			}
		}
		return n ? this._glSRGBExtensionValues.SRGB8_ALPHA8 : this._gl.RGBA8;
	}
	readPixels(e, t, r, i, a = !0, o = !0, s = null) {
		let c = a ? 4 : 3, l = a ? this._gl.RGBA : this._gl.RGB, u = r * i * c;
		if (!s) s = new Uint8Array(u);
		else if (s.length < u) return n.Error(`Data buffer is too small to store the read pixels (${s.length} should be more than ${u})`), Promise.resolve(s);
		return o && this.flushFramebuffer(), this._gl.readPixels(e, t, r, i, l, this._gl.UNSIGNED_BYTE, s), Promise.resolve(s);
	}
	static get IsSupportedAsync() {
		return Promise.resolve(this.isSupported());
	}
	static get IsSupported() {
		return this.isSupported();
	}
	static isSupported() {
		if (this._HasMajorPerformanceCaveat !== null) return !this._HasMajorPerformanceCaveat;
		if (this._IsSupported === null) try {
			let e = _._CreateCanvas(1, 1), t = e.getContext("webgl") || e.getContext("experimental-webgl");
			this._IsSupported = t != null && !!globalThis.WebGLRenderingContext;
		} catch {
			this._IsSupported = !1;
		}
		return this._IsSupported;
	}
	static get HasMajorPerformanceCaveat() {
		if (this._HasMajorPerformanceCaveat === null) try {
			let e = _._CreateCanvas(1, 1), t = e.getContext("webgl", { failIfMajorPerformanceCaveat: !0 }) || e.getContext("experimental-webgl", { failIfMajorPerformanceCaveat: !0 });
			this._HasMajorPerformanceCaveat = !t;
		} catch {
			this._HasMajorPerformanceCaveat = !1;
		}
		return this._HasMajorPerformanceCaveat;
	}
};
F._TempClearColorUint32 = /*#__PURE__*/ new Uint32Array(4), F._TempClearColorInt32 = /*#__PURE__*/ new Int32Array(4), F._TempClearColorFloat32 = /*#__PURE__*/ new Float32Array(4), F.ExceptionList = [
	{
		key: "Chrome/63.0",
		capture: "63\\.0\\.3239\\.(\\d+)",
		captureConstraint: 108,
		targets: ["uniformBuffer"]
	},
	{
		key: "Firefox/58",
		capture: null,
		captureConstraint: null,
		targets: ["uniformBuffer"]
	},
	{
		key: "Firefox/59",
		capture: null,
		captureConstraint: null,
		targets: ["uniformBuffer"]
	},
	{
		key: "Chrome/72.+?Mobile",
		capture: null,
		captureConstraint: null,
		targets: ["vao"]
	},
	{
		key: "Chrome/73.+?Mobile",
		capture: null,
		captureConstraint: null,
		targets: ["vao"]
	},
	{
		key: "Chrome/74.+?Mobile",
		capture: null,
		captureConstraint: null,
		targets: ["vao"]
	},
	{
		key: "Mac OS.+Chrome/71",
		capture: null,
		captureConstraint: null,
		targets: ["vao"]
	},
	{
		key: "Mac OS.+Chrome/72",
		capture: null,
		captureConstraint: null,
		targets: ["vao"]
	},
	{
		key: "Mac OS.+Chrome",
		capture: null,
		captureConstraint: null,
		targets: ["uniformBuffer"]
	},
	{
		key: "Chrome/12\\d\\..+?Mobile",
		capture: null,
		captureConstraint: null,
		targets: ["uniformBuffer"]
	},
	{
		key: ".*AppleWebKit.*(15.4).*Safari",
		capture: null,
		captureConstraint: null,
		targets: ["antialias", "maxMSAASamples"]
	},
	{
		key: ".*(15.4).*AppleWebKit.*Safari",
		capture: null,
		captureConstraint: null,
		targets: ["antialias", "maxMSAASamples"]
	}
], F._ConcatenateShader = b, F._IsSupported = null, F._HasMajorPerformanceCaveat = null;
//#endregion
export { j as a, E as c, A as i, S as l, N as n, O as o, M as r, D as s, F as t };
