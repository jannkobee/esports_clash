import { n as e } from "./typeStore-pENEWnX2.js";
import { t } from "./flowGraphExecutionBlockWithOutSignal-XngQvXka.js";
import { c as n } from "./flowGraphRichTypes.pure-BpKU4EZT.js";
//#region node_modules/@babylonjs/core/FlowGraph/Blocks/Execution/ControlFlow/flowGraphDebounceBlock.pure.js
var r = class extends t {
	constructor(e) {
		super(e), this.count = this.registerDataInput("count", n), this.reset = this._registerSignalInput("reset"), this.currentCount = this.registerDataOutput("currentCount", n);
	}
	_execute(e, t) {
		if (t === this.reset) {
			e._setExecutionVariable(this, "debounceCount", 0);
			return;
		}
		let n = this.count.getValue(e), r = e._getExecutionVariable(this, "debounceCount", 0) + 1;
		this.currentCount.setValue(r, e), e._setExecutionVariable(this, "debounceCount", r), r >= n && (this.out._activateSignal(e), e._setExecutionVariable(this, "debounceCount", 0));
	}
	getClassName() {
		return "FlowGraphDebounceBlock";
	}
}, i = !1;
function a() {
	i || (i = !0, e("FlowGraphDebounceBlock", r));
}
//#endregion
export { r as FlowGraphDebounceBlock, a as RegisterFlowGraphDebounceBlock };
