import { d as e } from "./math.scalar.functions-D7lyzZPV.js";
import { n as t, t as n } from "./engineStore-D0BoPdea.js";
import { r } from "./scene.pure-B0rulfRT.js";
import { n as i } from "./decorators.serialization-CGAHzP43.js";
import { i as a, r as o } from "./animation.pure-D6aX6Q8L.js";
import { t as s } from "./animatable.pure-DpllM6RG.js";
//#region node_modules/@babylonjs/core/Animations/animationGroup.pure.js
var c = /* @__PURE__ */ e({
	AnimationGroup: () => u,
	AnimationGroupClipFrames: () => g,
	AnimationGroupClipFramesInPlace: () => _,
	AnimationGroupClipInPlace: () => v,
	AnimationGroupClipKeys: () => m,
	AnimationGroupClipKeysInPlace: () => h,
	AnimationGroupMakeAnimationAdditive: () => p,
	AnimationGroupMergeAnimationGroups: () => d,
	AnimationGroupParse: () => f,
	RegisterAnimationGroup: () => b,
	TargetedAnimation: () => l
}), l = class {
	getClassName() {
		return "TargetedAnimation";
	}
	constructor(e) {
		this.parent = e, this.uniqueId = r.UniqueId;
	}
	serialize() {
		let e = {};
		return e.animation = this.animation.serialize(), e.targetId = this.target.id, e.targetUniqueId = this.target.uniqueId, e;
	}
}, u = class e {
	get mask() {
		return this._mask;
	}
	set mask(e) {
		this._mask !== e && (this._mask = e, this.syncWithMask(!0));
	}
	syncWithMask(e = !1) {
		if (!this.mask && !e) this._numActiveAnimatables = this._targetedAnimations.length;
		else {
			this._numActiveAnimatables = 0;
			for (let e = 0; e < this._animatables.length; ++e) {
				let t = this._animatables[e];
				!this.mask || this.mask.disabled || this.mask.retainsTarget(t.target.name) ? (this._numActiveAnimatables++, t.paused && t.restart()) : t.paused || t.pause();
			}
		}
	}
	removeUnmaskedAnimations() {
		if (this.mask && !this.mask.disabled) {
			for (let e = 0; e < this._animatables.length; ++e) {
				let t = this._animatables[e];
				this.mask.retainsTarget(t.target.name) || (t.stop(), this._animatables.splice(e, 1), --e);
			}
			for (let e = 0; e < this._targetedAnimations.length; e++) {
				let t = this._targetedAnimations[e];
				this.mask.retainsTarget(t.target.name) || (this._targetedAnimations.splice(e, 1), --e);
			}
		}
	}
	get from() {
		return this._from;
	}
	set from(e) {
		if (this._from !== e) {
			this._from = e;
			for (let e = 0; e < this._animatables.length; e++) {
				let t = this._animatables[e];
				t.fromFrame = this._from;
			}
		}
	}
	get to() {
		return this._to;
	}
	set to(e) {
		if (this._to !== e) {
			this._to = e;
			for (let e = 0; e < this._animatables.length; e++) {
				let t = this._animatables[e];
				t.toFrame = this._to;
			}
		}
	}
	get isStarted() {
		return this._isStarted;
	}
	get isPlaying() {
		return this._isStarted && !this._isPaused;
	}
	get speedRatio() {
		return this._speedRatio;
	}
	set speedRatio(e) {
		if (this._speedRatio !== e) {
			this._animatables[0] && (this._retainedCurrentFrame = this._animatables[0].masterFrame), this._updateVirtualFrame(), this._speedRatio = e, this._virtualFrameStart = this._virtualFrame, this._virtualFrameStartTime = this._scene._animationTime;
			for (let e = 0; e < this._animatables.length; e++) {
				let t = this._animatables[e];
				t.speedRatio = this._speedRatio;
			}
		}
	}
	get loopAnimation() {
		return this._loopAnimation;
	}
	set loopAnimation(e) {
		if (this._loopAnimation !== e) {
			this._loopAnimation = e;
			for (let e = 0; e < this._animatables.length; e++) {
				let t = this._animatables[e];
				t.loopAnimation = this._loopAnimation;
			}
		}
	}
	get isAdditive() {
		return this._isAdditive;
	}
	set isAdditive(e) {
		if (this._isAdditive !== e) {
			this._isAdditive = e;
			for (let e = 0; e < this._animatables.length; e++) {
				let t = this._animatables[e];
				t.isAdditive = this._isAdditive;
			}
		}
	}
	get weight() {
		return this._weight;
	}
	set weight(e) {
		this._weight !== e && (this._weight = e, this.setWeightForAllAnimatables(this._weight));
	}
	get targetedAnimations() {
		return this._targetedAnimations;
	}
	get animatables() {
		return this._animatables;
	}
	get children() {
		return this._targetedAnimations;
	}
	get playOrder() {
		return this._playOrder;
	}
	set playOrder(e) {
		if (this._playOrder !== e && (this._playOrder = e, this._animatables.length > 0)) {
			for (let e = 0; e < this._animatables.length; e++) this._animatables[e].playOrder = this._playOrder;
			this._scene.sortActiveAnimatables();
		}
	}
	get enableBlending() {
		return this._enableBlending;
	}
	set enableBlending(e) {
		if (this._enableBlending !== e && (this._enableBlending = e, e !== null)) for (let t = 0; t < this._targetedAnimations.length; ++t) this._targetedAnimations[t].animation.enableBlending = e;
	}
	get blendingSpeed() {
		return this._blendingSpeed;
	}
	set blendingSpeed(e) {
		if (this._blendingSpeed !== e && (this._blendingSpeed = e, e !== null)) for (let t = 0; t < this._targetedAnimations.length; ++t) this._targetedAnimations[t].animation.blendingSpeed = e;
	}
	getLength(e, t) {
		e ??= this._from, t ??= this._to;
		let n = this.targetedAnimations[0].animation.framePerSecond * this._speedRatio;
		return (t - e) / n;
	}
	getScene() {
		return this._scene;
	}
	constructor(e, r = null, i = -1, a = 0) {
		this.name = e, this._targetedAnimations = [], this._animatables = [], this._from = Number.MAX_VALUE, this._to = -Number.MAX_VALUE, this._speedRatio = 1, this._loopAnimation = !1, this._virtualFrame = 0, this._virtualFrameStart = 0, this._virtualFrameStartTime = 0, this._virtualFrameRate = 60, this._virtualFrameDirection = 1, this._virtualFrameInitial = 0, this._virtualFrameEnd = 0, this._virtualSamplingObserver = null, this._usesVirtualSampling = !1, this._retainedCurrentFrame = 0, this._isStopping = !1, this._isAdditive = !1, this._weight = -1, this._playOrder = 0, this._enableBlending = null, this._blendingSpeed = null, this._numActiveAnimatables = 0, this._shouldStart = !0, this._parentContainer = null, this.onAnimationEndObservable = new t(), this.onAnimationLoopObservable = new t(), this.onAnimationGroupLoopObservable = new t(), this.onAnimationGroupEndObservable = new t(), this.onAnimationGroupPauseObservable = new t(), this.onAnimationGroupPlayObservable = new t(), this.metadata = null, this._mask = null, this._animationLoopFlags = [], this._scene = r || n.LastCreatedScene, this._weight = i, this._playOrder = a, this.uniqueId = this._scene.getUniqueId(), s(), this._scene.addAnimationGroup(this);
	}
	addTargetedAnimation(e, t) {
		let n = new l(this);
		n.animation = e, n.target = t;
		let r = e.getKeys();
		return this._from > r[0].frame && (this._from = r[0].frame), this._to < r[r.length - 1].frame && (this._to = r[r.length - 1].frame), this._enableBlending !== null && (e.enableBlending = this._enableBlending), this._blendingSpeed !== null && (e.blendingSpeed = this._blendingSpeed), this._targetedAnimations.push(n), this._shouldStart = !0, n;
	}
	removeTargetedAnimation(e) {
		for (let t = this._targetedAnimations.length - 1; t > -1; t--) this._targetedAnimations[t].animation === e && this._targetedAnimations.splice(t, 1);
	}
	normalize(e = null, t = null) {
		e ??= this._from, t ??= this._to;
		for (let n = 0; n < this._targetedAnimations.length; n++) {
			let r = this._targetedAnimations[n].animation.getKeys(), i = r[0], a = r[r.length - 1];
			if (i.frame > e) {
				let t = {
					frame: e,
					value: i.value,
					inTangent: i.inTangent,
					outTangent: i.outTangent,
					interpolation: i.interpolation
				};
				r.splice(0, 0, t);
			}
			if (a.frame < t) {
				let e = {
					frame: t,
					value: a.value,
					inTangent: a.inTangent,
					outTangent: a.outTangent,
					interpolation: a.interpolation
				};
				r.push(e);
			}
		}
		return this._from = e, this._to = t, this;
	}
	_processLoop(e, t, n) {
		e.onAnimationLoop = () => {
			this.onAnimationLoopObservable.notifyObservers(t), !this._animationLoopFlags[n] && (this._animationLoopFlags[n] = !0, this._animationLoopCount++, this._animationLoopCount === this._numActiveAnimatables && (this.onAnimationGroupLoopObservable.notifyObservers(this), this._animationLoopCount = 0, this._animationLoopFlags.length = 0));
		};
	}
	start(e = !1, t = 1, n, r, i) {
		return this._start(e, t, n, r, i, !1);
	}
	startWithVirtualTimeline(e = !1, t = 1, n, r, i) {
		return this._start(e, t, n, r, i, !0);
	}
	_start(e, t, n, r, i, a) {
		if (this._isStarted || this._targetedAnimations.length === 0) return this;
		this._loopAnimation = e;
		let o = n ?? this._from, s = r ?? this._to;
		this._virtualFrame = o, this._virtualFrameStart = o, this._virtualFrameStartTime = this._scene._animationTime, this._virtualFrameRate = this._targetedAnimations[0]?.animation.framePerSecond ?? 60, this._virtualFrameDirection = s < o ? -1 : 1, this._virtualFrameInitial = o, this._virtualFrameEnd = s;
		let c = a ? this._mapVirtualFrame(o) : o, l = a ? Number.isFinite(s) ? this._mapVirtualFrame(s) : s < o ? 0 : this._to : s;
		this._retainedCurrentFrame = c, this._usesVirtualSampling = a && (c !== o || l !== s);
		let u = this._usesVirtualSampling ? this._virtualFrameDirection > 0 ? 0 : this._to : c, d = this._usesVirtualSampling ? this._virtualFrameDirection > 0 ? this._to : 0 : l;
		this._shouldStart = !1, this._animationLoopCount = 0, this._animationLoopFlags.length = 0;
		for (let n = 0; n < this._targetedAnimations.length; n++) {
			let r = this._targetedAnimations[n], a = this._scene.beginDirectAnimation(r.target, [r.animation], u, d, this._usesVirtualSampling || e, t, void 0, void 0, i === void 0 ? this._isAdditive : i);
			a.weight = this._weight, a.playOrder = this._playOrder, a.onAnimationEnd = () => {
				this.onAnimationEndObservable.notifyObservers(r), this._checkAnimationGroupEnded(a);
			}, this._processLoop(a, r, n), this._animatables.push(a), this._usesVirtualSampling && this._isTargetRetainedByMask(a.target) && a.goToFrame(c);
		}
		return this.syncWithMask(), this._scene.sortActiveAnimatables(), this._speedRatio = t, this._isStarted = !0, this._isPaused = !1, this._usesVirtualSampling && (this._virtualSamplingObserver = this._scene.onAfterAnimationsObservable.add(() => {
			this._sampleVirtualTimeline();
		})), this.onAnimationGroupPlayObservable.notifyObservers(this), this;
	}
	pause() {
		if (!this._isStarted) return this;
		this._updateVirtualFrame(), this._isPaused = !0;
		for (let e = 0; e < this._animatables.length; e++) this._animatables[e].pause();
		return this.onAnimationGroupPauseObservable.notifyObservers(this), this;
	}
	play(e) {
		return this.isStarted && this._animatables.length && !this._shouldStart ? (e !== void 0 && (this.loopAnimation = e), this.restart()) : (this.stop(), this.start(e, this._speedRatio)), this;
	}
	reset() {
		if (!this._isStarted) return this.play(), this.goToFrame(0), this.stop(!0), this;
		for (let e = 0; e < this._animatables.length; e++) this._animatables[e].reset();
		return this._virtualFrame = this._usesVirtualSampling ? this._virtualFrameInitial : this._animatables[0]?.fromFrame ?? 0, this._virtualFrameStart = this._virtualFrame, this._virtualFrameStartTime = this._scene._animationTime, this._usesVirtualSampling && (this._retainedCurrentFrame = this._mapVirtualFrame(this._virtualFrame), this._goToFrameWithMask(this._retainedCurrentFrame)), this;
	}
	restart() {
		if (!this._isStarted) return this;
		for (let e = 0; e < this._animatables.length; e++) this._animatables[e].restart();
		return this.syncWithMask(), this._virtualFrameStart = this._virtualFrame, this._virtualFrameStartTime = this._scene._animationTime, this._isPaused = !1, this.onAnimationGroupPlayObservable.notifyObservers(this), this;
	}
	stop(e = !1) {
		if (!this._isStarted) return this;
		this._animatables[0] && (this._retainedCurrentFrame = this._animatables[0].masterFrame), this._updateVirtualFrame(), this._removeVirtualSamplingObserver(), this._isStopping = !0;
		let t = this._animatables.slice();
		for (let n = 0; n < t.length; n++) t[n].stop(void 0, void 0, !0, e);
		let n = 0;
		for (let t = 0; t < this._scene._activeAnimatables.length; t++) {
			let r = this._scene._activeAnimatables[t];
			r._runtimeAnimations.length > 0 ? this._scene._activeAnimatables[n++] = r : e && this._checkAnimationGroupEnded(r, e);
		}
		return this._scene._activeAnimatables.length = n, this._isStarted = !1, this._isStopping = !1, this._usesVirtualSampling = !1, this;
	}
	setWeightForAllAnimatables(e) {
		for (let t = 0; t < this._animatables.length; t++) {
			let n = this._animatables[t];
			n.weight = e;
		}
		return this;
	}
	syncAllAnimationsWith(e) {
		for (let t = 0; t < this._animatables.length; t++) this._animatables[t].syncWith(e);
		return this;
	}
	goToFrame(e, t = !1) {
		if (!this._isStarted) return this;
		for (let n = 0; n < this._animatables.length; n++) this._animatables[n].goToFrame(e, t);
		return this;
	}
	getCurrentFrame() {
		return this.animatables[0]?.masterFrame || 0;
	}
	getRetainedCurrentFrame() {
		return this.animatables[0] && (this._retainedCurrentFrame = this.animatables[0].masterFrame), this._retainedCurrentFrame;
	}
	getVirtualCurrentFrame() {
		return this._updateVirtualFrame(), this._virtualFrame;
	}
	isVirtualFrameReached(e) {
		let t = this.getVirtualCurrentFrame();
		return this._virtualFrameDirection > 0 ? t >= e : t <= e;
	}
	isValidVirtualStopFrame(e) {
		return this._virtualFrameDirection > 0 ? e >= this._virtualFrameInitial && e < this._virtualFrameEnd : e <= this._virtualFrameInitial && e > this._virtualFrameEnd;
	}
	setVirtualCurrentFrame(e) {
		this._virtualFrame = e, this._virtualFrameStart = e, this._virtualFrameStartTime = this._scene._animationTime, this._retainedCurrentFrame = this._mapVirtualFrame(e), this._goToFrameWithMask(this._retainedCurrentFrame);
	}
	_updateVirtualFrame() {
		if (!this._isStarted || this._isPaused) return;
		let e = (this._scene._animationTime - this._virtualFrameStartTime) / 1e3;
		this._virtualFrame = this._virtualFrameStart + e * this._virtualFrameRate * this._speedRatio * this._virtualFrameDirection;
	}
	_sampleVirtualTimeline() {
		this._updateVirtualFrame(), !this._loopAnimation && Number.isFinite(this._virtualFrameEnd) && (this._virtualFrameDirection > 0 ? this._virtualFrame >= this._virtualFrameEnd : this._virtualFrame <= this._virtualFrameEnd) ? (this.setVirtualCurrentFrame(this._virtualFrameEnd), this._removeVirtualSamplingObserver(), this.stop()) : (this._retainedCurrentFrame = this._mapVirtualFrame(this._virtualFrame), this._goToFrameWithMask(this._retainedCurrentFrame));
	}
	_goToFrameWithMask(e) {
		for (let t = 0; t < this._animatables.length; t++) {
			let n = this._animatables[t];
			this._isTargetRetainedByMask(n.target) && n.goToFrame(e);
		}
	}
	_isTargetRetainedByMask(e) {
		return !this._mask || this._mask.disabled || this._mask.retainsTarget(e.name);
	}
	_removeVirtualSamplingObserver() {
		this._virtualSamplingObserver &&= (this._scene.onAfterAnimationsObservable.remove(this._virtualSamplingObserver), null);
	}
	_mapVirtualFrame(e) {
		let t = this._to;
		return t === 0 ? 0 : !Number.isFinite(e) || !Number.isFinite(t) || t < 0 ? e : e - (e > 0 ? Math.ceil((e - t) / t) : Math.floor(e / t)) * t;
	}
	dispose() {
		if (this.isStarted && this.stop(), this._targetedAnimations.length = 0, this._animatables.length = 0, this._scene.removeAnimationGroup(this), this._parentContainer) {
			let e = this._parentContainer.animationGroups.indexOf(this);
			e > -1 && this._parentContainer.animationGroups.splice(e, 1), this._parentContainer = null;
		}
		this.onAnimationEndObservable.clear(), this.onAnimationGroupEndObservable.clear(), this.onAnimationGroupPauseObservable.clear(), this.onAnimationGroupPlayObservable.clear(), this.onAnimationLoopObservable.clear(), this.onAnimationGroupLoopObservable.clear();
	}
	_checkAnimationGroupEnded(e, t = !1) {
		this._updateVirtualFrame(), !t && !this._isStopping && (this._retainedCurrentFrame = e.masterFrame);
		let n = this._animatables.indexOf(e);
		n > -1 && this._animatables.splice(n, 1), this._animatables.length === this._targetedAnimations.length - this._numActiveAnimatables && (!t && !this._isStopping && Number.isFinite(this._virtualFrameEnd) && (this._virtualFrame = this._virtualFrameEnd, this._retainedCurrentFrame = this._mapVirtualFrame(this._virtualFrameEnd)), this._isStarted = !1, t || this.onAnimationGroupEndObservable.notifyObservers(this), this._animatables.length = 0);
	}
	clone(t, n, r = !1, i = !1) {
		let a = new e(t || this.name, this._scene, this._weight, this._playOrder);
		a._from = this.from, a._to = this.to, a._speedRatio = this.speedRatio, a._loopAnimation = this.loopAnimation, a._isAdditive = this.isAdditive, a._enableBlending = this.enableBlending, a._blendingSpeed = this.blendingSpeed, a.metadata = this.metadata, a.mask = this.mask;
		for (let e of this._targetedAnimations) a.addTargetedAnimation(r ? e.animation.clone(i) : e.animation, n ? n(e.target) : e.target);
		return a;
	}
	serialize() {
		let e = {};
		e.name = this.name, e.from = this.from, e.to = this.to, e.speedRatio = this.speedRatio, e.loopAnimation = this.loopAnimation, e.isAdditive = this.isAdditive, e.weight = this.weight, e.playOrder = this.playOrder, e.enableBlending = this.enableBlending, e.blendingSpeed = this.blendingSpeed, e.targetedAnimations = [];
		for (let t = 0; t < this.targetedAnimations.length; t++) {
			let n = this.targetedAnimations[t];
			e.targetedAnimations[t] = n.serialize();
		}
		return i && i.HasTags(this) && (e.tags = i.GetTags(this)), this.metadata && (e.metadata = this.metadata), e;
	}
	getClassName() {
		return "AnimationGroup";
	}
	toString(e) {
		let t = "Name: " + this.name;
		return t += ", type: " + this.getClassName(), e && (t += ", from: " + this._from, t += ", to: " + this._to, t += ", isStarted: " + this._isStarted, t += ", speedRatio: " + this._speedRatio, t += ", targetedAnimations length: " + this._targetedAnimations.length, t += ", animatables length: " + this._animatables.length), t;
	}
};
function d(e, t = !0, n = !1, r) {
	if (e.length === 0) return null;
	r ??= e[0].weight;
	let i = Number.MAX_VALUE, a = -Number.MAX_VALUE;
	if (n) for (let t of e) t.from < i && (i = t.from), t.to > a && (a = t.to);
	let o = new u(e[0].name + "_merged", e[0].getScene(), r);
	for (let r of e) {
		n && r.normalize(i, a);
		for (let e of r.targetedAnimations) o.addTargetedAnimation(e.animation, e.target);
		t && r.dispose();
	}
	return o;
}
function f(e, t, n) {
	let r = new u(e.name, t, e.weight, e.playOrder), o = r;
	for (let i = 0; i < e.targetedAnimations.length; i++) {
		let o = e.targetedAnimations[i], s = a(o.animation), c = n ? n(o) : o.animation.property === "influence" ? t.getMorphTargetById(o.targetId) : t.getNodeById(o.targetId);
		c && r.addTargetedAnimation(s, c);
	}
	return i && i.AddTagsTo(r, e.tags), e.from !== null && e.to !== null && r.normalize(e.from, e.to), e.speedRatio !== void 0 && (o._speedRatio = e.speedRatio), e.loopAnimation !== void 0 && (o._loopAnimation = e.loopAnimation), e.isAdditive !== void 0 && (o._isAdditive = e.isAdditive), e.weight !== void 0 && (o._weight = e.weight), e.playOrder !== void 0 && (o._playOrder = e.playOrder), e.enableBlending !== void 0 && (o._enableBlending = e.enableBlending), e.blendingSpeed !== void 0 && (o._blendingSpeed = e.blendingSpeed), e.metadata !== void 0 && (r.metadata = e.metadata), r;
}
function p(e, t, n, r = !1, i) {
	let a;
	a = typeof t == "object" ? t : {
		referenceFrame: t,
		range: n,
		cloneOriginalAnimationGroup: r,
		clonedAnimationName: i
	};
	let s = e;
	a.cloneOriginalAnimationGroup && (s = e.clone(a.clonedAnimationGroupName || s.name));
	let c = s.targetedAnimations;
	for (let e = 0; e < c.length; e++) {
		let t = c[e];
		t.animation = o(t.animation, a);
	}
	if (s.isAdditive = !0, a.clipKeys) {
		let e = Number.MAX_VALUE, t = -Number.MAX_VALUE, n = s.targetedAnimations;
		for (let r = 0; r < n.length; r++) {
			let i = n[r].animation.getKeys();
			e > i[0].frame && (e = i[0].frame), t < i[i.length - 1].frame && (t = i[i.length - 1].frame);
		}
		let r = s;
		r._from = e, r._to = t;
	}
	return s;
}
function m(e, t, n, r, i) {
	return h(e.clone(r || e.name), t, n, i);
}
function h(e, t, n, r) {
	return v(e, t, n, r, !1);
}
function g(e, t, n, r, i) {
	return _(e.clone(r || e.name), t, n, i);
}
function _(e, t, n, r) {
	return v(e, t, n, r, !0);
}
function v(e, t, n, r, i = !1) {
	let a = Number.MAX_VALUE, o = -Number.MAX_VALUE, s = e.targetedAnimations;
	for (let e = 0; e < s.length; e++) {
		let c = s[e], l = r ? c.animation : c.animation.clone();
		i && (l.createKeyForFrame(t), l.createKeyForFrame(n));
		let u = l.getKeys(), d = [], f = Number.MAX_VALUE;
		for (let e = 0; e < u.length; e++) {
			let r = u[e];
			if (!i && e >= t && e <= n || i && r.frame >= t && r.frame <= n) {
				let e = {
					frame: r.frame,
					value: r.value.clone ? r.value.clone() : r.value,
					inTangent: r.inTangent,
					outTangent: r.outTangent,
					interpolation: r.interpolation,
					lockedTangent: r.lockedTangent
				};
				f === Number.MAX_VALUE && (f = e.frame), e.frame -= f, d.push(e);
			}
		}
		d.length === 0 ? (s.splice(e, 1), e--) : (a > d[0].frame && (a = d[0].frame), o < d[d.length - 1].frame && (o = d[d.length - 1].frame), l.setKeys(d, !0), c.animation = l);
	}
	let c = e;
	return c._from = a, c._to = o, e;
}
var y = !1;
function b() {
	y || (y = !0, u.MergeAnimationGroups = d, u.Parse = f, u.MakeAnimationAdditive = p, u.ClipKeys = m, u.ClipKeysInPlace = h, u.ClipFrames = g, u.ClipFramesInPlace = _, u.ClipInPlace = v);
}
//#endregion
export { c as n, u as t };
