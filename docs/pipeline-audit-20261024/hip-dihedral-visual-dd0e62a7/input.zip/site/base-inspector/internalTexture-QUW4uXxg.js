import { n as e } from "./engineStore-D0BoPdea.js";
//#region node_modules/@babylonjs/core/Materials/Textures/textureSampler.js
var t = class {
	get wrapU() {
		return this._cachedWrapU;
	}
	set wrapU(e) {
		this._cachedWrapU = e;
	}
	get wrapV() {
		return this._cachedWrapV;
	}
	set wrapV(e) {
		this._cachedWrapV = e;
	}
	get wrapR() {
		return this._cachedWrapR;
	}
	set wrapR(e) {
		this._cachedWrapR = e;
	}
	get anisotropicFilteringLevel() {
		return this._cachedAnisotropicFilteringLevel;
	}
	set anisotropicFilteringLevel(e) {
		this._cachedAnisotropicFilteringLevel = e;
	}
	get comparisonFunction() {
		return this._comparisonFunction;
	}
	set comparisonFunction(e) {
		this._comparisonFunction = e;
	}
	get useMipMaps() {
		return this._useMipMaps;
	}
	set useMipMaps(e) {
		this._useMipMaps = e;
	}
	constructor() {
		this.samplingMode = -1, this._useMipMaps = !0, this._cachedWrapU = null, this._cachedWrapV = null, this._cachedWrapR = null, this._cachedAnisotropicFilteringLevel = null, this._comparisonFunction = 0;
	}
	setParameters(e = 1, t = 1, n = 1, r = 1, i = 2, a = 0) {
		return this._cachedWrapU = e, this._cachedWrapV = t, this._cachedWrapR = n, this._cachedAnisotropicFilteringLevel = r, this.samplingMode = i, this._comparisonFunction = a, this;
	}
	compareSampler(e) {
		return this._cachedWrapU === e._cachedWrapU && this._cachedWrapV === e._cachedWrapV && this._cachedWrapR === e._cachedWrapR && this._cachedAnisotropicFilteringLevel === e._cachedAnisotropicFilteringLevel && this.samplingMode === e.samplingMode && this._comparisonFunction === e._comparisonFunction && this._useMipMaps === e._useMipMaps;
	}
}, n;
(function(e) {
	e[e.Unknown = 0] = "Unknown", e[e.Url = 1] = "Url", e[e.Temp = 2] = "Temp", e[e.Raw = 3] = "Raw", e[e.Dynamic = 4] = "Dynamic", e[e.RenderTarget = 5] = "RenderTarget", e[e.MultiRenderTarget = 6] = "MultiRenderTarget", e[e.Cube = 7] = "Cube", e[e.CubeRaw = 8] = "CubeRaw", e[e.CubePrefiltered = 9] = "CubePrefiltered", e[e.Raw3D = 10] = "Raw3D", e[e.Raw2DArray = 11] = "Raw2DArray", e[e.DepthStencil = 12] = "DepthStencil", e[e.CubeRawRGBD = 13] = "CubeRawRGBD", e[e.Depth = 14] = "Depth", e[e.External = 15] = "External";
})(n ||= {});
var r = class n extends t {
	get useMipMaps() {
		return this._useMipMaps === null ? this.generateMipMaps : this._useMipMaps;
	}
	set useMipMaps(e) {
		this._useMipMaps = e;
	}
	get uniqueId() {
		return this._uniqueId;
	}
	_setUniqueId(e) {
		this._uniqueId = e;
	}
	getEngine() {
		return this._engine;
	}
	get source() {
		return this._source;
	}
	constructor(t, r, i = !1) {
		super(), this.isReady = !1, this.isCube = !1, this.is3D = !1, this.is2DArray = !1, this.isMultiview = !1, this.url = "", this.generateMipMaps = !1, this._useMipMaps = null, this.mipLevelCount = 1, this.samples = 0, this.type = -1, this.format = -1, this.onLoadedObservable = new e(), this.onErrorObservable = new e(), this._loadError = null, this.onRebuildCallback = null, this.width = 0, this.height = 0, this.depth = 0, this.baseWidth = 0, this.baseHeight = 0, this.baseDepth = 0, this.invertY = !1, this._invertVScale = !1, this._associatedChannel = -1, this._source = 0, this._buffer = null, this._bufferView = null, this._bufferViewArray = null, this._bufferViewArrayArray = null, this._size = 0, this._extension = "", this._files = null, this._workingCanvas = null, this._workingContext = null, this._cachedCoordinatesMode = null, this._isDisabled = !1, this._compression = null, this._sphericalPolynomial = null, this._sphericalPolynomialPromise = null, this._sphericalPolynomialComputed = !1, this._lodGenerationScale = 0, this._lodGenerationOffset = 0, this._useSRGBBuffer = !1, this._creationFlags = 0, this._lodTextureHigh = null, this._lodTextureMid = null, this._lodTextureLow = null, this._isRGBD = !1, this._linearSpecularLOD = !1, this._irradianceTexture = null, this._hardwareTexture = null, this._maxLodLevel = null, this._references = 1, this._gammaSpace = null, this._premulAlpha = !1, this._dynamicTextureSource = null, this._autoMSAAManagement = !1, this._engine = t, this._source = r, this._uniqueId = n._Counter++, i || (this._hardwareTexture = t._createHardwareTexture());
	}
	incrementReferences() {
		this._references++;
	}
	_setError(e, t) {
		this._loadError = {
			message: e,
			exception: t
		}, this.onErrorObservable.notifyObservers(this._loadError);
	}
	updateSize(e, t, n = 1) {
		this._engine.updateTextureDimensions(this, e, t, n), this.width = e, this.height = t, this.depth = n, this.baseWidth = e, this.baseHeight = t, this.baseDepth = n, this._size = e * t * n;
	}
	_rebuild() {
		if (this.isReady = !1, this._cachedCoordinatesMode = null, this._cachedWrapU = null, this._cachedWrapV = null, this._cachedWrapR = null, this._cachedAnisotropicFilteringLevel = null, this.onRebuildCallback) {
			let e = this.onRebuildCallback(this), t = (t) => {
				t._swapAndDie(this, !1), this.isReady = e.isReady;
			};
			e.isAsync ? e.proxy.then(t) : t(e.proxy);
			return;
		}
		let e;
		switch (this.source) {
			case 2: break;
			case 1:
				e = this._engine.createTexture(this._originalUrl ?? this.url, !this.generateMipMaps, this.invertY, null, this.samplingMode, (e) => {
					e._swapAndDie(this, !1), this.isReady = !0;
				}, null, this._buffer, void 0, this.format, this._extension, void 0, void 0, void 0, this._useSRGBBuffer);
				return;
			case 3:
				if (e = this._engine.createRawTexture(this._bufferView, this.baseWidth, this.baseHeight, this.format, this.generateMipMaps, this.invertY, this.samplingMode, this._compression, this.type, this._creationFlags, this._useSRGBBuffer, this.mipLevelCount), e._swapAndDie(this, !1), this._bufferViewArray) for (let e = 0; e < this._bufferViewArray.length; e++) {
					let t = this._bufferViewArray[e];
					t && this._engine.updateRawTexture(this, t, this.format, this.invertY, this._compression, this.type, this._useSRGBBuffer, e);
				}
				this.isReady = !0;
				break;
			case 10:
				e = this._engine.createRawTexture3D(this._bufferView, this.baseWidth, this.baseHeight, this.baseDepth, this.format, this.generateMipMaps, this.invertY, this.samplingMode, this._compression, this.type), e._swapAndDie(this, !1), this.isReady = !0;
				break;
			case 11:
				if (e = this._engine.createRawTexture2DArray(this._bufferView, this.baseWidth, this.baseHeight, this.baseDepth, this.format, this.generateMipMaps, this.invertY, this.samplingMode, this._compression, this.type, this._creationFlags, this.mipLevelCount), e._swapAndDie(this, !1), this._bufferViewArray) for (let e = 0; e < this._bufferViewArray.length; e++) {
					let t = this._bufferViewArray[e];
					t && this._engine.updateRawTexture2DArray(this, t, this.format, this.invertY, this._compression, this.type, e);
				}
				this.isReady = !0;
				break;
			case 4:
				e = this._engine.createDynamicTexture(this.baseWidth, this.baseHeight, this.generateMipMaps, this.samplingMode), e._swapAndDie(this, !1), this._dynamicTextureSource && this._engine.updateDynamicTexture(this, this._dynamicTextureSource, this.invertY, this._premulAlpha, this.format, !0);
				break;
			case 7:
				e = this._engine.createCubeTexture(this.url, null, this._files, !this.generateMipMaps, () => {
					e._swapAndDie(this, !1), this.isReady = !0;
				}, null, this.format, this._extension, !1, 0, 0, null, void 0, this._useSRGBBuffer, ArrayBuffer.isView(this._buffer) ? this._buffer : null);
				return;
			case 8:
				e = this._engine.createRawCubeTexture(this._bufferViewArray, this.width, this._originalFormat ?? this.format, this.type, this.generateMipMaps, this.invertY, this.samplingMode, this._compression), e._swapAndDie(this, !1), this.isReady = !0;
				break;
			case 13: return;
			case 9:
				e = this._engine.createPrefilteredCubeTexture(this.url, null, this._lodGenerationScale, this._lodGenerationOffset, (e) => {
					e && e._swapAndDie(this, !1), this.isReady = !0;
				}, null, this.format, this._extension, void 0, ArrayBuffer.isView(this._buffer) ? this._buffer : null), e._sphericalPolynomial = this._sphericalPolynomial;
				return;
		}
	}
	_swapAndDie(e, t = !0) {
		this._hardwareTexture?.setUsage(e._source, this.generateMipMaps, this.is2DArray, this.isCube, this.is3D, this.width, this.height, this.depth), e._hardwareTexture = this._hardwareTexture, e._setUniqueId(n._Counter++), t && (e._isRGBD = this._isRGBD), this._lodTextureHigh && (e._lodTextureHigh && e._lodTextureHigh.dispose(), e._lodTextureHigh = this._lodTextureHigh), this._lodTextureMid && (e._lodTextureMid && e._lodTextureMid.dispose(), e._lodTextureMid = this._lodTextureMid), this._lodTextureLow && (e._lodTextureLow && e._lodTextureLow.dispose(), e._lodTextureLow = this._lodTextureLow), this._irradianceTexture && (e._irradianceTexture && e._irradianceTexture.dispose(), e._irradianceTexture = this._irradianceTexture);
		let r = this._engine.getLoadedTexturesCache(), i = r.indexOf(this);
		i !== -1 && r.splice(i, 1), i = r.indexOf(e), i === -1 && r.push(e);
	}
	dispose() {
		this._references--, this._references === 0 && (this.onLoadedObservable.clear(), this.onErrorObservable.clear(), this._engine._releaseTexture(this), this._hardwareTexture = null, this._dynamicTextureSource = null);
	}
};
r._Counter = 0;
//#endregion
export { r as t };
