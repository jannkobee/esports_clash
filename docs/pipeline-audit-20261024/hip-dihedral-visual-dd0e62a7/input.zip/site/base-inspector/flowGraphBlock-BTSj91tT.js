import { n as e } from "./engineStore-D0BoPdea.js";
import { t } from "./logger-DQIzSR_y.js";
import { a as n, d as r, l as i, n as a, o, t as s, u as c } from "./math.color.pure-CPmbqLkh.js";
import { t as l } from "./guid-DXeovnrE.js";
import { t as u } from "./flowGraphInteger.pure-DqL1vt3x.js";
//#region node_modules/@babylonjs/core/FlowGraph/CustomTypes/flowGraphMatrix.js
var d = class e {
	constructor(e = [
		1,
		0,
		0,
		1
	]) {
		this._m = e;
	}
	clone() {
		return new e(this._m.slice());
	}
	get m() {
		return this._m;
	}
	transformVector(e) {
		return this.transformVectorToRef(e, new i());
	}
	transformVectorToRef(e, t) {
		return t.x = e.x * this._m[0] + e.y * this._m[2], t.y = e.x * this._m[1] + e.y * this._m[3], t;
	}
	asArray() {
		return this.toArray();
	}
	toArray(e = []) {
		for (let t = 0; t < 4; t++) e[t] = this._m[t];
		return e;
	}
	fromArray(e) {
		for (let t = 0; t < 4; t++) this._m[t] = e[t];
		return this;
	}
	multiplyToRef(e, t) {
		let n = e._m, r = this._m, i = t._m;
		return i[0] = r[0] * n[0] + r[1] * n[2], i[1] = r[0] * n[1] + r[1] * n[3], i[2] = r[2] * n[0] + r[3] * n[2], i[3] = r[2] * n[1] + r[3] * n[3], t;
	}
	multiply(t) {
		return this.multiplyToRef(t, new e());
	}
	divideToRef(e, t) {
		let n = this._m, r = e._m, i = t._m;
		return i[0] = n[0] / r[0], i[1] = n[1] / r[1], i[2] = n[2] / r[2], i[3] = n[3] / r[3], t;
	}
	divide(t) {
		return this.divideToRef(t, new e());
	}
	addToRef(e, t) {
		let n = this._m, r = e.m, i = t.m;
		return i[0] = n[0] + r[0], i[1] = n[1] + r[1], i[2] = n[2] + r[2], i[3] = n[3] + r[3], t;
	}
	add(t) {
		return this.addToRef(t, new e());
	}
	subtractToRef(e, t) {
		let n = this._m, r = e.m, i = t.m;
		return i[0] = n[0] - r[0], i[1] = n[1] - r[1], i[2] = n[2] - r[2], i[3] = n[3] - r[3], t;
	}
	subtract(t) {
		return this.subtractToRef(t, new e());
	}
	transpose() {
		let t = this._m;
		return new e([
			t[0],
			t[2],
			t[1],
			t[3]
		]);
	}
	determinant() {
		let e = this._m;
		return e[0] * e[3] - e[1] * e[2];
	}
	inverse() {
		let t = this.determinant();
		if (t === 0) throw Error("Matrix is not invertible");
		let n = this._m, r = 1 / t;
		return new e([
			n[3] * r,
			-n[1] * r,
			-n[2] * r,
			n[0] * r
		]);
	}
	equals(e, t = 0) {
		let n = this._m, r = e.m;
		return t === 0 ? n[0] === r[0] && n[1] === r[1] && n[2] === r[2] && n[3] === r[3] : Math.abs(n[0] - r[0]) < t && Math.abs(n[1] - r[1]) < t && Math.abs(n[2] - r[2]) < t && Math.abs(n[3] - r[3]) < t;
	}
	getClassName() {
		return "FlowGraphMatrix2D";
	}
	toString() {
		return `FlowGraphMatrix2D(${this._m.join(", ")})`;
	}
}, f = class e {
	constructor(e = [
		1,
		0,
		0,
		0,
		1,
		0,
		0,
		0,
		1
	]) {
		this._m = e;
	}
	clone() {
		return new e(this._m.slice());
	}
	get m() {
		return this._m;
	}
	transformVector(e) {
		return this.transformVectorToRef(e, new c());
	}
	transformVectorToRef(e, t) {
		let n = this._m;
		return t.x = e.x * n[0] + e.y * n[3] + e.z * n[6], t.y = e.x * n[1] + e.y * n[4] + e.z * n[7], t.z = e.x * n[2] + e.y * n[5] + e.z * n[8], t;
	}
	multiplyToRef(e, t) {
		let n = e._m, r = this._m, i = t.m;
		return i[0] = r[0] * n[0] + r[1] * n[3] + r[2] * n[6], i[1] = r[0] * n[1] + r[1] * n[4] + r[2] * n[7], i[2] = r[0] * n[2] + r[1] * n[5] + r[2] * n[8], i[3] = r[3] * n[0] + r[4] * n[3] + r[5] * n[6], i[4] = r[3] * n[1] + r[4] * n[4] + r[5] * n[7], i[5] = r[3] * n[2] + r[4] * n[5] + r[5] * n[8], i[6] = r[6] * n[0] + r[7] * n[3] + r[8] * n[6], i[7] = r[6] * n[1] + r[7] * n[4] + r[8] * n[7], i[8] = r[6] * n[2] + r[7] * n[5] + r[8] * n[8], t;
	}
	multiply(t) {
		return this.multiplyToRef(t, new e());
	}
	divideToRef(e, t) {
		let n = this._m, r = e.m, i = t.m;
		return i[0] = n[0] / r[0], i[1] = n[1] / r[1], i[2] = n[2] / r[2], i[3] = n[3] / r[3], i[4] = n[4] / r[4], i[5] = n[5] / r[5], i[6] = n[6] / r[6], i[7] = n[7] / r[7], i[8] = n[8] / r[8], t;
	}
	divide(t) {
		return this.divideToRef(t, new e());
	}
	addToRef(e, t) {
		let n = this._m, r = e.m, i = t.m;
		return i[0] = n[0] + r[0], i[1] = n[1] + r[1], i[2] = n[2] + r[2], i[3] = n[3] + r[3], i[4] = n[4] + r[4], i[5] = n[5] + r[5], i[6] = n[6] + r[6], i[7] = n[7] + r[7], i[8] = n[8] + r[8], t;
	}
	add(t) {
		return this.addToRef(t, new e());
	}
	subtractToRef(e, t) {
		let n = this._m, r = e.m, i = t.m;
		return i[0] = n[0] - r[0], i[1] = n[1] - r[1], i[2] = n[2] - r[2], i[3] = n[3] - r[3], i[4] = n[4] - r[4], i[5] = n[5] - r[5], i[6] = n[6] - r[6], i[7] = n[7] - r[7], i[8] = n[8] - r[8], t;
	}
	subtract(t) {
		return this.subtractToRef(t, new e());
	}
	toArray(e = []) {
		for (let t = 0; t < 9; t++) e[t] = this._m[t];
		return e;
	}
	asArray() {
		return this.toArray();
	}
	fromArray(e) {
		for (let t = 0; t < 9; t++) this._m[t] = e[t];
		return this;
	}
	transpose() {
		let t = this._m;
		return new e([
			t[0],
			t[3],
			t[6],
			t[1],
			t[4],
			t[7],
			t[2],
			t[5],
			t[8]
		]);
	}
	determinant() {
		let e = this._m;
		return e[0] * (e[4] * e[8] - e[5] * e[7]) - e[1] * (e[3] * e[8] - e[5] * e[6]) + e[2] * (e[3] * e[7] - e[4] * e[6]);
	}
	inverse() {
		let t = this.determinant();
		if (t === 0) throw Error("Matrix is not invertible");
		let n = this._m, r = 1 / t;
		return new e([
			(n[4] * n[8] - n[5] * n[7]) * r,
			(n[2] * n[7] - n[1] * n[8]) * r,
			(n[1] * n[5] - n[2] * n[4]) * r,
			(n[5] * n[6] - n[3] * n[8]) * r,
			(n[0] * n[8] - n[2] * n[6]) * r,
			(n[2] * n[3] - n[0] * n[5]) * r,
			(n[3] * n[7] - n[4] * n[6]) * r,
			(n[1] * n[6] - n[0] * n[7]) * r,
			(n[0] * n[4] - n[1] * n[3]) * r
		]);
	}
	equals(e, t = 0) {
		let n = this._m, r = e.m;
		return t === 0 ? n[0] === r[0] && n[1] === r[1] && n[2] === r[2] && n[3] === r[3] && n[4] === r[4] && n[5] === r[5] && n[6] === r[6] && n[7] === r[7] && n[8] === r[8] : Math.abs(n[0] - r[0]) < t && Math.abs(n[1] - r[1]) < t && Math.abs(n[2] - r[2]) < t && Math.abs(n[3] - r[3]) < t && Math.abs(n[4] - r[4]) < t && Math.abs(n[5] - r[5]) < t && Math.abs(n[6] - r[6]) < t && Math.abs(n[7] - r[7]) < t && Math.abs(n[8] - r[8]) < t;
	}
	getClassName() {
		return "FlowGraphMatrix3D";
	}
	toString() {
		return `FlowGraphMatrix3D(${this._m.join(", ")})`;
	}
}, p = /* @__PURE__ */ new WeakMap();
function m(e) {
	return typeof e == "object" && e ? p.get(e) ?? 0 : 0;
}
function h(e) {
	return e === "Vector2" || e === "Vector3" || e === "Vector4" || e === "Quaternion" || e === "Color3" || e === "Color4";
}
function g(e) {
	return e === "Matrix" || e === "Matrix2D" || e === "Matrix3D";
}
function _(e) {
	return e === "AnimationGroup";
}
function v(e, t) {
	if (!e || !e.id && !e.name) return;
	let n = t.getNodes().filter((t) => e.id ? t.id === e.id : t.name === e.name);
	if (n.length === 0) return;
	let r = e.type ?? e.className, i = r ? n.filter((e) => e.getClassName() === r) : [], a = i.length > 0 ? i : n;
	return (e.uniqueId ? a.find((t) => t.uniqueId === e.uniqueId) : void 0) ?? a[0];
}
function y(e, t, n = !1) {
	if (e === "Vector2") return i.FromArray(t);
	if (e === "Vector3") return n && (t[2] *= -1), c.FromArray(t);
	if (e === "Vector4") return r.FromArray(t);
	if (e === "Quaternion") return n && (t[2] *= -1, t[3] *= -1), o.FromArray(t);
	if (e === "Color3") return new s(t[0], t[1], t[2]);
	if (e === "Color4") return new a(t[0], t[1], t[2], t[3]);
	throw Error(`Unknown vector class name ${e}`);
}
function b(e, n, r) {
	let i = n?.getClassName?.() ?? "";
	if (h(i) || g(i)) r[e] = {
		value: n.asArray(),
		className: i
	};
	else if (i === "FlowGraphInteger") r[e] = {
		value: n.value,
		className: i
	};
	else if (i && (n.id || n.name)) r[e] = {
		id: n.id,
		name: n.name,
		className: i,
		uniqueId: n.uniqueId
	};
	else if (typeof n != "object" || !n) r[e] = n;
	else {
		if (e === "pathConverter" || Object.values(n).some((e) => typeof e == "function")) return;
		try {
			r[e] = JSON.parse(JSON.stringify(n));
		} catch {
			t.Warn(`FlowGraph serialization: value for key "${e}" is not JSON-serializable and was skipped.`);
		}
	}
}
function x(e, t, r, i) {
	let a = t[e], o, s = a?.type ?? a?.className, c = v(a, i);
	if (c) o = c;
	else if (h(s)) o = y(s, a.value);
	else if (_(s)) {
		let e = i.animationGroups.filter((e) => e.name === a.name);
		o = e.length === 1 ? e[0] : e.find((e) => e.uniqueId === a.uniqueId);
	} else s === "Matrix" ? o = n.FromArray(a.value) : s === "Matrix2D" ? o = new d(a.value) : s === "Matrix3D" ? o = new f(a.value) : s === "FlowGraphInteger" ? o = u.FromValue(a.value) : s === "number" || s === "string" || s === "boolean" ? o = a.value[0] : e === "eventData" && typeof a == "object" && a ? (p.set(a, m(a) + 1), o = a) : o = a && a.value !== void 0 ? a.value : a;
	return o;
}
function S(e) {
	return e === "FlowGraphJsonPointerParserBlock";
}
//#endregion
//#region node_modules/@babylonjs/core/FlowGraph/flowGraphConnection.js
var C;
(function(e) {
	e[e.Input = 0] = "Input", e[e.Output = 1] = "Output";
})(C ||= {});
var w = class {
	constructor(e, t, n) {
		this._ownerBlock = n, this._connectedPoint = [], this.uniqueId = l(), this.connectedPointIds = [], this.name = e, this._connectionType = t;
	}
	get connectionType() {
		return this._connectionType;
	}
	_isSingularConnection() {
		return !0;
	}
	isConnected() {
		return this._connectedPoint.length > 0;
	}
	connectTo(e) {
		if (this._connectionType === e._connectionType) throw Error(`Cannot connect two points of type ${this.connectionType}`);
		if (this._isSingularConnection() && this._connectedPoint.length > 0 || e._isSingularConnection() && e._connectedPoint.length > 0) throw Error("Max number of connections for point reached");
		this._connectedPoint.push(e), e._connectedPoint.push(this);
	}
	disconnectFrom(e, t = !0) {
		let n = this._connectedPoint.indexOf(e), r = e._connectedPoint.indexOf(this);
		n !== -1 && r !== -1 && (t && this._connectedPoint.splice(n, 1), e._connectedPoint.splice(r, 1));
	}
	disconnectFromAll() {
		for (let e of this._connectedPoint) this.disconnectFrom(e, !1);
		this._connectedPoint.length = 0;
	}
	dispose() {
		for (let e of this._connectedPoint) this.disconnectFrom(e);
	}
	serialize(e = {}) {
		e.uniqueId = this.uniqueId, e.name = this.name, e._connectionType = this._connectionType, e.connectedPointIds = [], e.className = this.getClassName(), this.metadata !== void 0 && (e.metadata = this.metadata);
		for (let t of this._connectedPoint) e.connectedPointIds.push(t.uniqueId);
	}
	getClassName() {
		return "FGConnection";
	}
	deserialize(e) {
		this.uniqueId = e.uniqueId, this.name = e.name, this._connectionType = e._connectionType, this.connectedPointIds = e.connectedPointIds, this.metadata = e.metadata;
	}
}, T = class extends w {
	constructor(t, n, r, i, a = i.defaultValue, o = !1) {
		super(t, n, r), this.richType = i, this._defaultValue = a, this._optional = o, this._isDisabled = !1, this._lastValue = null, this.dataTransformer = null, this.onValueChangedObservable = new e();
	}
	get optional() {
		return this._optional;
	}
	get isDisabled() {
		return this._isDisabled;
	}
	set isDisabled(e) {
		this._isDisabled !== e && (this._isDisabled = e, this._isDisabled && this.disconnectFromAll());
	}
	_isSingularConnection() {
		return this.connectionType === 0;
	}
	setValue(e, t) {
		t._getConnectionValue(this) !== e && (t._setConnectionValue(this, e), this.onValueChangedObservable.notifyObservers(e));
	}
	resetToDefaultValue(e) {
		e._setConnectionValue(this, this._defaultValue);
	}
	_reresolveDefaultValueForScene(e) {
		let t = this._defaultValue;
		if (!t || typeof t != "object") return;
		let n;
		if (typeof t.getClassName == "function" && typeof t.getScene == "function") {
			if (t.getScene() === e) return;
			n = {
				id: t.id,
				name: t.name,
				className: t.getClassName(),
				uniqueId: t.uniqueId
			};
		} else if (typeof t.className == "string" && (t.id || t.name) && t.value === void 0) n = t;
		else return;
		let r = v(n, e);
		r && (this._defaultValue = r);
	}
	connectTo(e) {
		this._isDisabled || super.connectTo(e);
	}
	_getValueOrDefault(e) {
		let t = e._getConnectionValue(this) ?? this._defaultValue;
		return this.dataTransformer ? this.dataTransformer(t) : t;
	}
	getValue(e) {
		if (this.connectionType === 1) {
			e._notifyExecuteNode(this._ownerBlock), this._ownerBlock._updateOutputs(e);
			let t = this._getValueOrDefault(e);
			return this._lastValue = t, this.richType.typeTransformer ? this.richType.typeTransformer(t) : t;
		}
		let t = this.isConnected() ? this._connectedPoint[0].getValue(e) : this._getValueOrDefault(e);
		return this._lastValue = t, this.richType.typeTransformer ? this.richType.typeTransformer(t) : t;
	}
	_getLastValue() {
		return this._lastValue;
	}
	getClassName() {
		return "FlowGraphDataConnection";
	}
	serialize(e = {}) {
		super.serialize(e), e.richType = {}, this.richType.serialize(e.richType), e.optional = this._optional, b("defaultValue", this._defaultValue, e);
	}
}, E = class {
	constructor(e) {
		this.config = e, this.uniqueId = l(), this.name = this.config?.name ?? this.getClassName(), this.dataInputs = [], this.dataOutputs = [];
	}
	_updateOutputs(e) {}
	registerDataInput(e, t, n) {
		let r = new T(e, 0, this, t, n);
		return this.dataInputs.push(r), r;
	}
	registerDataOutput(e, t, n) {
		let r = new T(e, 1, this, t, n);
		return this.dataOutputs.push(r), r;
	}
	getDataInput(e) {
		return this.dataInputs.find((t) => t.name === e);
	}
	getDataOutput(e) {
		return this.dataOutputs.find((t) => t.name === e);
	}
	serialize(e = {}, t = b) {
		if (e.uniqueId = this.uniqueId, this.metadata !== void 0 && (e.metadata = this.metadata), e.config = {}, this.config) {
			let n = this.config, r = Object.keys(n);
			for (let i of r) t(i, n[i], e.config);
		}
		e.dataInputs = [], e.dataOutputs = [], e.className = this.getClassName();
		for (let t of this.dataInputs) {
			let n = {};
			t.serialize(n), e.dataInputs.push(n);
		}
		for (let t of this.dataOutputs) {
			let n = {};
			t.serialize(n), e.dataOutputs.push(n);
		}
	}
	deserialize(e) {}
	_log(e, t, n) {
		e.logger?.addLogItem({
			action: t,
			payload: n,
			className: this.getClassName(),
			uniqueId: this.uniqueId
		});
	}
	getClassName() {
		return "FlowGraphBlock";
	}
};
//#endregion
export { b as a, f as c, x as i, w as n, S as o, m as r, d as s, E as t };
