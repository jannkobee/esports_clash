import { l as e } from "./math.color.pure-CPmbqLkh.js";
//#region node_modules/@babylonjs/core/Events/pointerEvents.js
var t = class {};
t.POINTERDOWN = 1, t.POINTERUP = 2, t.POINTERMOVE = 4, t.POINTERWHEEL = 8, t.POINTERPICK = 16, t.POINTERTAP = 32, t.POINTERDOUBLETAP = 64;
var n = class {
	constructor(e, t) {
		this.type = e, this.event = t;
	}
}, r = class extends n {
	constructor(t, n, r, i) {
		super(t, n), this.ray = null, this.originalPickingInfo = null, this.skipOnPointerObservable = !1, this.localPosition = new e(r, i);
	}
}, i = class extends n {
	get pickInfo() {
		return this._pickInfo || this._generatePickInfo(), this._pickInfo;
	}
	constructor(e, t, n, r = null) {
		super(e, t), this._pickInfo = n, this._inputManager = r;
	}
	_generatePickInfo() {
		this._inputManager &&= (this._pickInfo = this._inputManager._pickMove(this.event), this._inputManager._setRayOnPointerInfo(this._pickInfo, this.event), null);
	}
};
//#endregion
export { i as n, r, t };
