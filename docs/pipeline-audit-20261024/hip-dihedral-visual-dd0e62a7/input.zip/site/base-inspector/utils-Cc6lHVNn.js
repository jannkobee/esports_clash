import { r as e } from "./domManagement-BZa7OPDn.js";
//#region node_modules/@babylonjs/core/FlowGraph/utils.js
var t = e() && /(Mac|iPhone|iPod|iPad)/i.test(navigator.platform);
function n(e, t) {
	return !(!e.parent || e.parent !== t && !n(e.parent, t));
}
function r(e) {
	if (e.getClassName) return e.getClassName();
}
function i(e, t) {
	return e === t && (e === "Vector2" || e === "Vector3" || e === "Vector4" || e === "Quaternion");
}
function a(e, t) {
	return e === t && (e === "Matrix" || e === "Matrix2D" || e === "Matrix3D");
}
function o(e, t) {
	return e === "FlowGraphInteger" && t === "FlowGraphInteger";
}
function s(e, t) {
	let n = typeof e == "number" || typeof e?.value == "number";
	return n && !t ? !isNaN(c(e)) : n;
}
function c(e) {
	return typeof e == "number" ? e : e.value;
}
//#endregion
export { n as a, s as c, r as i, a as n, t as o, i as r, c as s, o as t };
