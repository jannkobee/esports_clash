import { c as e, u as t } from "./math.color.pure-CPmbqLkh.js";
//#region node_modules/@babylonjs/core/Maths/sphericalPolynomial.pure.js
var n = [
	Math.sqrt(1 / (4 * Math.PI)),
	-Math.sqrt(3 / (4 * Math.PI)),
	Math.sqrt(3 / (4 * Math.PI)),
	-Math.sqrt(3 / (4 * Math.PI)),
	Math.sqrt(15 / (4 * Math.PI)),
	-Math.sqrt(15 / (4 * Math.PI)),
	Math.sqrt(5 / (16 * Math.PI)),
	-Math.sqrt(15 / (4 * Math.PI)),
	Math.sqrt(15 / (16 * Math.PI))
], r = [
	() => 1,
	(e) => e.y,
	(e) => e.z,
	(e) => e.x,
	(e) => e.x * e.y,
	(e) => e.y * e.z,
	(e) => 3 * e.z * e.z - 1,
	(e) => e.x * e.z,
	(e) => e.x * e.x - e.y * e.y
], i = (e, t) => n[e] * r[e](t), a = [
	Math.PI,
	2 * Math.PI / 3,
	2 * Math.PI / 3,
	2 * Math.PI / 3,
	Math.PI / 4,
	Math.PI / 4,
	Math.PI / 4,
	Math.PI / 4,
	Math.PI / 4
], o = class r {
	constructor() {
		this.preScaled = !1, this.l00 = t.Zero(), this.l1_1 = t.Zero(), this.l10 = t.Zero(), this.l11 = t.Zero(), this.l2_2 = t.Zero(), this.l2_1 = t.Zero(), this.l20 = t.Zero(), this.l21 = t.Zero(), this.l22 = t.Zero();
	}
	addLight(t, n, r) {
		e.Vector3[0].set(n.r, n.g, n.b);
		let a = e.Vector3[0], o = e.Vector3[1];
		a.scaleToRef(r, o), o.scaleToRef(i(0, t), e.Vector3[2]), this.l00.addInPlace(e.Vector3[2]), o.scaleToRef(i(1, t), e.Vector3[2]), this.l1_1.addInPlace(e.Vector3[2]), o.scaleToRef(i(2, t), e.Vector3[2]), this.l10.addInPlace(e.Vector3[2]), o.scaleToRef(i(3, t), e.Vector3[2]), this.l11.addInPlace(e.Vector3[2]), o.scaleToRef(i(4, t), e.Vector3[2]), this.l2_2.addInPlace(e.Vector3[2]), o.scaleToRef(i(5, t), e.Vector3[2]), this.l2_1.addInPlace(e.Vector3[2]), o.scaleToRef(i(6, t), e.Vector3[2]), this.l20.addInPlace(e.Vector3[2]), o.scaleToRef(i(7, t), e.Vector3[2]), this.l21.addInPlace(e.Vector3[2]), o.scaleToRef(i(8, t), e.Vector3[2]), this.l22.addInPlace(e.Vector3[2]);
	}
	scaleInPlace(e) {
		this.l00.scaleInPlace(e), this.l1_1.scaleInPlace(e), this.l10.scaleInPlace(e), this.l11.scaleInPlace(e), this.l2_2.scaleInPlace(e), this.l2_1.scaleInPlace(e), this.l20.scaleInPlace(e), this.l21.scaleInPlace(e), this.l22.scaleInPlace(e);
	}
	convertIncidentRadianceToIrradiance() {
		this.l00.scaleInPlace(a[0]), this.l1_1.scaleInPlace(a[1]), this.l10.scaleInPlace(a[2]), this.l11.scaleInPlace(a[3]), this.l2_2.scaleInPlace(a[4]), this.l2_1.scaleInPlace(a[5]), this.l20.scaleInPlace(a[6]), this.l21.scaleInPlace(a[7]), this.l22.scaleInPlace(a[8]);
	}
	convertIrradianceToLambertianRadiance() {
		this.scaleInPlace(1 / Math.PI);
	}
	preScaleForRendering() {
		this.preScaled = !0, this.l00.scaleInPlace(n[0]), this.l1_1.scaleInPlace(n[1]), this.l10.scaleInPlace(n[2]), this.l11.scaleInPlace(n[3]), this.l2_2.scaleInPlace(n[4]), this.l2_1.scaleInPlace(n[5]), this.l20.scaleInPlace(n[6]), this.l21.scaleInPlace(n[7]), this.l22.scaleInPlace(n[8]);
	}
	updateFromArray(e) {
		return t.FromArrayToRef(e[0], 0, this.l00), t.FromArrayToRef(e[1], 0, this.l1_1), t.FromArrayToRef(e[2], 0, this.l10), t.FromArrayToRef(e[3], 0, this.l11), t.FromArrayToRef(e[4], 0, this.l2_2), t.FromArrayToRef(e[5], 0, this.l2_1), t.FromArrayToRef(e[6], 0, this.l20), t.FromArrayToRef(e[7], 0, this.l21), t.FromArrayToRef(e[8], 0, this.l22), this;
	}
	updateFromFloatsArray(e) {
		return t.FromFloatsToRef(e[0], e[1], e[2], this.l00), t.FromFloatsToRef(e[3], e[4], e[5], this.l1_1), t.FromFloatsToRef(e[6], e[7], e[8], this.l10), t.FromFloatsToRef(e[9], e[10], e[11], this.l11), t.FromFloatsToRef(e[12], e[13], e[14], this.l2_2), t.FromFloatsToRef(e[15], e[16], e[17], this.l2_1), t.FromFloatsToRef(e[18], e[19], e[20], this.l20), t.FromFloatsToRef(e[21], e[22], e[23], this.l21), t.FromFloatsToRef(e[24], e[25], e[26], this.l22), this;
	}
	static FromArray(e) {
		return new r().updateFromArray(e);
	}
	static FromPolynomial(e) {
		let t = new r();
		return t.l00 = e.xx.scale(.376127).add(e.yy.scale(.376127)).add(e.zz.scale(.376126)), t.l1_1 = e.y.scale(.977204), t.l10 = e.z.scale(.977204), t.l11 = e.x.scale(.977204), t.l2_2 = e.xy.scale(1.16538), t.l2_1 = e.yz.scale(1.16538), t.l20 = e.zz.scale(1.34567).subtract(e.xx.scale(.672834)).subtract(e.yy.scale(.672834)), t.l21 = e.zx.scale(1.16538), t.l22 = e.xx.scale(1.16538).subtract(e.yy.scale(1.16538)), t.l1_1.scaleInPlace(-1), t.l11.scaleInPlace(-1), t.l2_1.scaleInPlace(-1), t.l21.scaleInPlace(-1), t.scaleInPlace(Math.PI), t;
	}
}, s = class n {
	constructor() {
		this.x = t.Zero(), this.y = t.Zero(), this.z = t.Zero(), this.xx = t.Zero(), this.yy = t.Zero(), this.zz = t.Zero(), this.xy = t.Zero(), this.yz = t.Zero(), this.zx = t.Zero();
	}
	get preScaledHarmonics() {
		return this._harmonics ||= o.FromPolynomial(this), this._harmonics.preScaled || this._harmonics.preScaleForRendering(), this._harmonics;
	}
	addAmbient(t) {
		e.Vector3[0].copyFromFloats(t.r, t.g, t.b);
		let n = e.Vector3[0];
		this.xx.addInPlace(n), this.yy.addInPlace(n), this.zz.addInPlace(n);
	}
	scaleInPlace(e) {
		this.x.scaleInPlace(e), this.y.scaleInPlace(e), this.z.scaleInPlace(e), this.xx.scaleInPlace(e), this.yy.scaleInPlace(e), this.zz.scaleInPlace(e), this.yz.scaleInPlace(e), this.zx.scaleInPlace(e), this.xy.scaleInPlace(e);
	}
	updateFromHarmonics(t) {
		return this._harmonics = t, this.x.copyFrom(t.l11), this.x.scaleInPlace(1.02333).scaleInPlace(-1), this.y.copyFrom(t.l1_1), this.y.scaleInPlace(1.02333).scaleInPlace(-1), this.z.copyFrom(t.l10), this.z.scaleInPlace(1.02333), this.xx.copyFrom(t.l00), e.Vector3[0].copyFrom(t.l20).scaleInPlace(.247708), e.Vector3[1].copyFrom(t.l22).scaleInPlace(.429043), this.xx.scaleInPlace(.886277).subtractInPlace(e.Vector3[0]).addInPlace(e.Vector3[1]), this.yy.copyFrom(t.l00), this.yy.scaleInPlace(.886277).subtractInPlace(e.Vector3[0]).subtractInPlace(e.Vector3[1]), this.zz.copyFrom(t.l00), e.Vector3[0].copyFrom(t.l20).scaleInPlace(.495417), this.zz.scaleInPlace(.886277).addInPlace(e.Vector3[0]), this.yz.copyFrom(t.l2_1), this.yz.scaleInPlace(.858086).scaleInPlace(-1), this.zx.copyFrom(t.l21), this.zx.scaleInPlace(.858086).scaleInPlace(-1), this.xy.copyFrom(t.l2_2), this.xy.scaleInPlace(.858086), this.scaleInPlace(1 / Math.PI), this;
	}
	static FromHarmonics(e) {
		return new n().updateFromHarmonics(e);
	}
	static FromArray(e) {
		let r = new n();
		return t.FromArrayToRef(e[0], 0, r.x), t.FromArrayToRef(e[1], 0, r.y), t.FromArrayToRef(e[2], 0, r.z), t.FromArrayToRef(e[3], 0, r.xx), t.FromArrayToRef(e[4], 0, r.yy), t.FromArrayToRef(e[5], 0, r.zz), t.FromArrayToRef(e[6], 0, r.yz), t.FromArrayToRef(e[7], 0, r.zx), t.FromArrayToRef(e[8], 0, r.xy), r;
	}
};
//#endregion
export { s as n, o as t };
