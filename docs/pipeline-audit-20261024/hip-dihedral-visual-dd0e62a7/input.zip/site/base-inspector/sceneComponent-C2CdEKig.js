import { n as e } from "./engineStore-D0BoPdea.js";
import { r as t } from "./abstractEngine.pure-C608BZav.js";
import { n } from "./buffer.pure-CgsgX1aa.js";
import { a as r, f as i, p as a, u as o } from "./math.color.pure-CPmbqLkh.js";
import { n as s, t as c } from "./smartArray-BmGU7Yab.js";
import { n as l } from "./lightConstants-Dqs8OH2d.js";
//#region node_modules/@babylonjs/core/PostProcesses/postProcessManager.js
var u = class {
	constructor(t) {
		this._vertexBuffers = {}, this._activePostProcesses = [], this.onBeforeRenderObservable = new e(), this._scene = t;
	}
	_prepareBuffers() {
		if (this._vertexBuffers[n.PositionKind]) return;
		let e = [];
		e.push(1, 1), e.push(-1, 1), e.push(-1, -1), e.push(1, -1), this._vertexBuffers[n.PositionKind] = new n(this._scene.getEngine(), e, n.PositionKind, !1, !1, 2), this._buildIndexBuffer();
	}
	_buildIndexBuffer() {
		let e = [];
		e.push(0), e.push(1), e.push(2), e.push(0), e.push(2), e.push(3), this._indexBuffer = this._scene.getEngine().createIndexBuffer(e);
	}
	_getActivePostProcesses(e) {
		let t = this._activePostProcesses;
		t.length = 0;
		for (let n = 0; n < e.length; n++) {
			let r = e[n];
			r && t.push(r);
		}
		return t;
	}
	_rebuild() {
		let e = this._vertexBuffers[n.PositionKind];
		e && (e._rebuild(), this._buildIndexBuffer());
	}
	_prepareFrame(e = null, t = null) {
		let n = this._scene.activeCamera;
		return !n || (t ||= this._getActivePostProcesses(n._postProcesses), !t || t.length === 0 || !this._scene.postProcessesEnabled) ? !1 : (t[0].activate(n, e, t != null), !0);
	}
	directRender(e, t = null, n = !1, r = 0, i = 0, a = !1, o = e.length) {
		let s = this._scene.getEngine();
		for (let c = 0; c < o; c++) {
			c < e.length - 1 ? e[c + 1].activate(this._scene.activeCamera || this._scene, t?.texture) : (t ? s.bindFramebuffer(t, r, void 0, void 0, n, i) : a || s.restoreDefaultFramebuffer(), s._debugInsertMarker?.(`post process ${e[c].name} output`));
			let o = e[c], l = o.apply();
			l && (o.onBeforeRenderObservable.notifyObservers(l), this._prepareBuffers(), s.bindBuffers(this._vertexBuffers, this._indexBuffer, l), s.drawElementsType(0, 0, 6), o.onAfterRenderObservable.notifyObservers(l));
		}
		s.setDepthBuffer(!0), s.setDepthWrite(!0);
	}
	_finalizeFrame(e, t, n, r, i = !1) {
		let a = this._scene.activeCamera;
		if (!a || (this.onBeforeRenderObservable.notifyObservers(this), r ||= this._getActivePostProcesses(a._postProcesses), r.length === 0 || !this._scene.postProcessesEnabled)) return;
		let o = this._scene.getEngine();
		for (let s = 0, c = r.length; s < c; s++) {
			let l = r[s];
			if (s < c - 1 ? l._outputTexture = r[s + 1].activate(a, t?.texture) : (t ? (o.bindFramebuffer(t, n, void 0, void 0, i), l._outputTexture = t) : (o.restoreDefaultFramebuffer(), l._outputTexture = null), o._debugInsertMarker?.(`post process ${r[s].name} output`)), e) break;
			let u = l.apply();
			u && (l.onBeforeRenderObservable.notifyObservers(u), this._prepareBuffers(), o.bindBuffers(this._vertexBuffers, this._indexBuffer, u), o.drawElementsType(0, 0, 6), l.onAfterRenderObservable.notifyObservers(u));
		}
		o.setDepthBuffer(!0), o.setDepthWrite(!0), o.setAlphaMode(0);
	}
	dispose() {
		let e = this._vertexBuffers[n.PositionKind];
		e && (e.dispose(), this._vertexBuffers[n.PositionKind] = null), this._indexBuffer &&= (this._scene.getEngine()._releaseBuffer(this._indexBuffer), null);
	}
}, d = new r(), f = new r(), p = new r(), m = {
	getScene: () => void 0,
	eyeAtCamera: !0
};
function h(e, t, n) {
	let r = n.asArray(), i = t.asArray();
	for (let e = 0; e < 16; e++) r[e] = i[e];
	return r[12] -= e.x, r[13] -= e.y, r[14] -= e.z, n.markAsUpdated(), n;
}
function g(e, t, n) {
	return i(t, f), h(e, f, p), i(p, n), n;
}
function _(e, t, n) {
	if (!m.eyeAtCamera) return g(e, t, n);
	let r = n.asArray(), i = t.asArray();
	for (let e = 0; e < 16; e++) r[e] = i[e];
	return r[12] = 0, r[13] = 0, r[14] = 0, n.markAsUpdated(), n;
}
function v(e, t, n, r) {
	return a(_(e, t, r), n, r), r;
}
function y(e, t, n, r) {
	return i(n, f), a(t, f, p), h(e, p, f), _(e, n, p), a(f, p, r), r;
}
function b(e, t, n, r, o, s) {
	return i(n, f), a(t, f, p), h(e, p, f), v(e, r, o, p), a(f, p, s), s;
}
function x(e, t) {
	let n = m.getScene();
	if (!n || d === t) return t;
	d.updateFlag = t.updateFlag;
	let r = n.floatingOriginOffset;
	switch (e) {
		case "world": return h(r, t, d);
		case "view": return _(r, t, d);
		case "worldView": return y(r, t, n.getViewMatrix(), d);
		case "viewProjection": return v(r, n.getViewMatrix(), n.getProjectionMatrix(), d);
		case "worldViewProjection": return b(r, t, n.getTransformMatrix(), n.getViewMatrix(), n.getProjectionMatrix(), d);
		default:
			if (e.startsWith("u_")) {
				let i = e.toLowerCase();
				if (i.startsWith("u_worldviewprojection")) return b(r, t, n.getTransformMatrix(), n.getViewMatrix(), n.getProjectionMatrix(), d);
				if (i.startsWith("u_viewprojection")) return v(r, n.getViewMatrix(), n.getProjectionMatrix(), d);
				if (i.startsWith("u_worldview")) return y(r, t, n.getViewMatrix(), d);
				if (i.startsWith("u_world")) return h(r, t, d);
				if (i.startsWith("u_view")) return _(r, t, d);
			}
			return t;
	}
}
var S = l, C = t, w = S.prototype._updateMatrixForUniform, T = t.prototype.setMatrix;
function E() {
	t.prototype.setMatrix = T, C._setMatrixOverride = void 0, S.prototype._updateMatrixForUniform = w, S.prototype._updateMatrixForUniformOverride = void 0;
}
function D() {
	C.prototype._setMatrixOverride = T, C.prototype.setMatrix = function(e, t) {
		return this._setMatrixOverride(e, x(e, t)), this;
	}, S.prototype._updateMatrixForUniformOverride = w, S.prototype._updateMatrixForUniform = function(e, t) {
		this._updateMatrixForUniformOverride(e, x(e, t));
	};
}
//#endregion
//#region node_modules/@babylonjs/core/Rendering/renderingGroup.js
var O = class e {
	set opaqueSortCompareFn(t) {
		this._opaqueSortCompareFn = t || e.PainterSortCompare, this._renderOpaque = this._renderOpaqueSorted;
	}
	set alphaTestSortCompareFn(t) {
		this._alphaTestSortCompareFn = t || e.PainterSortCompare, this._renderAlphaTest = this._renderAlphaTestSorted;
	}
	set transparentSortCompareFn(t) {
		this._transparentSortCompareFn = t || e.defaultTransparentSortCompare, this._renderTransparent = this._renderTransparentSorted;
	}
	constructor(e, t, n = null, r = null, i = null) {
		this.index = e, this._opaqueSubMeshes = new c(256), this._transparentSubMeshes = new c(256), this._alphaTestSubMeshes = new c(256), this._depthOnlySubMeshes = new c(256), this._particleSystems = new c(256), this._spriteManagers = new c(256), this._empty = !0, this._edgesRenderers = new s(16), this.disableDepthPrePass = !1, this._scene = t, this.opaqueSortCompareFn = n, this.alphaTestSortCompareFn = r, this.transparentSortCompareFn = i;
	}
	render(e, t, n, r, i = !0, a = !0, o = !0, s = !0, c) {
		if (e) {
			e(this._opaqueSubMeshes, this._alphaTestSubMeshes, this._transparentSubMeshes, this._depthOnlySubMeshes);
			return;
		}
		let l = this._scene.getEngine();
		i && this._depthOnlySubMeshes.length !== 0 && (l.setColorWrite(!1), this._renderAlphaTest(this._depthOnlySubMeshes), l.setColorWrite(!0)), a && this._opaqueSubMeshes.length !== 0 && this._renderOpaque(this._opaqueSubMeshes), o && this._alphaTestSubMeshes.length !== 0 && this._renderAlphaTest(this._alphaTestSubMeshes);
		let u = l.getStencilBuffer();
		if (l.setStencilBuffer(!1), t && this._renderSprites(), n && this._renderParticles(r), this.onBeforeTransparentRendering && this.onBeforeTransparentRendering(), s && (c || this._transparentSubMeshes.length !== 0 || this._scene.useOrderIndependentTransparency)) {
			if (l.setStencilBuffer(u), c) c(this._transparentSubMeshes, this);
			else if (this._scene.useOrderIndependentTransparency) {
				let e = this._scene.depthPeelingRenderer.render(this._transparentSubMeshes);
				e.length && this._renderTransparent(e);
			} else this._renderTransparent(this._transparentSubMeshes);
			l.setAlphaMode(0);
		}
		if (l.setStencilBuffer(!1), a && this._edgesRenderers.length) {
			for (let e = 0; e < this._edgesRenderers.length; e++) this._edgesRenderers.data[e].render();
			l.setAlphaMode(0);
		}
		l.setStencilBuffer(u);
	}
	_renderOpaqueSorted(t) {
		e._RenderSorted(t, this._opaqueSortCompareFn, this._scene.activeCamera, !1, this.disableDepthPrePass);
	}
	_renderAlphaTestSorted(t) {
		e._RenderSorted(t, this._alphaTestSortCompareFn, this._scene.activeCamera, !1, this.disableDepthPrePass);
	}
	_renderTransparentSorted(t) {
		e._RenderSorted(t, this._transparentSortCompareFn, this._scene.activeCamera, !0, this.disableDepthPrePass);
	}
	static _RenderSorted(t, n, r, i, a) {
		let s = 0, c, l = r ? r.globalPosition : e._ZeroVector;
		if (i) for (; s < t.length; s++) c = t.data[s], c._alphaIndex = c.getMesh().alphaIndex, c._distanceToCamera = o.Distance(c.getBoundingInfo().boundingSphere.centerWorld, l);
		let u = t.length === t.data.length ? t.data : t.data.slice(0, t.length);
		n && u.sort(n);
		let d = u[0].getMesh().getScene();
		for (s = 0; s < u.length; s++) if (c = u[s], !d._activeMeshesFrozenButKeepClipping || c.isInFrustum(d._frustumPlanes)) {
			if (i) {
				let e = c.getMaterial();
				if (e && e.needDepthPrePass && !a) {
					let t = e.getScene().getEngine();
					t.setColorWrite(!1), t.setAlphaMode(0), c.render(!1), t.setColorWrite(!0);
				}
			}
			c.render(i);
		}
	}
	static defaultTransparentSortCompare(t, n) {
		return t._alphaIndex > n._alphaIndex ? 1 : t._alphaIndex < n._alphaIndex ? -1 : e.backToFrontSortCompare(t, n);
	}
	static backToFrontSortCompare(e, t) {
		return e._distanceToCamera < t._distanceToCamera ? 1 : e._distanceToCamera > t._distanceToCamera ? -1 : 0;
	}
	static frontToBackSortCompare(e, t) {
		return e._distanceToCamera < t._distanceToCamera ? -1 : +(e._distanceToCamera > t._distanceToCamera);
	}
	static PainterSortCompare(e, t) {
		let n = e.getMesh(), r = t.getMesh();
		return n.material && r.material ? n.material.uniqueId - r.material.uniqueId : n.uniqueId - r.uniqueId;
	}
	prepare() {
		this._opaqueSubMeshes.reset(), this._transparentSubMeshes.reset(), this._alphaTestSubMeshes.reset(), this._depthOnlySubMeshes.reset(), this._particleSystems.reset(), this.prepareSprites(), this._edgesRenderers.reset(), this._empty = !0;
	}
	prepareSprites() {
		this._spriteManagers.reset();
	}
	dispose() {
		this._opaqueSubMeshes.dispose(), this._transparentSubMeshes.dispose(), this._alphaTestSubMeshes.dispose(), this._depthOnlySubMeshes.dispose(), this._particleSystems.dispose(), this._spriteManagers.dispose(), this._edgesRenderers.dispose();
	}
	dispatch(e, t, n) {
		t === void 0 && (t = e.getMesh()), n === void 0 && (n = e.getMaterial()), n != null && (n.needAlphaBlendingForMesh(t) ? this._transparentSubMeshes.push(e) : n.needAlphaTestingForMesh(t) ? (n.needDepthPrePass && !this.disableDepthPrePass && this._depthOnlySubMeshes.push(e), this._alphaTestSubMeshes.push(e)) : (n.needDepthPrePass && !this.disableDepthPrePass && this._depthOnlySubMeshes.push(e), this._opaqueSubMeshes.push(e)), t._renderingGroup = this, t._edgesRenderer && t.isEnabled() && t.isVisible && t._edgesRenderer.isEnabled && this._edgesRenderers.pushNoDuplicate(t._edgesRenderer), this._empty = !1);
	}
	dispatchSprites(e) {
		this._spriteManagers.push(e), this._empty = !1;
	}
	dispatchParticles(e) {
		this._particleSystems.push(e), this._empty = !1;
	}
	_renderParticles(e) {
		if (this._particleSystems.length === 0) return;
		let t = this._scene.activeCamera;
		this._scene.onBeforeParticlesRenderingObservable.notifyObservers(this._scene);
		for (let n = 0; n < this._particleSystems.length; n++) {
			let r = this._particleSystems.data[n];
			if ((t && t.layerMask & r.layerMask) === 0) continue;
			let i = r.emitter;
			(!i.position || !e || e.indexOf(i) !== -1) && this._scene._activeParticles.addCount(r.render(), !1);
		}
		this._scene.onAfterParticlesRenderingObservable.notifyObservers(this._scene);
	}
	_renderSprites() {
		if (!this._scene.spritesEnabled || this._spriteManagers.length === 0) return;
		let e = this._scene.activeCamera;
		this._scene.onBeforeSpritesRenderingObservable.notifyObservers(this._scene);
		for (let t = 0; t < this._spriteManagers.length; t++) {
			let n = this._spriteManagers.data[t];
			(e && e.layerMask & n.layerMask) !== 0 && n.render();
		}
		this._scene.onAfterSpritesRenderingObservable.notifyObservers(this._scene);
	}
};
O._ZeroVector = o.Zero();
//#endregion
//#region node_modules/@babylonjs/core/Rendering/renderingManager.js
var k = class {}, A = class e {
	get disableDepthPrePass() {
		return this._disableDepthPrePass;
	}
	set disableDepthPrePass(e) {
		this._disableDepthPrePass = e;
		for (let t of this._renderingGroups) t.disableDepthPrePass = e;
	}
	get maintainStateBetweenFrames() {
		return this._maintainStateBetweenFrames;
	}
	set maintainStateBetweenFrames(e) {
		e !== this._maintainStateBetweenFrames && (this._maintainStateBetweenFrames = e, this._maintainStateBetweenFrames || this.restoreDispachedFlags());
	}
	restoreDispachedFlags() {
		for (let e of this._scene.meshes) if (e.subMeshes) for (let t of e.subMeshes) t._wasDispatched = !1;
		if (this._scene.spriteManagers) for (let e of this._scene.spriteManagers) e._wasDispatched = !1;
		for (let e of this._scene.particleSystems) e._wasDispatched = !1;
	}
	constructor(t) {
		this._useSceneAutoClearSetup = !1, this._disableDepthPrePass = !1, this._renderingGroups = [], this._autoClearDepthStencil = {}, this._customOpaqueSortCompareFn = {}, this._customAlphaTestSortCompareFn = {}, this._customTransparentSortCompareFn = {}, this._renderingGroupInfo = new k(), this._maintainStateBetweenFrames = !1, this._scene = t;
		for (let t = e.MIN_RENDERINGGROUPS; t < e.MAX_RENDERINGGROUPS; t++) this._autoClearDepthStencil[t] = {
			autoClear: !0,
			depth: !0,
			stencil: !0
		};
	}
	get renderingGroups() {
		return this._renderingGroups;
	}
	getRenderingGroup(e) {
		let t = e || 0;
		return this._prepareRenderingGroup(t), this._renderingGroups[t];
	}
	_clearDepthStencilBuffer(e = !0, t = !0) {
		this._depthStencilBufferAlreadyCleaned ||= (this._scene.getEngine().clear(null, !1, e, t), !0);
	}
	render(t, n, r, i, a = !0, o = !0, s = !0, c = !0, l, u) {
		let d = this._renderingGroupInfo;
		d.scene = this._scene, d.camera = this._scene.activeCamera, d.renderingManager = this;
		let f = u ?? this._scene.spriteManagers;
		if (f && i) for (let e = 0; e < f.length; e++) {
			let t = f[e];
			this.dispatchSprites(t);
		}
		for (let u = e.MIN_RENDERINGGROUPS; u < e.MAX_RENDERINGGROUPS; u++) {
			this._depthStencilBufferAlreadyCleaned = u === e.MIN_RENDERINGGROUPS;
			let f = this._renderingGroups[u];
			if (!f || f._empty) continue;
			let p = 1 << u;
			if (d.renderingGroupId = u, this._scene.onBeforeRenderingGroupObservable.notifyObservers(d, p), e.AUTOCLEAR) {
				let e = this._useSceneAutoClearSetup ? this._scene.getAutoClearDepthStencilSetup(u) : this._autoClearDepthStencil[u];
				e && e.autoClear && this._clearDepthStencilBuffer(e.depth, e.stencil);
			}
			for (let e of this._scene._beforeRenderingGroupDrawStage) e.action(u);
			f.render(t, i, r, n, a, o, s, c, l);
			for (let e of this._scene._afterRenderingGroupDrawStage) e.action(u);
			this._scene.onAfterRenderingGroupObservable.notifyObservers(d, p);
		}
	}
	reset() {
		if (!this.maintainStateBetweenFrames) for (let t = e.MIN_RENDERINGGROUPS; t < e.MAX_RENDERINGGROUPS; t++) {
			let e = this._renderingGroups[t];
			e && e.prepare();
		}
	}
	resetSprites() {
		if (!this.maintainStateBetweenFrames) for (let t = e.MIN_RENDERINGGROUPS; t < e.MAX_RENDERINGGROUPS; t++) {
			let e = this._renderingGroups[t];
			e && e.prepareSprites();
		}
	}
	dispose() {
		this.freeRenderingGroups(), this._renderingGroups.length = 0, this._renderingGroupInfo = null;
	}
	freeRenderingGroups() {
		for (let t = e.MIN_RENDERINGGROUPS; t < e.MAX_RENDERINGGROUPS; t++) {
			let e = this._renderingGroups[t];
			e && e.dispose();
		}
	}
	_prepareRenderingGroup(e) {
		this._renderingGroups[e] === void 0 && (this._renderingGroups[e] = new O(e, this._scene, this._customOpaqueSortCompareFn[e], this._customAlphaTestSortCompareFn[e], this._customTransparentSortCompareFn[e]), this._renderingGroups[e].disableDepthPrePass = this._disableDepthPrePass);
	}
	dispatchSprites(e) {
		this.maintainStateBetweenFrames && e._wasDispatched || (e._wasDispatched = !0, this.getRenderingGroup(e.renderingGroupId).dispatchSprites(e));
	}
	dispatchParticles(e) {
		this.maintainStateBetweenFrames && e._wasDispatched || (e._wasDispatched = !0, this.getRenderingGroup(e.renderingGroupId).dispatchParticles(e));
	}
	dispatch(e, t, n) {
		t === void 0 && (t = e.getMesh()), !(this.maintainStateBetweenFrames && e._wasDispatched) && (e._wasDispatched = !0, this.getRenderingGroup(t.renderingGroupId).dispatch(e, t, n));
	}
	setRenderingOrder(e, t = null, n = null, r = null) {
		if (this._customOpaqueSortCompareFn[e] = t, this._customAlphaTestSortCompareFn[e] = n, this._customTransparentSortCompareFn[e] = r, this._renderingGroups[e]) {
			let t = this._renderingGroups[e];
			t.opaqueSortCompareFn = this._customOpaqueSortCompareFn[e], t.alphaTestSortCompareFn = this._customAlphaTestSortCompareFn[e], t.transparentSortCompareFn = this._customTransparentSortCompareFn[e];
		}
	}
	setRenderingAutoClearDepthStencil(e, t, n = !0, r = !0) {
		this._autoClearDepthStencil[e] = {
			autoClear: t,
			depth: n,
			stencil: r
		};
	}
	getAutoClearDepthStencilSetup(e) {
		return this._autoClearDepthStencil[e];
	}
};
A.MAX_RENDERINGGROUPS = 4, A.MIN_RENDERINGGROUPS = 0, A.AUTOCLEAR = !0;
//#endregion
//#region node_modules/@babylonjs/core/sceneComponent.js
var j = class {};
j.NAME_EFFECTLAYER = "EffectLayer", j.NAME_LAYER = "Layer", j.NAME_LENSFLARESYSTEM = "LensFlareSystem", j.NAME_BOUNDINGBOXRENDERER = "BoundingBoxRenderer", j.NAME_PARTICLESYSTEM = "ParticleSystem", j.NAME_GAMEPAD = "Gamepad", j.NAME_SIMPLIFICATIONQUEUE = "SimplificationQueue", j.NAME_GEOMETRYBUFFERRENDERER = "GeometryBufferRenderer", j.NAME_PREPASSRENDERER = "PrePassRenderer", j.NAME_DEPTHRENDERER = "DepthRenderer", j.NAME_DEPTHPEELINGRENDERER = "DepthPeelingRenderer", j.NAME_POSTPROCESSRENDERPIPELINEMANAGER = "PostProcessRenderPipelineManager", j.NAME_SPRITE = "Sprite", j.NAME_SUBSURFACE = "SubSurface", j.NAME_OUTLINERENDERER = "Outline", j.NAME_PROCEDURALTEXTURE = "ProceduralTexture", j.NAME_SHADOWGENERATOR = "ShadowGenerator", j.NAME_OCTREE = "Octree", j.NAME_PHYSICSENGINE = "PhysicsEngine", j.NAME_AUDIO = "Audio", j.NAME_FLUIDRENDERER = "FluidRenderer", j.NAME_IBLCDFGENERATOR = "iblCDFGenerator", j.NAME_CLUSTEREDLIGHTING = "ClusteredLighting", j.STEP_ISREADYFORMESH_EFFECTLAYER = 0, j.STEP_ISREADYFORMESH_DEPTHRENDERER = 1, j.STEP_BEFOREEVALUATEACTIVEMESH_BOUNDINGBOXRENDERER = 0, j.STEP_EVALUATESUBMESH_BOUNDINGBOXRENDERER = 0, j.STEP_PREACTIVEMESH_BOUNDINGBOXRENDERER = 0, j.STEP_CAMERADRAWRENDERTARGET_EFFECTLAYER = 1, j.STEP_BEFORECAMERADRAW_PREPASS = 0, j.STEP_BEFORECAMERADRAW_EFFECTLAYER = 1, j.STEP_BEFORECAMERADRAW_LAYER = 2, j.STEP_BEFORERENDERTARGETDRAW_PREPASS = 0, j.STEP_BEFORERENDERTARGETDRAW_LAYER = 1, j.STEP_BEFORERENDERINGMESH_PREPASS = 0, j.STEP_BEFORERENDERINGMESH_OUTLINE = 1, j.STEP_AFTERRENDERINGMESH_PREPASS = 0, j.STEP_AFTERRENDERINGMESH_OUTLINE = 1, j.STEP_AFTERRENDERINGGROUPDRAW_EFFECTLAYER_DRAW = 0, j.STEP_AFTERRENDERINGGROUPDRAW_BOUNDINGBOXRENDERER = 1, j.STEP_BEFORECAMERAUPDATE_SIMPLIFICATIONQUEUE = 0, j.STEP_BEFORECLEAR_PROCEDURALTEXTURE = 0, j.STEP_BEFORECLEAR_PREPASS = 1, j.STEP_BEFORERENDERTARGETCLEAR_PREPASS = 0, j.STEP_AFTERRENDERTARGETDRAW_PREPASS = 0, j.STEP_AFTERRENDERTARGETDRAW_LAYER = 1, j.STEP_AFTERCAMERADRAW_PREPASS = 0, j.STEP_AFTERCAMERADRAW_EFFECTLAYER = 1, j.STEP_AFTERCAMERADRAW_LENSFLARESYSTEM = 2, j.STEP_AFTERCAMERADRAW_EFFECTLAYER_DRAW = 3, j.STEP_AFTERCAMERADRAW_LAYER = 4, j.STEP_AFTERCAMERADRAW_FLUIDRENDERER = 5, j.STEP_AFTERCAMERAPOSTPROCESS_LAYER = 0, j.STEP_AFTERRENDERTARGETPOSTPROCESS_LAYER = 0, j.STEP_AFTERRENDER_AUDIO = 0, j.STEP_GATHERRENDERTARGETS_DEPTHRENDERER = 0, j.STEP_GATHERRENDERTARGETS_GEOMETRYBUFFERRENDERER = 1, j.STEP_GATHERRENDERTARGETS_SHADOWGENERATOR = 2, j.STEP_GATHERRENDERTARGETS_POSTPROCESSRENDERPIPELINEMANAGER = 3, j.STEP_GATHERACTIVECAMERARENDERTARGETS_DEPTHRENDERER = 0, j.STEP_GATHERACTIVECAMERARENDERTARGETS_FLUIDRENDERER = 1, j.STEP_GATHERACTIVECAMERARENDERTARGETS_CLUSTEREDLIGHTING = 2, j.STEP_POINTERMOVE_SPRITE = 0, j.STEP_POINTERDOWN_SPRITE = 0, j.STEP_POINTERUP_SPRITE = 0;
var M = class e extends Array {
	constructor(e) {
		super(...e);
	}
	static Create() {
		return Object.create(e.prototype);
	}
	registerStep(e, t, n) {
		let r = 0, i;
		for (; r < this.length && (i = this[r].index, !(e < i)); r++);
		this.splice(r, 0, {
			index: e,
			component: t,
			action: n.bind(t)
		});
	}
	clear() {
		this.length = 0;
	}
};
//#endregion
export { D as a, m as i, M as n, E as o, A as r, u as s, j as t };
