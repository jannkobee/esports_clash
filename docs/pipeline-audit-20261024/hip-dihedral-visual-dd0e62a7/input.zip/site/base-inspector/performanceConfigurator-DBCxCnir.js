//#region node_modules/@babylonjs/core/Engines/performanceConfigurator.js
var e = class e {
	static SetMatrixPrecision(t) {
		if (e.MatrixTrackPrecisionChange = !1, t && !e.MatrixUse64Bits && e.MatrixTrackedMatrices) for (let t = 0; t < e.MatrixTrackedMatrices.length; ++t) {
			let n = e.MatrixTrackedMatrices[t], r = n._m;
			n._m = Array(16);
			for (let e = 0; e < 16; ++e) n._m[e] = r[e];
		}
		e.MatrixUse64Bits = t, e.MatrixCurrentType = e.MatrixUse64Bits ? Array : Float32Array, e.MatrixTrackedMatrices = null;
	}
};
e.MatrixUse64Bits = !1, e.MatrixTrackPrecisionChange = !0, e.MatrixCurrentType = Float32Array, e.MatrixTrackedMatrices = [];
//#endregion
export { e as t };
