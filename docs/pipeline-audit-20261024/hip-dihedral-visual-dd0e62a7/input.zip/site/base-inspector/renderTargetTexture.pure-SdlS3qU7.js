import { n as e } from "./engineStore-D0BoPdea.js";
import { t } from "./logger-DQIzSR_y.js";
import { r as n, t as r } from "./abstractEngine.pure-C608BZav.js";
import { a as i, c as a, t as o, x as s } from "./tools.functions-DEecYKlu.js";
import { a as c, h as l, u } from "./math.color.pure-CPmbqLkh.js";
import { t as d } from "./smartArray-BmGU7Yab.js";
import { n as f, t as p } from "./lightConstants-Dqs8OH2d.js";
import { r as m, s as h } from "./sceneComponent-C2CdEKig.js";
import { t as g } from "./texture.pure-Ce-ILsRv.js";
//#region node_modules/@babylonjs/core/Engines/AbstractEngine/abstractEngine.texture.pure.js
var _ = !1;
function v() {
	_ || (_ = !0, r.prototype.createDepthStencilTexture = function(e, t, n) {
		if (t.isCube) {
			let n = e.width || e;
			return this._createDepthStencilCubeTexture(n, t);
		}
		return this._createDepthStencilTexture(e, t, n);
	});
}
//#endregion
//#region node_modules/@babylonjs/core/Rendering/objectRenderer.js
var y = class n {
	get renderList() {
		return this._renderList;
	}
	set renderList(e) {
		this._renderList !== e && (this._unObserveRenderList &&= (this._unObserveRenderList(), null), e && (this._unObserveRenderList = l(e, this._renderListHasChanged)), this._renderList = e);
	}
	get disableImageProcessing() {
		return this._disableImageProcessing;
	}
	set disableImageProcessing(e) {
		e !== this._disableImageProcessing && (this._disableImageProcessing = e, this._scene.markAllMaterialsAsDirty(64));
	}
	get disableDepthPrePass() {
		return this._disableDepthPrePass;
	}
	set disableDepthPrePass(e) {
		this._disableDepthPrePass = e, this._renderingManager.disableDepthPrePass = e;
	}
	get name() {
		return this._name;
	}
	set name(e) {
		if (this._name !== e) {
			if (this._name = e, this._sceneUBOs) for (let e = 0; e < this._sceneUBOs.length; ++e) this._sceneUBOs[e].name = `Scene ubo #${e} for ${this.name}`;
			if (this._scene) for (let e = 0; e < this._renderPassIds.length; ++e) {
				let t = this._renderPassIds[e];
				this._engine._renderPassNames[t] = `${this._name}#${e}`;
			}
		}
	}
	get renderPassIds() {
		return this._renderPassIds;
	}
	get currentRefreshId() {
		return this._currentRefreshId;
	}
	getActiveMeshes() {
		return this._activeMeshes;
	}
	setMaterialForRendering(e, t) {
		let n;
		n = Array.isArray(e) ? e : [e];
		for (let e = 0; e < n.length; ++e) for (let r = 0; r < this.options.numPasses; ++r) {
			let i = n[e];
			n[e].isAnInstance && (i = n[e].sourceMesh), i.setMaterialForRenderPass(this._renderPassIds[r], t === void 0 ? void 0 : Array.isArray(t) ? t[r] : t);
		}
	}
	_freezeActiveMeshes(e) {
		this._freezeActiveMeshesCancel = a(() => this._checkReadiness(), () => {
			if (this._freezeActiveMeshesCancel = null, e) for (let e = 0; e < this._activeMeshes.length; e++) this._activeMeshes.data[e]._freeze();
			this._prepareRenderingManager(0, !0), this._isFrozen = !0;
		}, (e, n) => {
			this._freezeActiveMeshesCancel = null, n ? (t.Error("ObjectRenderer: Timeout while waiting for the renderer to be ready."), e && t.Error(e)) : (t.Error("ObjectRenderer: An unexpected error occurred while waiting for the renderer to be ready."), e && (t.Error(e), e.stack && t.Error(e.stack)));
		});
	}
	_unfreezeActiveMeshes() {
		this._freezeActiveMeshesCancel?.(), this._freezeActiveMeshesCancel = null;
		for (let e = 0; e < this._activeMeshes.length; e++) this._activeMeshes.data[e]._unFreeze();
		this._isFrozen = !1;
	}
	constructor(t, n, r) {
		this._unObserveRenderList = null, this._renderListHasChanged = (e, t) => {
			let n = this._renderList ? this._renderList.length : 0;
			if (t === 0 && n > 0 || n === 0) for (let e of this._scene.meshes) e._markSubMeshesAsLightDirty();
		}, this.particleSystemList = null, this.spriteManagerList = null, this.getCustomRenderList = null, this.renderMeshes = !0, this.renderDepthOnlyMeshes = !0, this.renderOpaqueMeshes = !0, this.renderAlphaTestMeshes = !0, this.renderTransparentMeshes = !0, this.renderParticles = !0, this.renderSprites = !1, this.forceLayerMaskCheck = !1, this.enableBoundingBoxRendering = !1, this.enableOutlineRendering = !0, this._disableImageProcessing = !1, this.dontSetTransformationMatrix = !1, this._disableDepthPrePass = !1, this.onBeforeRenderObservable = new e(), this.onAfterRenderObservable = new e(), this.onBeforeRenderingManagerRenderObservable = new e(), this.onAfterRenderingManagerRenderObservable = new e(), this.onInitRenderingObservable = new e(), this.onFinishRenderingObservable = new e(), this.onFastPathRenderObservable = new e(), this._currentRefreshId = -1, this._refreshRate = 1, this._currentApplyByPostProcessSetting = !1, this._activeMeshes = new d(256), this._activeBoundingBoxes = new d(32), this._currentFrameId = -1, this._currentSceneUBOIndex = 0, this._isFrozen = !1, this._freezeActiveMeshesCancel = null, this._currentSceneCamera = null, this.name = t, this._scene = n, this._engine = this._scene.getEngine(), this._useUBO = this._engine.supportsUniformBuffers, this.renderList = [], this._renderPassIds = [], this.options = {
			numPasses: 1,
			doNotChangeAspectRatio: !0,
			enableClusteredLights: !1,
			...r
		}, this._createRenderPassId(), this.renderPassId = this._renderPassIds[0], this._renderingManager = new m(n), this._renderingManager._useSceneAutoClearSetup = !0, this.options.enableClusteredLights && this.onInitRenderingObservable.add(() => {
			for (let e of this._scene.lights) e.getTypeID() === p.LIGHTTYPEID_CLUSTERED_CONTAINER && e.isSupported && e._updateBatches(this.activeCamera).render();
		}), this._scene.addObjectRenderer(this);
	}
	_releaseRenderPassId() {
		for (let e = 0; e < this.options.numPasses; ++e) this._engine.releaseRenderPassId(this._renderPassIds[e]);
		this._renderPassIds.length = 0;
	}
	_createRenderPassId() {
		this._releaseRenderPassId();
		for (let e = 0; e < this.options.numPasses; ++e) this._renderPassIds[e] = this._engine.createRenderPassId(`${this.name}#${e}`);
	}
	_createSceneUBO(e, t) {
		let n = this._scene.getEngine(), r = new f(n, void 0, t, e, void 0, !1);
		return r.addUniform("viewProjection", 16), t && r.addUniform("viewProjectionR", 16), r.addUniform("view", 16), r.addUniform("projection", 16), r.addUniform("vEyePosition", 4), r.addUniform("inverseProjection", 16), r;
	}
	_getSceneUBO() {
		this._currentFrameId !== this._engine.frameId && (this._currentSceneUBOIndex = 0, this._currentFrameId = this._engine.frameId), this._sceneUBOs || (this._sceneUBOs = [], this._sceneUBOIsMultiview = []);
		let e = this._engine._currentRenderTarget, t = !!(e && e.texture?.isMultiview) || !!this._scene._multiviewSceneUboIsActive;
		if (this._currentSceneUBOIndex >= this._sceneUBOs.length) {
			let e = this._sceneUBOs.length;
			this._sceneUBOs.push(this._createSceneUBO(`Scene ubo #${e} for ${this.name}`, t)), this._sceneUBOIsMultiview.push(t);
		} else this._sceneUBOIsMultiview[this._currentSceneUBOIndex] !== t && (this._sceneUBOs[this._currentSceneUBOIndex].dispose(), this._sceneUBOs[this._currentSceneUBOIndex] = this._createSceneUBO(`Scene ubo #${this._currentSceneUBOIndex} for ${this.name}`, t), this._sceneUBOIsMultiview[this._currentSceneUBOIndex] = t);
		let n = this._sceneUBOs[this._currentSceneUBOIndex++];
		return n.unbindEffect(), n;
	}
	resetRefreshCounter() {
		this._currentRefreshId = -1;
	}
	get refreshRate() {
		return this._refreshRate;
	}
	set refreshRate(e) {
		this._refreshRate = e, this.resetRefreshCounter();
	}
	shouldRender() {
		return this._engine.snapshotRendering ? !0 : this._currentRefreshId === -1 || this.refreshRate === this._currentRefreshId ? (this._currentRefreshId = 1, !0) : (this._currentRefreshId++, !1);
	}
	isReadyForRendering(e, t) {
		this.prepareRenderList(), this.initRender(e, t);
		let n = this._checkReadiness();
		return this.finishRender(), n;
	}
	prepareRenderList() {
		let e = this._scene;
		if (this._waitingRenderList) {
			if (!this.renderListPredicate) {
				this.renderList = [];
				for (let t = 0; t < this._waitingRenderList.length; t++) {
					let n = this._waitingRenderList[t], r = e.getMeshById(n);
					r && this.renderList.push(r);
				}
			}
			this._waitingRenderList = void 0;
		}
		if (this.renderListPredicate) {
			this.renderList ? this.renderList.length = 0 : this.renderList = [];
			let e = this._scene.meshes;
			for (let t = 0; t < e.length; t++) {
				let n = e[t];
				this.renderListPredicate(n) && this.renderList.push(n);
			}
		}
		this._currentApplyByPostProcessSetting = this._scene.imageProcessingConfiguration.applyByPostProcess, this._disableImageProcessing && (this._scene.imageProcessingConfiguration._applyByPostProcess = this._disableImageProcessing);
	}
	initRender(e, t) {
		let n = this.activeCamera ?? this._scene.activeCamera;
		this._currentSceneCamera = this._scene.activeCamera, this._useUBO && (this._currentSceneUBO = this._scene.getSceneUniformBuffer(), this._currentSceneUBO.unbindEffect(), this._scene.setSceneUniformBuffer(this._getSceneUBO())), this.onInitRenderingObservable.notifyObservers(this), n && (this.dontSetTransformationMatrix || this._scene.setTransformMatrix(n.getViewMatrix(), n.getProjectionMatrix(!0)), this._scene._activeCamera = n, this._engine.setViewport(n.rigParent ? n.rigParent.viewport : n.viewport, e, t)), this._useUBO && this._scene.finalizeSceneUbo(), this._defaultRenderListPrepared = !1;
	}
	finishRender() {
		let e = this._scene;
		this._useUBO && this._scene.setSceneUniformBuffer(this._currentSceneUBO), this._disableImageProcessing && (e.imageProcessingConfiguration._applyByPostProcess = this._currentApplyByPostProcessSetting), e._activeCamera = this._currentSceneCamera, this._currentSceneCamera && (this.activeCamera && this.activeCamera !== e.activeCamera && e.setTransformMatrix(this._currentSceneCamera.getViewMatrix(), this._currentSceneCamera.getProjectionMatrix(!0)), this._engine.setViewport(this._currentSceneCamera.viewport)), e.resetCachedMaterial(), this.onFinishRenderingObservable.notifyObservers(this);
	}
	render(e = 0, t = !1) {
		let n = this._engine.currentRenderPassId;
		if (this._engine.currentRenderPassId = this._renderPassIds[e], this.onBeforeRenderObservable.notifyObservers(e), this._engine.snapshotRendering && this._engine.snapshotRenderingMode === 1) this.onFastPathRenderObservable.notifyObservers(e);
		else {
			let t = this._prepareRenderingManager(e), n = this._scene.getOutlineRenderer?.(), r = n?.enabled;
			n && (n.enabled = this.enableOutlineRendering), this.onBeforeRenderingManagerRenderObservable.notifyObservers(e), this._renderingManager.render(this.customRenderFunction, t, this.renderParticles, this.renderSprites, this.renderDepthOnlyMeshes, this.renderOpaqueMeshes, this.renderAlphaTestMeshes, this.renderTransparentMeshes, this.customRenderTransparentSubMeshes, this.spriteManagerList), this.onAfterRenderingManagerRenderObservable.notifyObservers(e), n && (n.enabled = r);
		}
		t || this.onAfterRenderObservable.notifyObservers(e), this._engine.currentRenderPassId = n;
	}
	_checkReadiness() {
		let e = this._scene, t = this._engine.currentRenderPassId, n = !0;
		e.getViewMatrix() || e.updateTransformMatrix();
		let r = this.options.numPasses;
		for (let t = 0; t < r && n; t++) {
			let i = this.renderList ? this.renderList : e.frameGraph ? e.meshes : e.getActiveMeshes().data, a = this.renderList || e.frameGraph ? i.length : e.getActiveMeshes().length;
			this._engine.currentRenderPassId = this._renderPassIds[t], this.onBeforeRenderObservable.notifyObservers(t);
			let o = null, s = a;
			this.getCustomRenderList && (o = this.getCustomRenderList(t, i, a), o && (s = o.length)), o ||= i, this.options.doNotChangeAspectRatio || e.updateTransformMatrix(!0);
			for (let e = 0; e < s && n; ++e) {
				let t = o[e];
				if (!t.isEnabled() || t.isBlocked || !t.isVisible || !t.subMeshes) continue;
				if (this.customIsReadyFunction) {
					if (!this.customIsReadyFunction(t, this.refreshRate, !0)) {
						n = !1;
						continue;
					}
				} else if (!t.isReady(!0)) {
					n = !1;
					continue;
				}
				let r = t._edgesRenderer, i = t.hasThinInstances;
				if (t.isAnInstance) {
					let e = t.sourceMesh;
					e.edgesShareWithInstances && e._edgesRenderer?.isEnabled && (r = e._edgesRenderer, i = !0);
				} else t.hasInstances && t.edgesShareWithInstances && (i = !0);
				!this.customRenderFunction && this.renderOpaqueMeshes && r?.isEnabled && (r.isReady(i) || (n = !1));
			}
			if (this.renderParticles && e.particlesEnabled) {
				let t = this.particleSystemList || e.particleSystems;
				for (let e of t) e.isReady() || (n = !1);
			}
			if (this.renderSprites && e.spritesEnabled) {
				let t = this.spriteManagerList || e.spriteManagers;
				if (t) for (let r of t) e.activeCamera && (r.layerMask & e.activeCamera.layerMask) === 0 || r.isReady && !r.isReady() && (n = !1);
			}
			this.onAfterRenderObservable.notifyObservers(t), r > 1 && (e.incrementRenderId(), e.resetCachedMaterial());
		}
		return this._engine.currentRenderPassId = t, n;
	}
	_prepareRenderingManager(e = 0, t = !1) {
		let n = this._scene, r = null, i, a, o = this.renderList ? this.renderList : n.frameGraph ? n.meshes : n.getActiveMeshes().data, s = this.renderList || n.frameGraph ? o.length : n.getActiveMeshes().length;
		if (this.getCustomRenderList && (r = this.getCustomRenderList(e, o, s)), r) i = r.length, a = this.forceLayerMaskCheck;
		else {
			if (this._defaultRenderListPrepared && !t && !this._engine.isWebGPU) return o;
			this._defaultRenderListPrepared = !0, r = o, i = s, a = !this.renderList || this.forceLayerMaskCheck;
		}
		let c = n.activeCamera, l = this.cameraForLOD ?? c, u = n.getBoundingBoxRenderer?.();
		if (n._activeMeshesFrozen && this._isFrozen) {
			if (this._renderingManager.resetSprites(), this.enableBoundingBoxRendering && u) {
				u.reset();
				for (let e = 0; e < this._activeBoundingBoxes.length; e++) {
					let t = this._activeBoundingBoxes.data[e];
					u.renderList.push(t);
				}
			}
			return r;
		}
		if (this._renderingManager.reset(), this._activeMeshes.reset(), this._activeBoundingBoxes.reset(), u && u.reset(), this.renderMeshes) {
			let e = n.getRenderId(), t = n.getFrameId();
			for (let o = 0; o < i; o++) {
				let i = r[o];
				if (i && !i.isBlocked) {
					if (this.customIsReadyFunction) {
						if (!this.customIsReadyFunction(i, this.refreshRate, !1)) {
							this.resetRefreshCounter();
							continue;
						}
					} else if (!i.isReady(this.refreshRate === 0)) {
						this.resetRefreshCounter();
						continue;
					}
					let r;
					if (l) {
						let e = i._internalAbstractMeshDataInfo._currentLOD.get(l);
						!e || e[1] !== t ? (r = n.customLODSelector ? n.customLODSelector(i, l) : i.getLOD(l), e ? (e[0] = r, e[1] = t) : i._internalAbstractMeshDataInfo._currentLOD.set(l, [r, t])) : r = e[0];
					} else r = i;
					if (!r) continue;
					r !== i && r.billboardMode !== 0 && r.computeWorldMatrix(), r._preActivateForIntermediateRendering(e);
					let o;
					if (o = a && c ? (i.layerMask & c.layerMask) === 0 : !1, i.isEnabled() && i.isVisible && i.subMeshes && !o) {
						if (this._activeMeshes.push(i), r._internalAbstractMeshDataInfo._wasActiveLastFrame = !0, r !== i && r._activate(e, !0), this.enableBoundingBoxRendering && u && u._preActiveMesh(i), i._activate(e, !0) && i.subMeshes.length) {
							i.isAnInstance ? i._internalAbstractMeshDataInfo._actAsRegularMesh && (r = i) : r._internalAbstractMeshDataInfo._onlyForInstancesIntermediate = !1, r._internalAbstractMeshDataInfo._isActiveIntermediate = !0, n._prepareSkeleton(r);
							for (let e = 0; e < r.subMeshes.length; e++) {
								let t = r.subMeshes[e];
								this.enableBoundingBoxRendering && u && u._evaluateSubMesh(i, t), this._renderingManager.dispatch(t, r);
							}
						}
						i._postActivate();
					}
				}
			}
		}
		if (this.enableBoundingBoxRendering && u && t) for (let e = 0; e < u.renderList.length; e++) {
			let t = u.renderList.data[e];
			this._activeBoundingBoxes.push(t);
		}
		if (this._scene.particlesEnabled && this.renderParticles) {
			this._scene.onBeforeParticlesRenderingObservable.notifyObservers(this._scene);
			let e = this.particleSystemList || n.particleSystems;
			for (let t = 0; t < e.length; t++) {
				let n = e[t], r = n.emitter;
				n.isStarted() && r && (!r.position || r.isEnabled()) && this._renderingManager.dispatchParticles(n);
			}
			this._scene.onAfterParticlesRenderingObservable.notifyObservers(this._scene);
		}
		return r;
	}
	get renderingManager() {
		return this._renderingManager;
	}
	setRenderingOrder(e, t = null, n = null, r = null) {
		this._renderingManager.setRenderingOrder(e, t, n, r);
	}
	setRenderingAutoClearDepthStencil(e, t, n = !0, r = !0) {
		this._renderingManager.setRenderingAutoClearDepthStencil(e, t, n, r), this._renderingManager._useSceneAutoClearSetup = !1;
	}
	clone() {
		let e = new n(this.name, this._scene, this.options);
		return this.renderList && (e.renderList = this.renderList.slice(0)), e;
	}
	dispose() {
		let e = this.renderList ? this.renderList : this._scene.getActiveMeshes().data, t = this.renderList ? this.renderList.length : this._scene.getActiveMeshes().length;
		for (let n = 0; n < t; n++) {
			let t = e[n];
			t && t.getMaterialForRenderPass(this.renderPassId) !== void 0 && t.setMaterialForRenderPass(this.renderPassId, void 0);
		}
		if (this.onInitRenderingObservable.clear(), this.onFinishRenderingObservable.clear(), this.onBeforeRenderObservable.clear(), this.onAfterRenderObservable.clear(), this.onBeforeRenderingManagerRenderObservable.clear(), this.onAfterRenderingManagerRenderObservable.clear(), this.onFastPathRenderObservable.clear(), this._releaseRenderPassId(), this.renderList = null, this._sceneUBOs) for (let e of this._sceneUBOs) e.dispose();
		this._sceneUBOs = void 0, this._scene.removeObjectRenderer(this);
	}
	_rebuild() {
		this.refreshRate === n.REFRESHRATE_RENDER_ONCE && (this.refreshRate = n.REFRESHRATE_RENDER_ONCE);
	}
	freeRenderingGroups() {
		this._renderingManager && this._renderingManager.freeRenderingGroups();
	}
};
y.REFRESHRATE_RENDER_ONCE = 0, y.REFRESHRATE_RENDER_ONEVERYFRAME = 1, y.REFRESHRATE_RENDER_ONEVERYTWOFRAMES = 2;
//#endregion
//#region node_modules/@babylonjs/core/Materials/Textures/renderTargetTexture.pure.js
var b = class n extends g {
	get renderListPredicate() {
		return this._objectRenderer.renderListPredicate;
	}
	set renderListPredicate(e) {
		this._objectRenderer.renderListPredicate = e;
	}
	get renderList() {
		return this._objectRenderer.renderList;
	}
	set renderList(e) {
		this._objectRenderer.renderList = e;
	}
	get particleSystemList() {
		return this._objectRenderer.particleSystemList;
	}
	set particleSystemList(e) {
		this._objectRenderer.particleSystemList = e;
	}
	get getCustomRenderList() {
		return this._objectRenderer.getCustomRenderList;
	}
	set getCustomRenderList(e) {
		this._objectRenderer.getCustomRenderList = e;
	}
	get renderParticles() {
		return this._objectRenderer.renderParticles;
	}
	set renderParticles(e) {
		this._objectRenderer.renderParticles = e;
	}
	get renderSprites() {
		return this._objectRenderer.renderSprites;
	}
	set renderSprites(e) {
		this._objectRenderer.renderSprites = e;
	}
	get enableBoundingBoxRendering() {
		return this._objectRenderer.enableBoundingBoxRendering;
	}
	set enableBoundingBoxRendering(e) {
		this._objectRenderer.enableBoundingBoxRendering = e;
	}
	get enableOutlineRendering() {
		return this._objectRenderer.enableOutlineRendering;
	}
	set enableOutlineRendering(e) {
		this._objectRenderer.enableOutlineRendering = e;
	}
	get forceLayerMaskCheck() {
		return this._objectRenderer.forceLayerMaskCheck;
	}
	set forceLayerMaskCheck(e) {
		this._objectRenderer.forceLayerMaskCheck = e;
	}
	get activeCamera() {
		return this._objectRenderer.activeCamera;
	}
	set activeCamera(e) {
		this._objectRenderer.activeCamera = e;
	}
	get cameraForLOD() {
		return this._objectRenderer.cameraForLOD;
	}
	set cameraForLOD(e) {
		this._objectRenderer.cameraForLOD = e;
	}
	get disableImageProcessing() {
		return this._objectRenderer.disableImageProcessing;
	}
	set disableImageProcessing(e) {
		this._objectRenderer.disableImageProcessing = e;
	}
	get customIsReadyFunction() {
		return this._objectRenderer.customIsReadyFunction;
	}
	set customIsReadyFunction(e) {
		this._objectRenderer.customIsReadyFunction = e;
	}
	get customRenderFunction() {
		return this._objectRenderer.customRenderFunction;
	}
	set customRenderFunction(e) {
		this._objectRenderer.customRenderFunction = e;
	}
	get postProcesses() {
		return this._postProcesses;
	}
	get _prePassEnabled() {
		return !!this._prePassRenderTarget && this._prePassRenderTarget.enabled;
	}
	set onAfterUnbind(e) {
		this._onAfterUnbindObserver && this.onAfterUnbindObservable.remove(this._onAfterUnbindObserver), this._onAfterUnbindObserver = this.onAfterUnbindObservable.add(e);
	}
	get onBeforeRenderObservable() {
		return this._objectRenderer.onBeforeRenderObservable;
	}
	set onBeforeRender(e) {
		this._onBeforeRenderObserver && this.onBeforeRenderObservable.remove(this._onBeforeRenderObserver), this._onBeforeRenderObserver = this.onBeforeRenderObservable.add(e);
	}
	get onAfterRenderObservable() {
		return this._objectRenderer.onAfterRenderObservable;
	}
	set onAfterRender(e) {
		this._onAfterRenderObserver && this.onAfterRenderObservable.remove(this._onAfterRenderObserver), this._onAfterRenderObserver = this.onAfterRenderObservable.add(e);
	}
	set onClear(e) {
		this._onClearObserver && this.onClearObservable.remove(this._onClearObserver), this._onClearObserver = this.onClearObservable.add(e);
	}
	get _waitingRenderList() {
		return this._objectRenderer._waitingRenderList;
	}
	set _waitingRenderList(e) {
		this._objectRenderer._waitingRenderList = e;
	}
	get renderPassId() {
		return this._objectRenderer.renderPassId;
	}
	get renderPassIds() {
		return this._objectRenderer.renderPassIds;
	}
	get currentRefreshId() {
		return this._objectRenderer.currentRefreshId;
	}
	setMaterialForRendering(e, t) {
		this._objectRenderer.setMaterialForRendering(e, t);
	}
	get isMulti() {
		return this._renderTarget?.isMulti ?? !1;
	}
	get renderTargetOptions() {
		return this._renderTargetOptions;
	}
	get renderTarget() {
		return this._renderTarget;
	}
	_onRatioRescale() {
		this._sizeRatio && this.resize(this._initialSizeParameter);
	}
	set boundingBoxSize(e) {
		if (this._boundingBoxSize && this._boundingBoxSize.equals(e)) return;
		this._boundingBoxSize = e;
		let t = this.getScene();
		t && t.markAllMaterialsAsDirty(1);
	}
	get boundingBoxSize() {
		return this._boundingBoxSize;
	}
	get depthStencilTexture() {
		return this._renderTarget?._depthStencilTexture ?? null;
	}
	constructor(n, r, i, a = !1, o = !0, s = 0, l = !1, d = g.TRILINEAR_SAMPLINGMODE, f = !0, p = !1, m = !1, h = 5, _ = !1, v, b, x = !1, S = !1) {
		let C, w = !0, T, E = !1;
		if (typeof a == "object") {
			let e = a;
			a = !!e.generateMipMaps, o = e.doNotChangeAspectRatio ?? !0, s = e.type ?? 0, l = !!e.isCube, d = e.samplingMode ?? g.TRILINEAR_SAMPLINGMODE, f = e.generateDepthBuffer ?? !0, p = !!e.generateStencilBuffer, m = !!e.isMulti, h = e.format ?? 5, _ = !!e.delayAllocation, v = e.samples, b = e.creationFlags, x = !!e.noColorAttachment, S = !!e.useSRGBBuffer, C = e.colorAttachment, w = e.gammaSpace ?? w, T = e.existingObjectRenderer, E = !!e.enableClusteredLights;
		}
		if (super(null, i, !a, void 0, d, void 0, void 0, void 0, void 0, h), this.ignoreCameraViewport = !1, this.onBeforeBindObservable = new e(), this.onAfterUnbindObservable = new e(), this.onClearObservable = new e(), this.onResizeObservable = new e(), this._cleared = !1, this.skipInitialClear = !1, this._samples = 1, this._canRescale = !0, this._renderTarget = null, this._dontDisposeObjectRenderer = !1, this.boundingBoxPosition = u.Zero(), this._disableEngineStages = !1, this._dumpToolsLoading = !1, i = this.getScene(), !i) return;
		let D = this.getScene().getEngine();
		this._gammaSpace = w, this._coordinatesMode = g.PROJECTION_MODE, this.name = n, this.isRenderTarget = !0, this._initialSizeParameter = r, this._dontDisposeObjectRenderer = !!T, this._processSizeParameter(r), this._objectRenderer = T ?? new y(n, i, {
			numPasses: l ? 6 : this.getRenderLayers() || 1,
			doNotChangeAspectRatio: o,
			enableClusteredLights: E
		}), this._onBeforeRenderingManagerRenderObserver = this._objectRenderer.onBeforeRenderingManagerRenderObservable.add(() => {
			let e = this._scene;
			if (!this._disableEngineStages) for (let t of e._beforeRenderTargetClearStage) t.action(this, this._currentFaceIndex, this._currentLayer);
			if (this.onClearObservable.hasObservers() ? this.onClearObservable.notifyObservers(D) : this.skipInitialClear || D.clear(this.clearColor ?? e.clearColor, !0, !0, !0), this._doNotChangeAspectRatio || e.updateTransformMatrix(!0), !this._disableEngineStages) for (let t of e._beforeRenderTargetDrawStage) t.action(this, this._currentFaceIndex, this._currentLayer);
			D._debugPushGroup && D._debugPushGroup(`Render to ${this.name} (face #${this._currentFaceIndex} layer #${this._currentLayer})`);
		}), this._onAfterRenderingManagerRenderObserver = this._objectRenderer.onAfterRenderingManagerRenderObservable.add(() => {
			if (D._debugPopGroup && D._debugPopGroup(), !this._disableEngineStages) for (let e of this._scene._afterRenderTargetDrawStage) e.action(this, this._currentFaceIndex, this._currentLayer);
			let e = this._texture?.generateMipMaps ?? !1;
			if (this._texture && (this._texture.generateMipMaps = !1), this._postProcessManager ? this._postProcessManager._finalizeFrame(!1, this._renderTarget ?? void 0, this._currentFaceIndex, this._postProcesses, this.ignoreCameraViewport) : this._currentUseCameraPostProcess && this._scene.postProcessManager._finalizeFrame(!1, this._renderTarget ?? void 0, this._currentFaceIndex), !this._disableEngineStages) for (let e of this._scene._afterRenderTargetPostProcessStage) e.action(this, this._currentFaceIndex, this._currentLayer);
			this._texture && (this._texture.generateMipMaps = e), this._doNotChangeAspectRatio || this._scene.updateTransformMatrix(!0), this._currentDumpForDebug && (this._dumpTools ? this._dumpTools.DumpFramebuffer(this.getRenderWidth(), this.getRenderHeight(), D) : t.Error("dumpTools module is still being loaded. To speed up the process import dump tools directly in your project"));
		}), this._onFastPathRenderObserver = this._objectRenderer.onFastPathRenderObservable.add(() => {
			this.onClearObservable.hasObservers() ? this.onClearObservable.notifyObservers(D) : this.skipInitialClear || D.clear(this.clearColor || this._scene.clearColor, !0, !0, !0);
		}), this._resizeObserver = D.onResizeObservable.add(() => {}), this._generateMipMaps = !!a, this._doNotChangeAspectRatio = o, !m && (this._renderTargetOptions = {
			generateMipMaps: a,
			type: s,
			format: this._format ?? void 0,
			samplingMode: this.samplingMode,
			generateDepthBuffer: f,
			generateStencilBuffer: p,
			samples: v,
			creationFlags: b,
			noColorAttachment: x,
			useSRGBBuffer: S,
			colorAttachment: C,
			label: this.name
		}, this.samplingMode === g.NEAREST_SAMPLINGMODE && (this.wrapU = g.CLAMP_ADDRESSMODE, this.wrapV = g.CLAMP_ADDRESSMODE), _ || (l ? (this._renderTarget = i.getEngine().createRenderTargetCubeTexture(this.getRenderSize(), this._renderTargetOptions), this.coordinatesMode = g.INVCUBIC_MODE, this._textureMatrix = c.Identity()) : this._renderTarget = i.getEngine().createRenderTargetTexture(this._size, this._renderTargetOptions), this._texture = this._renderTarget.texture, v !== void 0 && (this.samples = v)));
	}
	createDepthStencilTexture(e = 0, t = !0, n = !1, r = 1, i = 14, a) {
		this._renderTarget?.createDepthStencilTexture(e, t, n, r, i, a);
	}
	_processSizeParameter(e) {
		if (e.ratio) {
			this._sizeRatio = e.ratio;
			let t = this._getEngine();
			this._size = {
				width: this._bestReflectionRenderTargetDimension(t.getRenderWidth(), this._sizeRatio),
				height: this._bestReflectionRenderTargetDimension(t.getRenderHeight(), this._sizeRatio)
			};
		} else this._size = e;
	}
	get samples() {
		return this._renderTarget?.samples ?? this._samples;
	}
	set samples(e) {
		this._renderTarget && (this._samples = this._renderTarget.setSamples(e));
	}
	addPostProcess(e) {
		if (!this._postProcessManager) {
			let e = this.getScene();
			if (!e) return;
			this._postProcessManager = new h(e), this._postProcesses = [];
		}
		this._postProcesses.push(e), this._postProcesses[0].autoClear = !1;
	}
	clearPostProcesses(e = !1) {
		if (this._postProcesses) {
			if (e) for (let e of this._postProcesses) e.dispose();
			this._postProcesses = [];
		}
	}
	removePostProcess(e) {
		if (!this._postProcesses) return;
		let t = this._postProcesses.indexOf(e);
		t !== -1 && (this._postProcesses.splice(t, 1), this._postProcesses.length > 0 && (this._postProcesses[0].autoClear = !1));
	}
	resetRefreshCounter() {
		this._objectRenderer.resetRefreshCounter();
	}
	get refreshRate() {
		return this._objectRenderer.refreshRate;
	}
	set refreshRate(e) {
		this._objectRenderer.refreshRate = e;
	}
	_shouldRender() {
		return this._objectRenderer.shouldRender();
	}
	getRenderSize() {
		return this.getRenderWidth();
	}
	getRenderWidth() {
		return this._size.width ? this._size.width : this._size;
	}
	getRenderHeight() {
		return this._size.width ? this._size.height : this._size;
	}
	getRenderLayers() {
		return this._size.layers || this._size.depth || 0;
	}
	disableRescaling() {
		this._canRescale = !1;
	}
	get canRescale() {
		return this._canRescale;
	}
	scale(e) {
		let t = Math.max(1, this.getRenderSize() * e);
		this.resize(t);
	}
	getReflectionTextureMatrix() {
		return this.isCube ? this._textureMatrix : super.getReflectionTextureMatrix();
	}
	resize(e) {
		let t = this.isCube;
		this._renderTarget?.dispose(), this._renderTarget = null;
		let n = this.getScene();
		n && (this._processSizeParameter(e), this._renderTarget = t ? n.getEngine().createRenderTargetCubeTexture(this.getRenderSize(), this._renderTargetOptions) : n.getEngine().createRenderTargetTexture(this._size, this._renderTargetOptions), this._texture = this._renderTarget.texture, this._renderTargetOptions.samples !== void 0 && (this.samples = this._renderTargetOptions.samples), this.onResizeObservable.hasObservers() && this.onResizeObservable.notifyObservers(this));
	}
	render(e = !1, t = !1) {
		this._render(e, t);
	}
	isReadyForRendering() {
		this._dumpToolsLoading || (this._dumpToolsLoading = !0, import("./dumpTools.pure-D6MU3Hz5.js").then((e) => e.t).then((e) => this._dumpTools = e)), this._objectRenderer.prepareRenderList(), this.onBeforeBindObservable.notifyObservers(this), this._objectRenderer.initRender(this.getRenderWidth(), this.getRenderHeight());
		let e = this._objectRenderer._checkReadiness();
		return this.onAfterUnbindObservable.notifyObservers(this), this._objectRenderer.finishRender(), e;
	}
	_render(e = !1, t = !1) {
		let n = this.getScene();
		if (!n) return;
		this.useCameraPostProcesses !== void 0 && (e = this.useCameraPostProcesses);
		let r = n.getEngine();
		if (r._debugPushGroup && r._debugPushGroup(`Render to ${this.name}`), this._objectRenderer.prepareRenderList(), this.onBeforeBindObservable.notifyObservers(this), this._objectRenderer.initRender(this.getRenderWidth(), this.getRenderHeight()), (this.is2DArray || this.is3D) && !this.isMulti) for (let r = 0; r < this.getRenderLayers(); r++) this._renderToTarget(0, e, t, r), n.incrementRenderId(), n.resetCachedMaterial();
		else if (this.isCube && !this.isMulti) for (let r = 0; r < 6; r++) this._renderToTarget(r, e, t), n.incrementRenderId(), n.resetCachedMaterial();
		else this._renderToTarget(0, e, t);
		this.onAfterUnbindObservable.notifyObservers(this), this._objectRenderer.finishRender(), r._debugPopGroup && r._debugPopGroup();
	}
	_bestReflectionRenderTargetDimension(e, t) {
		let n = e * t, r = i(n + 16384 / (128 + n));
		return Math.min(o(e), r);
	}
	_bindFrameBuffer(e = 0, t = 0) {
		let n = this.getScene();
		if (!n) return;
		let r = n.getEngine();
		this._renderTarget && r.bindFramebuffer(this._renderTarget, this.isCube ? e : void 0, void 0, void 0, this.ignoreCameraViewport, 0, t);
	}
	_unbindFrameBuffer(e, t) {
		this._renderTarget && e.unBindFramebuffer(this._renderTarget, this.isCube, () => {
			this.onAfterRenderObservable.notifyObservers(t);
		});
	}
	_prepareFrame(e, t, n, r) {
		this._postProcessManager ? this._prePassEnabled || this._postProcessManager._prepareFrame(this._texture, this._postProcesses) || this._bindFrameBuffer(t, n) : (!r || !e.postProcessManager._prepareFrame(this._texture)) && this._bindFrameBuffer(t, n);
	}
	_renderToTarget(e, t, n, r = 0) {
		let i = this.getScene();
		if (!i) return;
		let a = i.getEngine();
		this._currentFaceIndex = e, this._currentLayer = r, this._currentUseCameraPostProcess = t, this._currentDumpForDebug = n, this._prepareFrame(i, e, r, t), this._objectRenderer.render(e + r, !0), this._unbindFrameBuffer(a, e), this._texture && this.isCube && e === 5 && a.generateMipMapsForCubemap(this._texture, !0);
	}
	setRenderingOrder(e, t = null, n = null, r = null) {
		this._objectRenderer.setRenderingOrder(e, t, n, r);
	}
	setRenderingAutoClearDepthStencil(e, t) {
		this._objectRenderer.setRenderingAutoClearDepthStencil(e, t);
	}
	clone() {
		let e = this.getSize(), t = new n(this.name, e, this.getScene(), this._renderTargetOptions.generateMipMaps, this._doNotChangeAspectRatio, this._renderTargetOptions.type, this.isCube, this._renderTargetOptions.samplingMode, this._renderTargetOptions.generateDepthBuffer, this._renderTargetOptions.generateStencilBuffer, void 0, this._renderTargetOptions.format, void 0, this._renderTargetOptions.samples);
		return t.hasAlpha = this.hasAlpha, t.level = this.level, t.coordinatesMode = this.coordinatesMode, this.renderList && (t.renderList = this.renderList.slice(0)), t;
	}
	serialize() {
		if (!this.name) return null;
		let e = super.serialize();
		if (e.renderTargetSize = this.getRenderSize(), e.renderList = [], this.renderList) for (let t = 0; t < this.renderList.length; t++) e.renderList.push(this.renderList[t].id);
		return e;
	}
	disposeFramebufferObjects() {
		this._renderTarget?.dispose(!0);
	}
	releaseInternalTexture() {
		this._renderTarget?.releaseTextures(), this._texture = null;
	}
	dispose() {
		this.onResizeObservable.clear(), this.onClearObservable.clear(), this.onAfterUnbindObservable.clear(), this.onBeforeBindObservable.clear(), this._postProcessManager &&= (this._postProcessManager.dispose(), null), this._prePassRenderTarget && this._prePassRenderTarget.dispose(), this._objectRenderer.onBeforeRenderingManagerRenderObservable.remove(this._onBeforeRenderingManagerRenderObserver), this._objectRenderer.onAfterRenderingManagerRenderObservable.remove(this._onAfterRenderingManagerRenderObserver), this._objectRenderer.onFastPathRenderObservable.remove(this._onFastPathRenderObserver), this._dontDisposeObjectRenderer || this._objectRenderer.dispose(), this.clearPostProcesses(!0), this._resizeObserver &&= (this.getScene().getEngine().onResizeObservable.remove(this._resizeObserver), null);
		let e = this.getScene();
		if (!e) return;
		let t = e.customRenderTargets.indexOf(this);
		t >= 0 && e.customRenderTargets.splice(t, 1);
		for (let n of e.cameras) t = n.customRenderTargets.indexOf(this), t >= 0 && n.customRenderTargets.splice(t, 1);
		this._renderTarget?.dispose(), this._renderTarget = null, this._texture = null, super.dispose();
	}
	_rebuild() {
		this._objectRenderer._rebuild(), this._postProcessManager && this._postProcessManager._rebuild();
	}
	freeRenderingGroups() {
		this._objectRenderer.freeRenderingGroups();
	}
	getViewCount() {
		return 1;
	}
};
b.REFRESHRATE_RENDER_ONCE = y.REFRESHRATE_RENDER_ONCE, b.REFRESHRATE_RENDER_ONEVERYFRAME = y.REFRESHRATE_RENDER_ONEVERYFRAME, b.REFRESHRATE_RENDER_ONEVERYTWOFRAMES = y.REFRESHRATE_RENDER_ONEVERYTWOFRAMES;
var x = !1;
function S() {
	x || (x = !0, v(), n.prototype.setDepthStencilTexture = function(e, t) {
		this._engine.setDepthStencilTexture(this._samplers[e], this._uniforms[e], t, e);
	}, g._CreateRenderTargetTexture = (e, t, n, r, i) => new b(e, t, n, r));
}
Object.getOwnPropertyDescriptor(b.prototype, "noPrePassRenderer") || Object.defineProperty(b.prototype, "noPrePassRenderer", s("RenderTargetTexture", "noPrePassRenderer"));
//#endregion
export { b as n, v as r, S as t };
