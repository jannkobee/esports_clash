import { t as e } from "./logger-DQIzSR_y.js";
import { r as t } from "./tools.pure-Dy2G52NL.js";
import { t as n } from "./workerPool-CbvEbM2K.js";
//#region node_modules/@babylonjs/core/Misc/khronosTextureContainer.js
var r = class t {
	constructor(n, r) {
		if (this.data = n, this.isInvalid = !1, !t.IsValid(n)) {
			this.isInvalid = !0, e.Error("texture missing KTX identifier");
			return;
		}
		let i = Uint32Array.BYTES_PER_ELEMENT, a = new DataView(this.data.buffer, this.data.byteOffset + 12, 13 * i), o = a.getUint32(0, !0) === 67305985;
		this.glType = a.getUint32(1 * i, o), this.glTypeSize = a.getUint32(2 * i, o), this.glFormat = a.getUint32(3 * i, o), this.glInternalFormat = a.getUint32(4 * i, o), this.glBaseInternalFormat = a.getUint32(5 * i, o), this.pixelWidth = a.getUint32(6 * i, o), this.pixelHeight = a.getUint32(7 * i, o), this.pixelDepth = a.getUint32(8 * i, o), this.numberOfArrayElements = a.getUint32(9 * i, o), this.numberOfFaces = a.getUint32(10 * i, o), this.numberOfMipmapLevels = a.getUint32(11 * i, o), this.bytesOfKeyValueData = a.getUint32(12 * i, o), this.glType === 0 ? (this.numberOfMipmapLevels = Math.max(1, this.numberOfMipmapLevels), this.pixelHeight === 0 || this.pixelDepth !== 0 ? (e.Error("only 2D textures currently supported"), this.isInvalid = !0) : this.numberOfArrayElements === 0 ? this.numberOfFaces === r ? this.loadType = t.COMPRESSED_2D : (e.Error("number of faces expected" + r + ", but found " + this.numberOfFaces), this.isInvalid = !0) : (e.Error("texture arrays not currently supported"), this.isInvalid = !0)) : (e.Error("only compressed formats currently supported"), this.isInvalid = !0);
	}
	uploadLevels(e, n) {
		switch (this.loadType) {
			case t.COMPRESSED_2D:
				this._upload2DCompressedLevels(e, n);
				break;
			case t.TEX_2D:
			case t.COMPRESSED_3D:
			case t.TEX_3D:
		}
	}
	_upload2DCompressedLevels(e, n) {
		let r = t.HEADER_LEN + this.bytesOfKeyValueData, i = this.pixelWidth, a = this.pixelHeight, o = n ? this.numberOfMipmapLevels : 1;
		for (let t = 0; t < o; t++) {
			let n = new Int32Array(this.data.buffer, this.data.byteOffset + r, 1)[0];
			r += 4;
			for (let o = 0; o < this.numberOfFaces; o++) {
				let s = new Uint8Array(this.data.buffer, this.data.byteOffset + r, n);
				e.getEngine()._uploadCompressedDataToTextureDirectly(e, e.format, i, a, s, o, t), r += n, r += 3 - (n + 3) % 4;
			}
			i = Math.max(1, i * .5), a = Math.max(1, a * .5);
		}
	}
	static IsValid(e) {
		if (e.byteLength >= 12) {
			let t = new Uint8Array(e.buffer, e.byteOffset, 12);
			if (t[0] === 171 && t[1] === 75 && t[2] === 84 && t[3] === 88 && t[4] === 32 && t[5] === 49 && t[6] === 49 && t[7] === 187 && t[8] === 13 && t[9] === 10 && t[10] === 26 && t[11] === 10) return !0;
		}
		return !1;
	}
};
r.HEADER_LEN = 64, r.COMPRESSED_2D = 0, r.COMPRESSED_3D = 1, r.TEX_2D = 2, r.TEX_3D = 3;
//#endregion
//#region node_modules/@babylonjs/core/Materials/Textures/ktx2decoderTypes.js
var i;
(function(e) {
	e[e.ETC1S = 0] = "ETC1S", e[e.UASTC4x4 = 1] = "UASTC4x4", e[e.RGBA32 = 2] = "RGBA32";
})(i ||= {});
var a;
(function(e) {
	e[e.ASTC_4X4_RGBA = 0] = "ASTC_4X4_RGBA", e[e.ASTC_4x4_RGBA = 0] = "ASTC_4x4_RGBA", e[e.BC7_RGBA = 1] = "BC7_RGBA", e[e.BC3_RGBA = 2] = "BC3_RGBA", e[e.BC1_RGB = 3] = "BC1_RGB", e[e.PVRTC1_4_RGBA = 4] = "PVRTC1_4_RGBA", e[e.PVRTC1_4_RGB = 5] = "PVRTC1_4_RGB", e[e.ETC2_RGBA = 6] = "ETC2_RGBA", e[e.ETC1_RGB = 7] = "ETC1_RGB", e[e.RGBA32 = 8] = "RGBA32", e[e.R8 = 9] = "R8", e[e.RG8 = 10] = "RG8";
})(a ||= {});
var o;
(function(e) {
	e[e.COMPRESSED_RGBA_BPTC_UNORM_EXT = 36492] = "COMPRESSED_RGBA_BPTC_UNORM_EXT", e[e.COMPRESSED_RGBA_ASTC_4X4_KHR = 37808] = "COMPRESSED_RGBA_ASTC_4X4_KHR", e[e.COMPRESSED_RGB_S3TC_DXT1_EXT = 33776] = "COMPRESSED_RGB_S3TC_DXT1_EXT", e[e.COMPRESSED_RGBA_S3TC_DXT5_EXT = 33779] = "COMPRESSED_RGBA_S3TC_DXT5_EXT", e[e.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG = 35842] = "COMPRESSED_RGBA_PVRTC_4BPPV1_IMG", e[e.COMPRESSED_RGB_PVRTC_4BPPV1_IMG = 35840] = "COMPRESSED_RGB_PVRTC_4BPPV1_IMG", e[e.COMPRESSED_RGBA8_ETC2_EAC = 37496] = "COMPRESSED_RGBA8_ETC2_EAC", e[e.COMPRESSED_RGB8_ETC2 = 37492] = "COMPRESSED_RGB8_ETC2", e[e.COMPRESSED_RGB_ETC1_WEBGL = 36196] = "COMPRESSED_RGB_ETC1_WEBGL", e[e.RGBA8Format = 32856] = "RGBA8Format", e[e.R8Format = 33321] = "R8Format", e[e.RG8Format = 33323] = "RG8Format";
})(o ||= {});
//#endregion
//#region node_modules/@babylonjs/core/Misc/khronosTextureContainer2Worker.js
function s(e, t) {
	let n = t?.jsDecoderModule || KTX2DECODER;
	e && (e.wasmBaseUrl && (n.Transcoder.WasmBaseUrl = e.wasmBaseUrl), e.wasmUASTCToASTC && (n.LiteTranscoder_UASTC_ASTC.WasmModuleURL = e.wasmUASTCToASTC), e.wasmUASTCToBC7 && (n.LiteTranscoder_UASTC_BC7.WasmModuleURL = e.wasmUASTCToBC7), e.wasmUASTCToRGBA_UNORM && (n.LiteTranscoder_UASTC_RGBA_UNORM.WasmModuleURL = e.wasmUASTCToRGBA_UNORM), e.wasmUASTCToRGBA_SRGB && (n.LiteTranscoder_UASTC_RGBA_SRGB.WasmModuleURL = e.wasmUASTCToRGBA_SRGB), e.wasmUASTCToR8_UNORM && (n.LiteTranscoder_UASTC_R8_UNORM.WasmModuleURL = e.wasmUASTCToR8_UNORM), e.wasmUASTCToRG8_UNORM && (n.LiteTranscoder_UASTC_RG8_UNORM.WasmModuleURL = e.wasmUASTCToRG8_UNORM), e.jsMSCTranscoder && (n.MSCTranscoder.JSModuleURL = e.jsMSCTranscoder), e.wasmMSCTranscoder && (n.MSCTranscoder.WasmModuleURL = e.wasmMSCTranscoder), e.wasmZSTDDecoder && (n.ZSTDDecoder.WasmModuleURL = e.wasmZSTDDecoder)), t && (t.wasmUASTCToASTC && (n.LiteTranscoder_UASTC_ASTC.WasmBinary = t.wasmUASTCToASTC), t.wasmUASTCToBC7 && (n.LiteTranscoder_UASTC_BC7.WasmBinary = t.wasmUASTCToBC7), t.wasmUASTCToRGBA_UNORM && (n.LiteTranscoder_UASTC_RGBA_UNORM.WasmBinary = t.wasmUASTCToRGBA_UNORM), t.wasmUASTCToRGBA_SRGB && (n.LiteTranscoder_UASTC_RGBA_SRGB.WasmBinary = t.wasmUASTCToRGBA_SRGB), t.wasmUASTCToR8_UNORM && (n.LiteTranscoder_UASTC_R8_UNORM.WasmBinary = t.wasmUASTCToR8_UNORM), t.wasmUASTCToRG8_UNORM && (n.LiteTranscoder_UASTC_RG8_UNORM.WasmBinary = t.wasmUASTCToRG8_UNORM), t.jsMSCTranscoder && (n.MSCTranscoder.JSModule = t.jsMSCTranscoder), t.wasmMSCTranscoder && (n.MSCTranscoder.WasmBinary = t.wasmMSCTranscoder), t.wasmZSTDDecoder && (n.ZSTDDecoder.WasmBinary = t.wasmZSTDDecoder));
}
function c(e) {
	e === void 0 && typeof KTX2DECODER < "u" && (e = KTX2DECODER);
	let t;
	onmessage = (n) => {
		if (n.data) switch (n.data.action) {
			case "init": {
				let r = n.data.urls;
				r && (r.jsDecoderModule && e === void 0 && (importScripts(r.jsDecoderModule), e = KTX2DECODER), s(r)), n.data.wasmBinaries && s(void 0, {
					...n.data.wasmBinaries,
					jsDecoderModule: e
				}), t = new e.KTX2Decoder(), postMessage({ action: "init" });
				break;
			}
			case "setDefaultDecoderOptions":
				e.KTX2Decoder.DefaultDecoderOptions = n.data.options;
				break;
			case "decode": t.decode(n.data.data, n.data.caps, n.data.options).then((e) => {
				let t = [];
				for (let n = 0; n < e.mipmaps.length; ++n) {
					let r = e.mipmaps[n];
					r && r.data && t.push(r.data.buffer);
				}
				postMessage({
					action: "decoded",
					success: !0,
					decodedData: e
				}, t);
			}).catch((e) => {
				postMessage({
					action: "decoded",
					success: !1,
					msg: e
				});
			});
		}
	};
}
async function l(e, t, n) {
	return await new Promise((r, i) => {
		let a = (t) => {
			e.removeEventListener("error", a), e.removeEventListener("message", o), i(t);
		}, o = (t) => {
			t.data.action === "init" && (e.removeEventListener("error", a), e.removeEventListener("message", o), r(e));
		};
		e.addEventListener("error", a), e.addEventListener("message", o), e.postMessage({
			action: "init",
			urls: n,
			wasmBinaries: t
		});
	});
}
//#endregion
//#region node_modules/@babylonjs/core/Misc/khronosTextureContainer2.js
var u = class {
	constructor() {
		this._isDirty = !0, this._useRGBAIfOnlyBC1BC3AvailableWhenUASTC = !0, this._ktx2DecoderOptions = {};
	}
	get isDirty() {
		return this._isDirty;
	}
	get useRGBAIfASTCBC7NotAvailableWhenUASTC() {
		return this._useRGBAIfASTCBC7NotAvailableWhenUASTC;
	}
	set useRGBAIfASTCBC7NotAvailableWhenUASTC(e) {
		this._useRGBAIfASTCBC7NotAvailableWhenUASTC !== e && (this._useRGBAIfASTCBC7NotAvailableWhenUASTC = e, this._isDirty = !0);
	}
	get useRGBAIfOnlyBC1BC3AvailableWhenUASTC() {
		return this._useRGBAIfOnlyBC1BC3AvailableWhenUASTC;
	}
	set useRGBAIfOnlyBC1BC3AvailableWhenUASTC(e) {
		this._useRGBAIfOnlyBC1BC3AvailableWhenUASTC !== e && (this._useRGBAIfOnlyBC1BC3AvailableWhenUASTC = e, this._isDirty = !0);
	}
	get forceRGBA() {
		return this._forceRGBA;
	}
	set forceRGBA(e) {
		this._forceRGBA !== e && (this._forceRGBA = e, this._isDirty = !0);
	}
	get forceR8() {
		return this._forceR8;
	}
	set forceR8(e) {
		this._forceR8 !== e && (this._forceR8 = e, this._isDirty = !0);
	}
	get forceRG8() {
		return this._forceRG8;
	}
	set forceRG8(e) {
		this._forceRG8 !== e && (this._forceRG8 = e, this._isDirty = !0);
	}
	get bypassTranscoders() {
		return this._bypassTranscoders;
	}
	set bypassTranscoders(e) {
		this._bypassTranscoders !== e && (this._bypassTranscoders = e, this._isDirty = !0);
	}
	_getKTX2DecoderOptions() {
		if (!this._isDirty) return this._ktx2DecoderOptions;
		this._isDirty = !1;
		let e = {};
		return this._useRGBAIfASTCBC7NotAvailableWhenUASTC !== void 0 && (e.useRGBAIfASTCBC7NotAvailableWhenUASTC = this._useRGBAIfASTCBC7NotAvailableWhenUASTC), this._forceRGBA !== void 0 && (e.forceRGBA = this._forceRGBA), this._forceR8 !== void 0 && (e.forceR8 = this._forceR8), this._forceRG8 !== void 0 && (e.forceRG8 = this._forceRG8), this._bypassTranscoders !== void 0 && (e.bypassTranscoders = this._bypassTranscoders), this.useRGBAIfOnlyBC1BC3AvailableWhenUASTC && (e.transcodeFormatDecisionTree = { UASTC: {
			transcodeFormat: [a.BC1_RGB, a.BC3_RGBA],
			yes: {
				transcodeFormat: a.RGBA32,
				engineFormat: 32856,
				roundToMultiple4: !1
			}
		} }), this._ktx2DecoderOptions = e, e;
	}
}, d = class e {
	static GetDefaultNumWorkers() {
		return typeof navigator != "object" || !navigator.hardwareConcurrency ? 1 : Math.min(Math.floor(navigator.hardwareConcurrency * .5), 4);
	}
	static _Initialize(r) {
		if (e._WorkerPoolPromise || e._DecoderModulePromise) return;
		let i = {
			wasmBaseUrl: t.ScriptBaseUrl,
			jsDecoderModule: t.GetBabylonScriptURL(this.URLConfig.jsDecoderModule, !0),
			wasmUASTCToASTC: t.GetBabylonScriptURL(this.URLConfig.wasmUASTCToASTC, !0),
			wasmUASTCToBC7: t.GetBabylonScriptURL(this.URLConfig.wasmUASTCToBC7, !0),
			wasmUASTCToRGBA_UNORM: t.GetBabylonScriptURL(this.URLConfig.wasmUASTCToRGBA_UNORM, !0),
			wasmUASTCToRGBA_SRGB: t.GetBabylonScriptURL(this.URLConfig.wasmUASTCToRGBA_SRGB, !0),
			wasmUASTCToR8_UNORM: t.GetBabylonScriptURL(this.URLConfig.wasmUASTCToR8_UNORM, !0),
			wasmUASTCToRG8_UNORM: t.GetBabylonScriptURL(this.URLConfig.wasmUASTCToRG8_UNORM, !0),
			jsMSCTranscoder: t.GetBabylonScriptURL(this.URLConfig.jsMSCTranscoder, !0),
			wasmMSCTranscoder: t.GetBabylonScriptURL(this.URLConfig.wasmMSCTranscoder, !0),
			wasmZSTDDecoder: t.GetBabylonScriptURL(this.URLConfig.wasmZSTDDecoder, !0)
		};
		r && typeof Worker == "function" && typeof URL < "u" ? e._WorkerPoolPromise = new Promise((e) => {
			let t = `${s}(${c})()`, a = URL.createObjectURL(new Blob([t], { type: "application/javascript" }));
			e(new n(r, async () => await l(new Worker(a), void 0, i)));
		}) : e._KTX2DecoderModule === void 0 ? e._DecoderModulePromise = t.LoadBabylonScriptAsync(i.jsDecoderModule).then(() => (e._KTX2DecoderModule = KTX2DECODER, e._KTX2DecoderModule.MSCTranscoder.UseFromWorkerThread = !1, e._KTX2DecoderModule.WASMMemoryManager.LoadBinariesFromCurrentThread = !0, s(i, e._KTX2DecoderModule), new e._KTX2DecoderModule.KTX2Decoder())) : (e._KTX2DecoderModule.MSCTranscoder.UseFromWorkerThread = !1, e._KTX2DecoderModule.WASMMemoryManager.LoadBinariesFromCurrentThread = !0, e._DecoderModulePromise = Promise.resolve(new e._KTX2DecoderModule.KTX2Decoder()));
	}
	constructor(t, n = e.DefaultNumWorkers) {
		this._engine = t;
		let r = typeof n == "object" && n.workerPool || e.WorkerPool;
		if (r) e._WorkerPoolPromise = Promise.resolve(r);
		else {
			typeof n == "object" ? e._KTX2DecoderModule = n?.binariesAndModulesContainer?.jsDecoderModule : typeof KTX2DECODER < "u" && (e._KTX2DecoderModule = KTX2DECODER);
			let t = typeof n == "number" ? n : n.numWorkers ?? e.DefaultNumWorkers;
			e._Initialize(t);
		}
	}
	async _uploadAsync(e, t, n) {
		let r = await this._decodeAsync(e, n);
		this._createTexture(r, t, n);
	}
	async _decodeAsync(t, n) {
		let r = this._engine.getCaps(), i = {
			astc: !!r.astc,
			bptc: !!r.bptc,
			s3tc: !!r.s3tc,
			pvrtc: !!r.pvrtc,
			etc2: !!r.etc2,
			etc1: !!r.etc1
		};
		if (e._WorkerPoolPromise) {
			let r = await e._WorkerPoolPromise;
			return await new Promise((a, o) => {
				r.push((r, s) => {
					let c = (e) => {
						r.removeEventListener("error", c), r.removeEventListener("message", l), o(e), s();
					}, l = (e) => {
						e.data.action === "decoded" && (r.removeEventListener("error", c), r.removeEventListener("message", l), e.data.success ? a(e.data.decodedData) : o({ message: e.data.msg }), s());
					};
					r.addEventListener("error", c), r.addEventListener("message", l), r.postMessage({
						action: "setDefaultDecoderOptions",
						options: e.DefaultDecoderOptions._getKTX2DecoderOptions()
					});
					let u = new Uint8Array(t.byteLength);
					u.set(new Uint8Array(t.buffer, t.byteOffset, t.byteLength)), r.postMessage({
						action: "decode",
						data: u,
						caps: i,
						options: n
					}, [u.buffer]);
				});
			});
		}
		if (e._DecoderModulePromise) {
			let i = await e._DecoderModulePromise;
			return e.DefaultDecoderOptions.isDirty && (e._KTX2DecoderModule.KTX2Decoder.DefaultDecoderOptions = e.DefaultDecoderOptions._getKTX2DecoderOptions()), await new Promise((e, a) => {
				i.decode(t, r, n).then((t) => {
					e(t);
				}).catch((e) => {
					a({ message: e });
				});
			});
		}
		throw Error("KTX2 decoder module is not available");
	}
	_createTexture(e, t, n) {
		if ((e.layerCount ?? 1) > 1) throw Error("KTX2 container - array textures are not supported by this texture loader.");
		let r = 3553;
		this._engine._bindTextureDirectly(r, t), n && (n.transcodedFormat = e.transcodedFormat, n.isInGammaSpace = e.isInGammaSpace, n.hasAlpha = e.hasAlpha, n.transcoderName = e.transcoderName);
		let i = !0;
		switch (e.transcodedFormat) {
			case 32856:
				t.type = 0, t.format = 5;
				break;
			case 33321:
				t.type = 0, t.format = 6;
				break;
			case 33323:
				t.type = 0, t.format = 7;
				break;
			default: t.format = e.transcodedFormat, i = !1;
		}
		if (t._gammaSpace = e.isInGammaSpace, t.generateMipMaps = e.mipmaps.length > 1, t.width = e.mipmaps[0].width, t.height = e.mipmaps[0].height, e.errors) throw Error("KTX2 container - could not transcode the data. " + e.errors);
		for (let n = 0; n < e.mipmaps.length; ++n) {
			let r = e.mipmaps[n];
			if (!r || !r.data) throw Error("KTX2 container - could not transcode one of the image");
			i ? (t.width = r.width, t.height = r.height, this._engine._uploadDataToTextureDirectly(t, r.data, 0, n, void 0, !0)) : this._engine._uploadCompressedDataToTextureDirectly(t, e.transcodedFormat, r.width, r.height, r.data, 0, n);
		}
		t._extension = ".ktx2", t.isReady = !0, this._engine._bindTextureDirectly(r, null);
	}
	static IsValid(e) {
		if (e.byteLength >= 12) {
			let t = new Uint8Array(e.buffer, e.byteOffset, 12);
			if (t[0] === 171 && t[1] === 75 && t[2] === 84 && t[3] === 88 && t[4] === 32 && t[5] === 50 && t[6] === 48 && t[7] === 187 && t[8] === 13 && t[9] === 10 && t[10] === 26 && t[11] === 10) return !0;
		}
		return !1;
	}
};
d.URLConfig = {
	jsDecoderModule: "https://cdn.babylonjs.com/babylon.ktx2Decoder.js",
	wasmUASTCToASTC: null,
	wasmUASTCToBC7: null,
	wasmUASTCToRGBA_UNORM: null,
	wasmUASTCToRGBA_SRGB: null,
	wasmUASTCToR8_UNORM: null,
	wasmUASTCToRG8_UNORM: null,
	jsMSCTranscoder: null,
	wasmMSCTranscoder: null,
	wasmZSTDDecoder: null
}, d.DefaultNumWorkers = d.GetDefaultNumWorkers(), d.DefaultDecoderOptions = new u();
//#endregion
//#region node_modules/@babylonjs/core/Materials/Textures/Loaders/ktxTextureLoader.js
function f(e) {
	switch (e) {
		case 35916: return 33776;
		case 35918: return 33778;
		case 35919: return 33779;
		case 37493: return 37492;
		case 37497: return 37496;
		case 37495: return 37494;
		case 37840: return 37808;
		case 37841: return 37809;
		case 37842: return 37810;
		case 37843: return 37811;
		case 37844: return 37812;
		case 37845: return 37813;
		case 37846: return 37814;
		case 37847: return 37815;
		case 37848: return 37816;
		case 37849: return 37817;
		case 37850: return 37818;
		case 37851: return 37819;
		case 37852: return 37820;
		case 37853: return 37821;
		case 36493: return 36492;
	}
	return null;
}
var p = class {
	constructor() {
		this.supportCascades = !1;
	}
	loadCubeData(e, t, n, i) {
		if (Array.isArray(e)) return;
		t._invertVScale = !t.invertY;
		let a = t.getEngine(), o = new r(e, 6), s = f(o.glInternalFormat);
		s === null ? t.format = o.glInternalFormat : (t.format = s, t._useSRGBBuffer = a._getUseSRGBBuffer(!0, !t.generateMipMaps), t._gammaSpace = !0);
		let c = o.numberOfMipmapLevels > 1 && t.generateMipMaps;
		a._unpackFlipY(!0), o.uploadLevels(t, t.generateMipMaps), t.width = o.pixelWidth, t.height = o.pixelHeight, a._setCubeMapTextureParams(t, c, o.numberOfMipmapLevels - 1), t.isReady = !0, t.onLoadedObservable.notifyObservers(t), t.onLoadedObservable.clear(), i && i();
	}
	loadData(t, n, i, a) {
		if (r.IsValid(t)) {
			n._invertVScale = !n.invertY;
			let e = new r(t, 1), a = f(e.glInternalFormat);
			a === null ? n.format = e.glInternalFormat : (n.format = a, n._useSRGBBuffer = n.getEngine()._getUseSRGBBuffer(!0, !n.generateMipMaps), n._gammaSpace = !0), i(e.pixelWidth, e.pixelHeight, n.generateMipMaps, !0, () => {
				e.uploadLevels(n, n.generateMipMaps);
			}, e.isInvalid);
		} else d.IsValid(t) ? new d(n.getEngine())._uploadAsync(t, n, a).then(() => {
			i(n.width, n.height, n.generateMipMaps, !0, () => {}, !1);
		}, (t) => {
			e.Warn(`Failed to load KTX2 texture data: ${t.message}`), i(0, 0, !1, !1, () => {}, !0);
		}) : (e.Error("texture missing KTX identifier"), i(0, 0, !1, !1, () => {}, !0));
	}
};
//#endregion
export { p as _KTXTextureLoader };
