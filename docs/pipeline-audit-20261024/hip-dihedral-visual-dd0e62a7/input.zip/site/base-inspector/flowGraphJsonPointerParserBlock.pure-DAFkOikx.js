import { d as e, n as t, t as n, u as r } from "./math.color.pure-CPmbqLkh.js";
import { n as i } from "./typeStore-pENEWnX2.js";
import { t as a } from "./flowGraphInteger.pure-DqL1vt3x.js";
import { n as o } from "./flowGraphRichTypes.pure-BpKU4EZT.js";
import { t as s } from "./flowGraphCachedOperationBlock-BsIcMusH.js";
//#region node_modules/@babylonjs/core/FlowGraph/flowGraphPathConverterComponent.js
var c = () => /* @__PURE__ */ new RegExp(/\/\{(\w+)\}(?=\/|$)/g), l = () => /* @__PURE__ */ new RegExp(/\/\[(\w+)\](?=\/|$)/g), u = class {
	constructor(e, t) {
		this.path = e, this.ownerBlock = t, this.templatedInputs = [], this.templateInfos = [];
		let n = /* @__PURE__ */ new Set(), r = (r, i) => {
			let s = r.exec(e);
			for (; s;) {
				let [, c] = s;
				if (n.has(c)) throw Error("Duplicate template variable detected.");
				n.add(c);
				let l = t.registerDataInput(c, o, new a(0));
				this.templatedInputs.push(l), this.templateInfos.push({
					name: c,
					style: i,
					connection: l
				}), s = r.exec(e);
			}
		};
		r(c(), "curly"), r(l(), "square");
	}
	getAccessor(e, t) {
		let n = this.path;
		for (let e of this.templateInfos) {
			let r = e.connection.getValue(t), i = e.style === "curly" ? `{${e.name}}` : `[${e.name}]`, a = d(this.path, e.name, r, t);
			n = n.replace(i, a);
		}
		return e.convert(n);
	}
};
function d(e, t, n, r) {
	if (n instanceof a) return m(n.value, t), n.value.toString();
	if (typeof n == "number") return m(n, t), n.toString();
	if (typeof n == "string") {
		if (n === "") throw Error(`Templated reference input "${t}" is null.`);
		return h(e, t, n);
	}
	if (n && typeof n == "object") {
		let i = r.getObjectReference(n, p(e, t));
		if (i) return h(e, t, i);
	}
	throw Error(`Invalid value for templated input "${t}": got ${typeof n}.`);
}
function f(e, t) {
	let n = [`{${t}}`, `[${t}]`];
	return e.split("/").findIndex((e) => n.indexOf(e) >= 0);
}
function p(e, t) {
	let n = f(e, t);
	return n > 0 ? e.split("/")[n - 1] : void 0;
}
function m(e, t) {
	if (typeof e != "number" || e < 0 || !Number.isFinite(e)) throw Error(`Invalid value for templated input "${t}": ${e}.`);
}
function h(e, t, n) {
	let r = e.split("/"), i = [`{${t}}`, `[${t}]`], a = r.findIndex((e) => i.indexOf(e) >= 0), o = n.split("/");
	if (a >= 0 && a < o.length && o[a] !== "") return o[a];
	for (let e = o.length - 1; e >= 0; e--) if (o[e] !== "") return o[e];
	return n;
}
//#endregion
//#region node_modules/@babylonjs/core/FlowGraph/Blocks/Data/Transformers/flowGraphJsonPointerParserBlock.pure.js
var g = class extends s {
	constructor(e) {
		super(o, e), this.config = e, this.object = this.registerDataOutput("object", o), this.propertyName = this.registerDataOutput("propertyName", o), this.setterFunction = this.registerDataOutput("setFunction", o, this._setPropertyValue.bind(this)), this.getterFunction = this.registerDataOutput("getFunction", o, this._getPropertyValue.bind(this)), this.generateAnimationsFunction = this.registerDataOutput("generateAnimationsFunction", o, this._getInterpolationAnimationPropertyInfo.bind(this)), this.animationTargets = this.registerDataOutput("animationTargets", o), this.templateComponent = new u(e.jsonPointer, this);
	}
	_doOperation(e) {
		let t = this.templateComponent.getAccessor(this.config.pathConverter, e), n = t.info.get(t.object, void 0, e), r = t.info.getTarget?.(t.object), i = t.info.getPropertyName?.[0](t.object) ?? t.info.interpolation?.[0]?.name;
		if (r) this.object.setValue(r, e), i && this.propertyName.setValue(i, e);
		else throw Error("Object is undefined");
		return n;
	}
	_setPropertyValue(e, t, n, r) {
		let i = this.templateComponent.getAccessor(this.config.pathConverter, r), a = i.info.type;
		if (this.config.valueType !== void 0 && ((a === "Color3" ? "Vector3" : a === "Color4" || a === "Quaternion" ? "Vector4" : a) !== this.config.valueType || i.info.isReadOnly || !i.info.set)) throw Error(`Property is not writable with value type ${this.config.valueType}`);
		a.startsWith("Color") && (n = _(n, a)), typeof n?.value == "number" && n?.getClassName?.() === "FlowGraphInteger" && (n = n.value), i.info.set?.(n, i.object);
	}
	_getPropertyValue(e, t, n) {
		let r = this.templateComponent.getAccessor(this.config.pathConverter, n), i = r.info.type, a = r.info.get(r.object, void 0, n);
		return i.startsWith("Color") ? v(a) : a;
	}
	_getInterpolationAnimationPropertyInfo(e, t, n) {
		let r = this.templateComponent.getAccessor(this.config.pathConverter, n);
		if (this.config.valueType !== void 0) {
			let e = r.info.type;
			if ((e === "Color3" ? "Vector3" : e === "Color4" || e === "Quaternion" ? "Vector4" : e) !== this.config.valueType || r.info.isReadOnly || !r.info.interpolation?.length) throw Error(`Property is not interpolatable with value type ${this.config.valueType}`);
		}
		return (e, t, i, a) => {
			let o = [], s = [], c = r.info.type;
			return c.startsWith("Color") && (e = e.map((e) => ({
				frame: e.frame,
				value: _(e.value, c)
			}))), r.info.interpolation?.forEach((t, n) => {
				let i = r.info.getPropertyName?.[n](r.object) || "Animation-interpolation-" + n, c = e.map((e) => ({
					frame: e.frame,
					value: t.getValue(r.object, e.value.asArray ? e.value.asArray() : [e.value], 0, 1)
				})), l = t.buildAnimations(r.object, i, 60, c);
				for (let e of l) a && e.babylonAnimation.setEasingFunction(a), o.push(e.babylonAnimation), s.push(e.babylonAnimatable);
			}), this.animationTargets.setValue(s, n), o;
		};
	}
	getClassName() {
		return "FlowGraphJsonPointerParserBlock";
	}
};
function _(e, r) {
	return e.getClassName().startsWith("Color") ? e : r === "Color3" ? new n(e.x, e.y, e.z) : r === "Color4" ? new t(e.x, e.y, e.z, e.w) : e;
}
function v(i) {
	if (i instanceof n) return new r(i.r, i.g, i.b);
	if (i instanceof t) return new e(i.r, i.g, i.b, i.a);
	throw Error("Invalid color type");
}
var y = !1;
function b() {
	y || (y = !0, i("FlowGraphJsonPointerParserBlock", g));
}
//#endregion
export { g as FlowGraphJsonPointerParserBlock, b as RegisterFlowGraphJsonPointerParserBlock };
