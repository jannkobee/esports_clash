//#region node_modules/@babylonjs/core/Misc/halfFloat.js
var e = null;
function t() {
	if (e) return e;
	let t = /* @__PURE__ */ new ArrayBuffer(4), n = new Float32Array(t), r = new Uint32Array(t), i = /* @__PURE__ */ new Uint32Array(512), a = /* @__PURE__ */ new Uint32Array(512);
	for (let e = 0; e < 256; ++e) {
		let t = e - 127;
		t < -24 ? (i[e] = 0, i[e | 256] = 32768, a[e] = 24, a[e | 256] = 24) : t < -14 ? (i[e] = 1024 >> -t - 14, i[e | 256] = 1024 >> -t - 14 | 32768, a[e] = -t - 1, a[e | 256] = -t - 1) : t <= 15 ? (i[e] = t + 15 << 10, i[e | 256] = t + 15 << 10 | 32768, a[e] = 13, a[e | 256] = 13) : t < 128 ? (i[e] = 31744, i[e | 256] = 64512, a[e] = 24, a[e | 256] = 24) : (i[e] = 31744, i[e | 256] = 64512, a[e] = 13, a[e | 256] = 13);
	}
	let o = /* @__PURE__ */ new Uint32Array(2048), s = /* @__PURE__ */ new Uint32Array(64), c = /* @__PURE__ */ new Uint32Array(64);
	for (let e = 1; e < 1024; ++e) {
		let t = e << 13, n = 0;
		for (; !(t & 8388608);) t <<= 1, n -= 8388608;
		t &= -8388609, n += 947912704, o[e] = t | n;
	}
	for (let e = 1024; e < 2048; ++e) o[e] = 939524096 + (e - 1024 << 13);
	for (let e = 1; e < 31; ++e) s[e] = e << 23;
	s[31] = 1199570944, s[32] = 2147483648;
	for (let e = 33; e < 63; ++e) s[e] = 2147483648 + (e - 32 << 23);
	s[63] = 3347054592;
	for (let e = 1; e < 64; ++e) e !== 32 && (c[e] = 1024);
	return e = {
		floatView: n,
		uint32View: r,
		baseTable: i,
		shiftTable: a,
		mantissaTable: o,
		exponentTable: s,
		offsetTable: c
	}, e;
}
var n = 65504;
function r(e) {
	let n = t();
	n.floatView[0] = e;
	let r = n.uint32View[0], i = r >> 23 & 511;
	return n.baseTable[i] + ((r & 8388607) >> n.shiftTable[i]);
}
function i(e) {
	let n = t();
	return n.uint32View[0] = n.mantissaTable[n.offsetTable[e >> 10] + (e & 1023)] + n.exponentTable[e >> 10], n.floatView[0];
}
//#endregion
export { n, r, i as t };
