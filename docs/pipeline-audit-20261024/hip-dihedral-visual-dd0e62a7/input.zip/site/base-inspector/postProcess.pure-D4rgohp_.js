import { n as e } from "./engineStore-D0BoPdea.js";
import { r as t, t as n } from "./abstractEngine.pure-C608BZav.js";
import { n as r } from "./tools.functions-DEecYKlu.js";
import { l as i } from "./math.color.pure-CPmbqLkh.js";
import { n as a, t as o } from "./typeStore-pENEWnX2.js";
import { n as s } from "./effectRenderer.pure-CXa3ZM9e.js";
import { b as c, i as l, o as u, y as d } from "./decorators-BldPRAAT.js";
import { t as f } from "./decorators.serialization-CGAHzP43.js";
import { t as p } from "./smartArray-BmGU7Yab.js";
//#region node_modules/@babylonjs/core/PostProcesses/postProcess.pure.js
var m = (() => {
	var t;
	let n = [], a, m = [], h = [], g, _, v = [], y = [], b, x = [], S = [], C, w = [], T = [], E, D = [], O = [], k, A = [], j = [], M, N = [], P = [], F, I, L = [], R = [], z, B = [], V = [], H, U = [], W = [], G, K = [], q = [], J, Y = [], X = [], Z, Q = [], $ = [], te, ne = [], re = [];
	return t = class {
		static get ForceGLSL() {
			return s.ForceGLSL;
		}
		static set ForceGLSL(e) {
			s.ForceGLSL = e;
		}
		static RegisterShaderCodeProcessing(e, t) {
			s.RegisterShaderCodeProcessing(e, t);
		}
		get name() {
			return this._effectWrapper.name;
		}
		set name(e) {
			this._effectWrapper.name = e;
		}
		get alphaMode() {
			return this._effectWrapper.alphaMode;
		}
		set alphaMode(e) {
			this._effectWrapper.alphaMode = e;
		}
		get samples() {
			return this._samples;
		}
		set samples(e) {
			this._samples = Math.min(e, this._engine.getCaps().maxMSAASamples), this._textures.forEach((e) => {
				e.setSamples(this._samples);
			});
		}
		get shaderLanguage() {
			return this._shaderLanguage;
		}
		getEffectName() {
			return this._fragmentUrl;
		}
		set onActivate(e) {
			this._onActivateObserver && this.onActivateObservable.remove(this._onActivateObserver), e && (this._onActivateObserver = this.onActivateObservable.add(e));
		}
		set onSizeChanged(e) {
			this._onSizeChangedObserver && this.onSizeChangedObservable.remove(this._onSizeChangedObserver), this._onSizeChangedObserver = this.onSizeChangedObservable.add(e);
		}
		set onApply(e) {
			this._onApplyObserver && this.onApplyObservable.remove(this._onApplyObserver), this._onApplyObserver = this.onApplyObservable.add(e);
		}
		set onBeforeRender(e) {
			this._onBeforeRenderObserver && this.onBeforeRenderObservable.remove(this._onBeforeRenderObserver), this._onBeforeRenderObserver = this.onBeforeRenderObservable.add(e);
		}
		set onAfterRender(e) {
			this._onAfterRenderObserver && this.onAfterRenderObservable.remove(this._onAfterRenderObserver), this._onAfterRenderObserver = this.onAfterRenderObservable.add(e);
		}
		get inputTexture() {
			return this._textures.data[this._currentRenderTextureInd];
		}
		set inputTexture(e) {
			this._forcedOutputTexture = e;
		}
		restoreDefaultInputTexture() {
			this._forcedOutputTexture && (this._forcedOutputTexture = null, this.markTextureDirty());
		}
		getCamera() {
			return this._camera;
		}
		get texelSize() {
			return this._shareOutputWithPostProcess ? this._shareOutputWithPostProcess.texelSize : (this._forcedOutputTexture && this._texelSize.copyFromFloats(1 / this._forcedOutputTexture.width, 1 / this._forcedOutputTexture.height), this._texelSize);
		}
		constructor(r, a, o, l, u, d, f = 1, g, _, b = null, C = 0, E = "postprocess", k, M = !1, F = 5, I, z) {
			this._parentContainer = (c(this, n), null), this.uniqueId = c(this, m, void 0), this.width = (c(this, h), c(this, v, -1)), this.height = (c(this, y), c(this, x, -1)), this.nodeMaterialSource = (c(this, S), null), this._outputTexture = null, this.renderTargetSamplingMode = c(this, w, void 0), this.clearColor = (c(this, T), c(this, D, void 0)), this.autoClear = (c(this, O), c(this, A, !0)), this.forceAutoClearInAlphaMode = (c(this, j), c(this, N, !1)), this.alphaConstants = (c(this, P), c(this, L, void 0)), this.animations = (c(this, R), []), this.enablePixelPerfectMode = c(this, B, !1), this.forceFullscreenViewport = (c(this, V), c(this, U, !0)), this.inspectableCustomProperties = c(this, W), this.scaleMode = c(this, K, 1), this.alwaysForcePOT = (c(this, q), c(this, Y, !1)), this._samples = (c(this, X), c(this, Q, 1)), this.adaptScaleToCurrentViewport = (c(this, $), c(this, ne, !1)), this.doNotSerialize = (c(this, re), !1), this._webGPUReady = !1, this._reusable = !1, this._renderId = 0, this.externalTextureSamplerBinding = !1, this._textures = new p(2), this._textureCache = [], this._currentRenderTextureInd = 0, this._scaleRatio = new i(1, 1), this._texelSize = i.Zero(), this.onActivateObservable = new e(), this.onSizeChangedObservable = new e(), this.onApplyObservable = new e(), this.onBeforeRenderObservable = new e(), this.onAfterRenderObservable = new e(), this.onDisposeObservable = new e(), ee();
			let H = 1, G = null, J;
			if (o && !Array.isArray(o)) {
				let e = o;
				o = e.uniforms ?? null, l = e.samplers ?? null, H = e.size ?? 1, d = e.camera ?? null, f = e.samplingMode ?? 1, g = e.engine, _ = e.reusable, b = Array.isArray(e.defines) ? e.defines.join("\n") : e.defines ?? null, C = e.textureType ?? 0, E = e.vertexUrl ?? "postprocess", k = e.indexParameters, M = e.blockCompilation ?? !1, F = e.textureFormat ?? 5, I = e.shaderLanguage ?? 0, G = e.uniformBuffers ?? null, z = e.extraInitializations, J = e.effectWrapper;
			} else u && (H = typeof u == "number" ? u : {
				width: u.width,
				height: u.height
			});
			if (this._useExistingThinPostProcess = !!J, this._effectWrapper = J ?? new s({
				name: r,
				useShaderStore: !0,
				useAsPostProcess: !0,
				fragmentShader: a,
				engine: g || d?.getScene().getEngine(),
				uniforms: o,
				samplers: l,
				uniformBuffers: G,
				defines: b,
				vertexUrl: E,
				indexParameters: k,
				blockCompilation: !0,
				shaderLanguage: I,
				extraInitializations: void 0
			}), this.name = r, this.onEffectCreatedObservable = this._effectWrapper.onEffectCreatedObservable, d == null ? g && (this._engine = g, this._engine.postProcesses.push(this)) : (this._camera = d, this._scene = d.getScene(), d.attachPostProcess(this), this._engine = this._scene.getEngine(), this._scene.addPostProcess(this), this.uniqueId = this._scene.getUniqueId()), this._options = H, this.renderTargetSamplingMode = f || 1, this._reusable = _ || !1, this._textureType = C, this._textureFormat = F, this._shaderLanguage = I || 0, this._samplers = l || [], this._samplers.indexOf("textureSampler") === -1 && this._samplers.push("textureSampler"), this._fragmentUrl = a, this._vertexUrl = E, this._parameters = o || [], this._parameters.indexOf("scale") === -1 && this._parameters.push("scale"), this._uniformBuffers = G || [], this._indexParameters = k, !this._useExistingThinPostProcess) {
				this._webGPUReady = this._shaderLanguage === 1;
				let e = [];
				this._gatherImports(this._engine.isWebGPU && !t.ForceGLSL, e), this._effectWrapper._webGPUReady = this._webGPUReady, this._effectWrapper._postConstructor(M, b, z, e);
			}
		}
		_gatherImports(e = !1, t) {
			e && this._webGPUReady ? t.push(Promise.all([import("./postprocess.vertex-DpZYH6av.js")])) : t.push(Promise.all([import("./postprocess.vertex-7rFBNJhZ.js")]));
		}
		getClassName() {
			return "PostProcess";
		}
		getEngine() {
			return this._engine;
		}
		getEffect() {
			return this._effectWrapper.drawWrapper.effect;
		}
		shareOutputWith(e) {
			return this._disposeTextures(), this._shareOutputWithPostProcess = e, this;
		}
		useOwnOutput() {
			this._textures.length == 0 && (this._textures = new p(2)), this._shareOutputWithPostProcess = null;
		}
		updateEffect(e = null, t = null, n = null, r, i, a, o, s) {
			this._effectWrapper.updateEffect(e, t, n, r, i, a, o, s), this._postProcessDefines = Array.isArray(this._effectWrapper.options.defines) ? this._effectWrapper.options.defines.join("\n") : this._effectWrapper.options.defines;
		}
		isReusable() {
			return this._reusable;
		}
		markTextureDirty() {
			this.width = -1;
		}
		_createRenderTargetTexture(e, t, n = 0) {
			for (let r = 0; r < this._textureCache.length; r++) if (this._textureCache[r].texture.width === e.width && this._textureCache[r].texture.height === e.height && this._textureCache[r].postProcessChannel === n && this._textureCache[r].texture._generateDepthBuffer === t.generateDepthBuffer && this._textureCache[r].texture.samples === t.samples) return this._textureCache[r].texture;
			let r = this._engine.createRenderTargetTexture(e, t);
			return this._textureCache.push({
				texture: r,
				postProcessChannel: n,
				lastUsedRenderId: -1
			}), r;
		}
		_flushTextureCache() {
			let e = this._renderId;
			for (let t = this._textureCache.length - 1; t >= 0; t--) if (e - this._textureCache[t].lastUsedRenderId > 100) {
				let e = !1;
				for (let n = 0; n < this._textures.length; n++) if (this._textures.data[n] === this._textureCache[t].texture) {
					e = !0;
					break;
				}
				e || (this._textureCache[t].texture.dispose(), this._textureCache.splice(t, 1));
			}
		}
		resize(e, t, n = null, r = !1, i = !1) {
			this._textures.length > 0 && this._textures.reset(), this.width = e, this.height = t;
			let a = null;
			if (n) {
				for (let e = 0; e < n._postProcesses.length; e++) if (n._postProcesses[e] !== null) {
					a = n._postProcesses[e];
					break;
				}
			}
			let o = {
				width: this.width,
				height: this.height
			}, s = {
				generateMipMaps: r,
				generateDepthBuffer: i || a === this,
				generateStencilBuffer: (i || a === this) && this._engine.isStencilEnable,
				samplingMode: this.renderTargetSamplingMode,
				type: this._textureType,
				format: this._textureFormat,
				samples: this._samples,
				label: "PostProcessRTT-" + this.name
			};
			this._textures.push(this._createRenderTargetTexture(o, s, 0)), this._reusable && this._textures.push(this._createRenderTargetTexture(o, s, 1)), this._texelSize.copyFromFloats(1 / this.width, 1 / this.height), this.onSizeChangedObservable.notifyObservers(this);
		}
		_getTarget() {
			let e;
			if (this._shareOutputWithPostProcess) e = this._shareOutputWithPostProcess.inputTexture;
			else if (this._forcedOutputTexture) e = this._forcedOutputTexture, this.width = this._forcedOutputTexture.width, this.height = this._forcedOutputTexture.height;
			else {
				e = this.inputTexture;
				let t;
				for (let n = 0; n < this._textureCache.length; n++) if (this._textureCache[n].texture === e) {
					t = this._textureCache[n];
					break;
				}
				t && (t.lastUsedRenderId = this._renderId);
			}
			return e;
		}
		activate(e, t = null, n) {
			let i = e === null || e.cameraRigMode !== void 0 ? e || this._camera : null, a = i?.getScene() ?? e, o = a.getEngine(), s = o.getCaps().maxTextureSize, c = (t ? t.width : this._engine.getRenderWidth(!0)) * this._options | 0, l = (t ? t.height : this._engine.getRenderHeight(!0)) * this._options | 0, u = this._options.width || c, d = this._options.height || l, f = this.renderTargetSamplingMode !== 7 && this.renderTargetSamplingMode !== 1 && this.renderTargetSamplingMode !== 2, p = null;
			if (!this._shareOutputWithPostProcess && !this._forcedOutputTexture) {
				if (this.adaptScaleToCurrentViewport) {
					let e = o.currentViewport;
					e && (u *= e.width, d *= e.height);
				}
				(f || this.alwaysForcePOT) && (this._options.width || (u = o.needPOTTextures ? r(u, s, this.scaleMode) : u), this._options.height || (d = o.needPOTTextures ? r(d, s, this.scaleMode) : d)), (this.width !== u || this.height !== d || !(p = this._getTarget())) && this.resize(u, d, i, f, n), this._textures.forEach((e) => {
					e.samples !== this.samples && this._engine.updateRenderTargetTextureSampleCount(e, this.samples);
				}), this._flushTextureCache(), this._renderId++;
			}
			return p ||= this._getTarget(), this.enablePixelPerfectMode ? (this._scaleRatio.copyFromFloats(c / u, l / d), this._engine.bindFramebuffer(p, 0, c, l, this.forceFullscreenViewport)) : (this._scaleRatio.copyFromFloats(1, 1), this._engine.bindFramebuffer(p, 0, void 0, void 0, this.forceFullscreenViewport)), this._engine._debugInsertMarker?.(`post process ${this.name} input`), this.onActivateObservable.notifyObservers(i), this.autoClear && (this.alphaMode === 0 || this.forceAutoClearInAlphaMode) && this._engine.clear(this.clearColor ? this.clearColor : a.clearColor, a._allowPostProcessClearColor, !0, !0), this._reusable && (this._currentRenderTextureInd = (this._currentRenderTextureInd + 1) % 2), p;
		}
		get isSupported() {
			return this._effectWrapper.drawWrapper.effect.isSupported;
		}
		get aspectRatio() {
			return this._shareOutputWithPostProcess ? this._shareOutputWithPostProcess.aspectRatio : this._forcedOutputTexture ? this._forcedOutputTexture.width / this._forcedOutputTexture.height : this.width / this.height;
		}
		isReady() {
			return this._effectWrapper.isReady();
		}
		apply() {
			if (!this._effectWrapper.isReady()) return null;
			this._engine.enableEffect(this._effectWrapper.drawWrapper), this._engine.setState(!1), this._engine.setDepthBuffer(!1), this._engine.setDepthWrite(!1), this.alphaConstants && this.getEngine().setAlphaConstants(this.alphaConstants.r, this.alphaConstants.g, this.alphaConstants.b, this.alphaConstants.a), this._engine.setAlphaMode(this.alphaMode);
			let e;
			return e = this._shareOutputWithPostProcess ? this._shareOutputWithPostProcess.inputTexture : this._forcedOutputTexture ? this._forcedOutputTexture : this.inputTexture, this.externalTextureSamplerBinding || this._effectWrapper.drawWrapper.effect._bindTexture("textureSampler", e?.texture), this._effectWrapper.drawWrapper.effect.setVector2("scale", this._scaleRatio), this.onApplyObservable.notifyObservers(this._effectWrapper.drawWrapper.effect), this._effectWrapper.bind(!0), this._effectWrapper.drawWrapper.effect;
		}
		_disposeTextures() {
			this._shareOutputWithPostProcess || this._forcedOutputTexture ? this._disposeTextureCache() : (this._disposeTextureCache(), this._textures.dispose());
		}
		_disposeTextureCache() {
			for (let e = this._textureCache.length - 1; e >= 0; e--) this._textureCache[e].texture.dispose();
			this._textureCache.length = 0;
		}
		setPrePassRenderer(e) {
			return this._prePassEffectConfiguration ? (this._prePassEffectConfiguration = e.addEffectConfiguration(this._prePassEffectConfiguration), this._prePassEffectConfiguration.enabled = !0, !0) : !1;
		}
		dispose(e) {
			e ||= this._camera, this._useExistingThinPostProcess || this._effectWrapper.dispose(), this._disposeTextures(), this._scene && this._scene.removePostProcess(this);
			let t;
			if (this._parentContainer &&= (t = this._parentContainer.postProcesses.indexOf(this), t > -1 && this._parentContainer.postProcesses.splice(t, 1), null), t = this._engine.postProcesses.indexOf(this), t !== -1 && this._engine.postProcesses.splice(t, 1), this.onDisposeObservable.notifyObservers(), e) {
				if (e.detachPostProcess(this), t = e._postProcesses.indexOf(this), t === 0 && e._postProcesses.length > 0) {
					let e = this._camera._getFirstPostProcess();
					e && e.markTextureDirty();
				}
				this.onActivateObservable.clear(), this.onAfterRenderObservable.clear(), this.onApplyObservable.clear(), this.onBeforeRenderObservable.clear(), this.onSizeChangedObservable.clear(), this.onEffectCreatedObservable.clear();
			}
		}
		serialize() {
			let e = f.Serialize(this), t = this.getCamera() || this._scene && this._scene.activeCamera;
			return e.customType = "BABYLON." + this.getClassName(), e.cameraId = t ? t.id : null, e.reusable = this._reusable, e.textureType = this._textureType, e.fragmentUrl = this._fragmentUrl, e.parameters = this._parameters, e.samplers = this._samplers, e.uniformBuffers = this._uniformBuffers, e.options = this._options, e.defines = this._postProcessDefines, e.textureFormat = this._textureFormat, e.vertexUrl = this._vertexUrl, e.indexParameters = this._indexParameters, e;
		}
		clone() {
			let e = this.serialize();
			e._engine = this._engine, e.cameraId = null;
			let n = t.Parse(e, this._scene, "");
			return n ? (n.onActivateObservable = this.onActivateObservable.clone(), n.onSizeChangedObservable = this.onSizeChangedObservable.clone(), n.onApplyObservable = this.onApplyObservable.clone(), n.onBeforeRenderObservable = this.onBeforeRenderObservable.clone(), n.onAfterRenderObservable = this.onAfterRenderObservable.clone(), n._prePassEffectConfiguration = this._prePassEffectConfiguration, n) : null;
		}
		static Parse(e, t, n) {
			let r = o(e.customType);
			if (!r || !r._Parse) return null;
			let i = t ? t.getCameraById(e.cameraId) : null;
			return r._Parse(e, i, t, n);
		}
		static _Parse(e, n, r, i) {
			return f.Parse(() => new t(e.name, e.fragmentUrl, e.parameters, e.samplers, e.options, n, e.renderTargetSamplingMode, e._engine, e.reusable, e.defines, e.textureType, e.vertexUrl, e.indexParameters, !1, e.textureFormat), e, r, i);
		}
	}, (() => {
		let e = typeof Symbol == "function" && Symbol.metadata ? Object.create(null) : void 0;
		a = [l()], g = [l()], _ = [l()], b = [l()], C = [l()], E = [u()], k = [l()], M = [l()], F = [l()], I = [l()], z = [l()], H = [l()], G = [l()], J = [l()], Z = [l("samples")], te = [l()], d(t, null, g, {
			kind: "getter",
			name: "name",
			static: !1,
			private: !1,
			access: {
				has: (e) => "name" in e,
				get: (e) => e.name
			},
			metadata: e
		}, null, n), d(t, null, F, {
			kind: "getter",
			name: "alphaMode",
			static: !1,
			private: !1,
			access: {
				has: (e) => "alphaMode" in e,
				get: (e) => e.alphaMode
			},
			metadata: e
		}, null, n), d(null, null, a, {
			kind: "field",
			name: "uniqueId",
			static: !1,
			private: !1,
			access: {
				has: (e) => "uniqueId" in e,
				get: (e) => e.uniqueId,
				set: (e, t) => {
					e.uniqueId = t;
				}
			},
			metadata: e
		}, m, h), d(null, null, _, {
			kind: "field",
			name: "width",
			static: !1,
			private: !1,
			access: {
				has: (e) => "width" in e,
				get: (e) => e.width,
				set: (e, t) => {
					e.width = t;
				}
			},
			metadata: e
		}, v, y), d(null, null, b, {
			kind: "field",
			name: "height",
			static: !1,
			private: !1,
			access: {
				has: (e) => "height" in e,
				get: (e) => e.height,
				set: (e, t) => {
					e.height = t;
				}
			},
			metadata: e
		}, x, S), d(null, null, C, {
			kind: "field",
			name: "renderTargetSamplingMode",
			static: !1,
			private: !1,
			access: {
				has: (e) => "renderTargetSamplingMode" in e,
				get: (e) => e.renderTargetSamplingMode,
				set: (e, t) => {
					e.renderTargetSamplingMode = t;
				}
			},
			metadata: e
		}, w, T), d(null, null, E, {
			kind: "field",
			name: "clearColor",
			static: !1,
			private: !1,
			access: {
				has: (e) => "clearColor" in e,
				get: (e) => e.clearColor,
				set: (e, t) => {
					e.clearColor = t;
				}
			},
			metadata: e
		}, D, O), d(null, null, k, {
			kind: "field",
			name: "autoClear",
			static: !1,
			private: !1,
			access: {
				has: (e) => "autoClear" in e,
				get: (e) => e.autoClear,
				set: (e, t) => {
					e.autoClear = t;
				}
			},
			metadata: e
		}, A, j), d(null, null, M, {
			kind: "field",
			name: "forceAutoClearInAlphaMode",
			static: !1,
			private: !1,
			access: {
				has: (e) => "forceAutoClearInAlphaMode" in e,
				get: (e) => e.forceAutoClearInAlphaMode,
				set: (e, t) => {
					e.forceAutoClearInAlphaMode = t;
				}
			},
			metadata: e
		}, N, P), d(null, null, I, {
			kind: "field",
			name: "alphaConstants",
			static: !1,
			private: !1,
			access: {
				has: (e) => "alphaConstants" in e,
				get: (e) => e.alphaConstants,
				set: (e, t) => {
					e.alphaConstants = t;
				}
			},
			metadata: e
		}, L, R), d(null, null, z, {
			kind: "field",
			name: "enablePixelPerfectMode",
			static: !1,
			private: !1,
			access: {
				has: (e) => "enablePixelPerfectMode" in e,
				get: (e) => e.enablePixelPerfectMode,
				set: (e, t) => {
					e.enablePixelPerfectMode = t;
				}
			},
			metadata: e
		}, B, V), d(null, null, H, {
			kind: "field",
			name: "forceFullscreenViewport",
			static: !1,
			private: !1,
			access: {
				has: (e) => "forceFullscreenViewport" in e,
				get: (e) => e.forceFullscreenViewport,
				set: (e, t) => {
					e.forceFullscreenViewport = t;
				}
			},
			metadata: e
		}, U, W), d(null, null, G, {
			kind: "field",
			name: "scaleMode",
			static: !1,
			private: !1,
			access: {
				has: (e) => "scaleMode" in e,
				get: (e) => e.scaleMode,
				set: (e, t) => {
					e.scaleMode = t;
				}
			},
			metadata: e
		}, K, q), d(null, null, J, {
			kind: "field",
			name: "alwaysForcePOT",
			static: !1,
			private: !1,
			access: {
				has: (e) => "alwaysForcePOT" in e,
				get: (e) => e.alwaysForcePOT,
				set: (e, t) => {
					e.alwaysForcePOT = t;
				}
			},
			metadata: e
		}, Y, X), d(null, null, Z, {
			kind: "field",
			name: "_samples",
			static: !1,
			private: !1,
			access: {
				has: (e) => "_samples" in e,
				get: (e) => e._samples,
				set: (e, t) => {
					e._samples = t;
				}
			},
			metadata: e
		}, Q, $), d(null, null, te, {
			kind: "field",
			name: "adaptScaleToCurrentViewport",
			static: !1,
			private: !1,
			access: {
				has: (e) => "adaptScaleToCurrentViewport" in e,
				get: (e) => e.adaptScaleToCurrentViewport,
				set: (e, t) => {
					e.adaptScaleToCurrentViewport = t;
				}
			},
			metadata: e
		}, ne, re), e && Object.defineProperty(t, Symbol.metadata, {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: e
		});
	})(), t;
})(), h = !1;
function ee() {
	h || (h = !0, n.prototype.setTextureFromPostProcess = function(e, t, n) {
		let r = null;
		t && (t._forcedOutputTexture ? r = t._forcedOutputTexture : t._textures.data[t._currentRenderTextureInd] && (r = t._textures.data[t._currentRenderTextureInd])), this._bindTexture(e, r?.texture ?? null, n);
	}, n.prototype.setTextureFromPostProcessOutput = function(e, t, n) {
		this._bindTexture(e, t?._outputTexture?.texture ?? null, n);
	}, t.prototype.setTextureFromPostProcess = function(e, t) {
		this._engine.setTextureFromPostProcess(this._samplers[e], t, e);
	}, t.prototype.setTextureFromPostProcessOutput = function(e, t) {
		this._engine.setTextureFromPostProcessOutput(this._samplers[e], t, e);
	}, a("BABYLON.PostProcess", m));
}
//#endregion
export { m as t };
