import { a as e, n as t } from "./math.scalar.functions-D7lyzZPV.js";
import { a as n, c as r, l as i, n as a, o, t as s, u as c } from "./math.color.pure-CPmbqLkh.js";
import { t as l } from "./math.size-Cv1hlevD.js";
//#region node_modules/@babylonjs/core/Animations/animationRange.js
var u = class e {
	constructor(e, t, n) {
		this.name = e, this.from = t, this.to = n;
	}
	clone() {
		return new e(this.name, this.from, this.to);
	}
}, d = Object.freeze(new o(0, 0, 0, 0)), f = Object.freeze(c.Zero()), p = Object.freeze(i.Zero()), m = Object.freeze(l.Zero()), h = Object.freeze(s.Black()), g = Object.freeze(new a(0, 0, 0, 0)), _ = {
	key: 0,
	repeatCount: 0,
	loopMode: 2
}, v = class r {
	static _PrepareAnimation(e, t, n, u, d, f, p, m) {
		let h;
		if (!isNaN(parseFloat(d)) && isFinite(d) ? h = r.ANIMATIONTYPE_FLOAT : d instanceof o ? h = r.ANIMATIONTYPE_QUATERNION : d instanceof c ? h = r.ANIMATIONTYPE_VECTOR3 : d instanceof i ? h = r.ANIMATIONTYPE_VECTOR2 : d instanceof s ? h = r.ANIMATIONTYPE_COLOR3 : d instanceof a ? h = r.ANIMATIONTYPE_COLOR4 : d instanceof l && (h = r.ANIMATIONTYPE_SIZE), h == null) return null;
		let g = new r(e, t, n, h, p), _ = [{
			frame: 0,
			value: d
		}, {
			frame: u,
			value: f
		}];
		return g.setKeys(_), m !== void 0 && g.setEasingFunction(m), g;
	}
	get runtimeAnimations() {
		return this._runtimeAnimations;
	}
	get hasRunningRuntimeAnimations() {
		for (let e of this._runtimeAnimations) if (!e.isStopped()) return !0;
		return !1;
	}
	constructor(e, t, n, i, a, o) {
		this.name = e, this.targetProperty = t, this.framePerSecond = n, this.dataType = i, this.loopMode = a, this.enableBlending = o, this._easingFunction = null, this._runtimeAnimations = [], this._events = [], this.blendingSpeed = .01, this._ranges = {}, this._coreAnimation = null, this.targetPropertyPath = t.split("."), this.dataType = i, this.loopMode = a === void 0 ? r.ANIMATIONLOOPMODE_CYCLE : a, this.uniqueId = r._UniqueIdGenerator++;
	}
	toString(e) {
		let t = "Name: " + this.name + ", property: " + this.targetProperty;
		if (t += ", datatype: " + [
			"Float",
			"Vector3",
			"Quaternion",
			"Matrix",
			"Color3",
			"Vector2"
		][this.dataType], t += ", nKeys: " + (this._keys ? this._keys.length : "none"), t += ", nRanges: " + (this._ranges ? Object.keys(this._ranges).length : "none"), e) {
			t += ", Ranges: {";
			let e = !0;
			for (let n in this._ranges) e || (t += ", "), e = !1, t += n;
			t += "}";
		}
		return t;
	}
	addEvent(e) {
		this._events.push(e), this._events.sort((e, t) => e.frame - t.frame);
	}
	removeEvents(e) {
		for (let t = 0; t < this._events.length; t++) this._events[t].frame === e && (this._events.splice(t, 1), t--);
	}
	getEvents() {
		return this._events;
	}
	createRange(e, t, n) {
		this._ranges[e] || (this._ranges[e] = new u(e, t, n));
	}
	deleteRange(e, t = !0) {
		let n = this._ranges[e];
		if (n) {
			if (t) {
				let e = n.from, t = n.to;
				for (let n = this._keys.length - 1; n >= 0; n--) this._keys[n].frame >= e && this._keys[n].frame <= t && this._keys.splice(n, 1);
			}
			this._ranges[e] = null;
		}
	}
	getRange(e) {
		return this._ranges[e];
	}
	getKeys() {
		return this._keys;
	}
	getHighestFrame() {
		let e = 0;
		for (let t = 0, n = this._keys.length; t < n; t++) e < this._keys[t].frame && (e = this._keys[t].frame);
		return e;
	}
	getEasingFunction() {
		return this._easingFunction;
	}
	setEasingFunction(e) {
		this._easingFunction = e;
	}
	floatInterpolateFunction(t, n, r) {
		return e(t, n, r);
	}
	floatInterpolateFunctionWithTangents(e, n, r, i, a) {
		return t(e, n, r, i, a);
	}
	quaternionInterpolateFunction(e, t, n) {
		return o.Slerp(e, t, n);
	}
	quaternionInterpolateFunctionWithTangents(e, t, n, r, i) {
		return o.Hermite(e, t, n, r, i).normalize();
	}
	vector3InterpolateFunction(e, t, n) {
		return c.Lerp(e, t, n);
	}
	vector3InterpolateFunctionWithTangents(e, t, n, r, i) {
		return c.Hermite(e, t, n, r, i);
	}
	vector2InterpolateFunction(e, t, n) {
		return i.Lerp(e, t, n);
	}
	vector2InterpolateFunctionWithTangents(e, t, n, r, a) {
		return i.Hermite(e, t, n, r, a);
	}
	sizeInterpolateFunction(e, t, n) {
		return l.Lerp(e, t, n);
	}
	color3InterpolateFunction(e, t, n) {
		return s.Lerp(e, t, n);
	}
	color3InterpolateFunctionWithTangents(e, t, n, r, i) {
		return s.Hermite(e, t, n, r, i);
	}
	color4InterpolateFunction(e, t, n) {
		return a.Lerp(e, t, n);
	}
	color4InterpolateFunctionWithTangents(e, t, n, r, i) {
		return a.Hermite(e, t, n, r, i);
	}
	_getKeyValue(e) {
		return typeof e == "function" ? e() : e;
	}
	evaluate(e) {
		return _.key = 0, this._interpolate(e, _);
	}
	_interpolate(e, t, n = !1) {
		if (t.loopMode === r.ANIMATIONLOOPMODE_CONSTANT && t.repeatCount > 0) return t.highLimitValue.clone ? t.highLimitValue.clone() : t.highLimitValue;
		let i = this._keys, a;
		if (this._coreAnimation) a = this._coreAnimation._key;
		else {
			let r = i.length;
			for (a = t.key; a >= 0 && e < i[a].frame;) --a;
			for (; a + 1 <= r - 1 && e >= i[a + 1].frame;) ++a;
			if (t.key = a, a < 0) return n ? void 0 : this._getKeyValue(i[0].value);
			if (a + 1 > r - 1) return n ? void 0 : this._getKeyValue(i[r - 1].value);
			this._key = a;
		}
		let o = i[a], s = i[a + 1];
		if (n && (e === o.frame || e === s.frame)) return;
		let c = this._getKeyValue(o.value), l = this._getKeyValue(s.value);
		if (o.interpolation === 1) return s.frame > e ? c : l;
		let u = o.outTangent !== void 0 && s.inTangent !== void 0, _ = s.frame - o.frame, v = (e - o.frame) / _, y = o.easingFunction || this.getEasingFunction();
		switch (y && (v = y.ease(v)), this.dataType) {
			case r.ANIMATIONTYPE_FLOAT: {
				let e = u ? this.floatInterpolateFunctionWithTangents(c, o.outTangent * _, l, s.inTangent * _, v) : this.floatInterpolateFunction(c, l, v);
				switch (t.loopMode) {
					case r.ANIMATIONLOOPMODE_CYCLE:
					case r.ANIMATIONLOOPMODE_CONSTANT:
					case r.ANIMATIONLOOPMODE_YOYO: return e;
					case r.ANIMATIONLOOPMODE_RELATIVE:
					case r.ANIMATIONLOOPMODE_RELATIVE_FROM_CURRENT: return (t.offsetValue ?? 0) * t.repeatCount + e;
				}
				break;
			}
			case r.ANIMATIONTYPE_QUATERNION: {
				let e = u ? this.quaternionInterpolateFunctionWithTangents(c, o.outTangent.scale(_), l, s.inTangent.scale(_), v) : this.quaternionInterpolateFunction(c, l, v);
				switch (t.loopMode) {
					case r.ANIMATIONLOOPMODE_CYCLE:
					case r.ANIMATIONLOOPMODE_CONSTANT:
					case r.ANIMATIONLOOPMODE_YOYO: return e;
					case r.ANIMATIONLOOPMODE_RELATIVE:
					case r.ANIMATIONLOOPMODE_RELATIVE_FROM_CURRENT: return e.addInPlace((t.offsetValue || d).scale(t.repeatCount));
				}
				return e;
			}
			case r.ANIMATIONTYPE_VECTOR3: {
				let e = u ? this.vector3InterpolateFunctionWithTangents(c, o.outTangent.scale(_), l, s.inTangent.scale(_), v) : this.vector3InterpolateFunction(c, l, v);
				switch (t.loopMode) {
					case r.ANIMATIONLOOPMODE_CYCLE:
					case r.ANIMATIONLOOPMODE_CONSTANT:
					case r.ANIMATIONLOOPMODE_YOYO: return e;
					case r.ANIMATIONLOOPMODE_RELATIVE:
					case r.ANIMATIONLOOPMODE_RELATIVE_FROM_CURRENT: return e.add((t.offsetValue || f).scale(t.repeatCount));
				}
				break;
			}
			case r.ANIMATIONTYPE_VECTOR2: {
				let e = u ? this.vector2InterpolateFunctionWithTangents(c, o.outTangent.scale(_), l, s.inTangent.scale(_), v) : this.vector2InterpolateFunction(c, l, v);
				switch (t.loopMode) {
					case r.ANIMATIONLOOPMODE_CYCLE:
					case r.ANIMATIONLOOPMODE_CONSTANT:
					case r.ANIMATIONLOOPMODE_YOYO: return e;
					case r.ANIMATIONLOOPMODE_RELATIVE:
					case r.ANIMATIONLOOPMODE_RELATIVE_FROM_CURRENT: return e.add((t.offsetValue || p).scale(t.repeatCount));
				}
				break;
			}
			case r.ANIMATIONTYPE_SIZE:
				switch (t.loopMode) {
					case r.ANIMATIONLOOPMODE_CYCLE:
					case r.ANIMATIONLOOPMODE_CONSTANT:
					case r.ANIMATIONLOOPMODE_YOYO: return this.sizeInterpolateFunction(c, l, v);
					case r.ANIMATIONLOOPMODE_RELATIVE:
					case r.ANIMATIONLOOPMODE_RELATIVE_FROM_CURRENT: return this.sizeInterpolateFunction(c, l, v).add((t.offsetValue || m).scale(t.repeatCount));
				}
				break;
			case r.ANIMATIONTYPE_COLOR3: {
				let e = u ? this.color3InterpolateFunctionWithTangents(c, o.outTangent.scale(_), l, s.inTangent.scale(_), v) : this.color3InterpolateFunction(c, l, v);
				switch (t.loopMode) {
					case r.ANIMATIONLOOPMODE_CYCLE:
					case r.ANIMATIONLOOPMODE_CONSTANT:
					case r.ANIMATIONLOOPMODE_YOYO: return e;
					case r.ANIMATIONLOOPMODE_RELATIVE:
					case r.ANIMATIONLOOPMODE_RELATIVE_FROM_CURRENT: return e.add((t.offsetValue || h).scale(t.repeatCount));
				}
				break;
			}
			case r.ANIMATIONTYPE_COLOR4: {
				let e = u ? this.color4InterpolateFunctionWithTangents(c, o.outTangent.scale(_), l, s.inTangent.scale(_), v) : this.color4InterpolateFunction(c, l, v);
				switch (t.loopMode) {
					case r.ANIMATIONLOOPMODE_CYCLE:
					case r.ANIMATIONLOOPMODE_CONSTANT:
					case r.ANIMATIONLOOPMODE_YOYO: return e;
					case r.ANIMATIONLOOPMODE_RELATIVE:
					case r.ANIMATIONLOOPMODE_RELATIVE_FROM_CURRENT: return e.add((t.offsetValue || g).scale(t.repeatCount));
				}
				break;
			}
			case r.ANIMATIONTYPE_MATRIX: switch (t.loopMode) {
				case r.ANIMATIONLOOPMODE_CYCLE:
				case r.ANIMATIONLOOPMODE_CONSTANT:
				case r.ANIMATIONLOOPMODE_YOYO: return r.AllowMatricesInterpolation ? this.matrixInterpolateFunction(c, l, v, t.workValue) : c;
				case r.ANIMATIONLOOPMODE_RELATIVE:
				case r.ANIMATIONLOOPMODE_RELATIVE_FROM_CURRENT: return c;
			}
		}
		return 0;
	}
	matrixInterpolateFunction(e, t, i, a) {
		return r.AllowMatrixDecomposeForInterpolation ? a ? (n.DecomposeLerpToRef(e, t, i, a), a) : n.DecomposeLerp(e, t, i) : a ? (n.LerpToRef(e, t, i, a), a) : n.Lerp(e, t, i);
	}
	clone(e = !1) {
		let t = new r(this.name, this.targetPropertyPath.join("."), this.framePerSecond, this.dataType, this.loopMode);
		if (t.enableBlending = this.enableBlending, t.blendingSpeed = this.blendingSpeed, this._keys && t.setKeys(this._keys, !1, e), this._ranges) {
			t._ranges = {};
			for (let e in this._ranges) {
				let n = this._ranges[e];
				n && (t._ranges[e] = n.clone());
			}
		}
		return t;
	}
	setKeys(e, t = !1, n = !1) {
		if (t) this._keys = e;
		else if (this._keys = e.slice(0), n) for (let e = 0; e < this._keys.length; e++) {
			let t = this._keys[e];
			this._keys[e] = {
				frame: t.frame,
				value: t.value.clone ? t.value.clone() : t.value,
				inTangent: t.inTangent && t.inTangent.clone ? t.inTangent.clone() : t.inTangent,
				outTangent: t.outTangent && t.outTangent.clone ? t.outTangent.clone() : t.outTangent,
				interpolation: t.interpolation,
				lockedTangent: t.lockedTangent,
				easingFunction: t.easingFunction
			};
		}
	}
	createKeyForFrame(e) {
		_.key = 0;
		let t = this._interpolate(e, _, !0);
		if (!t) return this._keys[_.key].frame === e ? _.key : _.key + 1;
		let n = {
			frame: e,
			value: t.clone ? t.clone() : t
		};
		return this._keys.splice(_.key + 1, 0, n), _.key + 1;
	}
	serialize() {
		let e = {};
		e.name = this.name, e.property = this.targetProperty, e.framePerSecond = this.framePerSecond, e.dataType = this.dataType, e.loopBehavior = this.loopMode, e.enableBlending = this.enableBlending, e.blendingSpeed = this.blendingSpeed;
		let t = this.dataType;
		e.keys = [];
		let n = this.getKeys();
		for (let i = 0; i < n.length; i++) {
			let a = n[i], o = {};
			switch (o.frame = a.frame, t) {
				case r.ANIMATIONTYPE_FLOAT:
					o.values = [a.value], a.inTangent !== void 0 && o.values.push(a.inTangent), a.outTangent !== void 0 && (a.inTangent === void 0 && o.values.push(void 0), o.values.push(a.outTangent)), a.interpolation !== void 0 && (a.inTangent === void 0 && o.values.push(void 0), a.outTangent === void 0 && o.values.push(void 0), o.values.push(a.interpolation));
					break;
				case r.ANIMATIONTYPE_QUATERNION:
				case r.ANIMATIONTYPE_MATRIX:
				case r.ANIMATIONTYPE_VECTOR3:
				case r.ANIMATIONTYPE_COLOR3:
				case r.ANIMATIONTYPE_COLOR4: o.values = a.value.asArray(), a.inTangent != null && o.values.push(a.inTangent.asArray()), a.outTangent != null && (a.inTangent === void 0 && o.values.push(void 0), o.values.push(a.outTangent.asArray())), a.interpolation !== void 0 && (a.inTangent === void 0 && o.values.push(void 0), a.outTangent === void 0 && o.values.push(void 0), o.values.push(a.interpolation));
			}
			e.keys.push(o);
		}
		e.ranges = [];
		for (let t in this._ranges) {
			let n = this._ranges[t];
			if (!n) continue;
			let r = {};
			r.name = t, r.from = n.from, r.to = n.to, e.ranges.push(r);
		}
		return e;
	}
	static _UniversalLerp(e, t, n) {
		let r = e.constructor;
		return r.Lerp ? r.Lerp(e, t, n) : r.Slerp ? r.Slerp(e, t, n) : e.toFixed ? e * (1 - n) + n * t : t;
	}
};
v._UniqueIdGenerator = 0, v.AllowMatricesInterpolation = !1, v.AllowMatrixDecomposeForInterpolation = !0, v.InheritOriginalValueFromActiveAnimations = !1, v.SnippetUrl = "https://snippet.babylonjs.com", v.ANIMATIONTYPE_FLOAT = 0, v.ANIMATIONTYPE_VECTOR3 = 1, v.ANIMATIONTYPE_QUATERNION = 2, v.ANIMATIONTYPE_MATRIX = 3, v.ANIMATIONTYPE_COLOR3 = 4, v.ANIMATIONTYPE_COLOR4 = 7, v.ANIMATIONTYPE_VECTOR2 = 5, v.ANIMATIONTYPE_SIZE = 6, v.ANIMATIONLOOPMODE_RELATIVE = 0, v.ANIMATIONLOOPMODE_CYCLE = 1, v.ANIMATIONLOOPMODE_CONSTANT = 2, v.ANIMATIONLOOPMODE_YOYO = 4, v.ANIMATIONLOOPMODE_RELATIVE_FROM_CURRENT = 5;
function y(e, t, i, a = !1, o) {
	let s;
	s = typeof t == "object" ? t : {
		referenceFrame: t ?? 0,
		range: i,
		cloneOriginalAnimation: a,
		clonedAnimationName: o
	};
	let c = e;
	s.cloneOriginalAnimation && (c = e.clone(), c.name = s.clonedAnimationName || c.name);
	let l = c.getKeys();
	if (!l.length) return c;
	let u = s.referenceFrame && s.referenceFrame >= 0 ? s.referenceFrame : 0, d = 0, f = l[0], p = l.length - 1, m = l[p], h = {
		referenceValue: f.value,
		referencePosition: r.Vector3[0],
		referenceQuaternion: r.Quaternion[0],
		referenceScaling: r.Vector3[1],
		keyPosition: r.Vector3[2],
		keyQuaternion: r.Quaternion[1],
		keyScaling: r.Vector3[3]
	}, g = f.frame, y = m.frame;
	if (s.range) {
		let e = c.getRange(s.range);
		e && (g = e.from, y = e.to);
	} else g = s.fromFrame ?? g, y = s.toFrame ?? y;
	g !== f.frame && (d = c.createKeyForFrame(g)), y !== m.frame && (p = c.createKeyForFrame(y));
	let b = c.getKeys();
	if (b.length === 1) {
		let e = c._getKeyValue(b[0].value);
		h.referenceValue = e.clone ? e.clone() : e;
	} else if (u <= f.frame) {
		let e = c._getKeyValue(f.value);
		h.referenceValue = e.clone ? e.clone() : e;
	} else if (u >= m.frame) {
		let e = c._getKeyValue(m.value);
		h.referenceValue = e.clone ? e.clone() : e;
	} else {
		_.key = 0;
		let e = c._interpolate(u, _);
		h.referenceValue = e.clone ? e.clone() : e;
	}
	c.dataType === v.ANIMATIONTYPE_QUATERNION ? h.referenceValue.normalize().conjugateInPlace() : c.dataType === v.ANIMATIONTYPE_MATRIX && (h.referenceValue.decompose(h.referenceScaling, h.referenceQuaternion, h.referencePosition), h.referenceQuaternion.normalize().conjugateInPlace());
	let x = Number.MAX_VALUE, S = s.clipKeys ? [] : null;
	for (let e = d; e <= p; e++) {
		let t = b[e];
		if ((S || s.cloneOriginalAnimation) && (t = {
			frame: t.frame,
			value: t.value.clone ? t.value.clone() : t.value,
			inTangent: t.inTangent,
			outTangent: t.outTangent,
			interpolation: t.interpolation,
			lockedTangent: t.lockedTangent,
			easingFunction: t.easingFunction
		}, S && (x === Number.MAX_VALUE && (x = t.frame), t.frame -= x, S.push(t))), !(e && c.dataType !== v.ANIMATIONTYPE_FLOAT && t.value === f.value)) switch (c.dataType) {
			case v.ANIMATIONTYPE_MATRIX:
				t.value.decompose(h.keyScaling, h.keyQuaternion, h.keyPosition), h.keyPosition.subtractInPlace(h.referencePosition), h.keyScaling.divideInPlace(h.referenceScaling), h.referenceQuaternion.multiplyToRef(h.keyQuaternion, h.keyQuaternion), n.ComposeToRef(h.keyScaling, h.keyQuaternion, h.keyPosition, t.value);
				break;
			case v.ANIMATIONTYPE_QUATERNION:
				h.referenceValue.multiplyToRef(t.value, t.value);
				break;
			case v.ANIMATIONTYPE_VECTOR2:
			case v.ANIMATIONTYPE_VECTOR3:
			case v.ANIMATIONTYPE_COLOR3:
			case v.ANIMATIONTYPE_COLOR4:
				t.value.subtractToRef(h.referenceValue, t.value);
				break;
			case v.ANIMATIONTYPE_SIZE:
				t.value.width -= h.referenceValue.width, t.value.height -= h.referenceValue.height;
				break;
			default: t.value -= h.referenceValue;
		}
	}
	return S && c.setKeys(S, !0), c;
}
function b(e, t, n, r) {
	let i = new v(e + "Animation", e, n, t, v.ANIMATIONLOOPMODE_CONSTANT);
	return i.setEasingFunction(r), i;
}
function x(e) {
	let t = new v(e.name, e.property, e.framePerSecond, e.dataType, e.loopBehavior), r = e.dataType, i = [], l, u;
	for (e.enableBlending && (t.enableBlending = e.enableBlending), e.blendingSpeed && (t.blendingSpeed = e.blendingSpeed), u = 0; u < e.keys.length; u++) {
		let t = e.keys[u], d, f, p;
		switch (r) {
			case v.ANIMATIONTYPE_FLOAT:
				l = t.values[0], t.values.length >= 2 && (d = t.values[1]), t.values.length >= 3 && (f = t.values[2]), t.values.length >= 4 && (p = t.values[3]);
				break;
			case v.ANIMATIONTYPE_QUATERNION:
				if (l = o.FromArray(t.values), t.values.length >= 8) {
					let e = o.FromArray(t.values.slice(4, 8));
					e.equals(o.Zero()) || (d = e);
				}
				if (t.values.length >= 12) {
					let e = o.FromArray(t.values.slice(8, 12));
					e.equals(o.Zero()) || (f = e);
				}
				t.values.length >= 13 && (p = t.values[12]);
				break;
			case v.ANIMATIONTYPE_MATRIX:
				l = n.FromArray(t.values), t.values.length >= 17 && (p = t.values[16]);
				break;
			case v.ANIMATIONTYPE_COLOR3:
				l = s.FromArray(t.values), t.values[3] && (d = s.FromArray(t.values[3])), t.values[4] && (f = s.FromArray(t.values[4])), t.values[5] && (p = t.values[5]);
				break;
			case v.ANIMATIONTYPE_COLOR4:
				l = a.FromArray(t.values), t.values[4] && (d = a.FromArray(t.values[4])), t.values[5] && (f = a.FromArray(t.values[5])), t.values[6] && (p = t.values[6]);
				break;
			case v.ANIMATIONTYPE_VECTOR3:
			default: l = c.FromArray(t.values), t.values[3] && (d = c.FromArray(t.values[3])), t.values[4] && (f = c.FromArray(t.values[4])), t.values[5] && (p = t.values[5]);
		}
		let m = {};
		m.frame = t.frame, m.value = l, d != null && (m.inTangent = d), f != null && (m.outTangent = f), p != null && (m.interpolation = p), i.push(m);
	}
	if (t.setKeys(i), e.ranges) for (u = 0; u < e.ranges.length; u++) l = e.ranges[u], t.createRange(l.name, l.from, l.to);
	return t;
}
//#endregion
export { h as a, m as c, u as d, x as i, p as l, b as n, g as o, y as r, d as s, v as t, f as u };
