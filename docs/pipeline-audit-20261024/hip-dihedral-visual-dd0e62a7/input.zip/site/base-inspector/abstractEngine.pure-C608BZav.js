import { n as e, t } from "./engineStore-D0BoPdea.js";
import { t as n } from "./internalTexture-QUW4uXxg.js";
import { t as r } from "./logger-DQIzSR_y.js";
import { t as i } from "./shaderStore-CXjvw9c2.js";
import { i as a, n as o, r as s, t as c } from "./domManagement-BZa7OPDn.js";
import { S as l, _ as u, c as d, d as f, h as p, l as m, m as h, o as g, u as _ } from "./tools.functions-DEecYKlu.js";
import { t as v } from "./performanceConfigurator-DBCxCnir.js";
//#region node_modules/@babylonjs/core/Engines/WebGL/webGLPipelineContext.js
var y = class {
	constructor() {
		this._valueCache = {}, this.vertexCompilationError = null, this.fragmentCompilationError = null, this.programLinkError = null, this.programValidationError = null, this._isDisposed = !1;
	}
	get isAsync() {
		return this.isParallelCompiled;
	}
	get isReady() {
		return this.program ? !this.isParallelCompiled || this.engine._isRenderingStateCompiled(this) : !1;
	}
	_handlesSpectorRebuildCallback(e) {
		e && this.program && e(this.program);
	}
	setEngine(e) {
		this.engine = e;
	}
	_fillEffectInformation(e, t, n, r, i, a, o, s) {
		let c = this.engine;
		if (c.supportsUniformBuffers) for (let n in t) e.bindUniformBlock(n, t[n]);
		this.engine.getUniforms(this, n).forEach((e, t) => {
			r[n[t]] = e;
		}), this._uniforms = r;
		let l = 0;
		for (; l < i.length; l++) e.getUniform(i[l]) ?? (i.splice(l, 1), l--);
		i.forEach((e, t) => {
			a[e] = t;
		});
		for (let e of c.getAttributes(this, o)) s.push(e);
	}
	dispose() {
		this._uniforms = {}, this._isDisposed = !0;
	}
	_cacheMatrix(e, t) {
		let n = this._valueCache[e], r = t.updateFlag;
		return n !== void 0 && n === r ? !1 : (this._valueCache[e] = r, !0);
	}
	_cacheFloat2(e, t, n) {
		let r = this._valueCache[e];
		if (!r || r.length !== 2) return r = [t, n], this._valueCache[e] = r, !0;
		let i = !1;
		return r[0] !== t && (r[0] = t, i = !0), r[1] !== n && (r[1] = n, i = !0), i;
	}
	_cacheFloat3(e, t, n, r) {
		let i = this._valueCache[e];
		if (!i || i.length !== 3) return i = [
			t,
			n,
			r
		], this._valueCache[e] = i, !0;
		let a = !1;
		return i[0] !== t && (i[0] = t, a = !0), i[1] !== n && (i[1] = n, a = !0), i[2] !== r && (i[2] = r, a = !0), a;
	}
	_cacheFloat4(e, t, n, r, i) {
		let a = this._valueCache[e];
		if (!a || a.length !== 4) return a = [
			t,
			n,
			r,
			i
		], this._valueCache[e] = a, !0;
		let o = !1;
		return a[0] !== t && (a[0] = t, o = !0), a[1] !== n && (a[1] = n, o = !0), a[2] !== r && (a[2] = r, o = !0), a[3] !== i && (a[3] = i, o = !0), o;
	}
	setInt(e, t) {
		let n = this._valueCache[e];
		(n === void 0 || n !== t) && this.engine.setInt(this._uniforms[e], t) && (this._valueCache[e] = t);
	}
	setInt2(e, t, n) {
		this._cacheFloat2(e, t, n) && (this.engine.setInt2(this._uniforms[e], t, n) || (this._valueCache[e] = null));
	}
	setInt3(e, t, n, r) {
		this._cacheFloat3(e, t, n, r) && (this.engine.setInt3(this._uniforms[e], t, n, r) || (this._valueCache[e] = null));
	}
	setInt4(e, t, n, r, i) {
		this._cacheFloat4(e, t, n, r, i) && (this.engine.setInt4(this._uniforms[e], t, n, r, i) || (this._valueCache[e] = null));
	}
	setIntArray(e, t) {
		this._valueCache[e] = null, this.engine.setIntArray(this._uniforms[e], t);
	}
	setIntArray2(e, t) {
		this._valueCache[e] = null, this.engine.setIntArray2(this._uniforms[e], t);
	}
	setIntArray3(e, t) {
		this._valueCache[e] = null, this.engine.setIntArray3(this._uniforms[e], t);
	}
	setIntArray4(e, t) {
		this._valueCache[e] = null, this.engine.setIntArray4(this._uniforms[e], t);
	}
	setUInt(e, t) {
		let n = this._valueCache[e];
		(n === void 0 || n !== t) && this.engine.setUInt(this._uniforms[e], t) && (this._valueCache[e] = t);
	}
	setUInt2(e, t, n) {
		this._cacheFloat2(e, t, n) && (this.engine.setUInt2(this._uniforms[e], t, n) || (this._valueCache[e] = null));
	}
	setUInt3(e, t, n, r) {
		this._cacheFloat3(e, t, n, r) && (this.engine.setUInt3(this._uniforms[e], t, n, r) || (this._valueCache[e] = null));
	}
	setUInt4(e, t, n, r, i) {
		this._cacheFloat4(e, t, n, r, i) && (this.engine.setUInt4(this._uniforms[e], t, n, r, i) || (this._valueCache[e] = null));
	}
	setUIntArray(e, t) {
		this._valueCache[e] = null, this.engine.setUIntArray(this._uniforms[e], t);
	}
	setUIntArray2(e, t) {
		this._valueCache[e] = null, this.engine.setUIntArray2(this._uniforms[e], t);
	}
	setUIntArray3(e, t) {
		this._valueCache[e] = null, this.engine.setUIntArray3(this._uniforms[e], t);
	}
	setUIntArray4(e, t) {
		this._valueCache[e] = null, this.engine.setUIntArray4(this._uniforms[e], t);
	}
	setArray(e, t) {
		this._valueCache[e] = null, this.engine.setArray(this._uniforms[e], t);
	}
	setArray2(e, t) {
		this._valueCache[e] = null, this.engine.setArray2(this._uniforms[e], t);
	}
	setArray3(e, t) {
		this._valueCache[e] = null, this.engine.setArray3(this._uniforms[e], t);
	}
	setArray4(e, t) {
		this._valueCache[e] = null, this.engine.setArray4(this._uniforms[e], t);
	}
	setMatrices(e, t) {
		t && (this._valueCache[e] = null, this.engine.setMatrices(this._uniforms[e], t));
	}
	setMatrix(e, t) {
		this._cacheMatrix(e, t) && (this.engine.setMatrices(this._uniforms[e], t.asArray()) || (this._valueCache[e] = null));
	}
	setMatrix3x3(e, t) {
		this._valueCache[e] = null, this.engine.setMatrix3x3(this._uniforms[e], t);
	}
	setMatrix2x2(e, t) {
		this._valueCache[e] = null, this.engine.setMatrix2x2(this._uniforms[e], t);
	}
	setFloat(e, t) {
		let n = this._valueCache[e];
		(n === void 0 || n !== t) && this.engine.setFloat(this._uniforms[e], t) && (this._valueCache[e] = t);
	}
	setVector2(e, t) {
		this._cacheFloat2(e, t.x, t.y) && (this.engine.setFloat2(this._uniforms[e], t.x, t.y) || (this._valueCache[e] = null));
	}
	setFloat2(e, t, n) {
		this._cacheFloat2(e, t, n) && (this.engine.setFloat2(this._uniforms[e], t, n) || (this._valueCache[e] = null));
	}
	setVector3(e, t) {
		this._cacheFloat3(e, t.x, t.y, t.z) && (this.engine.setFloat3(this._uniforms[e], t.x, t.y, t.z) || (this._valueCache[e] = null));
	}
	setFloat3(e, t, n, r) {
		this._cacheFloat3(e, t, n, r) && (this.engine.setFloat3(this._uniforms[e], t, n, r) || (this._valueCache[e] = null));
	}
	setVector4(e, t) {
		this._cacheFloat4(e, t.x, t.y, t.z, t.w) && (this.engine.setFloat4(this._uniforms[e], t.x, t.y, t.z, t.w) || (this._valueCache[e] = null));
	}
	setQuaternion(e, t) {
		this._cacheFloat4(e, t.x, t.y, t.z, t.w) && (this.engine.setFloat4(this._uniforms[e], t.x, t.y, t.z, t.w) || (this._valueCache[e] = null));
	}
	setFloat4(e, t, n, r, i) {
		this._cacheFloat4(e, t, n, r, i) && (this.engine.setFloat4(this._uniforms[e], t, n, r, i) || (this._valueCache[e] = null));
	}
	setColor3(e, t) {
		this._cacheFloat3(e, t.r, t.g, t.b) && (this.engine.setFloat3(this._uniforms[e], t.r, t.g, t.b) || (this._valueCache[e] = null));
	}
	setColor4(e, t, n) {
		this._cacheFloat4(e, t.r, t.g, t.b, n) && (this.engine.setFloat4(this._uniforms[e], t.r, t.g, t.b, n) || (this._valueCache[e] = null));
	}
	setDirectColor4(e, t) {
		this._cacheFloat4(e, t.r, t.g, t.b, t.a) && (this.engine.setFloat4(this._uniforms[e], t.r, t.g, t.b, t.a) || (this._valueCache[e] = null));
	}
	_getVertexShaderCode() {
		return this.vertexShader ? this.engine._getShaderSource(this.vertexShader) : null;
	}
	_getFragmentShaderCode() {
		return this.fragmentShader ? this.engine._getShaderSource(this.fragmentShader) : null;
	}
}, b = /* @__PURE__ */ new WeakMap(), x = {
	_webGLVersion: 2,
	cachedPipelines: {}
};
function S(e) {
	let t = b.get(e);
	if (!t) {
		if (!e) return x;
		t = {
			_webGLVersion: e.TEXTURE_BINDING_3D ? 2 : 1,
			_context: e,
			parallelShaderCompile: e.getExtension("KHR_parallel_shader_compile") || void 0,
			cachedPipelines: {}
		}, b.set(e, t);
	}
	return t;
}
function C(e) {
	b.delete(e);
}
function w(e, t, n, r, i, a) {
	let o = S(r);
	a ||= o._createShaderProgramInjection ?? D;
	let s = M(t, "vertex", r, o._contextWasLost), c = M(n, "fragment", r, o._contextWasLost);
	return a(e, s, c, r, i, o.validateShaderPrograms);
}
function T(e, t, n, r, i, a = null, o) {
	let s = S(i);
	o ||= s._createShaderProgramInjection ?? D;
	let c = s._webGLVersion > 1 ? "#version 300 es\n#define WEBGL2 \n" : "", l = j(t, "vertex", r, c, i, s._contextWasLost), u = j(n, "fragment", r, c, i, s._contextWasLost);
	return o(e, l, u, i, a, s.validateShaderPrograms);
}
function E(e, t) {
	let n = new y(), r = S(e);
	return r.parallelShaderCompile && !r.disableParallelShaderCompile && (n.isParallelCompiled = !0), n.context = r._context, n;
}
function D(e, t, n, r, i = null, a) {
	let o = r.createProgram();
	if (e.program = o, !o) throw Error("Unable to create program");
	return r.attachShader(o, t), r.attachShader(o, n), r.linkProgram(o), e.context = r, e.vertexShader = t, e.fragmentShader = n, e.isParallelCompiled || k(e, r, a), o;
}
function O(e, t, n) {
	let r = e;
	if (r._isDisposed) return !1;
	let i = S(t);
	return i && i.parallelShaderCompile && i.parallelShaderCompile.COMPLETION_STATUS_KHR && r.program && t.getProgramParameter(r.program, i.parallelShaderCompile.COMPLETION_STATUS_KHR) ? (k(r, t, n), !0) : !1;
}
function k(e, t, n) {
	let r = e.context, i = e.vertexShader, a = e.fragmentShader, o = e.program;
	if (!r.getProgramParameter(o, r.LINK_STATUS)) {
		if (!t.getShaderParameter(i, t.COMPILE_STATUS)) {
			let n = t.getShaderInfoLog(i);
			if (n) throw e.vertexCompilationError = n, Error("VERTEX SHADER " + n);
		}
		if (!t.getShaderParameter(a, t.COMPILE_STATUS)) {
			let n = t.getShaderInfoLog(a);
			if (n) throw e.fragmentCompilationError = n, Error("FRAGMENT SHADER " + n);
		}
		let n = r.getProgramInfoLog(o);
		if (n) throw e.programLinkError = n, Error(n);
	}
	if (n && (r.validateProgram(o), !r.getProgramParameter(o, r.VALIDATE_STATUS))) {
		let t = r.getProgramInfoLog(o);
		if (t) throw e.programValidationError = t, Error(t);
	}
	r.deleteShader(i), r.deleteShader(a), e.vertexShader = void 0, e.fragmentShader = void 0, e.onCompiled &&= (e.onCompiled(), void 0);
}
function A(e, t, n, r, i, a, o, s, c, l = "", u, d, f) {
	let p = S(e.context);
	d ||= p.createRawShaderProgramInjection ?? w, f ||= p.createShaderProgramInjection ?? T;
	let m = e;
	m.program = r ? d(m, t, n, m.context, c) : f(m, t, n, s, m.context, c), m.program.__SPECTOR_rebuildProgram = o, u();
}
function j(e, t, n, r, i, a) {
	return M(p(e, n, r), t, i, a);
}
function M(e, t, n, r) {
	let i = n.createShader(t === "vertex" ? n.VERTEX_SHADER : n.FRAGMENT_SHADER);
	if (!i) {
		let e = n.NO_ERROR, i;
		for (; (i = n.getError()) !== n.NO_ERROR;) e = i;
		throw Error(`Something went wrong while creating a gl ${t} shader object. gl error=${e}, gl isContextLost=${n.isContextLost()}, _contextWasLost=${r}`);
	}
	return n.shaderSource(i, e), n.compileShader(i), i;
}
function N(e, t) {
	t.useProgram(e);
}
function P(e, t) {
	let n = e;
	if (!n.isParallelCompiled) {
		t(e);
		return;
	}
	let r = n.onCompiled;
	n.onCompiled = () => {
		r?.(), t(e);
	};
}
//#endregion
//#region node_modules/@babylonjs/core/Materials/effect.functions.js
function F(e, t) {
	return S(t).cachedPipelines[e];
}
function I(e) {
	let t = e._name, n = e.context;
	if (t && n) {
		let e = S(n);
		e.cachedPipelines[t]?.dispose(), delete e.cachedPipelines[t];
	}
}
function L(e, t, n, r, i, o, s) {
	let c, l, u = a() ? o?.getHostDocument() : null;
	c = typeof t == "string" ? t : typeof t.vertexSource == "string" ? "source:" + t.vertexSource : typeof t.vertexElement == "string" ? u?.getElementById(t.vertexElement) || t.vertexElement : t.vertex || t, l = typeof t == "string" ? t : typeof t.fragmentSource == "string" ? "source:" + t.fragmentSource : typeof t.fragmentElement == "string" ? u?.getElementById(t.fragmentElement) || t.fragmentElement : t.fragment || t;
	let d = [void 0, void 0], p = () => {
		if (d[0] && d[1]) {
			let [a, c] = d;
			_(e), f(a, e, (a, l) => {
				s && (s._vertexSourceCodeBeforeMigration = l), n && (a = n("vertex", a)), e.isFragment = !0, f(c, e, (o, c) => {
					s && (s._fragmentSourceCodeBeforeMigration = c), n && (o = n("fragment", o));
					let l = m(a, o, e);
					e = null;
					let u = z(l.vertexCode, l.fragmentCode, t, i);
					r?.(u.vertexSourceCode, u.fragmentSourceCode);
				}, o);
			}, o);
		}
	};
	R(c, "Vertex", "", (e) => {
		s && (s._rawVertexSourceCode = e), d[0] = e, p();
	}, i), R(l, "Fragment", "Pixel", (e) => {
		s && (s._rawFragmentSourceCode = e), d[1] = e, p();
	}, i);
}
function R(e, t, n, r, a, o) {
	if (typeof HTMLElement < "u" && e instanceof HTMLElement) {
		r(c(e));
		return;
	}
	if (e.substring(0, 7) === "source:") {
		r(e.substring(7));
		return;
	}
	if (e.substring(0, 7) === "base64:") {
		r(window.atob(e.substring(7)));
		return;
	}
	let s = i.GetShadersStore(a);
	if (s[e + t + "Shader"]) {
		r(s[e + t + "Shader"]);
		return;
	}
	if (n && s[e + n + "Shader"]) {
		r(s[e + n + "Shader"]);
		return;
	}
	let l;
	if (l = e[0] === "." || e[0] === "/" || e.indexOf("http") > -1 ? e : i.GetShadersRepository(a) + e, o ||= u, !o) throw Error("loadFileInjection is not defined");
	o(l + "." + t.toLowerCase() + ".fx", r);
}
function z(e, t, n, r) {
	if (n) {
		let i = n.vertexElement || n.vertex || n.spectorName || n, a = n.fragmentElement || n.fragment || n.spectorName || n;
		return {
			vertexSourceCode: (r === 1 ? "//" : "") + "#define SHADER_NAME vertex:" + i + "\n" + e,
			fragmentSourceCode: (r === 1 ? "//" : "") + "#define SHADER_NAME fragment:" + a + "\n" + t
		};
	}
	return {
		vertexSourceCode: e,
		fragmentSourceCode: t
	};
}
var B = (e, t, n, i) => {
	try {
		let r = e.context ? S(e.context) : null;
		r && (r.disableParallelShaderCompile = e.disableParallelCompilation);
		let a = e.existingPipelineContext || t(e.shaderProcessingContext);
		return a._name = e.name, e.name && r && (r.cachedPipelines[e.name] = a), n(a, e.vertex, e.fragment, !!e.createAsRaw, "", "", e.rebuildRebind, e.defines, e.transformFeedbackVaryings, "", () => {
			i(a, () => {
				e.onRenderingStateCompiled?.(a);
			});
		}), a;
	} catch (e) {
		throw r.Error("Error compiling effect"), e;
	}
}, V = class t {
	static get ShadersRepository() {
		return i.ShadersRepository;
	}
	static set ShadersRepository(e) {
		i.ShadersRepository = e;
	}
	get isDisposed() {
		return this._isDisposed;
	}
	get onBindObservable() {
		return this._onBindObservable ||= new e(), this._onBindObservable;
	}
	get shaderLanguage() {
		return this._shaderLanguage;
	}
	constructor(n, r, i, a = null, o, s = null, c = null, l = null, u = null, d, f = "", p = 0, m) {
		this.defines = "", this.onCompiled = null, this.onError = null, this.onBind = null, this.uniqueId = 0, this.onCompileObservable = new e(), this.onErrorObservable = new e(), this._onBindObservable = null, this._isDisposed = !1, this._refCount = 1, this._bonesComputationForcedToCPU = !1, this._uniformBuffersNames = {}, this._multiTarget = !1, this._samplers = {}, this._isReady = !1, this._compilationError = "", this._allFallbacksProcessed = !1, this._uniforms = {}, this._key = "", this._fallbacks = null, this._vertexSourceCodeOverride = "", this._fragmentSourceCodeOverride = "", this._transformFeedbackVaryings = null, this._disableParallelShaderCompilation = !1, this._pipelineContext = null, this._vertexSourceCode = "", this._fragmentSourceCode = "", this._vertexSourceCodeBeforeMigration = "", this._fragmentSourceCodeBeforeMigration = "", this._rawVertexSourceCode = "", this._rawFragmentSourceCode = "", this._processCodeAfterIncludes = void 0, this._processFinalCode = null, this._onReleaseEffectsObserver = null, this.name = n, this._key = f;
		let h = this._key.replace(/\r/g, "").replace(/\n/g, "|"), g;
		if (r.attributes) {
			let e = r;
			if (this._engine = i, this._attributesNames = e.attributes, this._uniformsNames = e.uniformsNames.concat(e.samplers), this._samplerList = e.samplers.slice(), this.defines = e.defines, this.onError = e.onError, this.onCompiled = e.onCompiled, this._fallbacks = e.fallbacks, this._indexParameters = e.indexParameters, this._transformFeedbackVaryings = e.transformFeedbackVaryings || null, this._multiTarget = !!e.multiTarget, this._shaderLanguage = e.shaderLanguage ?? 0, this._disableParallelShaderCompilation = !!e.disableParallelShaderCompilation, e.uniformBuffersNames) {
				this._uniformBuffersNamesList = e.uniformBuffersNames.slice();
				for (let t = 0; t < e.uniformBuffersNames.length; t++) this._uniformBuffersNames[e.uniformBuffersNames[t]] = t;
			}
			this._processFinalCode = e.processFinalCode ?? null, this._processCodeAfterIncludes = e.processCodeAfterIncludes ?? void 0, m = e.extraInitializationsAsync, g = e.existingPipelineContext;
		} else this._engine = o, this.defines = s ?? "", this._uniformsNames = i.concat(a), this._samplerList = a ? a.slice() : [], this._attributesNames = r, this._uniformBuffersNamesList = [], this._shaderLanguage = p, this.onError = u, this.onCompiled = l, this._indexParameters = d, this._fallbacks = c;
		this._engine.shaderPlatformName === "WEBGL2" && (g = F(h, this._engine._gl) ?? g), this._attributeLocationByName = {}, this.uniqueId = t._UniqueIdSeed++, g ? (this._pipelineContext = g, this._pipelineContext.setEngine(this._engine), this._onRenderingStateCompiled(this._pipelineContext), this._pipelineContext.program && (this._pipelineContext.program.__SPECTOR_rebuildProgram = this._rebuildProgram.bind(this))) : this._processShaderCodeAsync(null, !1, null, m).catch((e) => {
			let t = e?.message ?? String(e), n = /* @__PURE__ */ Error(`Effect async shader preparation failed for "${String(this.name)}": ${t}`);
			e && typeof e.stack == "string" && (n.stack = `${n.message}\nCaused by: ${e.stack}`), this._processCompilationErrors(n);
		}), this._onReleaseEffectsObserver = this._engine.onReleaseEffectsObservable.addOnce(() => {
			this._onReleaseEffectsObserver = null, !this.isDisposed && this.dispose(!0);
		});
	}
	async _processShaderCodeAsync(e = null, t = !1, n = null, r) {
		r && await r(), this._processingContext = n || this._engine._getShaderProcessingContext(this._shaderLanguage, !1), L({
			defines: this.defines.split("\n"),
			indexParameters: this._indexParameters,
			isFragment: !1,
			shouldUseHighPrecisionShader: this._engine._shouldUseHighPrecisionShader,
			processor: e ?? this._engine._getShaderProcessor(this._shaderLanguage),
			supportsUniformBuffers: this._engine.supportsUniformBuffers,
			shadersRepository: i.GetShadersRepository(this._shaderLanguage),
			includesShadersStore: i.GetIncludesShadersStore(this._shaderLanguage),
			version: (this._engine.version * 100).toString(),
			platformName: this._engine.shaderPlatformName,
			processingContext: this._processingContext,
			isNDCHalfZRange: this._engine.isNDCHalfZRange,
			useReverseDepthBuffer: this._engine.useReverseDepthBuffer,
			processCodeAfterIncludes: this._processCodeAfterIncludes
		}, this.name, this._processFinalCode, (e, n) => {
			this._vertexSourceCode = e, this._fragmentSourceCode = n, this._prepareEffect(t);
		}, this._shaderLanguage, this._engine, this);
	}
	get key() {
		return this._key;
	}
	isReady() {
		try {
			return this._isReadyInternal();
		} catch {
			return !1;
		}
	}
	_isReadyInternal() {
		return this._engine.isDisposed || this._isReady ? !0 : this._pipelineContext ? this._pipelineContext.isReady : !1;
	}
	getEngine() {
		return this._engine;
	}
	getPipelineContext() {
		return this._pipelineContext;
	}
	getAttributesNames() {
		return this._attributesNames;
	}
	getAttributeLocation(e) {
		return this._attributes[e];
	}
	getAttributeLocationByName(e) {
		return this._attributeLocationByName[e];
	}
	getAttributesCount() {
		return this._attributes.length;
	}
	getUniformIndex(e) {
		return this._uniformsNames.indexOf(e);
	}
	getUniform(e) {
		return this._uniforms[e];
	}
	getSamplers() {
		return this._samplerList;
	}
	getUniformNames() {
		return this._uniformsNames;
	}
	getUniformBuffersNames() {
		return this._uniformBuffersNamesList;
	}
	getIndexParameters() {
		return this._indexParameters;
	}
	getCompilationError() {
		return this._compilationError;
	}
	allFallbacksProcessed() {
		return this._allFallbacksProcessed;
	}
	async whenCompiledAsync() {
		return await new Promise((e) => {
			this.executeWhenCompiled(e);
		});
	}
	executeWhenCompiled(e) {
		this.isReady() ? e(this) : (this.onCompileObservable.add((t) => {
			e(t);
		}), (!this._pipelineContext || this._pipelineContext.isAsync) && this._checkIsReady(null));
	}
	_checkIsReady(e) {
		d(() => this._isReadyInternal() || this._isDisposed, () => {}, (t) => {
			this._processCompilationErrors(t, e);
		}, 16, 12e4, !0, ` - Effect: ${typeof this.name == "string" ? this.name : this.key}`);
	}
	get vertexSourceCode() {
		return this._vertexSourceCodeOverride && this._fragmentSourceCodeOverride ? this._vertexSourceCodeOverride : this._pipelineContext?._getVertexShaderCode() ?? this._vertexSourceCode;
	}
	get fragmentSourceCode() {
		return this._vertexSourceCodeOverride && this._fragmentSourceCodeOverride ? this._fragmentSourceCodeOverride : this._pipelineContext?._getFragmentShaderCode() ?? this._fragmentSourceCode;
	}
	get vertexSourceCodeBeforeMigration() {
		return this._vertexSourceCodeBeforeMigration;
	}
	get fragmentSourceCodeBeforeMigration() {
		return this._fragmentSourceCodeBeforeMigration;
	}
	get rawVertexSourceCode() {
		return this._rawVertexSourceCode;
	}
	get rawFragmentSourceCode() {
		return this._rawFragmentSourceCode;
	}
	getPipelineGenerationOptions() {
		return {
			platformName: this._engine.shaderPlatformName,
			shaderLanguage: this._shaderLanguage,
			shaderNameOrContent: this.name,
			key: this._key,
			defines: this.defines.split("\n"),
			addGlobalDefines: !1,
			extendedProcessingOptions: {
				indexParameters: this._indexParameters,
				isNDCHalfZRange: this._engine.isNDCHalfZRange,
				useReverseDepthBuffer: this._engine.useReverseDepthBuffer,
				supportsUniformBuffers: this._engine.supportsUniformBuffers
			},
			extendedCreatePipelineOptions: {
				transformFeedbackVaryings: this._transformFeedbackVaryings,
				createAsRaw: !!(this._vertexSourceCodeOverride && this._fragmentSourceCodeOverride)
			}
		};
	}
	_rebuildProgram(e, t, n, r) {
		this._isReady = !1, this._vertexSourceCodeOverride = e, this._fragmentSourceCodeOverride = t, this.onError = (e, t) => {
			r && r(t);
		}, this.onCompiled = () => {
			let e = this.getEngine().scenes;
			if (e) for (let t = 0; t < e.length; t++) e[t].markAllMaterialsAsDirty(127);
			this._pipelineContext._handlesSpectorRebuildCallback?.(n);
		}, this._fallbacks = null, this._prepareEffect();
	}
	_onRenderingStateCompiled(e) {
		if (this._pipelineContext = e, this._pipelineContext.setEngine(this._engine), this._attributes = [], this._pipelineContext._fillEffectInformation(this, this._uniformBuffersNames, this._uniformsNames, this._uniforms, this._samplerList, this._samplers, this._attributesNames, this._attributes), this._attributesNames) for (let e = 0; e < this._attributesNames.length; e++) {
			let t = this._attributesNames[e];
			this._attributeLocationByName[t] = this._attributes[e];
		}
		this._engine.bindSamplers(this), this._compilationError = "", this._isReady = !0, this.onCompiled && this.onCompiled(this), this.onCompileObservable.notifyObservers(this), this.onCompileObservable.clear(), this._fallbacks && this._fallbacks.unBindMesh(), t.AutomaticallyClearCodeCache && this.clearCodeCache();
	}
	_prepareEffect(e = !1) {
		let t = this._pipelineContext;
		this._isReady = !1;
		try {
			let n = !!(this._vertexSourceCodeOverride && this._fragmentSourceCodeOverride), r = n ? null : this.defines, i = n ? this._vertexSourceCodeOverride : this._vertexSourceCode, a = n ? this._fragmentSourceCodeOverride : this._fragmentSourceCode, o = this._engine;
			this._pipelineContext = B({
				existingPipelineContext: e ? t : null,
				vertex: i,
				fragment: a,
				context: o.shaderPlatformName === "WEBGL2" || o.shaderPlatformName === "WEBGL1" ? o._gl : void 0,
				rebuildRebind: (e, t, n, r) => this._rebuildProgram(e, t, n, r),
				defines: r,
				transformFeedbackVaryings: this._transformFeedbackVaryings,
				name: this._key.replace(/\r/g, "").replace(/\n/g, "|"),
				createAsRaw: n,
				disableParallelCompilation: this._disableParallelShaderCompilation,
				shaderProcessingContext: this._processingContext,
				onRenderingStateCompiled: (n) => {
					t && !e && this._engine._deletePipelineContext(t), n && this._onRenderingStateCompiled(n);
				}
			}, this._engine.createPipelineContext.bind(this._engine), this._engine._preparePipelineContextAsync.bind(this._engine), this._engine._executeWhenRenderingStateIsCompiled.bind(this._engine)), this._pipelineContext.isAsync && this._checkIsReady(t);
		} catch (e) {
			this._processCompilationErrors(e, t);
		}
	}
	_getShaderCodeAndErrorLine(e, t, n) {
		let r = n ? /FRAGMENT SHADER ERROR: 0:(\d+?):/ : /VERTEX SHADER ERROR: 0:(\d+?):/, i = null;
		if (t && e) {
			let a = t.match(r);
			if (a && a.length === 2) {
				let t = parseInt(a[1]), r = e.split("\n", -1);
				r.length >= t && (i = `Offending line [${t}] in ${n ? "fragment" : "vertex"} code: ${r[t - 1]}`);
			}
		}
		return [e, i];
	}
	_processCompilationErrors(e, n = null) {
		this._compilationError = typeof e?.stack == "string" ? e.stack : e?.message ?? String(e);
		let i = this._attributesNames, a = this._fallbacks;
		if (r.Error("Unable to compile effect:"), r.Error(`Uniforms: ${this._uniformsNames.join(" ")}`), r.Error(`Attributes: ${i.join(" ")}`), r.Error("Defines:\n" + this.defines), t.LogShaderCodeOnCompilationError) {
			let e = null, t = null, n;
			this._pipelineContext?._getVertexShaderCode() && ([n, e] = this._getShaderCodeAndErrorLine(this._pipelineContext._getVertexShaderCode(), this._compilationError, !1), n && (r.Error("Vertex code:"), r.Error(n))), this._pipelineContext?._getFragmentShaderCode() && ([n, t] = this._getShaderCodeAndErrorLine(this._pipelineContext?._getFragmentShaderCode(), this._compilationError, !0), n && (r.Error("Fragment code:"), r.Error(n))), e && r.Error(e), t && r.Error(t);
		}
		r.Error("Error: " + this._compilationError);
		let o = () => {
			this.onError && this.onError(this, this._compilationError), this.onErrorObservable.notifyObservers(this), this._engine.onEffectErrorObservable.notifyObservers({
				effect: this,
				errors: this._compilationError
			});
		};
		n && (this._pipelineContext = n, this._isReady = !0, o()), a ? (this._pipelineContext = null, a.hasMoreFallbacks ? (this._allFallbacksProcessed = !1, r.Error("Trying next fallback."), this.defines = a.reduce(this.defines, this), this._prepareEffect()) : (this._allFallbacksProcessed = !0, o(), this.onErrorObservable.clear(), this._fallbacks && this._fallbacks.unBindMesh())) : (this._allFallbacksProcessed = !0, n || o());
	}
	get isSupported() {
		return this._compilationError === "";
	}
	_bindTexture(e, t) {
		this._engine._bindTexture(this._samplers[e], t, e);
	}
	setTexture(e, t) {
		this._engine.setTexture(this._samplers[e], this._uniforms[e], t, e);
	}
	setTextureArray(e, t) {
		let n = e + "Ex";
		if (this._samplerList.indexOf(n + "0") === -1) {
			let r = this._samplerList.indexOf(e);
			for (let e = 1; e < t.length; e++) {
				let t = n + (e - 1).toString();
				this._samplerList.splice(r + e, 0, t);
			}
			let i = 0;
			for (let e of this._samplerList) this._samplers[e] = i, i += 1;
		}
		this._engine.setTextureArray(this._samplers[e], this._uniforms[e], t, e);
	}
	bindUniformBuffer(e, n) {
		let r = this._uniformBuffersNames[n];
		r === void 0 || t._BaseCache[r] === e && this._engine._features.useUBOBindingCache || (t._BaseCache[r] = e, this._engine.bindUniformBufferBase(e, r, n));
	}
	bindUniformBlock(e, t) {
		this._engine.bindUniformBlock(this._pipelineContext, e, t);
	}
	setInt(e, t) {
		return this._pipelineContext.setInt(e, t), this;
	}
	setInt2(e, t, n) {
		return this._pipelineContext.setInt2(e, t, n), this;
	}
	setInt3(e, t, n, r) {
		return this._pipelineContext.setInt3(e, t, n, r), this;
	}
	setInt4(e, t, n, r, i) {
		return this._pipelineContext.setInt4(e, t, n, r, i), this;
	}
	setIntArray(e, t) {
		return this._pipelineContext.setIntArray(e, t), this;
	}
	setIntArray2(e, t) {
		return this._pipelineContext.setIntArray2(e, t), this;
	}
	setIntArray3(e, t) {
		return this._pipelineContext.setIntArray3(e, t), this;
	}
	setIntArray4(e, t) {
		return this._pipelineContext.setIntArray4(e, t), this;
	}
	setUInt(e, t) {
		return this._pipelineContext.setUInt(e, t), this;
	}
	setUInt2(e, t, n) {
		return this._pipelineContext.setUInt2(e, t, n), this;
	}
	setUInt3(e, t, n, r) {
		return this._pipelineContext.setUInt3(e, t, n, r), this;
	}
	setUInt4(e, t, n, r, i) {
		return this._pipelineContext.setUInt4(e, t, n, r, i), this;
	}
	setUIntArray(e, t) {
		return this._pipelineContext.setUIntArray(e, t), this;
	}
	setUIntArray2(e, t) {
		return this._pipelineContext.setUIntArray2(e, t), this;
	}
	setUIntArray3(e, t) {
		return this._pipelineContext.setUIntArray3(e, t), this;
	}
	setUIntArray4(e, t) {
		return this._pipelineContext.setUIntArray4(e, t), this;
	}
	setFloatArray(e, t) {
		return this._pipelineContext.setArray(e, t), this;
	}
	setFloatArray2(e, t) {
		return this._pipelineContext.setArray2(e, t), this;
	}
	setFloatArray3(e, t) {
		return this._pipelineContext.setArray3(e, t), this;
	}
	setFloatArray4(e, t) {
		return this._pipelineContext.setArray4(e, t), this;
	}
	setArray(e, t) {
		return this._pipelineContext.setArray(e, t), this;
	}
	setArray2(e, t) {
		return this._pipelineContext.setArray2(e, t), this;
	}
	setArray3(e, t) {
		return this._pipelineContext.setArray3(e, t), this;
	}
	setArray4(e, t) {
		return this._pipelineContext.setArray4(e, t), this;
	}
	setMatrices(e, t) {
		return this._pipelineContext.setMatrices(e, t), this;
	}
	setMatrix(e, t) {
		return this._pipelineContext.setMatrix(e, t), this;
	}
	setMatrix3x3(e, t) {
		return this._pipelineContext.setMatrix3x3(e, t), this;
	}
	setMatrix2x2(e, t) {
		return this._pipelineContext.setMatrix2x2(e, t), this;
	}
	setFloat(e, t) {
		return this._pipelineContext.setFloat(e, t), this;
	}
	setBool(e, t) {
		return this._pipelineContext.setInt(e, +!!t), this;
	}
	setVector2(e, t) {
		return this._pipelineContext.setVector2(e, t), this;
	}
	setFloat2(e, t, n) {
		return this._pipelineContext.setFloat2(e, t, n), this;
	}
	setVector3(e, t) {
		return this._pipelineContext.setVector3(e, t), this;
	}
	setFloat3(e, t, n, r) {
		return this._pipelineContext.setFloat3(e, t, n, r), this;
	}
	setVector4(e, t) {
		return this._pipelineContext.setVector4(e, t), this;
	}
	setQuaternion(e, t) {
		return this._pipelineContext.setQuaternion(e, t), this;
	}
	setFloat4(e, t, n, r, i) {
		return this._pipelineContext.setFloat4(e, t, n, r, i), this;
	}
	setColor3(e, t) {
		return this._pipelineContext.setColor3(e, t), this;
	}
	setColor4(e, t, n) {
		return this._pipelineContext.setColor4(e, t, n), this;
	}
	setDirectColor4(e, t) {
		return this._pipelineContext.setDirectColor4(e, t), this;
	}
	clearCodeCache() {
		this._vertexSourceCode = "", this._fragmentSourceCode = "", this._fragmentSourceCodeBeforeMigration = "", this._vertexSourceCodeBeforeMigration = "";
	}
	dispose(e = !1) {
		if (e) this._refCount = 0;
		else {
			if (t.PersistentMode) return;
			this._refCount--;
		}
		this._refCount > 0 || this._isDisposed || (this._onReleaseEffectsObserver &&= (this._engine.onReleaseEffectsObservable.remove(this._onReleaseEffectsObserver), null), this._pipelineContext && I(this._pipelineContext), this._engine._releaseEffect(this), this.clearCodeCache(), this._isDisposed = !0);
	}
	static RegisterShader(e, t, n, r = 0) {
		t && (i.GetShadersStore(r)[`${e}PixelShader`] = t), n && (i.GetShadersStore(r)[`${e}VertexShader`] = n);
	}
	static ResetCache() {
		t._BaseCache = {};
	}
};
V.LogShaderCodeOnCompilationError = !0, V.PersistentMode = !1, V.AutomaticallyClearCodeCache = !1, V._UniqueIdSeed = 0, V._BaseCache = {}, V.ShadersStore = i.ShadersStore, V.IncludesShadersStore = i.IncludesShadersStore;
//#endregion
//#region node_modules/@babylonjs/core/States/depthCullingState.js
var H = class {
	constructor(e = !0) {
		this._isDepthTestDirty = !1, this._isDepthMaskDirty = !1, this._isDepthFuncDirty = !1, this._isCullFaceDirty = !1, this._isCullDirty = !1, this._isZOffsetDirty = !1, this._isFrontFaceDirty = !1, e && this.reset();
	}
	get isDirty() {
		return this._isDepthFuncDirty || this._isDepthTestDirty || this._isDepthMaskDirty || this._isCullFaceDirty || this._isCullDirty || this._isZOffsetDirty || this._isFrontFaceDirty;
	}
	get zOffset() {
		return this._zOffset;
	}
	set zOffset(e) {
		this._zOffset !== e && (this._zOffset = e, this._isZOffsetDirty = !0);
	}
	get zOffsetUnits() {
		return this._zOffsetUnits;
	}
	set zOffsetUnits(e) {
		this._zOffsetUnits !== e && (this._zOffsetUnits = e, this._isZOffsetDirty = !0);
	}
	get cullFace() {
		return this._cullFace;
	}
	set cullFace(e) {
		this._cullFace !== e && (this._cullFace = e, this._isCullFaceDirty = !0);
	}
	get cull() {
		return this._cull;
	}
	set cull(e) {
		this._cull !== e && (this._cull = e, this._isCullDirty = !0);
	}
	get depthFunc() {
		return this._depthFunc;
	}
	set depthFunc(e) {
		this._depthFunc !== e && (this._depthFunc = e, this._isDepthFuncDirty = !0);
	}
	get depthMask() {
		return this._depthMask;
	}
	set depthMask(e) {
		this._depthMask !== e && (this._depthMask = e, this._isDepthMaskDirty = !0);
	}
	get depthTest() {
		return this._depthTest;
	}
	set depthTest(e) {
		this._depthTest !== e && (this._depthTest = e, this._isDepthTestDirty = !0);
	}
	get frontFace() {
		return this._frontFace;
	}
	set frontFace(e) {
		this._frontFace !== e && (this._frontFace = e, this._isFrontFaceDirty = !0);
	}
	reset() {
		this._depthMask = !0, this._depthTest = !0, this._depthFunc = null, this._cullFace = null, this._cull = null, this._zOffset = 0, this._zOffsetUnits = 0, this._frontFace = null, this._isDepthTestDirty = !0, this._isDepthMaskDirty = !0, this._isDepthFuncDirty = !1, this._isCullFaceDirty = !1, this._isCullDirty = !1, this._isZOffsetDirty = !0, this._isFrontFaceDirty = !1;
	}
	apply(e) {
		this.isDirty && (this._isCullDirty &&= (this.cull ? e.enable(e.CULL_FACE) : e.disable(e.CULL_FACE), !1), this._isCullFaceDirty &&= (e.cullFace(this.cullFace), !1), this._isDepthMaskDirty &&= (e.depthMask(this.depthMask), !1), this._isDepthTestDirty &&= (this.depthTest ? e.enable(e.DEPTH_TEST) : e.disable(e.DEPTH_TEST), !1), this._isDepthFuncDirty &&= (e.depthFunc(this.depthFunc), !1), this._isZOffsetDirty &&= (this.zOffset || this.zOffsetUnits ? (e.enable(e.POLYGON_OFFSET_FILL), e.polygonOffset(this.zOffset, this.zOffsetUnits)) : e.disable(e.POLYGON_OFFSET_FILL), !1), this._isFrontFaceDirty &&= (e.frontFace(this.frontFace), !1));
	}
}, U = class {
	get isDirty() {
		return this._isStencilTestDirty || this._isStencilMaskDirty || this._isStencilFuncDirty || this._isStencilOpDirty;
	}
	get func() {
		return this._func;
	}
	set func(e) {
		this._func !== e && (this._func = e, this._isStencilFuncDirty = !0);
	}
	get backFunc() {
		return this._func;
	}
	set backFunc(e) {
		this._backFunc !== e && (this._backFunc = e, this._isStencilFuncDirty = !0);
	}
	get funcRef() {
		return this._funcRef;
	}
	set funcRef(e) {
		this._funcRef !== e && (this._funcRef = e, this._isStencilFuncDirty = !0);
	}
	get funcMask() {
		return this._funcMask;
	}
	set funcMask(e) {
		this._funcMask !== e && (this._funcMask = e, this._isStencilFuncDirty = !0);
	}
	get opStencilFail() {
		return this._opStencilFail;
	}
	set opStencilFail(e) {
		this._opStencilFail !== e && (this._opStencilFail = e, this._isStencilOpDirty = !0);
	}
	get opDepthFail() {
		return this._opDepthFail;
	}
	set opDepthFail(e) {
		this._opDepthFail !== e && (this._opDepthFail = e, this._isStencilOpDirty = !0);
	}
	get opStencilDepthPass() {
		return this._opStencilDepthPass;
	}
	set opStencilDepthPass(e) {
		this._opStencilDepthPass !== e && (this._opStencilDepthPass = e, this._isStencilOpDirty = !0);
	}
	get backOpStencilFail() {
		return this._backOpStencilFail;
	}
	set backOpStencilFail(e) {
		this._backOpStencilFail !== e && (this._backOpStencilFail = e, this._isStencilOpDirty = !0);
	}
	get backOpDepthFail() {
		return this._backOpDepthFail;
	}
	set backOpDepthFail(e) {
		this._backOpDepthFail !== e && (this._backOpDepthFail = e, this._isStencilOpDirty = !0);
	}
	get backOpStencilDepthPass() {
		return this._backOpStencilDepthPass;
	}
	set backOpStencilDepthPass(e) {
		this._backOpStencilDepthPass !== e && (this._backOpStencilDepthPass = e, this._isStencilOpDirty = !0);
	}
	get mask() {
		return this._mask;
	}
	set mask(e) {
		this._mask !== e && (this._mask = e, this._isStencilMaskDirty = !0);
	}
	get enabled() {
		return this._enabled;
	}
	set enabled(e) {
		this._enabled !== e && (this._enabled = e, this._isStencilTestDirty = !0);
	}
	constructor(e = !0) {
		this._isStencilTestDirty = !1, this._isStencilMaskDirty = !1, this._isStencilFuncDirty = !1, this._isStencilOpDirty = !1, this.useStencilGlobalOnly = !1, e && this.reset();
	}
	reset() {
		this.stencilMaterial = void 0, this.stencilGlobal?.reset(), this._isStencilTestDirty = !0, this._isStencilMaskDirty = !0, this._isStencilFuncDirty = !0, this._isStencilOpDirty = !0;
	}
	apply(e) {
		if (!e) return;
		let t = !this.useStencilGlobalOnly && !!this.stencilMaterial?.enabled;
		this.enabled = t ? this.stencilMaterial.enabled : this.stencilGlobal.enabled, this.func = t ? this.stencilMaterial.func : this.stencilGlobal.func, this.backFunc = t ? this.stencilMaterial.backFunc : this.stencilGlobal.backFunc, this.funcRef = t ? this.stencilMaterial.funcRef : this.stencilGlobal.funcRef, this.funcMask = t ? this.stencilMaterial.funcMask : this.stencilGlobal.funcMask, this.opStencilFail = t ? this.stencilMaterial.opStencilFail : this.stencilGlobal.opStencilFail, this.opDepthFail = t ? this.stencilMaterial.opDepthFail : this.stencilGlobal.opDepthFail, this.opStencilDepthPass = t ? this.stencilMaterial.opStencilDepthPass : this.stencilGlobal.opStencilDepthPass, this.backOpStencilFail = t ? this.stencilMaterial.backOpStencilFail : this.stencilGlobal.backOpStencilFail, this.backOpDepthFail = t ? this.stencilMaterial.backOpDepthFail : this.stencilGlobal.backOpDepthFail, this.backOpStencilDepthPass = t ? this.stencilMaterial.backOpStencilDepthPass : this.stencilGlobal.backOpStencilDepthPass, this.mask = t ? this.stencilMaterial.mask : this.stencilGlobal.mask, this.isDirty && (this._isStencilTestDirty &&= (this.enabled ? e.enable(e.STENCIL_TEST) : e.disable(e.STENCIL_TEST), !1), this._isStencilMaskDirty &&= (e.stencilMask(this.mask), !1), this._isStencilFuncDirty &&= (e.stencilFuncSeparate(e.FRONT, this.func, this.funcRef, this.funcMask), e.stencilFuncSeparate(e.BACK, this.backFunc, this.funcRef, this.funcMask), !1), this._isStencilOpDirty &&= (e.stencilOpSeparate(e.FRONT, this.opStencilFail, this.opDepthFail, this.opStencilDepthPass), e.stencilOpSeparate(e.BACK, this.backOpStencilFail, this.backOpDepthFail, this.backOpStencilDepthPass), !1));
	}
}, W = class e {
	constructor() {
		this.reset();
	}
	reset() {
		this.enabled = !1, this.mask = 255, this.funcRef = 1, this.funcMask = 255, this.func = e.ALWAYS, this.opStencilFail = e.KEEP, this.opDepthFail = e.KEEP, this.opStencilDepthPass = e.REPLACE, this.backFunc = e.ALWAYS, this.backOpStencilFail = e.KEEP, this.backOpDepthFail = e.KEEP, this.backOpStencilDepthPass = e.REPLACE;
	}
	get stencilFunc() {
		return this.func;
	}
	set stencilFunc(e) {
		this.func = e;
	}
	get stencilBackFunc() {
		return this.backFunc;
	}
	set stencilBackFunc(e) {
		this.backFunc = e;
	}
	get stencilFuncRef() {
		return this.funcRef;
	}
	set stencilFuncRef(e) {
		this.funcRef = e;
	}
	get stencilFuncMask() {
		return this.funcMask;
	}
	set stencilFuncMask(e) {
		this.funcMask = e;
	}
	get stencilOpStencilFail() {
		return this.opStencilFail;
	}
	set stencilOpStencilFail(e) {
		this.opStencilFail = e;
	}
	get stencilOpDepthFail() {
		return this.opDepthFail;
	}
	set stencilOpDepthFail(e) {
		this.opDepthFail = e;
	}
	get stencilOpStencilDepthPass() {
		return this.opStencilDepthPass;
	}
	set stencilOpStencilDepthPass(e) {
		this.opStencilDepthPass = e;
	}
	get stencilBackOpStencilFail() {
		return this.backOpStencilFail;
	}
	set stencilBackOpStencilFail(e) {
		this.backOpStencilFail = e;
	}
	get stencilBackOpDepthFail() {
		return this.backOpDepthFail;
	}
	set stencilBackOpDepthFail(e) {
		this.backOpDepthFail = e;
	}
	get stencilBackOpStencilDepthPass() {
		return this.backOpStencilDepthPass;
	}
	set stencilBackOpStencilDepthPass(e) {
		this.backOpStencilDepthPass = e;
	}
	get stencilMask() {
		return this.mask;
	}
	set stencilMask(e) {
		this.mask = e;
	}
	get stencilTest() {
		return this.enabled;
	}
	set stencilTest(e) {
		this.enabled = e;
	}
};
W.ALWAYS = 519, W.KEEP = 7680, W.REPLACE = 7681;
//#endregion
//#region node_modules/@babylonjs/core/States/alphaCullingState.js
var G = class {
	constructor(e) {
		this._supportBlendParametersPerTarget = e, this._blendFunctionParameters = Array(32), this._blendEquationParameters = Array(16), this._blendConstants = [
			,
			,
			,
			,
		], this._isBlendConstantsDirty = !1, this._alphaBlend = Array(8).fill(!1), this._numTargetEnabled = 0, this._isAlphaBlendDirty = !1, this._isBlendFunctionParametersDirty = !1, this._isBlendEquationParametersDirty = !1, this._blendDisabledTargetsMask = 0, this._numTargets = 1, this.reset();
	}
	get isDirty() {
		return this._isAlphaBlendDirty || this._isBlendFunctionParametersDirty || this._isBlendEquationParametersDirty;
	}
	get alphaBlend() {
		return this._numTargetEnabled > 0;
	}
	set alphaBlend(e) {
		this.setAlphaBlend(e);
	}
	setAlphaBlend(e, t = 0) {
		this._alphaBlend[t] !== e && (e ? this._numTargetEnabled++ : this._numTargetEnabled--, this._alphaBlend[t] = e, this._isAlphaBlendDirty = !0);
	}
	setAlphaBlendConstants(e, t, n, r) {
		(this._blendConstants[0] !== e || this._blendConstants[1] !== t || this._blendConstants[2] !== n || this._blendConstants[3] !== r) && (this._blendConstants[0] = e, this._blendConstants[1] = t, this._blendConstants[2] = n, this._blendConstants[3] = r, this._isBlendConstantsDirty = !0);
	}
	setAlphaBlendFunctionParameters(e, t, n, r, i = 0) {
		let a = i * 4;
		(this._blendFunctionParameters[a + 0] !== e || this._blendFunctionParameters[a + 1] !== t || this._blendFunctionParameters[a + 2] !== n || this._blendFunctionParameters[a + 3] !== r) && (this._blendFunctionParameters[a + 0] = e, this._blendFunctionParameters[a + 1] = t, this._blendFunctionParameters[a + 2] = n, this._blendFunctionParameters[a + 3] = r, this._isBlendFunctionParametersDirty = !0);
	}
	setAlphaEquationParameters(e, t, n = 0) {
		let r = n * 2;
		(this._blendEquationParameters[r + 0] !== e || this._blendEquationParameters[r + 1] !== t) && (this._blendEquationParameters[r + 0] = e, this._blendEquationParameters[r + 1] = t, this._isBlendEquationParametersDirty = !0);
	}
	reset() {
		this._alphaBlend.fill(!1), this._numTargetEnabled = 0, this._blendFunctionParameters.fill(null), this._blendEquationParameters.fill(null), this._blendConstants[0] = null, this._blendConstants[1] = null, this._blendConstants[2] = null, this._blendConstants[3] = null, this._isAlphaBlendDirty = !0, this._isBlendFunctionParametersDirty = !1, this._isBlendEquationParametersDirty = !1, this._isBlendConstantsDirty = !1, this._blendDisabledTargetsMask = 0, this._numTargets = 1;
	}
	apply(e, t = 1, n = 0) {
		if (this._numTargets !== t && (this._numTargets = t, this._isAlphaBlendDirty = !0), this._blendDisabledTargetsMask !== n && (this._blendDisabledTargetsMask = n, this._isAlphaBlendDirty = !0), !this.isDirty) return;
		if (this._isBlendConstantsDirty &&= (e.blendColor(this._blendConstants[0], this._blendConstants[1], this._blendConstants[2], this._blendConstants[3]), !1), t === 1 || !this._supportBlendParametersPerTarget) {
			if (this._isAlphaBlendDirty) {
				if (t > 1 && n !== 0 && this.alphaBlend) throw Error("AlphaState: blending with integer MRT attachments requires per-target blend parameters");
				this._alphaBlend[0] && !(n & 1) ? e.enable(e.BLEND) : e.disable(e.BLEND), this._isAlphaBlendDirty = !1;
			}
			this._isBlendFunctionParametersDirty &&= (e.blendFuncSeparate(this._blendFunctionParameters[0], this._blendFunctionParameters[1], this._blendFunctionParameters[2], this._blendFunctionParameters[3]), !1), this._isBlendEquationParametersDirty &&= (e.blendEquationSeparate(this._blendEquationParameters[0], this._blendEquationParameters[1]), !1);
			return;
		}
		let r = e;
		if (this._isAlphaBlendDirty) {
			for (let i = 0; i < t; i++) {
				let t = i < this._numTargetEnabled ? i : 0;
				this._alphaBlend[t] && !(n & 1 << i) ? r.enableIndexed(e.BLEND, i) : r.disableIndexed(e.BLEND, i);
			}
			this._isAlphaBlendDirty = !1;
		}
		if (this._isBlendFunctionParametersDirty) {
			for (let e = 0; e < t; e++) {
				let t = e < this._numTargetEnabled ? e * 4 : 0;
				r.blendFuncSeparateIndexed(e, this._blendFunctionParameters[t + 0], this._blendFunctionParameters[t + 1], this._blendFunctionParameters[t + 2], this._blendFunctionParameters[t + 3]);
			}
			this._isBlendFunctionParametersDirty = !1;
		}
		if (this._isBlendEquationParametersDirty) {
			for (let e = 0; e < t; e++) {
				let t = e < this._numTargetEnabled ? e * 2 : 0;
				r.blendEquationSeparateIndexed(e, this._blendEquationParameters[t + 0], this._blendEquationParameters[t + 1]);
			}
			this._isBlendEquationParametersDirty = !1;
		}
	}
	setAlphaMode(e, t) {
		let n = 32774;
		switch (e) {
			case 0: break;
			case 7:
				this.setAlphaBlendFunctionParameters(1, 771, 1, 1, t);
				break;
			case 8:
				this.setAlphaBlendFunctionParameters(1, 771, 1, 771, t);
				break;
			case 2:
				this.setAlphaBlendFunctionParameters(770, 771, 1, 1, t);
				break;
			case 6:
				this.setAlphaBlendFunctionParameters(1, 1, 0, 1, t);
				break;
			case 1:
				this.setAlphaBlendFunctionParameters(770, 1, 0, 1, t);
				break;
			case 3:
				this.setAlphaBlendFunctionParameters(0, 769, 1, 1, t);
				break;
			case 4:
				this.setAlphaBlendFunctionParameters(774, 0, 1, 1, t);
				break;
			case 5:
				this.setAlphaBlendFunctionParameters(770, 769, 1, 1, t);
				break;
			case 9:
				this.setAlphaBlendFunctionParameters(32769, 32770, 32771, 32772, t);
				break;
			case 10:
				this.setAlphaBlendFunctionParameters(1, 769, 1, 771, t);
				break;
			case 11:
				this.setAlphaBlendFunctionParameters(1, 1, 1, 1, t);
				break;
			case 12:
				this.setAlphaBlendFunctionParameters(772, 1, 0, 0, t);
				break;
			case 13:
				this.setAlphaBlendFunctionParameters(775, 769, 773, 771, t);
				break;
			case 14:
				this.setAlphaBlendFunctionParameters(1, 771, 1, 771, t);
				break;
			case 15:
				this.setAlphaBlendFunctionParameters(1, 1, 1, 0, t);
				break;
			case 16:
				this.setAlphaBlendFunctionParameters(775, 769, 0, 1, t);
				break;
			case 17:
				this.setAlphaBlendFunctionParameters(770, 771, 1, 771, t);
				break;
			case 18:
				this.setAlphaBlendFunctionParameters(1, 1, 1, 1, t), n = 32775;
				break;
			case 19:
				this.setAlphaBlendFunctionParameters(1, 1, 1, 1, t), n = 32776;
				break;
			case 20:
				this.setAlphaBlendFunctionParameters(1, 35065, 0, 1, t);
				break;
			case 21: this.setAlphaBlendFunctionParameters(1, 0, 1, 771, t);
		}
		this.setAlphaEquationParameters(n, n, t);
	}
};
//#endregion
//#region node_modules/@babylonjs/core/Engines/abstractEngine.pure.js
function K(e, t) {
	if (t) {
		let { requestAnimationFrame: n } = t;
		if (typeof n == "function") return n(e);
	}
	if (a()) {
		let { requestAnimationFrame: n } = t || window;
		if (typeof n == "function") return n(e);
	} else if (typeof requestAnimationFrame == "function") return requestAnimationFrame(e);
	return setTimeout(e, 16);
}
var q = class i {
	get frameId() {
		return this._frameId;
	}
	get isWebGPU() {
		return this._isWebGPU;
	}
	_getShaderProcessor(e) {
		return this._shaderProcessor;
	}
	_resetAlphaMode() {
		this._alphaMode.fill(-1), this._alphaEquation.fill(-1);
	}
	get shaderPlatformName() {
		return this._shaderPlatformName;
	}
	_clearEmptyResources() {
		this._emptyTexture = null, this._emptyCubeTexture = null, this._emptyTexture3D = null, this._emptyTexture2DArray = null;
	}
	get useReverseDepthBuffer() {
		return this._useReverseDepthBuffer;
	}
	set useReverseDepthBuffer(e) {
		e !== this._useReverseDepthBuffer && (this._useReverseDepthBuffer = e, e ? this._depthCullingState.depthFunc = 518 : this._depthCullingState.depthFunc = 515);
	}
	setColorWrite(e) {
		e !== this._colorWrite && (this._colorWriteChanged = !0, this._colorWrite = e);
	}
	getColorWrite() {
		return this._colorWrite;
	}
	get depthCullingState() {
		return this._depthCullingState;
	}
	get alphaState() {
		return this._alphaState;
	}
	get stencilState() {
		return this._stencilState;
	}
	get stencilStateComposer() {
		return this._stencilStateComposer;
	}
	_getGlobalDefines(e) {
		if (e) this.isNDCHalfZRange ? e.IS_NDC_HALF_ZRANGE = "" : delete e.IS_NDC_HALF_ZRANGE, this.useReverseDepthBuffer ? e.USE_REVERSE_DEPTHBUFFER = "" : delete e.USE_REVERSE_DEPTHBUFFER, this.useExactSrgbConversions ? e.USE_EXACT_SRGB_CONVERSIONS = "" : delete e.USE_EXACT_SRGB_CONVERSIONS;
		else {
			let e = "";
			return this.isNDCHalfZRange && (e += "#define IS_NDC_HALF_ZRANGE"), this.useReverseDepthBuffer && (e && (e += "\n"), e += "#define USE_REVERSE_DEPTHBUFFER"), this.useExactSrgbConversions && (e && (e += "\n"), e += "#define USE_EXACT_SRGB_CONVERSIONS"), e;
		}
	}
	_rebuildInternalTextures() {
		let e = this._internalTexturesCache.slice();
		for (let t of e) t._rebuild();
	}
	_rebuildRenderTargetWrappers() {
		let e = this._renderTargetWrapperCache.slice();
		for (let t of e) t.textures?.some((e) => e.source === 15) || t._rebuild();
	}
	_rebuildEffects() {
		for (let e in this._compiledEffects) {
			let t = this._compiledEffects[e];
			t._pipelineContext = null, t._prepareEffect();
		}
		V.ResetCache();
	}
	_rebuildGraphicsResources() {
		this.wipeCaches(!0), this._rebuildEffects(), this._rebuildComputeEffects?.(), this._rebuildBuffers(), this._rebuildInternalTextures(), this._rebuildTextures(), this._rebuildRenderTargetWrappers(), this.wipeCaches(!0);
	}
	_flagContextRestored() {
		r.Warn(this.name + " context successfully restored."), this.onContextRestoredObservable.notifyObservers(this), this._contextWasLost = !1;
	}
	_restoreEngineAfterContextLost(e) {
		setTimeout(async () => {
			this._clearEmptyResources();
			let t = this._depthCullingState.depthTest, n = this._depthCullingState.depthFunc, i = this._depthCullingState.depthMask, a = this._stencilState.stencilTest;
			try {
				await e();
			} catch (e) {
				r.Error(`${this.name}: context restoration failed: ${String(e)}`);
				return;
			}
			this._rebuildGraphicsResources(), this._depthCullingState.depthTest = t, this._depthCullingState.depthFunc = n, this._depthCullingState.depthMask = i, this._stencilState.stencilTest = a, this._flagContextRestored();
		}, 0);
	}
	get isDisposed() {
		return this._isDisposed;
	}
	get snapshotRendering() {
		return !1;
	}
	set snapshotRendering(e) {}
	get snapshotRenderingMode() {
		return 0;
	}
	set snapshotRenderingMode(e) {}
	getClassName() {
		return "AbstractEngine";
	}
	get emptyTexture() {
		return this._emptyTexture ||= this.createRawTexture(/* @__PURE__ */ new Uint8Array(4), 1, 1, 5, !1, !1, 1), this._emptyTexture;
	}
	get emptyTexture3D() {
		return this._emptyTexture3D ||= this.createRawTexture3D(/* @__PURE__ */ new Uint8Array(4), 1, 1, 1, 5, !1, !1, 1), this._emptyTexture3D;
	}
	get emptyTexture2DArray() {
		return this._emptyTexture2DArray ||= this.createRawTexture2DArray(/* @__PURE__ */ new Uint8Array(4), 1, 1, 1, 5, !1, !1, 1), this._emptyTexture2DArray;
	}
	get emptyCubeTexture() {
		if (!this._emptyCubeTexture) {
			let e = /* @__PURE__ */ new Uint8Array(4), t = [
				e,
				e,
				e,
				e,
				e,
				e
			];
			this._emptyCubeTexture = this.createRawCubeTexture(t, 1, 5, 0, !1, !1, 1);
		}
		return this._emptyCubeTexture;
	}
	set framebufferDimensionsObject(e) {
		this._framebufferDimensionsObject = e;
	}
	get activeRenderLoops() {
		return this._activeRenderLoops;
	}
	stopRenderLoop(e) {
		if (!e) {
			this._activeRenderLoops.length = 0, this._cancelFrame();
			return;
		}
		let t = this._activeRenderLoops.indexOf(e);
		t >= 0 && (this._activeRenderLoops.splice(t, 1), this._activeRenderLoops.length == 0 && this._cancelFrame());
	}
	_cancelFrame() {
		if (this.customAnimationFrameRequester) {
			if (this._frameHandler !== 0) {
				this._frameHandler = 0;
				let { cancelAnimationFrame: e } = this.customAnimationFrameRequester;
				e && e(this.customAnimationFrameRequester.requestID), delete this.customAnimationFrameRequester.requestID;
			}
		} else if (this._frameHandler !== 0) {
			let e = this._frameHandler;
			if (this._frameHandler = 0, a()) {
				let { cancelAnimationFrame: t } = this.getHostWindow() || window;
				if (typeof t == "function") return t(e);
			} else if (typeof cancelAnimationFrame == "function") return cancelAnimationFrame(e);
			return clearTimeout(e);
		}
	}
	beginFrame() {
		this.onBeginFrameObservable.notifyObservers(this);
	}
	endFrame() {
		this._frameId++, this.onEndFrameObservable.notifyObservers(this);
	}
	get maxFPS() {
		return this._maxFPS;
	}
	set maxFPS(e) {
		this._maxFPS = e, e !== void 0 && (this._minFrameTime = e <= 0 ? Number.MAX_VALUE : 1e3 / e);
	}
	_isOverFrameTime(e) {
		if (!e || this._maxFPS === void 0) return !1;
		let t = e - this._lastFrameTime;
		return this._lastFrameTime = e, this._renderAccumulator += t, this._renderAccumulator < this._minFrameTime || (this._renderAccumulator -= this._minFrameTime, this._renderAccumulator > this._minFrameTime && (this._renderAccumulator = this._minFrameTime), !1);
	}
	_processFrame(e) {
		if (this._frameHandler = 0, !this._contextWasLost && !this._isOverFrameTime(e)) {
			let e = !0;
			(this.isDisposed || !this.renderEvenInBackground && this._windowIsBackground) && (e = !1), e && (this.beginFrame(), !this.skipFrameRender && !this._renderViews() && this._renderFrame(), this.endFrame());
		}
	}
	_renderLoop(e) {
		this._processFrame(e), this._activeRenderLoops.length > 0 && this._frameHandler === 0 && this._queueNewFrameForRenderLoop();
	}
	_renderFrame() {
		for (let e = 0; e < this._activeRenderLoops.length; e++) {
			let t = this._activeRenderLoops[e];
			t();
		}
	}
	_renderViews() {
		return !1;
	}
	_queueNewFrame(e, t) {
		return K(e, t);
	}
	_queueNewFrameForRenderLoop() {
		this.customAnimationFrameRequester ? (this.customAnimationFrameRequester.requestID = this._queueNewFrame(this.customAnimationFrameRequester.renderFunction || this._boundRenderFunction, this.customAnimationFrameRequester), this._frameHandler = this.customAnimationFrameRequester.requestID) : this._frameHandler = this._queueNewFrame(this._boundRenderFunction, this.getHostWindow());
	}
	runRenderLoop(e) {
		this._activeRenderLoops.indexOf(e) === -1 && (this._activeRenderLoops.push(e), this._activeRenderLoops.length === 1 && this._frameHandler === 0 && this._queueNewFrameForRenderLoop());
	}
	getDepthBuffer() {
		return this._depthCullingState.depthTest;
	}
	setDepthBuffer(e) {
		this._depthCullingState.depthTest = e;
	}
	setZOffset(e) {
		this._depthCullingState.zOffset = this.useReverseDepthBuffer ? -e : e;
	}
	getZOffset() {
		let e = this._depthCullingState.zOffset;
		return this.useReverseDepthBuffer ? -e : e;
	}
	setZOffsetUnits(e) {
		this._depthCullingState.zOffsetUnits = this.useReverseDepthBuffer ? -e : e;
	}
	getZOffsetUnits() {
		let e = this._depthCullingState.zOffsetUnits;
		return this.useReverseDepthBuffer ? -e : e;
	}
	getHostWindow() {
		return a() ? this._renderingCanvas && this._renderingCanvas.ownerDocument && this._renderingCanvas.ownerDocument.defaultView ? this._renderingCanvas.ownerDocument.defaultView : window : null;
	}
	get compatibilityMode() {
		return this._compatibilityMode;
	}
	set compatibilityMode(e) {
		this._compatibilityMode = !0;
	}
	_rebuildTextures() {
		for (let e of this.scenes) e._rebuildTextures();
		for (let e of this._virtualScenes) e._rebuildTextures();
	}
	_releaseRenderTargetWrapper(e) {
		let t = this._renderTargetWrapperCache.indexOf(e);
		t !== -1 && this._renderTargetWrapperCache.splice(t, 1);
	}
	get currentViewport() {
		return this._cachedViewport;
	}
	setViewport(e, t, n) {
		let r = t || this.getRenderWidth(), i = n || this.getRenderHeight(), a = e.x || 0, o = e.y || 0;
		this._cachedViewport = e, this._viewport(a * r, o * i, r * e.width, i * e.height);
	}
	createCanvasImage() {
		return document.createElement("img");
	}
	createCanvasPath2D(e) {
		return new Path2D(e);
	}
	get description() {
		let e = this.name + this.version;
		return this._caps.parallelShaderCompile && (e += " - Parallel shader compilation"), e;
	}
	_createTextureBase(e, a, o, s, c = 3, l = null, u = null, d, f, p = null, m = null, h = null, g = null, _, v, y) {
		e ||= "";
		let b = e.substring(0, 5) === "data:", x = e.substring(0, 5) === "blob:", S = b && e.indexOf(";base64,") !== -1, C = m || new n(this, 1);
		C !== m && (C.label = e.substring(0, 60));
		let w = e;
		this._transformTextureUrl && !S && !m && !p && (e = this._transformTextureUrl(e)), w !== e && (C._originalUrl = w);
		let T = e.lastIndexOf("."), E = g || (T > -1 ? e.substring(T).toLowerCase() : "");
		E.indexOf("?") > -1 && (E = E.split("?")[0]);
		let D = i.GetCompatibleTextureLoader(E, _);
		s && s.addPendingData(C), C.url = e, C.generateMipMaps = !a, C.samplingMode = c, C.invertY = o, C._useSRGBBuffer = this._getUseSRGBBuffer(!!y, a), this._doNotHandleContextLost || (C._buffer = p);
		let O = null;
		l && !m && (O = C.onLoadedObservable.add(l)), m || this._internalTexturesCache.push(C);
		let k = (n, i) => {
			s && s.removePendingData(C), e === w ? (O && C.onLoadedObservable.remove(O), t.UseFallbackTexture && e !== t.FallbackTexture && this._createTextureBase(t.FallbackTexture, a, C.invertY, s, c, null, u, d, f, p, C), n = (n || "Unknown error") + (t.UseFallbackTexture ? " - Fallback texture was used" : ""), C._setError(n, i), u && u(n, i)) : (r.Warn(`Failed to load ${e}, falling back to ${w}`), this._createTextureBase(w, a, C.invertY, s, c, l, u, d, f, p, C, h, g, _, v, y));
		};
		if (D) {
			let t = async (e) => {
				(await D).loadData(e, C, (e, t, n, r, i, a) => {
					a ? k("TextureLoader failed to load data") : d(C, E, s, {
						width: e,
						height: t
					}, C.invertY, !n, r, () => (i(), !1), c);
				}, v);
			};
			if (!p) this._loadFile(e, async (e) => {
				try {
					await t(new Uint8Array(e));
				} catch (e) {
					k("Failed to parse texture data", e);
				}
			}, void 0, s ? s.offlineProvider : void 0, !0, (e, t) => {
				k("Unable to load " + (e && e.responseURL, t));
			});
			else {
				let e = async (e) => {
					try {
						await t(e);
					} catch (e) {
						k("Failed to parse texture data", e);
					}
				};
				p instanceof ArrayBuffer ? e(new Uint8Array(p)) : ArrayBuffer.isView(p) ? e(p) : u && u("Unable to load: only ArrayBuffer or ArrayBufferView is supported", null);
			}
		} else {
			let t = (e) => {
				x && !this._doNotHandleContextLost && (C._buffer = e), d(C, E, s, e, C.invertY, a, !1, f, c);
			};
			!b || S ? p && (typeof p.decoding == "string" || p.close) ? t(p) : i._FileToolsLoadImage(e || "", t, k, s ? s.offlineProvider : null, _, C.invertY && this._features.needsInvertingBitmap ? { imageOrientation: "flipY" } : void 0, this) : typeof p == "string" || p instanceof ArrayBuffer || ArrayBuffer.isView(p) || p instanceof Blob ? i._FileToolsLoadImage(p, t, k, s ? s.offlineProvider : null, _, C.invertY && this._features.needsInvertingBitmap ? { imageOrientation: "flipY" } : void 0, this) : p && t(p);
		}
		return C;
	}
	_rebuildBuffers() {
		for (let e of this._uniformBuffers) e._rebuildAfterContextLost();
	}
	get _shouldUseHighPrecisionShader() {
		return !!(this._caps.highPrecisionShaderSupported && this._highPrecisionShadersAllowed);
	}
	getHostDocument() {
		return this._renderingCanvas && this._renderingCanvas.ownerDocument ? this._renderingCanvas.ownerDocument : o() ? document : null;
	}
	getLoadedTexturesCache() {
		return this._internalTexturesCache;
	}
	clearInternalTexturesCache() {
		this._internalTexturesCache.length = 0;
	}
	getCaps() {
		return this._caps;
	}
	resetTextureCache() {
		for (let e in this._boundTexturesCache) Object.prototype.hasOwnProperty.call(this._boundTexturesCache, e) && (this._boundTexturesCache[e] = null);
		this._currentTextureChannel = -1;
	}
	get name() {
		return this._name;
	}
	set name(e) {
		this._name = e;
	}
	static get NpmPackage() {
		return "babylonjs@9.32.0";
	}
	static get Version() {
		return "9.32.0";
	}
	getRenderingCanvas() {
		return this._renderingCanvas;
	}
	getAudioContext() {
		return this._audioContext;
	}
	getAudioDestination() {
		return this._audioDestination;
	}
	setHardwareScalingLevel(e) {
		this._hardwareScalingLevel = e, this.resize();
	}
	getHardwareScalingLevel() {
		return this._hardwareScalingLevel;
	}
	get doNotHandleContextLost() {
		return this._doNotHandleContextLost;
	}
	set doNotHandleContextLost(e) {
		this._doNotHandleContextLost = e;
	}
	get isStencilEnable() {
		return this._isStencilEnable;
	}
	getCreationOptions() {
		return this._creationOptions;
	}
	constructor(n, r, i) {
		this._colorWrite = !0, this._colorWriteChanged = !0, this._depthCullingState = new H(), this._stencilStateComposer = new U(), this._stencilState = new W(), this._alphaState = new G(!1), this._alphaMode = Array(8).fill(-1), this._alphaEquation = Array(8).fill(-1), this._activeRequests = [], this._badOS = !1, this._badDesktopOS = !1, this._compatibilityMode = !0, this._internalTexturesCache = [], this._currentRenderTarget = null, this._boundTexturesCache = {}, this._activeChannel = 0, this._currentTextureChannel = -1, this._viewportCached = {
			x: 0,
			y: 0,
			z: 0,
			w: 0
		}, this._isWebGPU = !1, this._enableGPUDebugMarkers = !1, this.onCanvasBlurObservable = new e(), this.onCanvasFocusObservable = new e(), this.onNewSceneAddedObservable = new e(), this.onResizeObservable = new e(), this.onCanvasPointerOutObservable = new e(), this.onEffectErrorObservable = new e(), this.disablePerformanceMonitorInBackground = !1, this.disableVertexArrayObjects = !1, this._frameId = 0, this.hostInformation = { isMobile: !1 }, this.isFullscreen = !1, this.enableOfflineSupport = !1, this.disableManifestCheck = !1, this.disableContextMenu = !0, this.currentRenderPassId = 0, this.isPointerLock = !1, this.postProcesses = [], this.canvasTabIndex = 1, this._contextWasLost = !1, this._useReverseDepthBuffer = !1, this.isNDCHalfZRange = !1, this.hasOriginBottomLeft = !0, this._renderTargetWrapperCache = [], this._compiledEffects = {}, this._isDisposed = !1, this.scenes = [], this._virtualScenes = [], this.onBeforeTextureInitObservable = new e(), this.renderEvenInBackground = !0, this.preventCacheWipeBetweenFrames = !1, this._frameHandler = 0, this._activeRenderLoops = [], this.customAnimationFrameRequester = null, this._windowIsBackground = !1, this._boundRenderFunction = (e) => this._renderLoop(e), this._lastFrameTime = 0, this._renderAccumulator = 0, this.skipFrameRender = !1, this.onBeforeShaderCompilationObservable = new e(), this.onAfterShaderCompilationObservable = new e(), this.onBeginFrameObservable = new e(), this.onEndFrameObservable = new e(), this._transformTextureUrl = null, this._uniformBuffers = [], this._storageBuffers = [], this._highPrecisionShadersAllowed = !0, this.onContextLostObservable = new e(), this.onContextRestoredObservable = new e(), this._name = "", this.premultipliedAlpha = !0, this.adaptToDeviceRatio = !1, this._lastDevicePixelRatio = 1, this._doNotHandleContextLost = !1, this.cullBackFaces = null, this._renderPassNames = ["main"], this._onReleaseRenderPassObservable = null, this._fps = 60, this._deltaTime = 0, this._deterministicLockstep = !1, this._lockstepMaxSteps = 4, this._timeStep = 1 / 60, this.onDisposeObservable = new e(), this.onReleaseEffectsObservable = new e(), t.Instances.push(this), this.startTime = g.Now, this._stencilStateComposer.stencilGlobal = this._stencilState, v.SetMatrixPrecision(!!r.useLargeWorldRendering || !!r.useHighPrecisionMatrix), s() && navigator.userAgent && (this._badOS = /iPad/i.test(navigator.userAgent) || /iPhone/i.test(navigator.userAgent), this._badDesktopOS = /^((?!chrome|android).)*safari/i.test(navigator.userAgent)), r.antialias = n ?? r.antialias, r.deterministicLockstep = r.deterministicLockstep ?? !1, r.lockstepMaxSteps = r.lockstepMaxSteps ?? 4, r.timeStep = r.timeStep ?? 1 / 60, r.stencil = r.stencil ?? !0, this._audioContext = r.audioEngineOptions?.audioContext ?? null, this._audioDestination = r.audioEngineOptions?.audioDestination ?? null, this.premultipliedAlpha = r.premultipliedAlpha ?? !0, this._doNotHandleContextLost = !!r.doNotHandleContextLost, this._isStencilEnable = !!r.stencil, this.useExactSrgbConversions = r.useExactSrgbConversions ?? !1, this.useReverseDepthBuffer = r.useReverseDepthBuffer ?? !1, this.canvasTabIndex = r.canvasTabIndex ?? this.canvasTabIndex;
		let o = a() && window.devicePixelRatio || 1, c = r.limitDeviceRatio || o;
		i = i || r.adaptToDeviceRatio || !1, this.adaptToDeviceRatio = i, this._hardwareScalingLevel = i ? 1 / Math.min(c, o) : 1, this._lastDevicePixelRatio = o, this._creationOptions = r;
	}
	resize(e = !1) {
		let t, n;
		if (this.adaptToDeviceRatio) {
			let e = a() && window.devicePixelRatio || 1, t = this._lastDevicePixelRatio / e;
			this._lastDevicePixelRatio = e, this._hardwareScalingLevel *= t;
		}
		if (a() && o()) {
			if (this._renderingCanvas) {
				let e = this._renderingCanvas.getBoundingClientRect?.();
				t = this._renderingCanvas.clientWidth || e?.width || this._renderingCanvas.width * this._hardwareScalingLevel || 100, n = this._renderingCanvas.clientHeight || e?.height || this._renderingCanvas.height * this._hardwareScalingLevel || 100;
			} else t = window.innerWidth, n = window.innerHeight;
		} else t = this._renderingCanvas ? this._renderingCanvas.width : 100, n = this._renderingCanvas ? this._renderingCanvas.height : 100;
		this.setSize(t / this._hardwareScalingLevel, n / this._hardwareScalingLevel, e);
	}
	setSize(e, t, n = !1) {
		if (!this._renderingCanvas || (e |= 0, t |= 0, !n && this._renderingCanvas.width === e && this._renderingCanvas.height === t)) return !1;
		if (this._renderingCanvas.width = e, this._renderingCanvas.height = t, this.scenes) {
			for (let e = 0; e < this.scenes.length; e++) {
				let t = this.scenes[e];
				for (let e = 0; e < t.cameras.length; e++) {
					let n = t.cameras[e];
					n._currentRenderId = 0;
				}
			}
			this.onResizeObservable.hasObservers() && this.onResizeObservable.notifyObservers(this);
		}
		return !0;
	}
	createRawTexture(e, t, n, r, i, a, o, s, c, u, d, f) {
		throw l("engine.rawTexture");
	}
	createRawCubeTexture(e, t, n, r, i, a, o, s) {
		throw l("engine.rawTexture");
	}
	createRawTexture3D(e, t, n, r, i, a, o, s, c, u, d) {
		throw l("engine.rawTexture");
	}
	createRawTexture2DArray(e, t, n, r, i, a, o, s, c, u, d, f) {
		throw l("engine.rawTexture");
	}
	_sharedInit(e) {
		this._renderingCanvas = e;
	}
	_setupMobileChecks() {
		navigator && navigator.userAgent && (this._checkForMobile = () => {
			let e = navigator.userAgent;
			this.hostInformation.isMobile = e.indexOf("Mobile") !== -1 || e.indexOf("Mac") !== -1 && o() && "ontouchend" in document;
		}, this._checkForMobile(), a() && window.addEventListener("resize", this._checkForMobile));
	}
	createVideoElement(e) {
		return document.createElement("video");
	}
	_reportDrawCall(e = 1) {
		this._drawCalls?.addCount(e, !1);
	}
	getFps() {
		return this._fps;
	}
	getDeltaTime() {
		return this._deltaTime;
	}
	isDeterministicLockStep() {
		return this._deterministicLockstep;
	}
	getLockstepMaxSteps() {
		return this._lockstepMaxSteps;
	}
	getTimeStep() {
		return this._timeStep * 1e3;
	}
	_createImageBitmapFromSource(e, t) {
		throw Error("createImageBitmapFromSource is not implemented");
	}
	createImageBitmap(e, t) {
		return createImageBitmap(e, t);
	}
	resizeImageBitmap(e, t, n) {
		throw Error("resizeImageBitmap is not implemented");
	}
	getFontOffset(e) {
		throw Error("getFontOffset is not implemented");
	}
	static _CreateCanvas(e, t) {
		if (typeof document > "u") return new OffscreenCanvas(e, t);
		let n = document.createElement("canvas");
		return n.width = e, n.height = t, n;
	}
	createCanvas(e, t) {
		return i._CreateCanvas(e, t);
	}
	static _FileToolsLoadImage(e, t, n, r, i, a, o) {
		if (!h.loadImage) throw l("FileTools");
		return h.loadImage(e, t, n, r, i, a, o);
	}
	_loadFile(e, t, n, r, i, a) {
		let o = u(e, t, n, r, i, a);
		return this._activeRequests.push(o), o.onCompleteObservable.add(() => {
			let e = this._activeRequests.indexOf(o);
			e !== -1 && this._activeRequests.splice(e, 1);
		}), o;
	}
	static _FileToolsLoadFile(e, t, n, r, i, a) {
		if (h.loadFile) return h.loadFile(e, t, n, r, i, a);
		throw l("FileTools");
	}
	dispose() {
		for (this.releaseEffects(), this._isDisposed = !0, this.stopRenderLoop(), this._emptyTexture &&= (this._releaseTexture(this._emptyTexture), null), this._emptyCubeTexture &&= (this._releaseTexture(this._emptyCubeTexture), null), this._renderingCanvas = null, this.onBeforeTextureInitObservable && this.onBeforeTextureInitObservable.clear(); this.postProcesses.length;) this.postProcesses[0].dispose();
		for (; this.scenes.length;) this.scenes[0].dispose();
		for (; this._virtualScenes.length;) this._virtualScenes[0].dispose();
		this.releaseComputeEffects?.(), V.ResetCache();
		for (let e of this._activeRequests) e.abort();
		this._boundRenderFunction = null, this.onDisposeObservable.notifyObservers(this), this.onDisposeObservable.clear(), this.onResizeObservable.clear(), this.onCanvasBlurObservable.clear(), this.onCanvasFocusObservable.clear(), this.onCanvasPointerOutObservable.clear(), this.onNewSceneAddedObservable.clear(), this.onEffectErrorObservable.clear(), a() && window.removeEventListener("resize", this._checkForMobile);
		let e = t.Instances.indexOf(this);
		e >= 0 && t.Instances.splice(e, 1), t.Instances.length || (t.OnEnginesDisposedObservable.notifyObservers(this), t.OnEnginesDisposedObservable.clear()), this.onBeginFrameObservable.clear(), this.onEndFrameObservable.clear(), this._onReleaseRenderPassObservable?.clear(), this._onReleaseRenderPassObservable = null;
	}
	static DefaultLoadingScreenFactory(e) {
		throw l("LoadingScreen");
	}
	static MarkAllMaterialsAsDirty(e, n) {
		for (let r = 0; r < t.Instances.length; r++) {
			let i = t.Instances[r];
			for (let t = 0; t < i.scenes.length; t++) i.scenes[t].markAllMaterialsAsDirty(e, n);
		}
	}
	static GetCompatibleTextureLoader(e, t) {
		return null;
	}
};
q._RenderPassIdCounter = 0, q._RescalePostProcessFactory = null, q.CollisionsEpsilon = .001, q.QueueNewFrame = K;
//#endregion
export { D as a, O as c, E as d, w as f, S as h, I as i, A as l, C as m, G as n, P as o, T as p, V as r, k as s, q as t, N as u };
