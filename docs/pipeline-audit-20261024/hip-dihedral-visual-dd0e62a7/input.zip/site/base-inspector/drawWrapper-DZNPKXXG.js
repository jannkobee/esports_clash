import { s as e } from "./tools.functions-DEecYKlu.js";
//#region node_modules/@babylonjs/core/Materials/drawWrapper.js
var t = class {
	static GetEffect(e) {
		return e.getPipelineContext === void 0 ? e.effect : e;
	}
	constructor(e, t = !0) {
		this._wasPreviouslyReady = !1, this._forceRebindOnNextCall = !0, this._wasPreviouslyUsingInstances = null, this.effect = null, this.defines = null, this.drawContext = e.createDrawContext(), t && (this.materialContext = e.createMaterialContext());
	}
	setEffect(e, t, n = !0) {
		!n && this.effect !== e && this.drawContext?._releaseUniformBufferSlots?.(), this.effect = e, t !== void 0 && (this.defines = t), n && this.drawContext?.reset();
	}
	dispose(t = !1) {
		if (this.effect) {
			let n = this.effect;
			t ? n.dispose() : e.SetImmediate(() => {
				n.getEngine().onEndFrameObservable.addOnce(() => {
					n.dispose();
				});
			}), this.effect = null;
		}
		this.drawContext?.dispose();
	}
};
//#endregion
export { t };
