//#region node_modules/@babylonjs/core/Misc/HighDynamicRange/hdr.js
function e(e, t) {
	return t > 1023 ? e * 2 ** 1023 * 2 ** (t - 1023) : t < -1074 ? e * 2 ** -1074 * 2 ** (t + 1074) : e * 2 ** t;
}
function t(t, n, r, i, a, o) {
	a > 0 ? (a = e(1, a - 136), t[o + 0] = n * a, t[o + 1] = r * a, t[o + 2] = i * a) : (t[o + 0] = 0, t[o + 1] = 0, t[o + 2] = 0);
}
function n(e, t) {
	let n = "", r;
	for (let i = t; i < e.length - t && (r = String.fromCharCode(e[i]), r != "\n"); i++) n += r;
	return n;
}
function r(e) {
	let t = n(e, 0);
	if (t[0] != "#" || t[1] != "?") throw "Bad HDR Format.";
	let r = !1, i = !1, a = 0;
	do
		a += t.length + 1, t = n(e, a), t == "FORMAT=32-bit_rle_rgbe" ? i = !0 : t.length == 0 && (r = !0);
	while (!r);
	if (!i) throw "HDR Bad header format, unsupported FORMAT";
	a += t.length + 1, t = n(e, a);
	let o = /^-Y (.*) \+X (.*)$/g.exec(t);
	if (!o || o.length < 3) throw "HDR Bad header format, no size";
	let s = parseInt(o[2]), c = parseInt(o[1]);
	if (s < 8 || s > 32767) throw "HDR Bad header format, unsupported size";
	return a += t.length + 1, {
		height: c,
		width: s,
		dataPosition: a
	};
}
function i(e, t) {
	return a(e, t);
}
function a(e, n) {
	let r = n.height, i = n.width, a, s, c, l, u, d = n.dataPosition, f, p, m, h = /* @__PURE__ */ new ArrayBuffer(i * 4), g = new Uint8Array(h), _ = /* @__PURE__ */ new ArrayBuffer(n.width * n.height * 4 * 3), v = new Float32Array(_);
	for (; r > 0;) {
		if (a = e[d++], s = e[d++], c = e[d++], l = e[d++], a != 2 || s != 2 || c & 128 || n.width < 8 || n.width > 32767) return o(e, n);
		if ((c << 8 | l) != i) throw "HDR Bad header format, wrong scan line width";
		for (f = 0, m = 0; m < 4; m++) for (p = (m + 1) * i; f < p;) if (a = e[d++], s = e[d++], a > 128) {
			if (u = a - 128, u == 0 || u > p - f) throw "HDR Bad Format, bad scanline data (run)";
			for (; u-- > 0;) g[f++] = s;
		} else {
			if (u = a, u == 0 || u > p - f) throw "HDR Bad Format, bad scanline data (non-run)";
			if (g[f++] = s, --u > 0) for (let t = 0; t < u; t++) g[f++] = e[d++];
		}
		for (m = 0; m < i; m++) a = g[m], s = g[m + i], c = g[m + 2 * i], l = g[m + 3 * i], t(v, a, s, c, l, (n.height - r) * i * 3 + m * 3);
		r--;
	}
	return v;
}
function o(e, n) {
	let r = n.height, i = n.width, a, o, s, c, l, u = n.dataPosition, d = /* @__PURE__ */ new ArrayBuffer(n.width * n.height * 4 * 3), f = new Float32Array(d);
	for (; r > 0;) {
		for (l = 0; l < n.width; l++) a = e[u++], o = e[u++], s = e[u++], c = e[u++], t(f, a, o, s, c, (n.height - r) * i * 3 + l * 3);
		r--;
	}
	return f;
}
//#endregion
//#region node_modules/@babylonjs/core/Materials/Textures/Loaders/hdrTextureLoader.js
var s = class {
	constructor() {
		this.supportCascades = !1;
	}
	loadCubeData() {
		throw ".hdr not supported in Cube.";
	}
	loadData(e, t, n) {
		let a = new Uint8Array(e.buffer, e.byteOffset, e.byteLength), o = r(a), s = i(a, o), c = o.width * o.height, l = new Float32Array(c * 4);
		for (let e = 0; e < c; e += 1) l[e * 4] = s[e * 3], l[e * 4 + 1] = s[e * 3 + 1], l[e * 4 + 2] = s[e * 3 + 2], l[e * 4 + 3] = 1;
		n(o.width, o.height, t.generateMipMaps, !1, () => {
			let e = t.getEngine();
			t.type = 1, t.format = 5, t._gammaSpace = !1, e._uploadDataToTextureDirectly(t, l);
		});
	}
};
//#endregion
export { s as _HDRTextureLoader };
