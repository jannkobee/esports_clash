import { a as e } from "./math.color.pure-CPmbqLkh.js";
import { h as t } from "./decorators-BldPRAAT.js";
import { t as n } from "./material.pure-BwKfnJ6P.js";
//#region node_modules/@babylonjs/core/Materials/materialHelper.geometryrendering.js
function r(e, t, n = 16777215) {
	let r = t(e);
	if (!Number.isInteger(r) || r < 0 || r > n) throw Error(`Invalid geometry object ID ${r} for mesh "${e.name}". Object IDs must be integers between 0 and 0x${n.toString(16).toUpperCase()}.`);
	return r;
}
function i(e, t) {
	let n = t(e);
	if (!Number.isInteger(n) || n < 0 || n > 255 || n !== 0 && !(n & 63)) throw Error(`Invalid geometry mesh-blending tag ${n} for mesh "${e.name}". Tags must be 0 or contain a group ID between 1 and 63.`);
	return n;
}
var a;
(function(e) {
	e[e.Zero = 0] = "Zero", e[e.One = 1] = "One", e[e.MaxViewZ = 2] = "MaxViewZ", e[e.NoClear = 3] = "NoClear";
})(a ||= {});
var o = class t {
	static CreateConfiguration(n) {
		return t._Configurations[n] = {
			defines: {},
			previousWorldMatrices: {},
			previousViewProjection: e.Zero(),
			currentViewProjection: e.Zero(),
			previousBones: {},
			lastUpdateFrameId: -1,
			excludedSkinnedMesh: [],
			reverseCulling: !1,
			objectIdIsRedFormat: !1
		}, t._Configurations[n];
	}
	static DeleteConfiguration(e) {
		delete t._Configurations[e];
	}
	static GetConfiguration(e) {
		return t._Configurations[e];
	}
	static _PrepareConfiguration(e, n, r) {
		let i = t._Configurations[e];
		i._attachments = n, i._colorAttachments = r, i._mrtCount = n.length;
		let a = "#define PREPASS\n";
		for (let e of t.GeometryTextureDescriptions) {
			let t = i.defines[e.defineIndex];
			t !== void 0 && (a += `#define ${e.define}\n#define ${e.defineIndex} ${t}\n`);
		}
		i.objectIdIsRedFormat && (a += "#define PREPASS_OBJECT_ID_R8\n"), i._defines = a + `#define SCENE_MRT_COUNT ${n.length}\n`;
	}
	static _PrepareStringDefines(e, n) {
		let r = t._Configurations[e];
		return r?._defines ? (n.push(r._defines), !0) : !1;
	}
	static _BindAttachmentsForEffect(e, n) {
		let r = t._Configurations[e.currentRenderPassId];
		return !r?._attachments || (e.bindAttachments(n._multiTarget ? r._attachments : r._colorAttachments), n._multiTarget || r.defines.PREPASS_COLOR_INDEX !== void 0);
	}
	static _RestoreAttachments(e) {
		let n = t._Configurations[e.currentRenderPassId];
		n?._colorAttachments && e.bindAttachments(n._colorAttachments);
	}
	static _BindColorAttachments(e) {
		let n = t._Configurations[e.currentRenderPassId];
		return !n?._colorAttachments || (e.bindAttachments(n._colorAttachments), n.defines.PREPASS_COLOR_INDEX !== void 0);
	}
	static _IsColorAttachmentEnabled(e) {
		let n = t._Configurations[e.currentRenderPassId];
		return !n?._colorAttachments || n.defines.PREPASS_COLOR_INDEX !== void 0;
	}
	static _BindZeroAlphaDiscard(e, n) {
		let r = t._Configurations[e.currentRenderPassId];
		if (!r) return;
		let i = e.getAlphaMode(), a = r.defines.PREPASS_COLOR_INDEX === void 0 || i === 2 || i === 1 || i === 17;
		n.setFloat("geometryZeroAlphaDiscard", +!!a);
	}
	static AddUniformsAndSamplers(e, t) {
		e.push("previousWorld", "previousViewProjection", "mPreviousBones", "objectId", "meshBlendTag");
	}
	static MarkAsDirty(e, t) {
		for (let n of t) if (n.subMeshes) for (let t of n.subMeshes) t._removeDrawWrapper(e);
	}
	static PrepareDefines(e, n, r) {
		if (!r._arePrePassDirty) return;
		let i = t._Configurations[e];
		if (!i) return;
		r.PREPASS = !0;
		let a = 0;
		for (let e = 0; e < t.GeometryTextureDescriptions.length; e++) {
			let n = t.GeometryTextureDescriptions[e], o = n.define, s = n.defineIndex, c = i.defines[s];
			c === void 0 ? (r[o] = !1, delete r[s]) : (r[o] = !0, r[s] = c, a++);
		}
		r.PREPASS_OBJECT_ID_R8 = i.objectIdIsRedFormat, r.SCENE_MRT_COUNT = i._mrtCount ?? a, r.BONES_VELOCITY_ENABLED = n.useBones && n.computeBonesUsingShaders && n.skeleton && !n.skeleton.isUsingTextureForMatrices && i.excludedSkinnedMesh.indexOf(n) === -1;
	}
	static Bind(e, n, a, o, s) {
		let c = t._Configurations[e];
		if (!c) return;
		let l = a.getScene(), u = l.getEngine();
		if (c.reverseCulling && u.setStateCullFaceType(l._mirroredCameraPosition ? s.cullBackFaces : !s.cullBackFaces), c.defines.PREPASS_OBJECT_ID_INDEX !== void 0) {
			let e = c.objectIdIsRedFormat ? 255 : 16777215, t = a.uniqueId;
			if (c.objectIdProvider) t = r(a, c.objectIdProvider, e);
			else if (t > e) throw Error(`Invalid geometry object ID ${t} for mesh "${a.name}". Object IDs must be integers between 0 and 0x${e.toString(16).toUpperCase()}.`);
			n.setFloat("objectId", t);
		}
		if (c.defines.PREPASS_MESH_BLEND_TAG_INDEX !== void 0) {
			let e = c.meshBlendTagProvider ? i(a, c.meshBlendTagProvider) : a.meshBlendingTag;
			n.setInt("meshBlendTag", e);
		}
		if (c.defines.PREPASS_VELOCITY_INDEX !== void 0 || c.defines.PREPASS_VELOCITY_LINEAR_INDEX !== void 0) {
			let e = c._currentWorldMatrices ??= {}, t = c._worldMatrixFrameIds ??= {};
			if (e[a.uniqueId] || (e[a.uniqueId] = o.clone(), c.previousWorldMatrices[a.uniqueId] = o.clone()), t[a.uniqueId] !== u.frameId && (c.previousWorldMatrices[a.uniqueId].copyFrom(e[a.uniqueId]), t[a.uniqueId] = u.frameId), e[a.uniqueId].copyFrom(o), c.lastUpdateFrameId === -1 ? (c.lastUpdateFrameId = u.frameId, c.previousViewProjection.copyFrom(l.getTransformMatrix()), c.currentViewProjection.copyFrom(l.getTransformMatrix())) : c.currentViewProjection.updateFlag === l.getTransformMatrix().updateFlag ? c.lastUpdateFrameId !== u.frameId && (c.lastUpdateFrameId = u.frameId, c.previousViewProjection.copyFrom(c.currentViewProjection)) : (c.lastUpdateFrameId = u.frameId, c.previousViewProjection.copyFrom(c.currentViewProjection), c.currentViewProjection.copyFrom(l.getTransformMatrix())), n.setMatrix("previousWorld", c.previousWorldMatrices[a.uniqueId]), n.setMatrix("previousViewProjection", c.previousViewProjection), a.useBones && a.computeBonesUsingShaders && a.skeleton) {
				let e = a.skeleton;
				if (!e.isUsingTextureForMatrices || n.getUniformIndex("boneTextureInfo") === -1) {
					let t = e.getTransformMatrices(a);
					t && (c.previousBones[a.uniqueId] || (c.previousBones[a.uniqueId] = t.slice()), n.setMatrices("mPreviousBones", c.previousBones[a.uniqueId]), c.previousBones[a.uniqueId].set(t));
				}
			}
		}
	}
};
o.GeometryTextureDescriptions = [
	{
		type: 0,
		name: "IrradianceLegacy",
		clearType: 0,
		define: "PREPASS_IRRADIANCE_LEGACY",
		defineIndex: "PREPASS_IRRADIANCE_LEGACY_INDEX"
	},
	{
		type: 1,
		name: "WorldPosition",
		clearType: 0,
		define: "PREPASS_POSITION",
		defineIndex: "PREPASS_POSITION_INDEX"
	},
	{
		type: 2,
		name: "Velocity",
		clearType: 0,
		define: "PREPASS_VELOCITY",
		defineIndex: "PREPASS_VELOCITY_INDEX"
	},
	{
		type: 3,
		name: "Reflectivity",
		clearType: 0,
		define: "PREPASS_REFLECTIVITY",
		defineIndex: "PREPASS_REFLECTIVITY_INDEX"
	},
	{
		type: 5,
		name: "ViewDepth",
		clearType: 2,
		define: "PREPASS_DEPTH",
		defineIndex: "PREPASS_DEPTH_INDEX"
	},
	{
		type: 6,
		name: "ViewNormal",
		clearType: 0,
		define: "PREPASS_NORMAL",
		defineIndex: "PREPASS_NORMAL_INDEX"
	},
	{
		type: 7,
		name: "AlbedoSqrt",
		clearType: 0,
		define: "PREPASS_ALBEDO_SQRT",
		defineIndex: "PREPASS_ALBEDO_SQRT_INDEX"
	},
	{
		type: 8,
		name: "WorldNormal",
		clearType: 0,
		define: "PREPASS_WORLD_NORMAL",
		defineIndex: "PREPASS_WORLD_NORMAL_INDEX"
	},
	{
		type: 9,
		name: "LocalPosition",
		clearType: 0,
		define: "PREPASS_LOCAL_POSITION",
		defineIndex: "PREPASS_LOCAL_POSITION_INDEX"
	},
	{
		type: 10,
		name: "ScreenDepth",
		clearType: 1,
		define: "PREPASS_SCREENSPACE_DEPTH",
		defineIndex: "PREPASS_SCREENSPACE_DEPTH_INDEX"
	},
	{
		type: 11,
		name: "LinearVelocity",
		clearType: 0,
		define: "PREPASS_VELOCITY_LINEAR",
		defineIndex: "PREPASS_VELOCITY_LINEAR_INDEX"
	},
	{
		type: 12,
		name: "Albedo",
		clearType: 0,
		define: "PREPASS_ALBEDO",
		defineIndex: "PREPASS_ALBEDO_INDEX"
	},
	{
		type: 13,
		name: "NormalizedViewDepth",
		clearType: 1,
		define: "PREPASS_NORMALIZED_VIEW_DEPTH",
		defineIndex: "PREPASS_NORMALIZED_VIEW_DEPTH_INDEX"
	},
	{
		type: 4,
		name: "Color",
		clearType: 3,
		define: "PREPASS_COLOR",
		defineIndex: "PREPASS_COLOR_INDEX"
	},
	{
		type: 14,
		name: "Irradiance",
		clearType: 0,
		define: "PREPASS_IRRADIANCE",
		defineIndex: "PREPASS_IRRADIANCE_INDEX"
	},
	{
		type: 15,
		name: "ObjectId",
		clearType: 0,
		define: "PREPASS_OBJECT_ID",
		defineIndex: "PREPASS_OBJECT_ID_INDEX"
	},
	{
		type: 16,
		name: "MeshBlendTag",
		clearType: 0,
		define: "PREPASS_MESH_BLEND_TAG",
		defineIndex: "PREPASS_MESH_BLEND_TAG_INDEX"
	}
], o._Configurations = {};
//#endregion
//#region node_modules/@babylonjs/core/Materials/prePassConfiguration.js
var s = class {
	constructor() {
		this.previousWorldMatrices = {}, this.previousBones = {};
	}
	static AddUniforms(e) {
		e.push("previousWorld", "previousViewProjection", "mPreviousBones");
	}
	static AddSamplers(e) {}
	bindForSubMesh(e, t, n, r, i) {
		if (t.prePassRenderer && t.prePassRenderer.enabled && t.prePassRenderer.currentRTisSceneRT && (t.prePassRenderer.getIndex(2) !== -1 || t.prePassRenderer.getIndex(11) !== -1)) {
			this.previousWorldMatrices[n.uniqueId] || (this.previousWorldMatrices[n.uniqueId] = r.clone()), this.previousViewProjection || (this.previousViewProjection = t.getTransformMatrix().clone(), this.currentViewProjection = t.getTransformMatrix().clone());
			let i = t.getEngine();
			this.currentViewProjection.updateFlag === t.getTransformMatrix().updateFlag ? this._lastUpdateFrameId !== i.frameId && (this._lastUpdateFrameId = i.frameId, this.previousViewProjection.copyFrom(this.currentViewProjection)) : (this._lastUpdateFrameId = i.frameId, this.previousViewProjection.copyFrom(this.currentViewProjection), this.currentViewProjection.copyFrom(t.getTransformMatrix())), e.setMatrix("previousWorld", this.previousWorldMatrices[n.uniqueId]), e.setMatrix("previousViewProjection", this.previousViewProjection), this.previousWorldMatrices[n.uniqueId] = r.clone();
		}
	}
}, c = class {
	constructor(e) {
		if (this.VERTEXOUTPUT_INVARIANT = !1, this._keys = [], this._isDirty = !0, this._areLightsDirty = !0, this._areLightsDisposed = !1, this._areAttributesDirty = !0, this._areTexturesDirty = !0, this._areFresnelDirty = !0, this._areMiscDirty = !0, this._arePrePassDirty = !0, this._areImageProcessingDirty = !0, this._normals = !1, this._uvs = !1, this._needNormals = !1, this._needUVs = !1, this._externalProperties = e, e) for (let t in e) Object.prototype.hasOwnProperty.call(e, t) && this._setDefaultValue(t);
	}
	get isDirty() {
		return this._isDirty;
	}
	markAsProcessed() {
		this._isDirty = !1, this._areAttributesDirty = !1, this._areTexturesDirty = !1, this._areFresnelDirty = !1, this._areLightsDirty = !1, this._areLightsDisposed = !1, this._areMiscDirty = !1, this._arePrePassDirty = !1, this._areImageProcessingDirty = !1;
	}
	markAsUnprocessed() {
		this._isDirty = !0;
	}
	markAllAsDirty() {
		this._areTexturesDirty = !0, this._areAttributesDirty = !0, this._areLightsDirty = !0, this._areFresnelDirty = !0, this._areMiscDirty = !0, this._arePrePassDirty = !0, this._areImageProcessingDirty = !0, this._isDirty = !0;
	}
	markAsImageProcessingDirty() {
		this._areImageProcessingDirty = !0, this._isDirty = !0;
	}
	markAsLightDirty(e = !1) {
		this._areLightsDirty = !0, this._areLightsDisposed = this._areLightsDisposed || e, this._isDirty = !0;
	}
	markAsAttributesDirty() {
		this._areAttributesDirty = !0, this._isDirty = !0;
	}
	markAsTexturesDirty() {
		this._areTexturesDirty = !0, this._isDirty = !0;
	}
	markAsFresnelDirty() {
		this._areFresnelDirty = !0, this._isDirty = !0;
	}
	markAsMiscDirty() {
		this._areMiscDirty = !0, this._isDirty = !0;
	}
	markAsPrePassDirty() {
		this._arePrePassDirty = !0, this._isDirty = !0;
	}
	rebuild() {
		this._keys.length = 0;
		for (let e of Object.keys(this)) e[0] !== "_" && this._keys.push(e);
		if (this._externalProperties) for (let e in this._externalProperties) this._keys.indexOf(e) === -1 && this._keys.push(e);
	}
	isEqual(e) {
		if (this._keys.length !== e._keys.length) return !1;
		for (let t = 0; t < this._keys.length; t++) {
			let n = this._keys[t];
			if (this[n] !== e[n]) return !1;
		}
		return !0;
	}
	cloneTo(e) {
		this._keys.length !== e._keys.length && (e._keys = this._keys.slice(0));
		for (let t = 0; t < this._keys.length; t++) {
			let n = this._keys[t];
			e[n] = this[n];
		}
	}
	reset() {
		for (let e of this._keys) this._setDefaultValue(e);
	}
	_setDefaultValue(e) {
		let t = this._externalProperties?.[e]?.type ?? typeof this[e], n = this._externalProperties?.[e]?.default;
		switch (t) {
			case "number":
				this[e] = n ?? 0;
				break;
			case "string":
				this[e] = n ?? "";
				break;
			default: this[e] = n ?? !1;
		}
	}
	toString() {
		let e = "";
		for (let t = 0; t < this._keys.length; t++) {
			let n = this._keys[t], r = this[n];
			switch (typeof r) {
				case "number":
				case "string":
					e += "#define " + n + " " + r + "\n";
					break;
				default: r && (e += "#define " + n + "\n");
			}
		}
		return e;
	}
};
//#endregion
//#region node_modules/@babylonjs/core/Materials/imageProcessingConfiguration.defines.js
function l(e) {
	return class extends e {
		constructor() {
			super(...arguments), this.IMAGEPROCESSING = !1, this.WHITEBALANCE = !1, this.VIGNETTE = !1, this.VIGNETTEBLENDMODEMULTIPLY = !1, this.VIGNETTEBLENDMODEOPAQUE = !1, this.TONEMAPPING = 0, this.CONTRAST = !1, this.COLORCURVES = !1, this.COLORGRADING = !1, this.COLORGRADING3D = !1, this.SAMPLER3DGREENDEPTH = !1, this.SAMPLER3DBGRMAP = !1, this.DITHER = !1, this.IMAGEPROCESSINGPOSTPROCESS = !1, this.SKIPFINALCOLORCLAMP = !1, this.EXPOSURE = !1;
		}
	};
}
//#endregion
//#region node_modules/@babylonjs/core/Materials/pushMaterial.js
var u = class extends n {
	constructor(t, n, r = !0, i = !1) {
		super(t, n, void 0, i), this._normalMatrix = new e(), this._storeEffectOnSubMeshes = r;
	}
	getEffect() {
		return this._storeEffectOnSubMeshes ? this._activeEffect : super.getEffect();
	}
	isReady(e, t) {
		return e ? !this._storeEffectOnSubMeshes || !e.subMeshes || e.subMeshes.length === 0 || this.isReadyForSubMesh(e, e.subMeshes[0], t) : !1;
	}
	_isReadyForSubMesh(e) {
		let t = e.materialDefines;
		return !!(!this.checkReadyOnEveryCall && e.effect && t && t._renderId === this.getScene().getRenderId());
	}
	bindOnlyWorldMatrix(e) {
		this._activeEffect.setMatrix("world", e);
	}
	bindOnlyNormalMatrix(e) {
		this._activeEffect.setMatrix("normalMatrix", e);
	}
	bind(e, t) {
		t && this.bindForSubMesh(e, t, t.subMeshes[0]);
	}
	_afterBind(e, t = null, n) {
		super._afterBind(e, t, n), this.getScene()._cachedEffect = t, n ? n._drawWrapper._forceRebindOnNextCall = !1 : this._drawWrapper._forceRebindOnNextCall = !1;
	}
	_mustRebind(e, t, n, r = 1) {
		return n._drawWrapper._forceRebindOnNextCall || e.isCachedMaterialInvalid(this, t, r);
	}
	dispose(e, t, n) {
		this._activeEffect = void 0, super.dispose(e, t, n);
	}
}, d = class {
	constructor() {
		this._defines = {}, this._currentRank = 32, this._maxRank = -1, this._mesh = null;
	}
	unBindMesh() {
		this._mesh = null;
	}
	addFallback(e, t) {
		this._defines[e] || (e < this._currentRank && (this._currentRank = e), e > this._maxRank && (this._maxRank = e), this._defines[e] = []), this._defines[e].push(t);
	}
	addCPUSkinningFallback(e, t) {
		this._mesh = t, e < this._currentRank && (this._currentRank = e), e > this._maxRank && (this._maxRank = e);
	}
	get hasMoreFallbacks() {
		return this._currentRank <= this._maxRank;
	}
	reduce(e, t) {
		if (this._mesh && this._mesh.computeBonesUsingShaders && this._mesh.numBoneInfluencers > 0) {
			this._mesh.computeBonesUsingShaders = !1, e = e.replace("#define NUM_BONE_INFLUENCERS " + this._mesh.numBoneInfluencers, "#define NUM_BONE_INFLUENCERS 0"), t._bonesComputationForcedToCPU = !0;
			let n = this._mesh.getScene();
			for (let e = 0; e < n.meshes.length; e++) {
				let r = n.meshes[e];
				if (!r.material) !this._mesh.material && r.computeBonesUsingShaders && r.numBoneInfluencers > 0 && (r.computeBonesUsingShaders = !1);
				else if (r.computeBonesUsingShaders && r.numBoneInfluencers !== 0) {
					if (r.material.getEffect() === t) r.computeBonesUsingShaders = !1;
					else if (r.subMeshes) {
						for (let e of r.subMeshes) if (e.effect === t) {
							r.computeBonesUsingShaders = !1;
							break;
						}
					}
				}
			}
		} else {
			let t = this._defines[this._currentRank];
			if (t) for (let n = 0; n < t.length; n++) e = e.replace("#define " + t[n], "");
			this._currentRank++;
		}
		return e;
	}
}, f = /* @__PURE__ */ new WeakMap();
function p(e) {
	let t = e.getVertexBuffers();
	if (!t) return null;
	let n = f.get(e);
	if (!n) n = /* @__PURE__ */ new Map(), f.set(e, n);
	else {
		let e = !1;
		for (let r in t) if (!n.has(r)) {
			e = !0;
			break;
		}
		if (!e) return n;
	}
	for (let e in t) {
		let r = t[e];
		if (r) {
			let t = r.byteOffset, i = r.byteStride, a = r.type, o = r.normalized;
			n.set(e, {
				offset: t,
				stride: i,
				type: a,
				normalized: o
			});
		}
	}
	return n;
}
function m(e, t) {
	t.forEach((t, n) => {
		let r = `vp_${n}_info`;
		e.setFloat4(r, t.offset, t.stride, t.type, +!!t.normalized);
	});
}
//#endregion
//#region node_modules/@babylonjs/core/Misc/shaderImportLoader.js
var h = class {
	constructor(e, t) {
		this._webGL = {
			load: e,
			loaded: !1,
			loadPromise: null
		}, this._webGPU = {
			load: t,
			loaded: !1,
			loadPromise: null
		};
	}
	getLoadCallback(e) {
		let t = e === 1 ? this._webGPU : this._webGL;
		return t.loaded ? void 0 : async () => {
			await this._loadAsync(t);
		};
	}
	async _loadAsync(e) {
		if (e.loaded) return;
		let t = e.loadPromise, n = t === null;
		n && (t = Promise.all(e.load()), e.loadPromise = t);
		let r = !1;
		try {
			await t, r = !0;
		} finally {
			n && this._completeLoad(e, r);
		}
	}
	_completeLoad(e, t) {
		e.loaded = t, e.loadPromise = null;
	}
};
//#endregion
//#region node_modules/@babylonjs/core/Materials/uv.defines.js
function g(e) {
	return class extends e {
		constructor() {
			super(...arguments), this.MAINUV1 = !1, this.MAINUV2 = !1, this.MAINUV3 = !1, this.MAINUV4 = !1, this.MAINUV5 = !1, this.MAINUV6 = !1, this.UV1 = !1, this.UV2 = !1, this.UV3 = !1, this.UV4 = !1, this.UV5 = !1, this.UV6 = !1;
		}
	};
}
//#endregion
//#region node_modules/@babylonjs/core/Materials/prepass.defines.js
function _(e) {
	return class extends e {
		constructor() {
			super(...arguments), this.PREPASS = !1, this.PREPASS_COLOR = !1, this.PREPASS_COLOR_INDEX = -1, this.PREPASS_IRRADIANCE_LEGACY = !1, this.PREPASS_IRRADIANCE_LEGACY_INDEX = -1, this.PREPASS_IRRADIANCE = !1, this.PREPASS_IRRADIANCE_INDEX = -1, this.PREPASS_ALBEDO = !1, this.PREPASS_ALBEDO_INDEX = -1, this.PREPASS_ALBEDO_SQRT = !1, this.PREPASS_ALBEDO_SQRT_INDEX = -1, this.PREPASS_DEPTH = !1, this.PREPASS_DEPTH_INDEX = -1, this.PREPASS_SCREENSPACE_DEPTH = !1, this.PREPASS_SCREENSPACE_DEPTH_INDEX = -1, this.PREPASS_NORMALIZED_VIEW_DEPTH = !1, this.PREPASS_NORMALIZED_VIEW_DEPTH_INDEX = -1, this.PREPASS_NORMAL = !1, this.PREPASS_NORMAL_INDEX = -1, this.PREPASS_NORMAL_WORLDSPACE = !1, this.PREPASS_WORLD_NORMAL = !1, this.PREPASS_WORLD_NORMAL_INDEX = -1, this.PREPASS_POSITION = !1, this.PREPASS_POSITION_INDEX = -1, this.PREPASS_LOCAL_POSITION = !1, this.PREPASS_LOCAL_POSITION_INDEX = -1, this.PREPASS_VELOCITY = !1, this.PREPASS_VELOCITY_INDEX = -1, this.PREPASS_VELOCITY_LINEAR = !1, this.PREPASS_VELOCITY_LINEAR_INDEX = -1, this.PREPASS_REFLECTIVITY = !1, this.PREPASS_REFLECTIVITY_INDEX = -1, this.PREPASS_OBJECT_ID = !1, this.PREPASS_OBJECT_ID_INDEX = -1, this.PREPASS_OBJECT_ID_R8 = !1, this.PREPASS_MESH_BLEND_TAG = !1, this.PREPASS_MESH_BLEND_TAG_INDEX = -1, this.SCENE_MRT_COUNT = 0;
		}
	};
}
//#endregion
//#region node_modules/@babylonjs/core/Materials/imageProcessing.js
function v(e) {
	return class extends e {
		constructor(...e) {
			super(...e);
			let n = new.target;
			if (!n[Symbol.metadata]) {
				let e = Object.getPrototypeOf(n)?.[Symbol.metadata];
				n[Symbol.metadata] = e ? Object.create(e) : {};
			}
			let r = t(n[Symbol.metadata]);
			r._imageProcessingConfiguration ||= {
				type: 9,
				sourceName: void 0
			};
		}
		get imageProcessingConfiguration() {
			return this._imageProcessingConfiguration;
		}
		set imageProcessingConfiguration(e) {
			this._attachImageProcessingConfiguration(e), this._markAllSubMeshesAsImageProcessingDirty && this._markAllSubMeshesAsImageProcessingDirty();
		}
		_attachImageProcessingConfiguration(e) {
			e !== this._imageProcessingConfiguration && (this._imageProcessingConfiguration && this._imageProcessingObserver && this._imageProcessingConfiguration.onUpdateParameters.remove(this._imageProcessingObserver), !e && this.getScene ? this._imageProcessingConfiguration = this.getScene().imageProcessingConfiguration : e && (this._imageProcessingConfiguration = e), this._imageProcessingConfiguration && (this._imageProcessingObserver = this._imageProcessingConfiguration.onUpdateParameters.add(() => {
				this._markAllSubMeshesAsImageProcessingDirty && this._markAllSubMeshesAsImageProcessingDirty();
			})));
		}
		get cameraColorCurvesEnabled() {
			return this.imageProcessingConfiguration.colorCurvesEnabled;
		}
		set cameraColorCurvesEnabled(e) {
			this.imageProcessingConfiguration.colorCurvesEnabled = e;
		}
		get cameraColorGradingEnabled() {
			return this.imageProcessingConfiguration.colorGradingEnabled;
		}
		set cameraColorGradingEnabled(e) {
			this.imageProcessingConfiguration.colorGradingEnabled = e;
		}
		get cameraToneMappingEnabled() {
			return this._imageProcessingConfiguration.toneMappingEnabled;
		}
		set cameraToneMappingEnabled(e) {
			this._imageProcessingConfiguration.toneMappingEnabled = e;
		}
		get cameraExposure() {
			return this._imageProcessingConfiguration.exposure;
		}
		set cameraExposure(e) {
			this._imageProcessingConfiguration.exposure = e;
		}
		get cameraContrast() {
			return this._imageProcessingConfiguration.contrast;
		}
		set cameraContrast(e) {
			this._imageProcessingConfiguration.contrast = e;
		}
		get cameraColorGradingTexture() {
			return this._imageProcessingConfiguration.colorGradingTexture;
		}
		set cameraColorGradingTexture(e) {
			this._imageProcessingConfiguration.colorGradingTexture = e;
		}
		get cameraColorCurves() {
			return this._imageProcessingConfiguration.colorCurves;
		}
		set cameraColorCurves(e) {
			this._imageProcessingConfiguration.colorCurves = e;
		}
	};
}
//#endregion
export { m as a, u as c, s as d, o as f, h as i, l, r as m, _ as n, p as o, i as p, g as r, d as s, v as t, c as u };
