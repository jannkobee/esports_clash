//#region node_modules/@babylonjs/core/tslib.es6.js
function e(e, t, n, r, i, a) {
	function o(e) {
		if (e !== void 0 && typeof e != "function") throw TypeError("Function expected");
		return e;
	}
	for (var s = r.kind, c = s === "getter" ? "get" : s === "setter" ? "set" : "value", l = !t && e ? r.static ? e : e.prototype : null, u = t || (l ? Object.getOwnPropertyDescriptor(l, r.name) : {}), d, f = !1, p = n.length - 1; p >= 0; p--) {
		var m = {};
		for (var h in r) m[h] = h === "access" ? {} : r[h];
		for (var h in r.access) m.access[h] = r.access[h];
		m.addInitializer = function(e) {
			if (f) throw TypeError("Cannot add initializers after decoration has completed");
			a.push(o(e || null));
		};
		var g = (0, n[p])(s === "accessor" ? {
			get: u.get,
			set: u.set
		} : u[c], m);
		if (s === "accessor") {
			if (g === void 0) continue;
			if (typeof g != "object" || !g) throw TypeError("Object expected");
			(d = o(g.get)) && (u.get = d), (d = o(g.set)) && (u.set = d), (d = o(g.init)) && i.unshift(d);
		} else (d = o(g)) && (s === "field" ? i.unshift(d) : u[c] = d);
	}
	l && Object.defineProperty(l, r.name, u), f = !0;
}
function t(e, t, n) {
	for (var r = arguments.length > 2, i = 0; i < t.length; i++) n = r ? t[i].call(e, n) : t[i].call(e);
	return r ? n : void 0;
}
function n(e, t, n, r) {
	if (n === "a" && !r) throw TypeError("Private accessor was defined without a getter");
	if (typeof t == "function" ? e !== t || !r : !t.has(e)) throw TypeError("Cannot read private member from an object whose class did not declare it");
	return n === "m" ? r : n === "a" ? r.call(e) : r ? r.value : t.get(e);
}
function r(e, t, n, r, i) {
	if (r === "m") throw TypeError("Private method is not writable");
	if (r === "a" && !i) throw TypeError("Private accessor was defined without a setter");
	if (typeof t == "function" ? e !== t || !i : !t.has(e)) throw TypeError("Cannot write private member to an object whose class did not declare it");
	return r === "a" ? i.call(e, n) : i ? i.value = n : t.set(e, n), n;
}
//#endregion
//#region node_modules/@babylonjs/core/Misc/decorators.functions.js
var i = "__bjs_serializable__", a = /* @__PURE__ */ new WeakMap();
function o(e, t) {
	return Object.prototype.hasOwnProperty.call(e, t);
}
function s() {
	let e = Symbol.metadata;
	return e || (e = Symbol("Symbol.metadata"), Object.defineProperty(Symbol, "metadata", {
		configurable: !0,
		writable: !0,
		value: e
	})), e;
}
var c = s();
function l(e) {
	return typeof e == "function" ? e : e?.constructor;
}
function u(e) {
	if (!e) throw Error(`Decorator metadata is unavailable; the Symbol.metadata (${String(c)}) polyfill must run before decorated classes are evaluated.`);
	return o(e, i) || (e[i] = {}), e[i];
}
function d(e) {
	let t = l(e), n = t ? t[c] : void 0;
	if (!n) return {};
	let r = a.get(n);
	if (r) return r;
	let s = {}, u = [], d = n;
	for (; d;) u.push(d), d = Object.getPrototypeOf(d);
	for (let e of u) if (o(e, i)) {
		let t = e[i];
		for (let e in t) s[e] = t[e];
	}
	return a.set(n, s), s;
}
//#endregion
//#region node_modules/@babylonjs/core/Misc/decorators.js
function f(e, t) {
	return (n, r) => {
		if (!r.metadata) return;
		let i = String(r.name), a = u(r.metadata);
		a[i] || (a[i] = {
			type: e,
			sourceName: t
		});
	};
}
function p(e, t = null) {
	return (n, r) => {
		let i = t || "_" + String(r.name);
		return {
			init(e) {
				return (e !== void 0 || !(i in this)) && (this[i] = e), e;
			},
			get() {
				return this[i];
			},
			set(t) {
				typeof this[i]?.equals == "function" && this[i].equals(t) || this[i] !== t && (this[i] = t, this[e]());
			}
		};
	};
}
function m(e, t = null) {
	return p(e, t);
}
function h(e) {
	return f(0, e);
}
function g(e) {
	return f(1, e);
}
function _(e) {
	return f(2, e);
}
function v(e) {
	return f(3, e);
}
function y(e) {
	return f(4, e);
}
function b(e) {
	return f(5, e);
}
function x(e) {
	return f(6, e);
}
function S(e) {
	return f(7, e);
}
function C(e) {
	return f(8, e);
}
function w(e) {
	return f(10, e);
}
function T(e) {
	return f(12, e);
}
function E(e, t, n) {
	let r = String(t.name), i = null, a = function(...o) {
		if (i === null) {
			i = e, typeof _native < "u" && _native[r] && (i = n(_native[r], e));
			let o = this && (t.static ? this : Object.getPrototypeOf(this));
			o?.[r] === a && (o[r] = i);
		}
		return i.apply(this, o);
	};
	return a;
}
function D(e, t) {
	return E(e, t, (e) => e);
}
D.filter = function(e) {
	return (t, n) => E(t, n, (t, n) => function(...r) {
		return e(...r) ? t(...r) : n.apply(this, r);
	});
};
function O(e, t = null) {
	return (n, r) => {
		let i = t || "_" + String(r.name);
		return {
			get() {
				return this[i]?.value;
			},
			set(t) {
				typeof this[i]?.value?.equals == "function" && this[i].value.equals(t) || this[i].value !== t && (this[i].value = t, this[e]());
			}
		};
	};
}
//#endregion
export { n as _, _ as a, t as b, v as c, w as d, g as f, d as g, u as h, h as i, T as l, b as m, m as n, C as o, y as p, D as r, S as s, O as t, x as u, r as v, e as y };
