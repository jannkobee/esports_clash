import { i as e } from "./domManagement-BZa7OPDn.js";
//#region node_modules/@babylonjs/core/Misc/devTools.js
var t = {};
function n(e, n = !1) {
	if (!(n && t[e])) return t[e] = !0, `${e} needs to be imported before as it contains a side-effect required by your code.`;
}
var r = {}, i = 0;
function a(e, t, n = !1) {
	let a = function() {
		if (n && i === 0) {
			let n = `${e}.${t}`;
			r[n] || (r[n] = !0, console.warn(`[Babylon.js] ${n}() requires a side-effect import. See: https://doc.babylonjs.com/setup/treeshaking`));
		}
	};
	return a.__isSideEffectStub = !0, a;
}
function o(e) {
	return e ? !e.__isSideEffectStub : !1;
}
function s(e, t) {
	return {
		get() {},
		set(e) {
			Object.defineProperty(this, t, {
				value: e,
				writable: !0,
				configurable: !0,
				enumerable: !0
			});
		},
		configurable: !0,
		enumerable: !0
	};
}
//#endregion
//#region node_modules/@babylonjs/core/Engines/abstractEngine.functions.js
var c = {};
function l(e, t, n = "") {
	return n + (t ? t + "\n" : "") + e;
}
function u(e, t, r, i, a, o, s) {
	let l = s || c.loadFile;
	if (!l) throw n("FileTools");
	return l(e, t, r, i, a, o);
}
function d(e, t, n, r) {
	if (e) t ? e.IS_NDC_HALF_ZRANGE = "" : delete e.IS_NDC_HALF_ZRANGE, n ? e.USE_REVERSE_DEPTHBUFFER = "" : delete e.USE_REVERSE_DEPTHBUFFER, r ? e.USE_EXACT_SRGB_CONVERSIONS = "" : delete e.USE_EXACT_SRGB_CONVERSIONS;
	else {
		let e = "";
		return t && (e += "#define IS_NDC_HALF_ZRANGE"), n && (e && (e += "\n"), e += "#define USE_REVERSE_DEPTHBUFFER"), r && (e && (e += "\n"), e += "#define USE_EXACT_SRGB_CONVERSIONS"), e;
	}
}
function f(e, t, n = !1, r) {
	switch (e) {
		case 3: {
			let e = new Int8Array(t);
			return r && e.set(new Int8Array(r)), e;
		}
		case 0: {
			let e = new Uint8Array(t);
			return r && e.set(new Uint8Array(r)), e;
		}
		case 4: {
			let e = typeof t == "number" ? new Int16Array(n ? t / 2 : t) : new Int16Array(t);
			return r && e.set(new Int16Array(r)), e;
		}
		case 5:
		case 8:
		case 9:
		case 10:
		case 2: {
			let e = typeof t == "number" ? new Uint16Array(n ? t / 2 : t) : new Uint16Array(t);
			return r && e.set(new Uint16Array(r)), e;
		}
		case 6: {
			let e = typeof t == "number" ? new Int32Array(n ? t / 4 : t) : new Int32Array(t);
			return r && e.set(new Int32Array(r)), e;
		}
		case 7:
		case 11:
		case 12:
		case 13:
		case 14:
		case 15: {
			let e = typeof t == "number" ? new Uint32Array(n ? t / 4 : t) : new Uint32Array(t);
			return r && e.set(new Uint32Array(r)), e;
		}
		case 1: {
			let e = typeof t == "number" ? new Float32Array(n ? t / 4 : t) : new Float32Array(t);
			return r && e.set(new Float32Array(r)), e;
		}
	}
	let i = new Uint8Array(t);
	return r && i.set(new Uint8Array(r)), i;
}
//#endregion
//#region node_modules/@babylonjs/core/Engines/Processors/shaderCodeNode.js
var p = "attribute", m = "varying", h = class {
	constructor() {
		this.children = [];
	}
	isValid(e) {
		return !0;
	}
	process(e, t, n) {
		let r = "";
		if (this.line) {
			let n = this.line, i = t.processor;
			if (i) {
				i.lineProcessor && (n = i.lineProcessor(n, t.isFragment, t.processingContext));
				let r = t.processor?.attributeKeywordName ?? p, a = t.isFragment && t.processor?.varyingFragmentKeywordName ? t.processor?.varyingFragmentKeywordName : !t.isFragment && t.processor?.varyingVertexKeywordName ? t.processor?.varyingVertexKeywordName : m;
				!t.isFragment && i.attributeProcessor && this.line.startsWith(r) ? n = i.attributeProcessor(this.line, e, t.processingContext) : i.varyingProcessor && (i.varyingCheck?.(this.line, t.isFragment) || !i.varyingCheck && this.line.startsWith(a)) ? n = i.varyingProcessor(this.line, t.isFragment, e, t.processingContext) : i.uniformProcessor && i.uniformRegexp && i.uniformRegexp.test(this.line) ? t.lookForClosingBracketForUniformBuffer || (n = i.uniformProcessor(this.line, t.isFragment, e, t.processingContext)) : i.uniformBufferProcessor && i.uniformBufferRegexp && i.uniformBufferRegexp.test(this.line) ? t.lookForClosingBracketForUniformBuffer ||= (n = i.uniformBufferProcessor(this.line, t.isFragment, t.processingContext), !0) : i.textureProcessor && i.textureRegexp && i.textureRegexp.test(this.line) ? n = i.textureProcessor(this.line, t.isFragment, e, t.processingContext) : (i.uniformProcessor || i.uniformBufferProcessor) && this.line.startsWith("uniform") && !t.lookForClosingBracketForUniformBuffer && (/uniform\s+(?:(?:highp)?|(?:lowp)?)\s*(\S+)\s+(\S+)\s*;/.test(this.line) ? i.uniformProcessor && (n = i.uniformProcessor(this.line, t.isFragment, e, t.processingContext)) : i.uniformBufferProcessor && (n = i.uniformBufferProcessor(this.line, t.isFragment, t.processingContext), t.lookForClosingBracketForUniformBuffer = !0)), t.lookForClosingBracketForUniformBuffer && this.line.indexOf("}") !== -1 && (t.lookForClosingBracketForUniformBuffer = !1, i.endOfUniformBufferProcessor && (n = i.endOfUniformBufferProcessor(this.line, t.isFragment, t.processingContext)));
			}
			r += n + "\n";
		}
		for (let i of this.children) r += i.process(e, t, n);
		return this.additionalDefineKey && (e[this.additionalDefineKey] = this.additionalDefineValue || "true", n[this.additionalDefineKey] = e[this.additionalDefineKey]), r;
	}
}, ee = class e {
	constructor() {
		this._lines = [];
	}
	get currentLine() {
		return this._lines[this.lineIndex];
	}
	get canRead() {
		return this.lineIndex < this._lines.length - 1;
	}
	set lines(t) {
		this._lines.length = 0;
		let n = !1;
		for (let r of t) {
			if (!r || r === "\r") continue;
			let t = n, i = {
				parenthesisDepth: 0,
				inBlockComment: t,
				inLineComment: !1
			};
			if (e._ScanCode(i, r), n = i.inBlockComment, r[0] === "#") {
				this._lines.push(r);
				continue;
			}
			let a = r.trim();
			if (!a) continue;
			if (a.startsWith("//")) {
				this._lines.push(r);
				continue;
			}
			let o = a.indexOf(";");
			if (o === -1) this._lines.push(a);
			else if (o === a.length - 1) a.length > 1 && this._lines.push(a);
			else {
				let n = r.split(";"), i = {
					parenthesisDepth: 0,
					inBlockComment: t,
					inLineComment: !1
				};
				for (let t = 0; t < n.length; t++) {
					let r = n[t];
					e._ScanCode(i, r), r = r.trim(), r ? this._lines.push(r + (t === n.length - 1 ? "" : ";")) : i.parenthesisDepth > 0 && !i.inLineComment && t !== n.length - 1 && (this._lines[this._lines.length - 1] += ";");
				}
			}
		}
	}
	static _ScanCode(e, t) {
		for (let n = 0; n < t.length && !e.inLineComment; n++) {
			let r = t[n];
			e.inBlockComment ? r === "*" && t[n + 1] === "/" && (e.inBlockComment = !1, n++) : r === "/" && t[n + 1] === "*" ? (e.inBlockComment = !0, n++) : r === "/" && t[n + 1] === "/" ? e.inLineComment = !0 : r === "(" ? e.parenthesisDepth++ : r === ")" && (e.parenthesisDepth = Math.max(0, e.parenthesisDepth - 1));
		}
	}
}, g = class extends h {
	process(e, t, n) {
		for (let r = 0; r < this.children.length; r++) {
			let i = this.children[r];
			if (i.isValid(e)) return i.process(e, t, n);
		}
		return "";
	}
}, _ = class extends h {
	isValid(e) {
		return this.testExpression.isTrue(e);
	}
}, v = class e {
	isTrue(e) {
		return !0;
	}
	static postfixToInfix(t) {
		let n = [];
		for (let r of t) if (e._OperatorPriority[r] === void 0) n.push(r);
		else {
			let e = n[n.length - 1], t = n[n.length - 2];
			n.length -= 2, n.push(`(${t}${r}${e})`);
		}
		return n[n.length - 1];
	}
	static infixToPostfix(t) {
		let n = e._InfixToPostfixCache.get(t);
		if (n) return n.accessTime = Date.now(), n.result;
		if (!t.includes("&&") && !t.includes("||") && !t.includes(")") && !t.includes("(")) return [t];
		let r = [], i = -1, a = () => {
			u = u.trim(), u !== "" && (r.push(u), u = "");
		}, o = (t) => {
			i < e._Stack.length - 1 && (e._Stack[++i] = t);
		}, s = () => e._Stack[i], c = () => i === -1 ? "!!INVALID EXPRESSION!!" : e._Stack[i--], l = 0, u = "";
		for (; l < t.length;) {
			let n = t.charAt(l), d = l < t.length - 1 ? t.substring(l, 2 + l) : "";
			if (n === "(") u = "", o(n);
			else if (n === ")") {
				for (a(); i !== -1 && s() !== "(";) r.push(c());
				c();
			} else if (e._OperatorPriority[d] > 1) {
				for (a(); i !== -1 && e._OperatorPriority[s()] >= e._OperatorPriority[d];) r.push(c());
				o(d), l++;
			} else u += n;
			l++;
		}
		for (a(); i !== -1;) s() === "(" ? c() : r.push(c());
		return e._InfixToPostfixCache.size >= e.InfixToPostfixCacheLimitSize && e.ClearCache(), e._InfixToPostfixCache.set(t, {
			result: r,
			accessTime: Date.now()
		}), r;
	}
	static ClearCache() {
		let t = Array.from(e._InfixToPostfixCache.entries()).sort((e, t) => e[1].accessTime - t[1].accessTime);
		for (let n = 0; n < e.InfixToPostfixCacheCleanupSize; n++) e._InfixToPostfixCache.delete(t[n][0]);
	}
};
v.InfixToPostfixCacheLimitSize = 5e4, v.InfixToPostfixCacheCleanupSize = 25e3, v._InfixToPostfixCache = /* @__PURE__ */ new Map(), v._OperatorPriority = {
	")": 0,
	"(": 1,
	"||": 2,
	"&&": 3
}, v._Stack = [
	"",
	"",
	"",
	"",
	"",
	"",
	"",
	"",
	"",
	"",
	"",
	"",
	"",
	"",
	"",
	"",
	"",
	"",
	"",
	""
];
//#endregion
//#region node_modules/@babylonjs/core/Engines/Processors/Expressions/Operators/shaderDefineIsDefinedOperator.js
var y = class extends v {
	constructor(e, t = !1) {
		super(), this.define = e, this.not = t;
	}
	isTrue(e) {
		let t = e[this.define] !== void 0;
		return this.not && (t = !t), t;
	}
}, b = class extends v {
	isTrue(e) {
		return this.leftOperand.isTrue(e) || this.rightOperand.isTrue(e);
	}
}, x = class extends v {
	isTrue(e) {
		return this.leftOperand.isTrue(e) && this.rightOperand.isTrue(e);
	}
}, S = class extends v {
	constructor(e, t, n) {
		super(), this.define = e, this.operand = t, this.testValue = n;
	}
	toString() {
		return `${this.define} ${this.operand} ${this.testValue}`;
	}
	isTrue(e) {
		let t = !1, n = parseInt(e[this.define] == null ? this.define : e[this.define]), r = parseInt(e[this.testValue] == null ? this.testValue : e[this.testValue]);
		if (isNaN(n) || isNaN(r)) return !1;
		switch (this.operand) {
			case ">":
				t = n > r;
				break;
			case "<":
				t = n < r;
				break;
			case "<=":
				t = n <= r;
				break;
			case ">=":
				t = n >= r;
				break;
			case "==":
				t = n === r;
				break;
			case "!=": t = n !== r;
		}
		return t;
	}
}, C = /defined\s*?\((.+?)\)/g, w = /defined\s*?\[(.+?)\]/g, T = /#include\s?<(.+)>(\((.*)\))*(\[(.*)\])*/g, E = /__decl__/, D = /light\{X\}.(\w*)/g, O = /\{X\}/g, k = [], A = /(#ifdef)|(#else)|(#elif)|(#endif)|(#ifndef)|(#if)/;
function j(e) {
	e.processor && e.processor.initializeShaders && e.processor.initializeShaders(e.processingContext);
}
function M(e, t, n, r) {
	t.processor?.preProcessShaderCode && (e = t.processor.preProcessShaderCode(e, t.isFragment)), U(e, t, (e) => {
		t.processCodeAfterIncludes && (e = t.processCodeAfterIncludes(t.isFragment ? "fragment" : "vertex", e, t.defines)), n(H(e, t, r), e);
	});
}
function N(e, t, n) {
	return !n.processor || !n.processor.finalizeShaders ? {
		vertexCode: e,
		fragmentCode: t
	} : n.processor.finalizeShaders(e, t, n.processingContext);
}
function P(e, t) {
	if (t.processor?.noPrecision) return e;
	let n = t.shouldUseHighPrecisionShader;
	return e.indexOf("precision highp float") === -1 ? e = n ? "precision highp float;\n" + e : "precision mediump float;\n" + e : n || (e = e.replace("precision highp float", "precision mediump float")), e;
}
function F(e) {
	let t = /defined\((.+)\)/.exec(e);
	if (t && t.length) return new y(t[1].trim(), e[0] === "!");
	let n = [
		"==",
		"!=",
		">=",
		"<=",
		"<",
		">"
	], r = "", i = 0;
	for (r of n) if (i = e.indexOf(r), i > -1) break;
	if (i === -1) return new y(e);
	let a = e.substring(0, i).trim(), o = e.substring(i + r.length).trim();
	return new S(a, r, o);
}
function I(e) {
	e = e.replace(C, "defined[$1]");
	let t = v.infixToPostfix(e), n = [];
	for (let e of t) if (e !== "||" && e !== "&&") n.push(e);
	else if (n.length >= 2) {
		let t = n[n.length - 1], r = n[n.length - 2];
		n.length -= 2;
		let i = e == "&&" ? new x() : new b();
		typeof t == "string" && (t = t.replace(w, "defined($1)")), typeof r == "string" && (r = r.replace(w, "defined($1)")), i.leftOperand = typeof r == "string" ? F(r) : r, i.rightOperand = typeof t == "string" ? F(t) : t, n.push(i);
	}
	let r = n[n.length - 1];
	return typeof r == "string" && (r = r.replace(w, "defined($1)")), typeof r == "string" ? F(r) : r;
}
function L(e, t) {
	let n = new _(), r = e.substring(0, t), i = e.substring(t);
	return i = i.substring(0, (i.indexOf("//") + 1 || i.length + 1) - 1).trim(), n.testExpression = r === "#ifdef" ? new y(i) : r === "#ifndef" ? new y(i, !0) : I(i), n;
}
function R(e, t, n, r) {
	let i;
	for (; z(e, n, r);) {
		i = e.currentLine;
		let a = i.substring(0, 5).toLowerCase();
		if (a === "#else") {
			let n = new h();
			t.children.push(n), z(e, n, r);
			return;
		}
		if (a === "#elif") {
			let e = L(i, 5);
			t.children.push(e), n = e;
		}
	}
}
function z(e, t, n) {
	for (; e.canRead;) {
		e.lineIndex++;
		let r = e.currentLine;
		if (r.indexOf("#") >= 0) {
			let i = A.exec(r);
			if (i && i.length) {
				switch (i[0]) {
					case "#ifdef": {
						let i = new g();
						t.children.push(i);
						let a = L(r, 6);
						i.children.push(a), R(e, i, a, n);
						break;
					}
					case "#else":
					case "#elif": return !0;
					case "#endif": return !1;
					case "#ifndef": {
						let i = new g();
						t.children.push(i);
						let a = L(r, 7);
						i.children.push(a), R(e, i, a, n);
						break;
					}
					case "#if": {
						let i = new g(), a = L(r, 3);
						t.children.push(i), i.children.push(a), R(e, i, a, n);
						break;
					}
				}
				continue;
			}
		}
		let i = new h();
		if (i.line = r, t.children.push(i), r[0] === "#" && r[1] === "d") {
			let e = r.replace(";", "").split(" ");
			i.additionalDefineKey = e[1], e.length === 3 && (i.additionalDefineValue = e[2]);
		}
	}
	return !1;
}
function B(e, t, n, r) {
	let i = new h(), a = new ee();
	return a.lineIndex = -1, a.lines = e.split("\n"), z(a, i, r), i.process(t, n, r);
}
function V(e, t) {
	let n = e.defines, r = {};
	for (let e of n) {
		let t = e.replace("#define", "").replace(";", "").trim().split(" ");
		r[t[0]] = t.length > 1 ? t[1] : "";
	}
	return e.processor?.shaderLanguage === 0 && (r.GL_ES = "true"), r.__VERSION__ = e.version, r[e.platformName] = "true", d(r, t?.isNDCHalfZRange, t?.useReverseDepthBuffer, t?.useExactSrgbConversions), r;
}
function H(e, t, n) {
	let r = P(e, t);
	if (!t.processor || t.processor.shaderLanguage === 0 && r.indexOf("#version 3") !== -1 && (r = r.replace("#version 300 es", ""), !t.processor.parseGLES3)) return r;
	let i = t.defines, a = V(t, n);
	t.processor.preProcessor && (r = t.processor.preProcessor(r, i, a, t.isFragment, t.processingContext));
	let o = {};
	return r = B(r, a, t, o), t.processor.postProcessor && (r = t.processor.postProcessor(r, i, t.isFragment, t.processingContext, n ? { drawBuffersExtensionDisabled: !n.getCaps().drawBuffersExtension } : {}, a, o)), n?._features.needShaderCodeInlining && (r = n.inlineShaderCode(r)), r;
}
function U(e, t, n) {
	k.length = 0;
	let r;
	for (; (r = T.exec(e)) !== null;) k.push(r);
	let i = [e], a = !1;
	for (let e of k) {
		let r = e[1];
		if (r.indexOf("__decl__") !== -1 && (r = r.replace(E, ""), t.supportsUniformBuffers && (r = r.replace("Vertex", "Ubo").replace("Fragment", "Ubo")), r += "Declaration"), t.includesShadersStore[r]) {
			let n = t.includesShadersStore[r];
			if (e[2]) {
				let t = e[3].split(",");
				for (let e = 0; e < t.length; e += 2) {
					let r = new RegExp(t[e], "g"), i = t[e + 1];
					n = n.replace(r, i);
				}
			}
			if (e[4]) {
				let r = e[5];
				if (r.indexOf("..") !== -1) {
					let e = r.split(".."), i = parseInt(e[0]), a = parseInt(e[1]), o = n.slice(0);
					n = "", isNaN(a) && (a = t.indexParameters[e[1]]);
					for (let e = i; e < a; e++) t.supportsUniformBuffers || (o = o.replace(D, (e, t) => t + "{X}")), n += o.replace(O, e.toString()) + "\n";
				} else t.supportsUniformBuffers || (n = n.replace(D, (e, t) => t + "{X}")), n = n.replace(O, r);
			}
			let o = [];
			for (let t of i) {
				let r = t.split(e[0]);
				for (let e = 0; e < r.length - 1; e++) o.push(r[e]), o.push(n);
				o.push(r[r.length - 1]);
			}
			i = o, a = a || n.indexOf("#include<") >= 0 || n.indexOf("#include <") >= 0;
		} else {
			let e = t.shadersRepository + "ShadersInclude/" + r + ".fx";
			W.loadFile(e, (e) => {
				t.includesShadersStore[r] = e, U(i.join(""), t, n);
			});
			return;
		}
	}
	k.length = 0;
	let o = i.join("");
	a ? U(o.toString(), t, n) : n(o);
}
var W = { loadFile: (e, t, r, i, a, o) => {
	throw n("FileTools");
} }, G = [], K = class {
	static SetImmediate(e) {
		G.length === 0 && setTimeout(() => {
			let e = G;
			G = [];
			for (let t of e) t();
		}, 1), G.push(e);
	}
};
function q(e, t, n) {
	try {
		if (e()) return t(), !0;
	} catch (e) {
		return n?.(e), !0;
	}
	return !1;
}
var J = (e, t, n, r = 16, i = 3e4, a = !0, o) => {
	if (a && q(e, t, n)) return null;
	let s = setInterval(() => {
		q(e, t, n) ? clearInterval(s) : (i -= r, i < 0 && (clearInterval(s), n?.(/* @__PURE__ */ Error("Operation timed out after maximum retries. " + (o || "")), !0)));
	}, r);
	return () => clearInterval(s);
}, Y = class {
	static get Now() {
		return e() && window.performance && window.performance.now ? window.performance.now() : Date.now();
	}
};
//#endregion
//#region node_modules/@babylonjs/core/Misc/tools.functions.js
function X(e) {
	let t = 1;
	do
		t *= 2;
	while (t < e);
	return t === e;
}
function te(e, t, n) {
	return e * (1 - n) + t * n;
}
function Z(e) {
	let t = Q(e), n = $(e);
	return t - e > e - n ? n : t;
}
function Q(e) {
	return e--, e |= e >> 1, e |= e >> 2, e |= e >> 4, e |= e >> 8, e |= e >> 16, e++, e;
}
function $(e) {
	return e |= e >> 1, e |= e >> 2, e |= e >> 4, e |= e >> 8, e |= e >> 16, e - (e >> 1);
}
function ne(e, t, n = 2) {
	let r;
	switch (n) {
		case 1:
			r = $(e);
			break;
		case 2:
			r = Z(e);
			break;
		default: r = Q(e);
	}
	return Math.min(r, t);
}
//#endregion
export { n as S, u as _, Z as a, a as b, J as c, M as d, U as f, d as g, l as h, te as i, N as l, c as m, ne as n, Y as o, W as p, X as r, K as s, $ as t, j as u, f as v, s as x, o as y };
