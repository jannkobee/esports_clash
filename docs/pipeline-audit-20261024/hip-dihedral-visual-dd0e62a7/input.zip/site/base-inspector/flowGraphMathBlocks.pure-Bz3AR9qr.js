import { a as e, d as t, l as n, o as r, u as i } from "./math.color.pure-CPmbqLkh.js";
import { n as a } from "./typeStore-pENEWnX2.js";
import { t as o } from "./flowGraphInteger.pure-DqL1vt3x.js";
import { c as s, s as c, t as l } from "./flowGraphBlock-BTSj91tT.js";
import { c as u, i as d, n as f, r as p, s as m, t as h } from "./utils-Cc6lHVNn.js";
import { c as g, g as _, i as v, n as y, r as b } from "./flowGraphRichTypes.pure-BpKU4EZT.js";
import { t as ee } from "./flowGraphCachedOperationBlock-BsIcMusH.js";
import { t as x } from "./flowGraphBinaryOperationBlock-CDgwbjsR.js";
import { t as S } from "./flowGraphUnaryOperationBlock-CzhraRE5.js";
import { t as C } from "./flowGraphTernaryOperationBlock-BSG-deqh.js";
//#region node_modules/@babylonjs/core/FlowGraph/Blocks/Data/flowGraphConstantOperationBlock.js
var w = class extends ee {
	constructor(e, t, n, r) {
		super(e, r), this._operation = t, this._className = n;
	}
	_doOperation(e) {
		return this._operation(e);
	}
	getClassName() {
		return this._className;
	}
}, T = class extends x {
	constructor(e) {
		super(_(e?.type), _(e?.type), _(e?.type), (e, t) => this._polymorphicAdd(e, t), "FlowGraphAddBlock", e);
	}
	_polymorphicAdd(e, n) {
		let r = d(e), i = d(n);
		if (p(r, i) || f(r, i) || h(r, i)) return e.add(n);
		if (r === "Quaternion" || i === "Vector4") return new t(e.x, e.y, e.z, e.w).addInPlace(n);
		if (r === "Vector4" || i === "Quaternion") return e.add(n);
		if (this.config?.preventIntegerFloatArithmetic && typeof e != typeof n) throw Error("Cannot add different types of numbers.");
		return m(e) + m(n);
	}
}, E = class extends x {
	constructor(e) {
		super(_(e?.type), _(e?.type), _(e?.type), (e, t) => this._polymorphicSubtract(e, t), "FlowGraphSubtractBlock", e);
	}
	_polymorphicSubtract(e, n) {
		let r = d(e), i = d(n);
		if (p(r, i) || h(r, i) || f(r, i)) return e.subtract(n);
		if (r === "Quaternion" || i === "Vector4") return new t(e.x, e.y, e.z, e.w).subtractInPlace(n);
		if (r === "Vector4" || i === "Quaternion") return e.subtract(n);
		if (this.config?.preventIntegerFloatArithmetic && typeof e != typeof n) throw Error("Cannot add different types of numbers.");
		return m(e) - m(n);
	}
}, te = class extends x {
	constructor(e) {
		super(_(e?.type), _(e?.type), _(e?.type), (e, t) => this._polymorphicMultiply(e, t), "FlowGraphMultiplyBlock", e);
	}
	_polymorphicMultiply(n, r) {
		let i = d(n), a = d(r);
		if (p(i, a) || h(i, a)) return n.multiply(r);
		if (i === "Quaternion" || a === "Vector4") return new t(n.x, n.y, n.z, n.w).multiplyInPlace(r);
		if (i === "Vector4" || a === "Quaternion") return n.multiply(r);
		if (f(i, a)) {
			if (this.config?.useMatrixPerComponent) {
				let t = n.m;
				for (let e = 0; e < t.length; e++) t[e] *= r.m[e];
				return i === "Matrix2D" ? new c(t) : i === "Matrix3D" ? new s(t) : e.FromArray(t);
			}
			return n = n, r = r, r.multiply(n);
		}
		if (this.config?.preventIntegerFloatArithmetic && typeof n != typeof r) throw Error("Cannot add different types of numbers.");
		return m(n) * m(r);
	}
}, ne = class extends x {
	constructor(e) {
		super(_(e?.type), _(e?.type), _(e?.type), (e, t) => this._polymorphicDivide(e, t), "FlowGraphDivideBlock", e);
	}
	_polymorphicDivide(n, r) {
		let i = d(n), a = d(r);
		if (p(i, a) || h(i, a)) return n.divide(r);
		if (i === "Quaternion" || a === "Quaternion") {
			let e = n.clone();
			return e.x /= r.x, e.y /= r.y, e.z /= r.z, e.w /= r.w, e;
		}
		if (i === "Quaternion" || a === "Vector4") return new t(n.x, n.y, n.z, n.w).divideInPlace(r);
		if (i === "Vector4" || a === "Quaternion") return n.divide(r);
		if (f(i, a)) {
			if (this.config?.useMatrixPerComponent) {
				let t = n.m;
				for (let e = 0; e < t.length; e++) t[e] /= r.m[e];
				return i === "Matrix2D" ? new c(t) : i === "Matrix3D" ? new s(t) : e.FromArray(t);
			}
			return n = n, r = r, n.divide(r);
		}
		if (this.config?.preventIntegerFloatArithmetic && typeof n != typeof r) throw Error("Cannot add different types of numbers.");
		return m(n) / m(r);
	}
}, D = class extends w {
	constructor(e) {
		super(g, (e) => this._random(e), "FlowGraphRandomBlock", e), this.min = this.registerDataInput("min", g, e?.min ?? 0), this.max = this.registerDataInput("max", g, e?.max ?? 1), e?.seed && (this._seed = e.seed);
	}
	_isSeed(e = this._seed) {
		return e !== void 0;
	}
	_getRandomValue() {
		if (this._isSeed(this._seed)) {
			let e = Math.sin(this._seed++) * 1e4;
			return e - Math.floor(e);
		}
		return Math.random();
	}
	_random(e) {
		let t = this.min.getValue(e), n = this.max.getValue(e);
		return this._getRandomValue() * (n - t) + t;
	}
}, O = class extends w {
	constructor(e) {
		super(g, () => Math.E, "FlowGraphEBlock", e);
	}
}, k = class extends w {
	constructor(e) {
		super(g, () => Math.PI, "FlowGraphPIBlock", e);
	}
}, A = class extends w {
	constructor(e) {
		super(g, () => 2 * Math.PI, "FlowGraphTauBlock", e);
	}
}, re = class extends w {
	constructor(e) {
		super(g, () => Infinity, "FlowGraphInfBlock", e);
	}
}, j = class extends w {
	constructor(e) {
		super(g, () => NaN, "FlowGraphNaNBlock", e);
	}
};
function M(a, l) {
	switch (d(a)) {
		case "FlowGraphInteger": return a = a, new o(l(a.value));
		case "Vector2": return a = a, new n(l(a.x), l(a.y));
		case "Vector3": return a = a, new i(l(a.x), l(a.y), l(a.z));
		case "Vector4": return a = a, new t(l(a.x), l(a.y), l(a.z), l(a.w));
		case "Quaternion": return a = a, new r(l(a.x), l(a.y), l(a.z), l(a.w));
		case "Matrix": return a = a, e.FromArray(a.m.map(l));
		case "Matrix2D": return a = a, new c(a.m.map(l));
		case "Matrix3D": return a = a, new s(a.m.map(l));
		default: return a = a, l(a);
	}
}
var N = class extends S {
	constructor(e) {
		super(g, g, (e) => this._polymorphicAbs(e), "FlowGraphAbsBlock", e);
	}
	_polymorphicAbs(e) {
		return M(e, Math.abs);
	}
}, P = class extends S {
	constructor(e) {
		super(g, g, (e) => this._polymorphicSign(e), "FlowGraphSignBlock", e);
	}
	_polymorphicSign(e) {
		return M(e, Math.sign);
	}
}, F = class extends S {
	constructor(e) {
		super(g, g, (e) => this._polymorphicTrunc(e), "FlowGraphTruncBlock", e);
	}
	_polymorphicTrunc(e) {
		return M(e, Math.trunc);
	}
}, I = class extends S {
	constructor(e) {
		super(g, g, (e) => this._polymorphicFloor(e), "FlowGraphFloorBlock", e);
	}
	_polymorphicFloor(e) {
		return M(e, Math.floor);
	}
}, L = class extends S {
	constructor(e) {
		super(y, y, (e) => this._polymorphicCeiling(e), "FlowGraphCeilBlock", e);
	}
	_polymorphicCeiling(e) {
		return M(e, Math.ceil);
	}
}, R = class extends S {
	constructor(e) {
		super(y, y, (e) => this._polymorphicRound(e), "FlowGraphRoundBlock", e);
	}
	_polymorphicRound(e) {
		return M(e, (e) => e < 0 && this.config?.roundHalfAwayFromZero ? -Math.round(-e) : Math.round(e));
	}
}, z = class extends S {
	constructor(e) {
		super(y, y, (e) => this._polymorphicFraction(e), "FlowGraphFractBlock", e);
	}
	_polymorphicFraction(e) {
		return M(e, (e) => e - Math.floor(e));
	}
}, B = class extends S {
	constructor(e) {
		super(y, y, (e) => this._polymorphicNeg(e), "FlowGraphNegationBlock", e);
	}
	_polymorphicNeg(e) {
		return M(e, (e) => -e);
	}
};
function V(a, l, u) {
	switch (d(a)) {
		case "FlowGraphInteger": return a = a, l = l, new o(u(a.value, l.value));
		case "Vector2": return a = a, l = l, new n(u(a.x, l.x), u(a.y, l.y));
		case "Vector3": return a = a, l = l, new i(u(a.x, l.x), u(a.y, l.y), u(a.z, l.z));
		case "Vector4": return a = a, l = l, new t(u(a.x, l.x), u(a.y, l.y), u(a.z, l.z), u(a.w, l.w));
		case "Quaternion": return a = a, l = l, new r(u(a.x, l.x), u(a.y, l.y), u(a.z, l.z), u(a.w, l.w));
		case "Matrix": return a = a, e.FromArray(a.m.map((e, t) => u(e, l.m[t])));
		case "Matrix2D": return a = a, new c(a.m.map((e, t) => u(e, l.m[t])));
		case "Matrix3D": return a = a, new s(a.m.map((e, t) => u(e, l.m[t])));
		default: return u(m(a), m(l));
	}
}
var H = class extends x {
	constructor(e) {
		super(y, y, y, (e, t) => this._polymorphicRemainder(e, t), "FlowGraphModuloBlock", e);
	}
	_polymorphicRemainder(e, t) {
		return V(e, t, (e, t) => e % t);
	}
}, U = class extends x {
	constructor(e) {
		super(y, y, y, (e, t) => this._polymorphicMin(e, t), "FlowGraphMinBlock", e);
	}
	_polymorphicMin(e, t) {
		return V(e, t, Math.min);
	}
}, W = class extends x {
	constructor(e) {
		super(y, y, y, (e, t) => this._polymorphicMax(e, t), "FlowGraphMaxBlock", e);
	}
	_polymorphicMax(e, t) {
		return V(e, t, Math.max);
	}
};
function ie(e, t, n) {
	return Math.min(Math.max(e, Math.min(t, n)), Math.max(t, n));
}
function G(a, l, u, f) {
	switch (d(a)) {
		case "FlowGraphInteger": return a = a, l = l, u = u, new o(f(a.value, l.value, u.value));
		case "Vector2": return a = a, l = l, u = u, new n(f(a.x, l.x, u.x), f(a.y, l.y, u.y));
		case "Vector3": return a = a, l = l, u = u, new i(f(a.x, l.x, u.x), f(a.y, l.y, u.y), f(a.z, l.z, u.z));
		case "Vector4": return a = a, l = l, u = u, new t(f(a.x, l.x, u.x), f(a.y, l.y, u.y), f(a.z, l.z, u.z), f(a.w, l.w, u.w));
		case "Quaternion": return a = a, l = l, u = u, new r(f(a.x, l.x, u.x), f(a.y, l.y, u.y), f(a.z, l.z, u.z), f(a.w, l.w, u.w));
		case "Matrix": return e.FromArray(a.m.map((e, t) => f(e, l.m[t], u.m[t])));
		case "Matrix2D": return new c(a.m.map((e, t) => f(e, l.m[t], u.m[t])));
		case "Matrix3D": return new s(a.m.map((e, t) => f(e, l.m[t], u.m[t])));
		default: return f(m(a), m(l), m(u));
	}
}
var K = class extends C {
	constructor(e) {
		super(y, y, y, y, (e, t, n) => this._polymorphicClamp(e, t, n), "FlowGraphClampBlock", e);
	}
	_polymorphicClamp(e, t, n) {
		return G(e, t, n, ie);
	}
};
function q(e) {
	return Math.min(Math.max(e, 0), 1);
}
var J = class extends S {
	constructor(e) {
		super(y, y, (e) => this._polymorphicSaturate(e), "FlowGraphSaturateBlock", e);
	}
	_polymorphicSaturate(e) {
		return M(e, q);
	}
};
function ae(e, t, n) {
	return (1 - n) * e + n * t;
}
function oe(e, t, n) {
	if (e === t) return n < e ? 0 : 1;
	let r = q((n - Math.min(e, t)) / Math.abs(t - e));
	return r * r * (3 - 2 * r);
}
var Y = class extends C {
	constructor(e) {
		super(y, y, y, y, (e, t, n) => this._polymorphicInterpolate(e, t, n), "FlowGraphMathInterpolationBlock", e);
	}
	_polymorphicInterpolate(e, t, n) {
		return G(e, t, n, ae);
	}
}, X = class extends C {
	constructor(e) {
		super(y, y, g, y, (e, t, n) => r.Slerp(e, t, n), "FlowGraphMathSlerpBlock", e);
	}
}, Z = class extends C {
	constructor(e) {
		super(y, y, y, y, (e, t, n) => this._polymorphicSmoothStep(e, t, n), "FlowGraphSmoothStepBlock", e);
	}
	_polymorphicSmoothStep(e, t, n) {
		return G(e, t, n, oe);
	}
}, se = class extends x {
	constructor(e) {
		super(y, y, b, (e, t) => this._polymorphicEq(e, t), "FlowGraphEqualityBlock", e);
	}
	_polymorphicEq(e, t) {
		let n = d(e), r = d(t), i = (e) => e === "Vector4" || e === "Quaternion";
		return i(n) && i(r) || p(n, r) || f(n, r) || h(n, r) ? e.equals(t) : u(e) && u(t) ? m(e) === m(t) : typeof e == typeof t && e === t;
	}
};
function Q(e, t, n) {
	if (u(e) && u(t)) return n(m(e), m(t));
	throw Error(`Cannot compare ${e} and ${t}`);
}
var ce = class extends x {
	constructor(e) {
		super(y, y, b, (e, t) => this._polymorphicLessThan(e, t), "FlowGraphLessThanBlock", e);
	}
	_polymorphicLessThan(e, t) {
		return Q(e, t, (e, t) => e < t);
	}
}, le = class extends x {
	constructor(e) {
		super(y, y, b, (e, t) => this._polymorphicLessThanOrEqual(e, t), "FlowGraphLessThanOrEqualBlock", e);
	}
	_polymorphicLessThanOrEqual(e, t) {
		return Q(e, t, (e, t) => e <= t);
	}
}, ue = class extends x {
	constructor(e) {
		super(y, y, b, (e, t) => this._polymorphicGreaterThan(e, t), "FlowGraphGreaterThanBlock", e);
	}
	_polymorphicGreaterThan(e, t) {
		return Q(e, t, (e, t) => e > t);
	}
}, de = class extends x {
	constructor(e) {
		super(y, y, b, (e, t) => this._polymorphicGreaterThanOrEqual(e, t), "FlowGraphGreaterThanOrEqualBlock", e);
	}
	_polymorphicGreaterThanOrEqual(e, t) {
		return Q(e, t, (e, t) => e >= t);
	}
}, fe = class extends S {
	constructor(e) {
		super(y, b, (e) => this._polymorphicIsNan(e), "FlowGraphIsNaNBlock", e);
	}
	_polymorphicIsNan(e) {
		if (u(e, !0)) return isNaN(m(e));
		throw Error(`Cannot get NaN of ${e}`);
	}
}, pe = class extends S {
	constructor(e) {
		super(y, b, (e) => this._polymorphicIsInf(e), "FlowGraphIsInfBlock", e);
	}
	_polymorphicIsInf(e) {
		if (u(e)) return !isFinite(m(e));
		throw Error(`Cannot get isInf of ${e}`);
	}
}, me = class extends S {
	constructor(e) {
		super(y, y, (e) => this._polymorphicDegToRad(e), "FlowGraphDegToRadBlock", e);
	}
	_degToRad(e) {
		return e * Math.PI / 180;
	}
	_polymorphicDegToRad(e) {
		return M(e, this._degToRad);
	}
}, he = class extends S {
	constructor(e) {
		super(y, y, (e) => this._polymorphicRadToDeg(e), "FlowGraphRadToDegBlock", e);
	}
	_radToDeg(e) {
		return e * 180 / Math.PI;
	}
	_polymorphicRadToDeg(e) {
		return M(e, this._radToDeg);
	}
}, ge = class extends S {
	constructor(e) {
		super(g, g, (e) => this._polymorphicSin(e), "FlowGraphSinBlock", e);
	}
	_polymorphicSin(e) {
		return M(e, Math.sin);
	}
}, _e = class extends S {
	constructor(e) {
		super(g, g, (e) => this._polymorphicCos(e), "FlowGraphCosBlock", e);
	}
	_polymorphicCos(e) {
		return M(e, Math.cos);
	}
}, ve = class extends S {
	constructor(e) {
		super(g, g, (e) => this._polymorphicTan(e), "FlowGraphTanBlock", e);
	}
	_polymorphicTan(e) {
		return M(e, Math.tan);
	}
}, ye = class extends S {
	constructor(e) {
		super(g, g, (e) => this._polymorphicAsin(e), "FlowGraphASinBlock", e);
	}
	_polymorphicAsin(e) {
		return M(e, Math.asin);
	}
}, be = class extends S {
	constructor(e) {
		super(g, g, (e) => this._polymorphicAcos(e), "FlowGraphACosBlock", e);
	}
	_polymorphicAcos(e) {
		return M(e, Math.acos);
	}
}, xe = class extends S {
	constructor(e) {
		super(g, g, (e) => this._polymorphicAtan(e), "FlowGraphATanBlock", e);
	}
	_polymorphicAtan(e) {
		return M(e, Math.atan);
	}
}, Se = class extends x {
	constructor(e) {
		super(y, y, y, (e, t) => this._polymorphicAtan2(e, t), "FlowGraphATan2Block", e);
	}
	_polymorphicAtan2(e, t) {
		return V(e, t, Math.atan2);
	}
}, Ce = class extends S {
	constructor(e) {
		super(y, y, (e) => this._polymorphicSinh(e), "FlowGraphSinhBlock", e);
	}
	_polymorphicSinh(e) {
		return M(e, Math.sinh);
	}
}, we = class extends S {
	constructor(e) {
		super(y, y, (e) => this._polymorphicCosh(e), "FlowGraphCoshBlock", e);
	}
	_polymorphicCosh(e) {
		return M(e, Math.cosh);
	}
}, Te = class extends S {
	constructor(e) {
		super(y, y, (e) => this._polymorphicTanh(e), "FlowGraphTanhBlock", e);
	}
	_polymorphicTanh(e) {
		return M(e, Math.tanh);
	}
}, Ee = class extends S {
	constructor(e) {
		super(y, g, (e) => this._polymorphicAsinh(e), "FlowGraphASinhBlock", e);
	}
	_polymorphicAsinh(e) {
		return M(e, Math.asinh);
	}
}, De = class extends S {
	constructor(e) {
		super(y, g, (e) => this._polymorphicAcosh(e), "FlowGraphACoshBlock", e);
	}
	_polymorphicAcosh(e) {
		return M(e, Math.acosh);
	}
}, Oe = class extends S {
	constructor(e) {
		super(y, g, (e) => this._polymorphicAtanh(e), "FlowGraphATanhBlock", e);
	}
	_polymorphicAtanh(e) {
		return M(e, Math.atanh);
	}
}, ke = class extends S {
	constructor(e) {
		super(y, g, (e) => this._polymorphicExp(e), "FlowGraphExponentialBlock", e);
	}
	_polymorphicExp(e) {
		return M(e, Math.exp);
	}
}, Ae = class extends S {
	constructor(e) {
		super(y, g, (e) => this._polymorphicLog(e), "FlowGraphLogBlock", e);
	}
	_polymorphicLog(e) {
		return M(e, Math.log);
	}
}, je = class extends S {
	constructor(e) {
		super(y, g, (e) => this._polymorphicLog2(e), "FlowGraphLog2Block", e);
	}
	_polymorphicLog2(e) {
		return M(e, Math.log2);
	}
}, Me = class extends S {
	constructor(e) {
		super(y, g, (e) => this._polymorphicLog10(e), "FlowGraphLog10Block", e);
	}
	_polymorphicLog10(e) {
		return M(e, Math.log10);
	}
}, Ne = class extends S {
	constructor(e) {
		super(y, g, (e) => this._polymorphicSqrt(e), "FlowGraphSquareRootBlock", e);
	}
	_polymorphicSqrt(e) {
		return M(e, Math.sqrt);
	}
}, Pe = class extends S {
	constructor(e) {
		super(y, g, (e) => this._polymorphicCubeRoot(e), "FlowGraphCubeRootBlock", e);
	}
	_polymorphicCubeRoot(e) {
		return M(e, Math.cbrt);
	}
}, Fe = class extends x {
	constructor(e) {
		super(y, g, g, (e, t) => this._polymorphicPow(e, t), "FlowGraphPowerBlock", e);
	}
	_polymorphicPow(e, t) {
		return V(e, t, Math.pow);
	}
}, Ie = class extends S {
	constructor(e) {
		super(_(e?.valueType || "FlowGraphInteger"), _(e?.valueType || "FlowGraphInteger"), (e) => typeof e == "boolean" ? !e : typeof e == "number" ? ~e : new o(~e.value), "FlowGraphBitwiseNotBlock", e);
	}
}, Le = class extends x {
	constructor(e) {
		super(_(e?.valueType || "FlowGraphInteger"), _(e?.valueType || "FlowGraphInteger"), _(e?.valueType || "FlowGraphInteger"), (e, t) => {
			if (typeof e == "boolean" && typeof t == "boolean") return e && t;
			if (typeof e == "number" && typeof t == "number") return e & t;
			if (typeof e == "object" && typeof t == "object") return new o(e.value & t.value);
			throw Error(`Cannot perform bitwise AND on ${e} and ${t}`);
		}, "FlowGraphBitwiseAndBlock", e);
	}
}, Re = class extends x {
	constructor(e) {
		super(_(e?.valueType || "FlowGraphInteger"), _(e?.valueType || "FlowGraphInteger"), _(e?.valueType || "FlowGraphInteger"), (e, t) => {
			if (typeof e == "boolean" && typeof t == "boolean") return e || t;
			if (typeof e == "number" && typeof t == "number") return e | t;
			if (typeof e == "object" && typeof t == "object") return new o(e.value | t.value);
			throw Error(`Cannot perform bitwise OR on ${e} and ${t}`);
		}, "FlowGraphBitwiseOrBlock", e);
	}
}, ze = class extends x {
	constructor(e) {
		super(_(e?.valueType || "FlowGraphInteger"), _(e?.valueType || "FlowGraphInteger"), _(e?.valueType || "FlowGraphInteger"), (e, t) => {
			if (typeof e == "boolean" && typeof t == "boolean") return e !== t;
			if (typeof e == "number" && typeof t == "number") return e ^ t;
			if (typeof e == "object" && typeof t == "object") return new o(e.value ^ t.value);
			throw Error(`Cannot perform bitwise XOR on ${e} and ${t}`);
		}, "FlowGraphBitwiseXorBlock", e);
	}
}, Be = class extends x {
	constructor(e) {
		super(v, v, v, (e, t) => new o(e.value << t.value), "FlowGraphBitwiseLeftShiftBlock", e);
	}
}, Ve = class extends x {
	constructor(e) {
		super(v, v, v, (e, t) => new o(e.value >> t.value), "FlowGraphBitwiseRightShiftBlock", e);
	}
}, $ = class extends S {
	constructor(e) {
		super(v, v, (e) => new o(Math.clz32(e.value)), "FlowGraphLeadingZerosBlock", e);
	}
}, He = class extends S {
	constructor(e) {
		super(v, v, (e) => new o(e.value ? 31 - Math.clz32(e.value & -e.value) : 32), "FlowGraphTrailingZerosBlock", e);
	}
};
function Ue(e) {
	let t = 0;
	for (; e;) t += e & 1, e >>>= 1;
	return t;
}
var We = class extends S {
	constructor(e) {
		super(v, v, (e) => new o(Ue(e.value)), "FlowGraphOneBitsCounterBlock", e);
	}
};
function Ge(e, t, n) {
	let r = .4122214708 * e + .5363325363 * t + .0514459929 * n, i = .2119034982 * e + .6806995451 * t + .1073969566 * n, a = .0883024619 * e + .2817188376 * t + .6299787005 * n, o = Math.cbrt(r), s = Math.cbrt(i), c = Math.cbrt(a), l = .2104542553 * o + .793617785 * s - .0040720468 * c, u = 1.9779984951 * o - 2.428592205 * s + .4505937099 * c, d = .0259040371 * o + .7827717662 * s - .808675766 * c;
	return {
		l,
		c: Math.hypot(u, d),
		h: Math.atan2(d, u)
	};
}
function Ke(e, t, n) {
	let r = t * Math.cos(n), i = t * Math.sin(n), a = e + .3963377774 * r + .2158037573 * i, o = e - .1055613458 * r - .0638541728 * i, s = e - .0894841775 * r - 1.291485548 * i, c = a * a * a, l = o * o * o, u = s * s * s;
	return {
		r: 4.0767416621 * c - 3.3077115913 * l + .2309699292 * u,
		g: -1.2684380046 * c + 2.6097574011 * l - .3413193965 * u,
		b: -.0041960863 * c - .7034186147 * l + 1.707614701 * u
	};
}
var qe = class extends l {
	constructor(e) {
		super(e), this.r = this.registerDataInput("r", g, 0), this.g = this.registerDataInput("g", g, 0), this.b = this.registerDataInput("b", g, 0), this.l = this.registerDataOutput("l", g, 0), this.c = this.registerDataOutput("c", g, 0), this.h = this.registerDataOutput("h", g, 0);
	}
	_updateOutputs(e) {
		let { l: t, c: n, h: r } = Ge(this.r.getValue(e), this.g.getValue(e), this.b.getValue(e));
		this.l.setValue(t, e), this.c.setValue(n, e), this.h.setValue(r, e);
	}
	getClassName() {
		return "FlowGraphRGBToOkLChBlock";
	}
}, Je = class extends l {
	constructor(e) {
		super(e), this.l = this.registerDataInput("l", g, 0), this.c = this.registerDataInput("c", g, 0), this.h = this.registerDataInput("h", g, 0), this.r = this.registerDataOutput("r", g, 0), this.g = this.registerDataOutput("g", g, 0), this.b = this.registerDataOutput("b", g, 0);
	}
	_updateOutputs(e) {
		let { r: t, g: n, b: r } = Ke(this.l.getValue(e), this.c.getValue(e), this.h.getValue(e));
		this.r.setValue(t, e), this.g.setValue(n, e), this.b.setValue(r, e);
	}
	getClassName() {
		return "FlowGraphRGBFromOkLChBlock";
	}
}, Ye = !1;
function Xe() {
	Ye || (Ye = !0, a("FlowGraphAddBlock", T), a("FlowGraphSubtractBlock", E), a("FlowGraphMultiplyBlock", te), a("FlowGraphDivideBlock", ne), a("FlowGraphRandomBlock", D), a("FlowGraphEBlock", O), a("FlowGraphPIBlock", k), a("FlowGraphTauBlock", A), a("FlowGraphInfBlock", re), a("FlowGraphNaNBlock", j), a("FlowGraphAbsBlock", N), a("FlowGraphSignBlock", P), a("FlowGraphTruncBlock", F), a("FlowGraphFloorBlock", I), a("FlowGraphCeilBlock", L), a("FlowGraphRoundBlock", R), a("FlowGraphFractBlock", z), a("FlowGraphNegationBlock", B), a("FlowGraphModuloBlock", H), a("FlowGraphMinBlock", U), a("FlowGraphMaxBlock", W), a("FlowGraphClampBlock", K), a("FlowGraphSaturateBlock", J), a("FlowGraphMathInterpolationBlock", Y), a("FlowGraphMathSlerpBlock", X), a("FlowGraphSmoothStepBlock", Z), a("FlowGraphRGBToOkLChBlock", qe), a("FlowGraphRGBFromOkLChBlock", Je), a("FlowGraphEqualityBlock", se), a("FlowGraphLessThanBlock", ce), a("FlowGraphLessThanOrEqualBlock", le), a("FlowGraphGreaterThanBlock", ue), a("FlowGraphGreaterThanOrEqualBlock", de), a("FlowGraphIsNaNBlock", fe), a("FlowGraphIsInfBlock", pe), a("FlowGraphDegToRadBlock", me), a("FlowGraphRadToDegBlock", he), a("FlowGraphASinBlock", ye), a("FlowGraphACosBlock", be), a("FlowGraphATanBlock", xe), a("FlowGraphATan2Block", Se), a("FlowGraphSinhBlock", Ce), a("FlowGraphCoshBlock", we), a("FlowGraphTanhBlock", Te), a("FlowGraphASinhBlock", Ee), a("FlowGraphACoshBlock", De), a("FlowGraphATanhBlock", Oe), a("FlowGraphExponentialBlock", ke), a("FlowGraphLogBlock", Ae), a("FlowGraphLog2Block", je), a("FlowGraphLog10Block", Me), a("FlowGraphSquareRootBlock", Ne), a("FlowGraphCubeRootBlock", Pe), a("FlowGraphPowerBlock", Fe), a("FlowGraphBitwiseNotBlock", Ie), a("FlowGraphBitwiseAndBlock", Le), a("FlowGraphBitwiseOrBlock", Re), a("FlowGraphBitwiseXorBlock", ze), a("FlowGraphBitwiseLeftShiftBlock", Be), a("FlowGraphBitwiseRightShiftBlock", Ve), a("FlowGraphLeadingZerosBlock", $), a("FlowGraphTrailingZerosBlock", He), a("FlowGraphOneBitsCounterBlock", We));
}
//#endregion
export { N as FlowGraphAbsBlock, be as FlowGraphAcosBlock, De as FlowGraphAcoshBlock, T as FlowGraphAddBlock, ye as FlowGraphAsinBlock, Ee as FlowGraphAsinhBlock, Se as FlowGraphAtan2Block, xe as FlowGraphAtanBlock, Oe as FlowGraphAtanhBlock, Le as FlowGraphBitwiseAndBlock, Be as FlowGraphBitwiseLeftShiftBlock, Ie as FlowGraphBitwiseNotBlock, Re as FlowGraphBitwiseOrBlock, Ve as FlowGraphBitwiseRightShiftBlock, ze as FlowGraphBitwiseXorBlock, L as FlowGraphCeilBlock, K as FlowGraphClampBlock, _e as FlowGraphCosBlock, we as FlowGraphCoshBlock, Pe as FlowGraphCubeRootBlock, me as FlowGraphDegToRadBlock, ne as FlowGraphDivideBlock, O as FlowGraphEBlock, se as FlowGraphEqualityBlock, ke as FlowGraphExpBlock, I as FlowGraphFloorBlock, z as FlowGraphFractionBlock, ue as FlowGraphGreaterThanBlock, de as FlowGraphGreaterThanOrEqualBlock, re as FlowGraphInfBlock, pe as FlowGraphIsInfinityBlock, fe as FlowGraphIsNanBlock, $ as FlowGraphLeadingZerosBlock, ce as FlowGraphLessThanBlock, le as FlowGraphLessThanOrEqualBlock, Me as FlowGraphLog10Block, je as FlowGraphLog2Block, Ae as FlowGraphLogBlock, Y as FlowGraphMathInterpolationBlock, X as FlowGraphMathSlerpBlock, Z as FlowGraphMathSmoothStepBlock, W as FlowGraphMaxBlock, U as FlowGraphMinBlock, H as FlowGraphModuloBlock, te as FlowGraphMultiplyBlock, j as FlowGraphNaNBlock, B as FlowGraphNegationBlock, We as FlowGraphOneBitsCounterBlock, k as FlowGraphPiBlock, Fe as FlowGraphPowerBlock, Je as FlowGraphRGBFromOkLChBlock, qe as FlowGraphRGBToOkLChBlock, he as FlowGraphRadToDegBlock, D as FlowGraphRandomBlock, R as FlowGraphRoundBlock, J as FlowGraphSaturateBlock, P as FlowGraphSignBlock, ge as FlowGraphSinBlock, Ce as FlowGraphSinhBlock, Ne as FlowGraphSquareRootBlock, E as FlowGraphSubtractBlock, ve as FlowGraphTanBlock, Te as FlowGraphTanhBlock, A as FlowGraphTauBlock, He as FlowGraphTrailingZerosBlock, F as FlowGraphTruncBlock, Xe as RegisterFlowGraphMathBlocks };
