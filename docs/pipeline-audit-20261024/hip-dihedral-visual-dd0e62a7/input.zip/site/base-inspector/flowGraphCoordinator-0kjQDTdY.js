import { n as e } from "./engineStore-D0BoPdea.js";
import { t } from "./logger-DQIzSR_y.js";
import { t as n } from "./abstractEngine.pure-C608BZav.js";
import { b as r, i, y as a } from "./decorators-BldPRAAT.js";
import { t as o } from "./guid-DXeovnrE.js";
import { r as s } from "./tools.pure-Dy2G52NL.js";
import { t as c } from "./pointerEvents-BQVevekB.js";
import { t as l } from "./keyboardEvents-BnzTAWpo.js";
import { a as u } from "./flowGraphBlock-BTSj91tT.js";
import { t as d } from "./flowGraphAssetsContext-6T_gO7Vp.js";
import { t as f } from "./flowGraphExecutionBlock-CX4ysaWA.js";
import { t as p } from "./flowGraphAsyncExecutionBlock-y06fnRVP.js";
import { a as m, o as h } from "./utils-Cc6lHVNn.js";
import { t as g } from "./flowGraphEventBlock-Dyv9PqYT.js";
//#region node_modules/@babylonjs/core/FlowGraph/flowGraphLogger.js
var _;
(function(e) {
	e.ExecuteBlock = "ExecuteBlock", e.ExecuteEvent = "ExecuteEvent", e.TriggerConnection = "TriggerConnection", e.ContextVariableSet = "ContextVariableSet", e.GlobalVariableSet = "GlobalVariableSet", e.GlobalVariableDelete = "GlobalVariableDelete", e.GlobalVariableGet = "GlobalVariableGet", e.AddConnection = "AddConnection", e.GetConnectionValue = "GetConnectionValue", e.SetConnectionValue = "SetConnectionValue", e.ActivateSignal = "ActivateSignal", e.ContextVariableGet = "ContextVariableGet";
})(_ ||= {});
var v = class {
	constructor() {
		this.logToConsole = !1, this.log = [];
	}
	addLogItem(e) {
		if (e.time ||= Date.now(), this.log.push(e), this.logToConsole) {
			let n = e.payload?.value;
			typeof n == "object" && n.getClassName ? t.Log(`[FGLog] ${e.className}:${e.uniqueId.split("-")[0]} ${e.action} - ${JSON.stringify(n.getClassName())}: ${n.toString()}`) : t.Log(`[FGLog] ${e.className}:${e.uniqueId.split("-")[0]} ${e.action} - ${JSON.stringify(e.payload)}`);
		}
	}
	getItemsOfType(e) {
		return this.log.filter((t) => t.action === e);
	}
}, y = (() => {
	var t;
	let n, s = [], c = [], l, f = [], p = [];
	return t = class {
		get enableLogging() {
			return this._enableLogging;
		}
		set enableLogging(e) {
			this._enableLogging !== e && (this._enableLogging = e, this._enableLogging ? (this.logger = new v(), this.logger.logToConsole = !0) : this.logger = null);
		}
		constructor(t) {
			this.uniqueId = r(this, s, o()), this.name = (r(this, c), r(this, f, "")), this._userVariables = (r(this, p), {}), this._variableTypes = {}, this._executionVariables = {}, this._globalContextVariables = {}, this._connectionValues = {}, this._pendingBlocks = [], this._executionId = 0, this.onNodeExecutedObservable = new e(), this.onBreakpointHitObservable = new e(), this.breakpointPredicate = null, this._pendingActivation = null, this._stepMode = !1, this._skipBreakpointForBlockId = null, this.treatDataAsRightHanded = !1, this._enableLogging = !1, this._configuration = t, this.assetsContext = t.assetsContext ?? t.scene;
		}
		hasVariable(e) {
			return e in this._userVariables;
		}
		setVariable(e, t) {
			this._userVariables[e] = t, this.logger?.addLogItem({
				time: Date.now(),
				className: this.getClassName(),
				uniqueId: this.uniqueId,
				action: "ContextVariableSet",
				payload: {
					name: e,
					value: t
				}
			});
		}
		getAsset(e, t) {
			return d(this.assetsContext, e, t);
		}
		getVariable(e) {
			return this.logger?.addLogItem({
				time: Date.now(),
				className: this.getClassName(),
				uniqueId: this.uniqueId,
				action: "ContextVariableGet",
				payload: {
					name: e,
					value: this._userVariables[e]
				}
			}), this._userVariables[e];
		}
		get userVariables() {
			return this._userVariables;
		}
		setVariableType(e, t) {
			this._variableTypes[e] = t;
		}
		getVariableType(e) {
			return this._variableTypes[e];
		}
		get variableTypes() {
			return this._variableTypes;
		}
		getScene() {
			return this._configuration.scene;
		}
		getEventReference(e) {
			return this._configuration.coordinator._getEventReference(e);
		}
		decodeIndexReference(e, t) {
			return this._configuration.coordinator.config.hostResolver?.decodeIndexReference?.(e, t);
		}
		getObjectReference(e, t) {
			return this._configuration.coordinator.config.hostResolver?.getObjectReference?.(e, t);
		}
		_getUniqueIdPrefixedName(e, t) {
			return `${e.uniqueId}_${t}`;
		}
		_getGlobalContextVariable(e, t) {
			return this.logger?.addLogItem({
				time: Date.now(),
				className: this.getClassName(),
				uniqueId: this.uniqueId,
				action: "GlobalVariableGet",
				payload: {
					name: e,
					defaultValue: t,
					possibleValue: this._globalContextVariables[e]
				}
			}), this._hasGlobalContextVariable(e) ? this._globalContextVariables[e] : t;
		}
		_setGlobalContextVariable(e, t) {
			this.logger?.addLogItem({
				time: Date.now(),
				className: this.getClassName(),
				uniqueId: this.uniqueId,
				action: "GlobalVariableSet",
				payload: {
					name: e,
					value: t
				}
			}), this._globalContextVariables[e] = t;
		}
		_deleteGlobalContextVariable(e) {
			this.logger?.addLogItem({
				time: Date.now(),
				className: this.getClassName(),
				uniqueId: this.uniqueId,
				action: "GlobalVariableDelete",
				payload: { name: e }
			}), delete this._globalContextVariables[e];
		}
		_hasGlobalContextVariable(e) {
			return e in this._globalContextVariables;
		}
		_setExecutionVariable(e, t, n) {
			this._executionVariables[this._getUniqueIdPrefixedName(e, t)] = n;
		}
		_getExecutionVariable(e, t, n) {
			return this._hasExecutionVariable(e, t) ? this._executionVariables[this._getUniqueIdPrefixedName(e, t)] : n;
		}
		_deleteExecutionVariable(e, t) {
			delete this._executionVariables[this._getUniqueIdPrefixedName(e, t)];
		}
		_hasExecutionVariable(e, t) {
			return this._getUniqueIdPrefixedName(e, t) in this._executionVariables;
		}
		_hasConnectionValue(e) {
			return e.uniqueId in this._connectionValues;
		}
		_setConnectionValue(e, t) {
			this._connectionValues[e.uniqueId] = t, this.logger?.addLogItem({
				time: Date.now(),
				className: this.getClassName(),
				uniqueId: this.uniqueId,
				action: "SetConnectionValue",
				payload: {
					connectionPointId: e.uniqueId,
					value: t
				}
			});
		}
		_setConnectionValueByKey(e, t) {
			this._connectionValues[e] = t;
		}
		_getConnectionValue(e) {
			return this.logger?.addLogItem({
				time: Date.now(),
				className: this.getClassName(),
				uniqueId: this.uniqueId,
				action: "GetConnectionValue",
				payload: {
					connectionPointId: e.uniqueId,
					value: this._connectionValues[e.uniqueId]
				}
			}), this._connectionValues[e.uniqueId];
		}
		get configuration() {
			return this._configuration;
		}
		get hasPendingBlocks() {
			return this._pendingBlocks.length > 0;
		}
		_addPendingBlock(e) {
			this._pendingBlocks.includes(e) || (this._pendingBlocks.push(e), this._pendingBlocks.sort((e, t) => e.priority - t.priority));
		}
		_removePendingBlock(e) {
			let t = this._pendingBlocks.indexOf(e);
			t !== -1 && this._pendingBlocks.splice(t, 1);
		}
		_clearPendingBlocks() {
			for (let e of this._pendingBlocks.slice()) e._cancelPendingTasks(this);
			this._pendingBlocks.length = 0;
		}
		_notifyExecuteNode(e) {
			this.onNodeExecutedObservable.notifyObservers(e), this.logger?.addLogItem({
				time: Date.now(),
				className: e.getClassName(),
				uniqueId: e.uniqueId,
				action: "ExecuteBlock"
			});
		}
		_notifyOnTick(e) {
			this._setGlobalContextVariable("firstTickPayload", this._getGlobalContextVariable("firstTickPayload", e)), this._setGlobalContextVariable("timeSinceStart", e.timeSinceStart), this._setGlobalContextVariable("deltaTime", e.deltaTime);
			for (let e of this._pendingBlocks) e._executeOnTick?.(this);
		}
		_increaseExecutionId() {
			this._executionId++;
		}
		get executionId() {
			return this._executionId;
		}
		_shouldBreak(e, t) {
			return this._skipBreakpointForBlockId === e.uniqueId ? (this._skipBreakpointForBlockId = null, !1) : this._pendingActivation ? !0 : this._stepMode ? (this._stepMode = !1, this._pendingActivation = {
				block: e,
				context: this,
				signal: t
			}, this.onBreakpointHitObservable.notifyObservers(this._pendingActivation), !0) : this.breakpointPredicate && this.breakpointPredicate(e) ? (this._pendingActivation = {
				block: e,
				context: this,
				signal: t
			}, this.onBreakpointHitObservable.notifyObservers(this._pendingActivation), !0) : !1;
		}
		get pendingActivation() {
			return this._pendingActivation;
		}
		continueExecution() {
			let e = this._pendingActivation;
			e && (this._pendingActivation = null, this._skipBreakpointForBlockId = e.block.uniqueId, e.signal._activateSignal(this), this._skipBreakpointForBlockId = null);
		}
		stepExecution() {
			let e = this._pendingActivation;
			e && (this._pendingActivation = null, this._stepMode = !0, this._skipBreakpointForBlockId = e.block.uniqueId, e.signal._activateSignal(this), this._stepMode = !1, this._skipBreakpointForBlockId = null);
		}
		_clearPendingActivation() {
			this._pendingActivation = null, this._stepMode = !1, this._skipBreakpointForBlockId = null;
		}
		serialize(e = {}, t = u) {
			e.uniqueId = this.uniqueId, e.name = this.name, e._userVariables = {};
			for (let n in this._userVariables) t(n, this._userVariables[n], e._userVariables);
			Object.keys(this._variableTypes).length > 0 && (e._variableTypes = { ...this._variableTypes }), e._connectionValues = {};
			for (let n in this._connectionValues) t(n, this._connectionValues[n], e._connectionValues);
			this.assetsContext !== this.getScene() && (e._assetsContext = {
				meshes: this.assetsContext.meshes.map((e) => e.id),
				materials: this.assetsContext.materials.map((e) => e.id),
				textures: this.assetsContext.textures.map((e) => e.name),
				animations: this.assetsContext.animations.map((e) => e.name),
				lights: this.assetsContext.lights.map((e) => e.id),
				cameras: this.assetsContext.cameras.map((e) => e.id),
				sounds: this.assetsContext.sounds?.map((e) => e.name),
				skeletons: this.assetsContext.skeletons.map((e) => e.id),
				particleSystems: this.assetsContext.particleSystems.map((e) => e.name),
				geometries: this.assetsContext.geometries.map((e) => e.id),
				multiMaterials: this.assetsContext.multiMaterials.map((e) => e.id),
				transformNodes: this.assetsContext.transformNodes.map((e) => e.id)
			});
		}
		getClassName() {
			return "FlowGraphContext";
		}
	}, (() => {
		let e = typeof Symbol == "function" && Symbol.metadata ? Object.create(null) : void 0;
		n = [i()], l = [i()], a(null, null, n, {
			kind: "field",
			name: "uniqueId",
			static: !1,
			private: !1,
			access: {
				has: (e) => "uniqueId" in e,
				get: (e) => e.uniqueId,
				set: (e, t) => {
					e.uniqueId = t;
				}
			},
			metadata: e
		}, s, c), a(null, null, l, {
			kind: "field",
			name: "name",
			static: !1,
			private: !1,
			access: {
				has: (e) => "name" in e,
				get: (e) => e.name,
				set: (e, t) => {
					e.name = t;
				}
			},
			metadata: e
		}, f, p), e && Object.defineProperty(t, Symbol.metadata, {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: e
		});
	})(), t;
})(), b = class t {
	constructor(t) {
		this.onEventTriggeredObservable = new e(), this.sceneReadyTriggered = !1, this._pointerUnderMeshState = {}, this._onBlurHandler = null, this.pressedKeys = /* @__PURE__ */ new Set(), this._startingTime = 0, this._scene = t, this._initialize();
	}
	_initialize() {
		this._sceneReadyObserver = this._scene.onReadyObservable.addOnce(() => {
			this.sceneReadyTriggered ||= (this.onEventTriggeredObservable.notifyObservers({ type: "SceneReady" }), !0);
		}), this._sceneDisposeObserver = this._scene.onDisposeObservable.add(() => {
			this.onEventTriggeredObservable.notifyObservers({ type: "SceneDispose" });
		}), this._sceneOnBeforeRenderObserver = this._scene.onBeforeRenderObservable.add(() => {
			let e = this._scene.getEngine().getDeltaTime() / 1e3;
			this.onEventTriggeredObservable.notifyObservers({
				type: "SceneBeforeRender",
				payload: {
					timeSinceStart: this._startingTime,
					deltaTime: e
				}
			}), this._startingTime += e;
		}), this._meshPickedObserver = this._scene.onPointerObservable.add((e) => {
			this.onEventTriggeredObservable.notifyObservers({
				type: "MeshPick",
				payload: e
			});
		}, c.POINTERPICK), this._pointerDownObserver = this._scene.onPointerObservable.add((e) => {
			this.onEventTriggeredObservable.notifyObservers({
				type: "PointerDown",
				payload: e
			});
		}, c.POINTERDOWN), this._pointerUpObserver = this._scene.onPointerObservable.add((e) => {
			this.onEventTriggeredObservable.notifyObservers({
				type: "PointerUp",
				payload: e
			});
		}, c.POINTERUP), this._pointerMoveObserver = this._scene.onPointerObservable.add((e) => {
			this.onEventTriggeredObservable.notifyObservers({
				type: "PointerMove",
				payload: e
			});
		}, c.POINTERMOVE), this._meshUnderPointerObserver = this._scene.onMeshUnderPointerUpdatedObservable.add((e) => {
			let t = e.pointerId, n = e.mesh, r = this._pointerUnderMeshState[t];
			!r && n ? this.onEventTriggeredObservable.notifyObservers({
				type: "PointerOver",
				payload: {
					pointerId: t,
					mesh: n
				}
			}) : r && !n ? this.onEventTriggeredObservable.notifyObservers({
				type: "PointerOut",
				payload: {
					pointerId: t,
					mesh: r
				}
			}) : r && n && r !== n && (this.onEventTriggeredObservable.notifyObservers({
				type: "PointerOut",
				payload: {
					pointerId: t,
					mesh: r,
					over: n
				}
			}), this.onEventTriggeredObservable.notifyObservers({
				type: "PointerOver",
				payload: {
					pointerId: t,
					mesh: n,
					out: r
				}
			})), this._pointerUnderMeshState[t] = n;
		}, c.POINTERMOVE), this._keyDownObserver = this._scene.onKeyboardObservable.add((e) => {
			let n = e.event.code;
			this.pressedKeys.add(n), t._COMMAND_OR_CTRL_CODES.has(n) && this.pressedKeys.add("CommandOrControl"), this.onEventTriggeredObservable.notifyObservers({
				type: "KeyDown",
				payload: e
			});
		}, l.KEYDOWN), this._keyUpObserver = this._scene.onKeyboardObservable.add((e) => {
			let n = e.event.code;
			if (this.pressedKeys.delete(n), t._COMMAND_OR_CTRL_CODES.has(n)) {
				let e = !1;
				for (let r of Array.from(t._COMMAND_OR_CTRL_CODES)) if (r !== n && this.pressedKeys.has(r)) {
					e = !0;
					break;
				}
				e || this.pressedKeys.delete("CommandOrControl");
			}
			this.onEventTriggeredObservable.notifyObservers({
				type: "KeyUp",
				payload: e
			});
		}, l.KEYUP);
		let e = this._scene.getEngine().getRenderingCanvas();
		e && (this._onBlurHandler = () => this.pressedKeys.clear(), e.addEventListener("blur", this._onBlurHandler));
	}
	dispose() {
		this._sceneDisposeObserver?.remove(), this._sceneReadyObserver?.remove(), this._sceneOnBeforeRenderObserver?.remove(), this._meshPickedObserver?.remove(), this._meshUnderPointerObserver?.remove(), this._pointerDownObserver?.remove(), this._pointerUpObserver?.remove(), this._pointerMoveObserver?.remove(), this._keyDownObserver?.remove(), this._keyUpObserver?.remove(), this._onBlurHandler &&= (this._scene.getEngine().getRenderingCanvas()?.removeEventListener("blur", this._onBlurHandler), null), this.pressedKeys.clear(), this.onEventTriggeredObservable.clear();
	}
};
b._COMMAND_OR_CTRL_CODES = h ? /* @__PURE__ */ new Set(["MetaLeft", "MetaRight"]) : /* @__PURE__ */ new Set(["ControlLeft", "ControlRight"]);
//#endregion
//#region node_modules/@babylonjs/core/FlowGraph/flowGraphValidator.js
var x;
(function(e) {
	e[e.Error = 0] = "Error", e[e.Warning = 1] = "Warning";
})(x ||= {});
var S = /* @__PURE__ */ new Set([
	"number",
	"FlowGraphInteger",
	"boolean"
]), C = /* @__PURE__ */ new Set(["Vector4", "Quaternion"]), w = /* @__PURE__ */ new Set(["Color3", "Color4"]);
function T(e, t) {
	return !!(e === t || e === "any" || t === "any" || S.has(e) && S.has(t) || C.has(e) && C.has(t) || w.has(e) && w.has(t));
}
function E(e) {
	let t = [], n = /* @__PURE__ */ new Map(), r = (e) => {
		if (t.push(e), e.block) {
			let t = n.get(e.block.uniqueId);
			t || (t = [], n.set(e.block.uniqueId, t)), t.push(e);
		}
	}, i = [];
	e.visitAllBlocks((e) => {
		i.push(e);
	}), O(e).length === 0 && r({
		severity: 0,
		message: "Graph has no event blocks — nothing will trigger execution."
	});
	for (let e of i) for (let t of e.dataInputs) !t.optional && !t.isDisabled && !t.isConnected() && r({
		severity: 1,
		message: `"${t.name}" is not connected and will use its default value.`,
		block: e,
		connectionName: t.name
	});
	for (let e of i) if (e instanceof f) {
		if (k(e)) continue;
		let t = e.signalInputs.find((e) => e.name === "in");
		t && !t.isConnected() && r({
			severity: 0,
			message: "Execution block has no incoming signal — it will never execute.",
			block: e,
			connectionName: "in"
		});
	}
	for (let e of i) for (let t of e.dataInputs) {
		if (!t.isConnected()) continue;
		let n = t._connectedPoint[0], i = n.richType?.typeName, a = t.richType?.typeName;
		if (i && a && !T(i, a)) {
			if (n.richType.typeTransformer !== void 0 || t.richType.typeTransformer !== void 0) continue;
			r({
				severity: 1,
				message: `Type mismatch: "${n._ownerBlock.name}.${n.name}" (${i}) → "${e.name}.${t.name}" (${a}).`,
				block: e,
				connectionName: t.name
			});
		}
	}
	let a = /* @__PURE__ */ new Set();
	return e.visitAllBlocks((e) => {
		a.add(e.uniqueId);
	}), A(i, r), t.sort((e, t) => e.severity - t.severity), {
		isValid: t.every((e) => e.severity !== 0),
		issues: t,
		errorCount: t.filter((e) => e.severity === 0).length,
		warningCount: t.filter((e) => e.severity === 1).length,
		issuesByBlock: n
	};
}
function D(e, t) {
	let n = E(e), r = /* @__PURE__ */ new Set();
	e.visitAllBlocks((e) => {
		r.add(e.uniqueId);
	});
	for (let e of t) if (!r.has(e.uniqueId)) {
		let t = {
			severity: 1,
			message: "Block is unreachable from any event block.",
			block: e
		};
		n.issues.push(t), n.warningCount++;
		let r = n.issuesByBlock.get(e.uniqueId);
		r || (r = [], n.issuesByBlock.set(e.uniqueId, r)), r.push(t);
		for (let t of e.dataInputs) if (!t.optional && !t.isDisabled && !t.isConnected()) {
			let i = {
				severity: 1,
				message: `"${t.name}" is not connected and will use its default value.`,
				block: e,
				connectionName: t.name
			};
			n.issues.push(i), n.warningCount++, r.push(i);
		}
		if (e instanceof f && !k(e)) {
			let t = e.signalInputs.find((e) => e.name === "in");
			if (t && !t.isConnected()) {
				let t = {
					severity: 0,
					message: "Execution block has no incoming signal — it will never execute.",
					block: e,
					connectionName: "in"
				};
				n.issues.push(t), n.errorCount++, r.push(t);
			}
		}
	}
	return n.isValid = n.issues.every((e) => e.severity !== 0), n.issues.sort((e, t) => e.severity - t.severity), n;
}
function O(e) {
	let t = [];
	for (let n in e._eventBlocks) for (let r of e._eventBlocks[n]) t.push(r);
	return t;
}
function k(e) {
	return e instanceof g;
}
function A(e, t) {
	let n = /* @__PURE__ */ new Map();
	for (let t of e) n.set(t.uniqueId, 0);
	let r = /* @__PURE__ */ new Set();
	function i(e) {
		n.set(e.uniqueId, 1);
		for (let a of e.dataInputs) if (a.isConnected()) for (let o of a._connectedPoint) {
			let a = o._ownerBlock;
			if (a instanceof f) continue;
			let s = n.get(a.uniqueId);
			if (s === 1) return r.has(e.uniqueId) || (r.add(e.uniqueId), t({
				severity: 0,
				message: "Data dependency cycle detected — getValue() will recurse infinitely.",
				block: e
			})), r.has(a.uniqueId) || (r.add(a.uniqueId), t({
				severity: 0,
				message: "Data dependency cycle detected — getValue() will recurse infinitely.",
				block: a
			})), !0;
			s === 0 && i(a);
		}
		return n.set(e.uniqueId, 2), !1;
	}
	for (let t of e) n.get(t.uniqueId) === 0 && i(t);
}
//#endregion
//#region node_modules/@babylonjs/core/FlowGraph/flowGraph.js
var j;
(function(e) {
	e[e.Stopped = 0] = "Stopped", e[e.Started = 1] = "Started", e[e.Paused = 2] = "Paused";
})(j ||= {});
var M = class t {
	_getGlobalFlowGraphEditor() {
		if (typeof FLOWGRAPHEDITOR < "u") {
			if (FLOWGRAPHEDITOR.FlowGraphEditor) return FLOWGRAPHEDITOR;
			if (FLOWGRAPHEDITOR.default?.FlowGraphEditor) return FLOWGRAPHEDITOR.default;
		}
		if (typeof BABYLON < "u" && BABYLON.FlowGraphEditor !== void 0) return BABYLON;
	}
	get scene() {
		return this._scene;
	}
	get coordinator() {
		return this._coordinator;
	}
	get sceneEventCoordinator() {
		return this._sceneEventCoordinator;
	}
	get state() {
		return this._state;
	}
	set state(e) {
		this._state = e, this.onStateChangedObservable.notifyObservers(e);
	}
	constructor(t) {
		this._BJSFLOWGRAPHEDITOR = this._getGlobalFlowGraphEditor(), this.onStateChangedObservable = new e(), this._eventBlocks = {
			SceneReady: [],
			SceneDispose: [],
			SceneBeforeRender: [],
			MeshPick: [],
			PointerDown: [],
			PointerUp: [],
			PointerMove: [],
			PointerOver: [],
			PointerOut: [],
			KeyDown: [],
			KeyUp: [],
			SceneAfterRender: [],
			NoTrigger: []
		}, this._allBlocks = [], this._executionContexts = [], this._state = 0, this._scene = t.scene, this._sceneEventCoordinator = new b(this._scene), this._coordinator = t.coordinator, this.name = t.name ?? "Graph", this.uniqueId = t.uniqueId ?? o();
	}
	_attachEventObserver() {
		this._eventObserver ||= this._sceneEventCoordinator.onEventTriggeredObservable.add((e, t) => {
			if (e.type === "SceneDispose") {
				this.dispose();
				return;
			}
			if (this.state !== 1) return;
			let n = e.type === "MeshPick" || e.type === "PointerOver" || e.type === "PointerOut" ? [] : void 0, r = e.payload, i = r?.pickInfo?.pickedMesh ?? r?.mesh;
			for (let r of this._executionContexts) {
				let a = this._getContextualOrder(e.type, r);
				for (let o of a) {
					let a = o, s = a._getReferencedMesh?.(r);
					if (i && s && n?.some((e) => e !== s && m(i, s))) continue;
					let c = a.eventKey;
					this._coordinator._beginEventDispatch(c, t);
					let l, u;
					try {
						l = o._executeEvent(r, e.payload);
					} finally {
						u = this._coordinator._endEventDispatch();
					}
					if (u?.propagationStopped && s && n?.push(s), t.skipNextObservers || !l) break;
				}
				if (t.skipNextObservers) break;
			}
			switch (e.type) {
				case "SceneReady":
					this._sceneEventCoordinator.sceneReadyTriggered = !0;
					break;
				case "SceneBeforeRender": for (let t of this._executionContexts) t._notifyOnTick(e.payload);
			}
		});
	}
	_detachEventObserver() {
		this._eventObserver?.remove(), this._eventObserver = null;
	}
	setScene(e) {
		if (e !== this._scene) {
			this.state === 1 && this.stop(), this._detachEventObserver(), this._sceneEventCoordinator.dispose(), this._executionContexts.length = 0, this._scene = e, this._scene.constantlyUpdateMeshUnderPointer = !0;
			for (let t of this._allBlocks) for (let n of t.dataInputs) n._reresolveDefaultValueForScene(e);
			this._sceneEventCoordinator = new b(this._scene), this._attachEventObserver();
		}
	}
	createContext() {
		let e = new y({
			scene: this._scene,
			coordinator: this._coordinator,
			sceneEventCoordinator: this._sceneEventCoordinator
		});
		return this._executionContexts.push(e), e;
	}
	getContext(e) {
		return this._executionContexts[e];
	}
	get contextCount() {
		return this._executionContexts.length;
	}
	removeContext(e) {
		if (e < 0 || e >= this._executionContexts.length) return;
		let [t] = this._executionContexts.splice(e, 1);
		return t._clearPendingBlocks(), t;
	}
	getAllBlocks() {
		return this._allBlocks;
	}
	addBlock(e) {
		this._allBlocks.indexOf(e) === -1 && this._allBlocks.push(e);
	}
	removeBlock(e) {
		let t = this._allBlocks.indexOf(e);
		if (t !== -1 && this._allBlocks.splice(t, 1), e instanceof f && "type" in e) {
			let t = e, n = this._eventBlocks[t.type];
			if (n) {
				let e = n.indexOf(t);
				e !== -1 && n.splice(e, 1);
			}
		}
		if (e instanceof p) for (let t of this._executionContexts) e._cancelPendingTasks(t), e._resetAfterCanceled(t);
		for (let t of e.dataInputs) t.disconnectFromAll();
		for (let t of e.dataOutputs) t.disconnectFromAll();
		if (e instanceof f) {
			for (let t of e.signalInputs) t.disconnectFromAll();
			for (let t of e.signalOutputs) t.disconnectFromAll();
		}
	}
	addEventBlock(e) {
		if (this.addBlock(e), (e.type === "PointerOver" || e.type === "PointerOut") && (this._scene.constantlyUpdateMeshUnderPointer = !0), this._eventBlocks[e.type].push(e), this.state === 1) for (let t of this._executionContexts) e._startPendingTasks(t);
		else this.onStateChangedObservable.addOnce((t) => {
			if (t === 1) for (let t of this._executionContexts) e._startPendingTasks(t);
		});
	}
	stop() {
		if (this.state !== 0) {
			this._detachEventObserver(), this.state = 0;
			for (let e of this._executionContexts) e._clearPendingBlocks(), e._clearPendingActivation();
			this._executionContexts.length = 0;
		}
	}
	pause() {
		if (this.state === 1) {
			this._detachEventObserver(), this.state = 2;
			for (let e of this._executionContexts) e._clearPendingBlocks();
		}
	}
	start(e = !1) {
		if (this.state === 1) return;
		let t = this.state === 2;
		this._executionContexts.length === 0 && this.createContext(), this._attachEventObserver(), this.state = 1, this._startPendingEvents(), t || (this._sceneEventCoordinator.sceneReadyTriggered = !1, e || this._scene.isReady(!0) ? (this._sceneEventCoordinator.sceneReadyTriggered = !0, this._sceneEventCoordinator.onEventTriggeredObservable.notifyObservers({ type: "SceneReady" })) : this._scene.executeWhenReady(() => {
			this.state === 1 && !this._sceneEventCoordinator.sceneReadyTriggered && (this._sceneEventCoordinator.sceneReadyTriggered = !0, this._sceneEventCoordinator.onEventTriggeredObservable.notifyObservers({ type: "SceneReady" }));
		}, !0));
	}
	_startPendingEvents() {
		for (let e of this._executionContexts) for (let t in this._eventBlocks) {
			let n = this._getContextualOrder(t, e);
			for (let t of n) t._startPendingTasks(e);
		}
	}
	_getContextualOrder(e, t) {
		let n = this._eventBlocks[e].sort((e, t) => t.initPriority - e.initPriority);
		if (e === "MeshPick" || e === "PointerOver" || e === "PointerOut") {
			let r = [];
			for (let i of n) {
				let a = e === "MeshPick" ? i.asset.getValue(t) : i._getReferencedMesh(t), o = 0;
				for (; o < n.length; o++) {
					let r = n[o], i = e === "MeshPick" ? r.asset.getValue(t) : r._getReferencedMesh(t);
					if (a && i && m(a, i)) break;
				}
				r.splice(o, 0, i);
			}
			return r;
		}
		return n;
	}
	dispose() {
		if (this._detachEventObserver(), this._sceneEventCoordinator.dispose(), this.state !== 0) {
			this.state = 0;
			for (let e of this._executionContexts) e._clearPendingBlocks(), e._clearPendingActivation();
			this._executionContexts.length = 0;
			for (let e in this._eventBlocks) this._eventBlocks[e].length = 0;
			this._allBlocks.length = 0;
		}
	}
	visitAllBlocks(e) {
		let t = [], n = /* @__PURE__ */ new Set();
		for (let e in this._eventBlocks) for (let r of this._eventBlocks[e]) t.push(r), n.add(r.uniqueId);
		for (; t.length > 0;) {
			let r = t.pop();
			e(r);
			for (let e of r.dataInputs) for (let r of e._connectedPoint) n.has(r._ownerBlock.uniqueId) || (t.push(r._ownerBlock), n.add(r._ownerBlock.uniqueId));
			if (r instanceof f) for (let e of r.signalOutputs) for (let r of e._connectedPoint) n.has(r._ownerBlock.uniqueId) || (t.push(r._ownerBlock), n.add(r._ownerBlock.uniqueId));
		}
	}
	validate() {
		return D(this, this._allBlocks);
	}
	serialize(e = {}, t) {
		e.name = this.name, e.uniqueId = this.uniqueId, this.metadata !== void 0 && (e.metadata = this.metadata), e.allBlocks = [];
		let n = /* @__PURE__ */ new Set(), r = (t) => {
			if (n.has(t.uniqueId)) return;
			n.add(t.uniqueId);
			let r = {};
			t.serialize(r), e.allBlocks.push(r);
		};
		this.visitAllBlocks(r);
		for (let e of this._allBlocks) r(e);
		e.executionContexts = [];
		for (let n of this._executionContexts) {
			let r = {};
			n.serialize(r, t), e.executionContexts.push(r);
		}
	}
	async edit(e) {
		return await new Promise((n) => {
			if (this._BJSFLOWGRAPHEDITOR = this._BJSFLOWGRAPHEDITOR || this._getGlobalFlowGraphEditor(), this._BJSFLOWGRAPHEDITOR === void 0) {
				let r = e && e.editorURL ? e.editorURL : t.EditorURL;
				s.LoadBabylonScript(r, () => {
					this._BJSFLOWGRAPHEDITOR = this._BJSFLOWGRAPHEDITOR || this._getGlobalFlowGraphEditor(), this._createFlowGraphEditor(e?.flowGraphEditorConfig), n();
				});
			} else this._createFlowGraphEditor(e?.flowGraphEditorConfig), n();
		});
	}
	_createFlowGraphEditor(e) {
		let t = {
			flowGraph: this,
			hostScene: this._scene,
			attachToLiveScene: !0,
			...e
		};
		this._BJSFLOWGRAPHEDITOR.FlowGraphEditor.Show(t);
	}
};
M.EditorURL = `${s._DefaultCdnUrl}/v${n.Version}/flowGraphEditor/babylon.flowGraphEditor.js`;
//#endregion
//#region node_modules/@babylonjs/core/FlowGraph/flowGraphHostResolver.js
var N = "flowgraph://events/";
function P(e) {
	return N + e;
}
function F(e) {
	return e.startsWith("flowgraph://events/") ? e.substring(19) : void 0;
}
//#endregion
//#region node_modules/@babylonjs/core/FlowGraph/flowGraphCoordinator.js
var I = class n {
	static get OnFlowGraphAddedObservable() {
		return this._OnFlowGraphAddedObservable;
	}
	static get OnFlowGraphRemovedObservable() {
		return this._OnFlowGraphRemovedObservable;
	}
	constructor(e) {
		this.config = e, this.dispatchEventsSynchronously = !0, this._flowGraphs = [], this._customEventsMap = /* @__PURE__ */ new Map(), this._eventExecutionCounter = /* @__PURE__ */ new Map(), this._executeOnNextFrame = [], this._eventUniqueId = 0, this._eventDispatchStack = [], this._attachToScene(this.config.scene);
	}
	_attachToScene(e) {
		this._disposeObserver = e.onDisposeObservable.add(() => {
			this.dispose();
		}), this._onBeforeRenderObserver = e.onBeforeRenderObservable.add(() => {
			this._eventExecutionCounter.clear();
			let e = this._executeOnNextFrame.slice(0);
			if (e.length) for (let t of e) {
				this.notifyCustomEvent(t.id, t.data, !1);
				let e = this._executeOnNextFrame.findIndex((e) => e.uniqueId === t.uniqueId);
				e !== -1 && this._executeOnNextFrame.splice(e, 1);
			}
		});
		let t = n.SceneCoordinators.get(e);
		t || (t = [], n.SceneCoordinators.set(e, t)), t.push(this);
	}
	_detachFromScene(e) {
		this._disposeObserver.remove(), this._onBeforeRenderObserver.remove();
		let t = n.SceneCoordinators.get(e);
		if (!t) return;
		let r = t.indexOf(this);
		r !== -1 && t.splice(r, 1);
	}
	_setScene(e, t = !0) {
		let n = this.config.scene;
		if (e !== n) {
			if (this._detachFromScene(n), this.config.scene = e, t) for (let t of this._flowGraphs) t.setScene(e);
			this._attachToScene(e);
		}
	}
	createGraph(e) {
		let t = e ?? `Graph ${this._flowGraphs.length + 1}`, r = new M({
			scene: this.config.scene,
			coordinator: this,
			name: t
		});
		return this._flowGraphs.push(r), n._OnFlowGraphAddedObservable.notifyObservers(r), r;
	}
	removeGraph(e) {
		let t = this._flowGraphs.indexOf(e);
		t !== -1 && (e.dispose(), this._flowGraphs.splice(t, 1), n._OnFlowGraphRemovedObservable.notifyObservers(e));
	}
	start() {
		for (let e of this._flowGraphs) e.start();
	}
	dispose() {
		for (let e of this._flowGraphs) e.dispose(), n._OnFlowGraphRemovedObservable.notifyObservers(e);
		this._flowGraphs.length = 0, this._detachFromScene(this.config.scene);
	}
	serialize(e, t) {
		e._flowGraphs = [];
		for (let n of this._flowGraphs) {
			let r = {};
			n.serialize(r, t), e._flowGraphs.push(r);
		}
		e.dispatchEventsSynchronously = this.dispatchEventsSynchronously;
	}
	get flowGraphs() {
		return this._flowGraphs;
	}
	getCustomEventObservable(t) {
		let n = this._customEventsMap.get(t);
		return n || (n = new e(), this._customEventsMap.set(t, n)), n;
	}
	notifyCustomEvent(e, r, i = !this.dispatchEventsSynchronously) {
		if (i) {
			this._executeOnNextFrame.push({
				id: e,
				data: r,
				uniqueId: this._eventUniqueId++
			});
			return;
		}
		if (this._eventExecutionCounter.has(e)) {
			let r = this._eventExecutionCounter.get(e);
			if (this._eventExecutionCounter.set(e, r + 1), r >= n.MaxEventTypeExecutionPerFrame) {
				r === n.MaxEventTypeExecutionPerFrame && t.Warn(`FlowGraphCoordinator: Too many executions of event "${e}".`);
				return;
			}
		} else this._eventExecutionCounter.set(e, 1);
		let a = this._customEventsMap.get(e);
		a && a.notifyObservers(r);
	}
	_beginEventDispatch(e, t) {
		this._eventDispatchStack.push({
			eventId: e,
			state: t,
			propagationStopped: !1
		});
	}
	_endEventDispatch() {
		return this._eventDispatchStack.pop();
	}
	stopEventPropagation(e, t) {
		if (typeof e != "string") return;
		let n = (this.config.hostResolver?.decodeEventReference ?? F)(e);
		if (n !== void 0) {
			for (let e = this._eventDispatchStack.length - 1; e >= 0; e--) if (this._eventDispatchStack[e].eventId === n) {
				this._eventDispatchStack[e].propagationStopped = !0, t && (this._eventDispatchStack[e].state.skipNextObservers = !0);
				return;
			}
		}
	}
	_getEventReference(e) {
		let t = this.config.hostResolver?.encodeEventReference;
		return t ? t(e) : P(e);
	}
};
I.MaxEventsPerType = 30, I.MaxEventTypeExecutionPerFrame = 30, I.SceneCoordinators = /* @__PURE__ */ new Map(), I._OnFlowGraphAddedObservable = new e(), I._OnFlowGraphRemovedObservable = new e();
//#endregion
export { I as t };
