//#region node_modules/@babylonjs/core/Misc/smartArray.js
var e = class e {
	constructor(t) {
		this.length = 0, this.data = Array(t), this._id = e._GlobalId++;
	}
	push(e) {
		this.data[this.length++] = e, this.length > this.data.length && (this.data.length *= 2);
	}
	forEach(e) {
		for (let t = 0; t < this.length; t++) e(this.data[t]);
	}
	sort(e) {
		this.data.sort(e);
	}
	reset() {
		this.length = 0;
	}
	dispose() {
		this.reset(), this.data && (this.data.length = 0);
	}
	concat(e) {
		if (e.length !== 0) {
			this.length + e.length > this.data.length && (this.data.length = (this.length + e.length) * 2);
			for (let t = 0; t < e.length; t++) this.data[this.length++] = (e.data || e)[t];
		}
	}
	indexOf(e) {
		let t = this.data.indexOf(e);
		return t >= this.length ? -1 : t;
	}
	contains(e) {
		return this.indexOf(e) !== -1;
	}
};
e._GlobalId = 0;
var t = class extends e {
	constructor() {
		super(...arguments), this._duplicateId = 0;
	}
	push(e) {
		super.push(e), e.__smartArrayFlags ||= {}, e.__smartArrayFlags[this._id] = this._duplicateId;
	}
	pushNoDuplicate(e) {
		return e.__smartArrayFlags && e.__smartArrayFlags[this._id] === this._duplicateId ? !1 : (this.push(e), !0);
	}
	reset() {
		super.reset(), this._duplicateId++;
	}
	concatWithNoDuplicate(e) {
		if (e.length !== 0) {
			this.length + e.length > this.data.length && (this.data.length = (this.length + e.length) * 2);
			for (let t = 0; t < e.length; t++) {
				let n = (e.data || e)[t];
				this.pushNoDuplicate(n);
			}
		}
	}
};
//#endregion
export { t as n, e as t };
