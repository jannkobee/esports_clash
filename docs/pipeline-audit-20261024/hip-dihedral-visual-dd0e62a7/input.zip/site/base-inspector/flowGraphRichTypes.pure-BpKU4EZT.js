import { a as e, d as t, l as n, n as r, o as i, t as a, u as o } from "./math.color.pure-CPmbqLkh.js";
import { t as s } from "./flowGraphInteger.pure-DqL1vt3x.js";
import { c, s as l } from "./flowGraphBlock-BTSj91tT.js";
//#region node_modules/@babylonjs/core/FlowGraph/flowGraphRichTypes.pure.js
var u;
(function(e) {
	e.Any = "any", e.String = "string", e.Number = "number", e.Boolean = "boolean", e.Object = "object", e.Integer = "FlowGraphInteger", e.Vector2 = "Vector2", e.Vector3 = "Vector3", e.Vector4 = "Vector4", e.Quaternion = "Quaternion", e.Matrix = "Matrix", e.Matrix2D = "Matrix2D", e.Matrix3D = "Matrix3D", e.Color3 = "Color3", e.Color4 = "Color4";
})(u ||= {});
var d = class {
	constructor(e, t, n = -1) {
		this.typeName = e, this.defaultValue = t, this.animationType = n;
	}
	serialize(e) {
		e.typeName = this.typeName, e.defaultValue = this.defaultValue;
	}
}, f = new d("any", void 0), p = new d("string", ""), m = new d("number", 0, 0), h = new d("boolean", !1), g = new d("Vector2", n.Zero(), 5), _ = new d("Vector3", o.Zero(), 1), v = new d("Vector4", t.Zero()), y = new d("Matrix", e.Identity(), 3), b = new d("Matrix2D", new l()), x = new d("Matrix3D", new c()), S = new d("Color3", a.Black(), 4), C = new d("Color4", new r(0, 0, 0, 0), 7), w = new d("Quaternion", i.Identity(), 2), T = new d("FlowGraphInteger", new s(0), 0);
function E(e) {
	let t = e;
	switch (typeof e) {
		case "string": return p;
		case "number": return m;
		case "boolean": return h;
		case "object":
			if (t.getClassName) switch (t.getClassName()) {
				case "Vector2": return g;
				case "Vector3": return _;
				case "Vector4": return v;
				case "Matrix": return y;
				case "Color3": return S;
				case "Color4": return C;
				case "Quaternion": return w;
				case "FlowGraphInteger": return T;
				case "Matrix2D": return b;
				case "Matrix3D": return x;
			}
			return f;
		default: return f;
	}
}
function D(e) {
	switch (e) {
		case "string": return p;
		case "number": return m;
		case "boolean": return h;
		case "Vector2": return g;
		case "Vector3": return _;
		case "Vector4": return v;
		case "Matrix": return y;
		case "Color3": return S;
		case "Color4": return C;
		case "Quaternion": return w;
		case "FlowGraphInteger": return T;
		case "Matrix2D": return b;
		case "Matrix3D": return x;
		default: return f;
	}
}
function O(e) {
	switch (e) {
		case "number": return 0;
		case "Vector2": return 5;
		case "Vector3": return 1;
		case "Matrix": return 3;
		case "Color3": return 4;
		case "Color4": return 7;
		case "Quaternion": return 2;
		default: return 0;
	}
}
function k(e) {
	switch (e) {
		case 0: return m;
		case 5: return g;
		case 1: return _;
		case 3: return y;
		case 4: return S;
		case 7: return C;
		case 2: return w;
		default: return f;
	}
}
var A = !1;
function j() {
	A || (A = !0, w.typeTransformer = (e) => {
		if (e.getClassName) {
			if (e.getClassName() === "Vector4") return i.FromArray(e.asArray());
			if (e.getClassName() === "Vector3") return i.FromEulerVector(e);
			if (e.getClassName() === "Matrix") return i.FromRotationMatrix(e);
		}
		return e;
	});
}
//#endregion
export { E as _, y as a, m as c, g as d, _ as f, D as g, k as h, T as i, w as l, O as m, f as n, b as o, v as p, h as r, x as s, j as t, p as u };
