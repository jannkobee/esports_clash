import { a as e, d as t, l as n, u as r } from "./math.color.pure-CPmbqLkh.js";
import { n as i } from "./typeStore-pENEWnX2.js";
import { c as a, s as o, t as s } from "./flowGraphBlock-BTSj91tT.js";
import { a as c, c as l, d as u, f as d, o as f, p, s as m } from "./flowGraphRichTypes.pure-BpKU4EZT.js";
import { t as h } from "./flowGraphCachedOperationBlock-BsIcMusH.js";
//#region node_modules/@babylonjs/core/FlowGraph/Blocks/Data/Math/flowGraphMathCombineExtractBlocks.pure.js
var g = class extends h {
	constructor(e, t, n) {
		super(t, n);
		for (let t = 0; t < e; t++) this.registerDataInput(`input_${t}`, l, 0);
	}
}, _ = class extends s {
	constructor(e, t, n) {
		super(n), this.registerDataInput("input", t);
		for (let t = 0; t < e; t++) this.registerDataOutput(`output_${t}`, l, 0);
	}
}, v = class extends g {
	constructor(e) {
		super(2, u, e);
	}
	_doOperation(e) {
		e._hasExecutionVariable(this, "cachedVector") || e._setExecutionVariable(this, "cachedVector", new n());
		let t = e._getExecutionVariable(this, "cachedVector", null);
		return t.set(this.getDataInput("input_0").getValue(e), this.getDataInput("input_1").getValue(e)), t;
	}
	getClassName() {
		return "FlowGraphCombineVector2Block";
	}
}, y = class extends g {
	constructor(e) {
		super(3, d, e);
	}
	_doOperation(e) {
		e._hasExecutionVariable(this, "cachedVector") || e._setExecutionVariable(this, "cachedVector", new r());
		let t = e._getExecutionVariable(this, "cachedVector", null);
		return t.set(this.getDataInput("input_0").getValue(e), this.getDataInput("input_1").getValue(e), this.getDataInput("input_2").getValue(e)), t;
	}
	getClassName() {
		return "FlowGraphCombineVector3Block";
	}
}, b = class extends g {
	constructor(e) {
		super(4, p, e);
	}
	_doOperation(e) {
		e._hasExecutionVariable(this, "cachedVector") || e._setExecutionVariable(this, "cachedVector", new t());
		let n = e._getExecutionVariable(this, "cachedVector", null);
		return n.set(this.getDataInput("input_0").getValue(e), this.getDataInput("input_1").getValue(e), this.getDataInput("input_2").getValue(e), this.getDataInput("input_3").getValue(e)), n;
	}
	getClassName() {
		return "FlowGraphCombineVector4Block";
	}
}, x = class extends g {
	constructor(e) {
		super(16, c, e);
	}
	_doOperation(t) {
		t._hasExecutionVariable(this, "cachedMatrix") || t._setExecutionVariable(this, "cachedMatrix", new e());
		let n = t._getExecutionVariable(this, "cachedMatrix", null);
		return this.config?.inputIsColumnMajor === !1 ? (n.set(this.getDataInput("input_0").getValue(t), this.getDataInput("input_4").getValue(t), this.getDataInput("input_8").getValue(t), this.getDataInput("input_12").getValue(t), this.getDataInput("input_1").getValue(t), this.getDataInput("input_5").getValue(t), this.getDataInput("input_9").getValue(t), this.getDataInput("input_13").getValue(t), this.getDataInput("input_2").getValue(t), this.getDataInput("input_6").getValue(t), this.getDataInput("input_10").getValue(t), this.getDataInput("input_14").getValue(t), this.getDataInput("input_3").getValue(t), this.getDataInput("input_7").getValue(t), this.getDataInput("input_11").getValue(t), this.getDataInput("input_15").getValue(t)), n) : (n.set(this.getDataInput("input_0").getValue(t), this.getDataInput("input_1").getValue(t), this.getDataInput("input_2").getValue(t), this.getDataInput("input_3").getValue(t), this.getDataInput("input_4").getValue(t), this.getDataInput("input_5").getValue(t), this.getDataInput("input_6").getValue(t), this.getDataInput("input_7").getValue(t), this.getDataInput("input_8").getValue(t), this.getDataInput("input_9").getValue(t), this.getDataInput("input_10").getValue(t), this.getDataInput("input_11").getValue(t), this.getDataInput("input_12").getValue(t), this.getDataInput("input_13").getValue(t), this.getDataInput("input_14").getValue(t), this.getDataInput("input_15").getValue(t)), n);
	}
	getClassName() {
		return "FlowGraphCombineMatrixBlock";
	}
}, S = class extends g {
	constructor(e) {
		super(4, f, e);
	}
	_doOperation(e) {
		e._hasExecutionVariable(this, "cachedMatrix") || e._setExecutionVariable(this, "cachedMatrix", new o());
		let t = e._getExecutionVariable(this, "cachedMatrix", null), n = this.config?.inputIsColumnMajor !== !1;
		return t.fromArray(n ? [
			this.getDataInput("input_0").getValue(e),
			this.getDataInput("input_1").getValue(e),
			this.getDataInput("input_2").getValue(e),
			this.getDataInput("input_3").getValue(e)
		] : [
			this.getDataInput("input_0").getValue(e),
			this.getDataInput("input_2").getValue(e),
			this.getDataInput("input_1").getValue(e),
			this.getDataInput("input_3").getValue(e)
		]), t;
	}
	getClassName() {
		return "FlowGraphCombineMatrix2DBlock";
	}
}, C = class extends g {
	constructor(e) {
		super(9, m, e);
	}
	_doOperation(e) {
		e._hasExecutionVariable(this, "cachedMatrix") || e._setExecutionVariable(this, "cachedMatrix", new a());
		let t = e._getExecutionVariable(this, "cachedMatrix", null), n = this.config?.inputIsColumnMajor !== !1;
		return t.fromArray(n ? [
			this.getDataInput("input_0").getValue(e),
			this.getDataInput("input_1").getValue(e),
			this.getDataInput("input_2").getValue(e),
			this.getDataInput("input_3").getValue(e),
			this.getDataInput("input_4").getValue(e),
			this.getDataInput("input_5").getValue(e),
			this.getDataInput("input_6").getValue(e),
			this.getDataInput("input_7").getValue(e),
			this.getDataInput("input_8").getValue(e)
		] : [
			this.getDataInput("input_0").getValue(e),
			this.getDataInput("input_3").getValue(e),
			this.getDataInput("input_6").getValue(e),
			this.getDataInput("input_1").getValue(e),
			this.getDataInput("input_4").getValue(e),
			this.getDataInput("input_7").getValue(e),
			this.getDataInput("input_2").getValue(e),
			this.getDataInput("input_5").getValue(e),
			this.getDataInput("input_8").getValue(e)
		]), t;
	}
	getClassName() {
		return "FlowGraphCombineMatrix3DBlock";
	}
}, w = class extends _ {
	constructor(e) {
		super(2, u, e);
	}
	_updateOutputs(e) {
		let t = this.getDataInput("input")?.getValue(e);
		t || (t = n.Zero(), this.getDataInput("input").setValue(t, e)), this.getDataOutput("output_0").setValue(t.x, e), this.getDataOutput("output_1").setValue(t.y, e);
	}
	getClassName() {
		return "FlowGraphExtractVector2Block";
	}
}, T = class extends _ {
	constructor(e) {
		super(3, d, e);
	}
	_updateOutputs(e) {
		let t = this.getDataInput("input")?.getValue(e);
		t || (t = r.Zero(), this.getDataInput("input").setValue(t, e)), this.getDataOutput("output_0").setValue(t.x, e), this.getDataOutput("output_1").setValue(t.y, e), this.getDataOutput("output_2").setValue(t.z, e);
	}
	getClassName() {
		return "FlowGraphExtractVector3Block";
	}
}, E = class extends _ {
	constructor(e) {
		super(4, p, e);
	}
	_updateOutputs(e) {
		let n = this.getDataInput("input")?.getValue(e);
		n || (n = t.Zero(), this.getDataInput("input").setValue(n, e)), this.getDataOutput("output_0").setValue(n.x, e), this.getDataOutput("output_1").setValue(n.y, e), this.getDataOutput("output_2").setValue(n.z, e), this.getDataOutput("output_3").setValue(n.w, e);
	}
	getClassName() {
		return "FlowGraphExtractVector4Block";
	}
}, D = class extends _ {
	constructor(e) {
		super(16, c, e);
	}
	_updateOutputs(t) {
		let n = this.getDataInput("input")?.getValue(t);
		n || (n = e.Identity(), this.getDataInput("input").setValue(n, t));
		for (let e = 0; e < 16; e++) this.getDataOutput(`output_${e}`).setValue(n.m[e], t);
	}
	getClassName() {
		return "FlowGraphExtractMatrixBlock";
	}
}, O = class extends _ {
	constructor(e) {
		super(4, f, e);
	}
	_updateOutputs(e) {
		let t = this.getDataInput("input")?.getValue(e);
		t || (t = new o(), this.getDataInput("input").setValue(t, e));
		for (let n = 0; n < 4; n++) this.getDataOutput(`output_${n}`).setValue(t.m[n], e);
	}
	getClassName() {
		return "FlowGraphExtractMatrix2DBlock";
	}
}, k = class extends _ {
	constructor(e) {
		super(9, m, e);
	}
	_updateOutputs(e) {
		let t = this.getDataInput("input")?.getValue(e);
		t || (t = new a(), this.getDataInput("input").setValue(t, e));
		for (let n = 0; n < 9; n++) this.getDataOutput(`output_${n}`).setValue(t.m[n], e);
	}
	getClassName() {
		return "FlowGraphExtractMatrix3DBlock";
	}
}, A = !1;
function j() {
	A || (A = !0, i("FlowGraphCombineVector2Block", v), i("FlowGraphCombineVector3Block", y), i("FlowGraphCombineVector4Block", b), i("FlowGraphCombineMatrixBlock", x), i("FlowGraphCombineMatrix2DBlock", S), i("FlowGraphCombineMatrix3DBlock", C), i("FlowGraphExtractVector2Block", w), i("FlowGraphExtractVector3Block", T), i("FlowGraphExtractVector4Block", E), i("FlowGraphExtractMatrixBlock", D), i("FlowGraphExtractMatrix2DBlock", O), i("FlowGraphExtractMatrix3DBlock", k));
}
//#endregion
export { S as FlowGraphCombineMatrix2DBlock, C as FlowGraphCombineMatrix3DBlock, x as FlowGraphCombineMatrixBlock, v as FlowGraphCombineVector2Block, y as FlowGraphCombineVector3Block, b as FlowGraphCombineVector4Block, O as FlowGraphExtractMatrix2DBlock, k as FlowGraphExtractMatrix3DBlock, D as FlowGraphExtractMatrixBlock, w as FlowGraphExtractVector2Block, T as FlowGraphExtractVector3Block, E as FlowGraphExtractVector4Block, j as RegisterFlowGraphMathCombineExtractBlocks };
