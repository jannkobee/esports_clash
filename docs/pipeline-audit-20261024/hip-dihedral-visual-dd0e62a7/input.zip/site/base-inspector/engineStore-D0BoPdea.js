//#region node_modules/@babylonjs/core/Misc/observable.pure.js
var e = typeof WeakRef < "u", t = class {
	constructor(e, t = !1, n, r) {
		this.initialize(e, t, n, r);
	}
	initialize(e, t = !1, n, r) {
		return this.mask = e, this.skipNextObservers = t, this.target = n, this.currentTarget = r, this;
	}
}, n = class {
	constructor(e, t, n = null) {
		this.callback = e, this.mask = t, this.scope = n, this._willBeUnregistered = !1, this.unregisterOnNextCall = !1, this._remove = null;
	}
	remove(e = !1) {
		this._remove && this._remove(e);
	}
}, r = class r {
	static FromPromise(e, t) {
		let n = new r();
		return e.then((e) => {
			n.notifyObservers(e);
		}).catch((e) => {
			if (t) t.notifyObservers(e);
			else throw e;
		}), n;
	}
	get observers() {
		return this._observers;
	}
	constructor(e, n = !1) {
		this.notifyIfTriggered = n, this._observers = [], this._numObserversMarkedAsDeleted = 0, this._hasNotified = !1, this._eventState = new t(0), e && (this._onObserverAdded = e);
	}
	add(t, r = -1, i = !1, a = null, o = !1) {
		if (!t) return null;
		let s = new n(t, r, a);
		s.unregisterOnNextCall = o, i ? this._observers.unshift(s) : this._observers.push(s), this._onObserverAdded && this._onObserverAdded(s), this._hasNotified && this.notifyIfTriggered && this.notifyObserver(s, this._lastNotifiedValue);
		let c = e ? new WeakRef(this) : { deref: () => this };
		return s._remove = (e = !1) => {
			let t = c.deref();
			t && (e ? t.remove(s) : t._remove(s));
		}, s;
	}
	addOnce(e) {
		return this.add(e, void 0, void 0, void 0, !0);
	}
	remove(e) {
		return e ? (e._remove = null, this._observers.indexOf(e) !== -1 && (this._deferUnregister(e), !0)) : !1;
	}
	removeCallback(e, t) {
		for (let n = 0; n < this._observers.length; n++) {
			let r = this._observers[n];
			if (!r._willBeUnregistered && r.callback === e && (!t || t === r.scope)) return this._deferUnregister(r), !0;
		}
		return !1;
	}
	_deferUnregister(e) {
		e._willBeUnregistered || (this._numObserversMarkedAsDeleted++, e.unregisterOnNextCall = !1, e._willBeUnregistered = !0, setTimeout(() => {
			this._remove(e);
		}, 0));
	}
	_remove(e, t = !0) {
		if (!e) return !1;
		let n = this._observers.indexOf(e);
		return n !== -1 && (t && this._numObserversMarkedAsDeleted--, this._observers.splice(n, 1), !0);
	}
	makeObserverTopPriority(e) {
		this._remove(e, !1), this._observers.unshift(e);
	}
	makeObserverBottomPriority(e) {
		this._remove(e, !1), this._observers.push(e);
	}
	notifyObservers(e, t = -1, n, r, i) {
		if (this.notifyIfTriggered && (this._hasNotified = !0, this._lastNotifiedValue = e), !this._observers.length) return !0;
		let a = this._eventState;
		a.mask = t, a.target = n, a.currentTarget = r, a.skipNextObservers = !1, a.lastReturnValue = e, a.userInfo = i;
		for (let n of this._observers) if (!n._willBeUnregistered && (n.mask & t && (n.unregisterOnNextCall && this._deferUnregister(n), a.lastReturnValue = n.scope ? n.callback.apply(n.scope, [e, a]) : n.callback(e, a)), a.skipNextObservers)) return !1;
		return !0;
	}
	notifyObserver(e, t, n = -1) {
		if (this.notifyIfTriggered && (this._hasNotified = !0, this._lastNotifiedValue = t), e._willBeUnregistered) return;
		let r = this._eventState;
		r.mask = n, r.skipNextObservers = !1, e.unregisterOnNextCall && this._deferUnregister(e), e.callback(t, r);
	}
	hasObservers() {
		return this._observers.length - this._numObserversMarkedAsDeleted > 0;
	}
	clear() {
		for (; this._observers.length;) {
			let e = this._observers.pop();
			e && (e._remove = null);
		}
		this._onObserverAdded = null, this._numObserversMarkedAsDeleted = 0, this.cleanLastNotifiedState();
	}
	cleanLastNotifiedState() {
		this._hasNotified = !1, this._lastNotifiedValue = void 0;
	}
	clone() {
		let e = new r();
		return e._observers = this._observers.slice(0), e;
	}
	hasSpecificMask(e = -1) {
		for (let t of this._observers) if (t.mask & e || t.mask === e) return !0;
		return !1;
	}
}, i = class {
	static get LastCreatedEngine() {
		return this.Instances.length === 0 ? null : this.Instances[this.Instances.length - 1];
	}
	static get LastCreatedScene() {
		return this._LastCreatedScene;
	}
};
i.Instances = [], i.OnEnginesDisposedObservable = new r(), i._LastCreatedScene = null, i.UseFallbackTexture = !0, i.FallbackTexture = "";
//#endregion
export { r as n, i as t };
