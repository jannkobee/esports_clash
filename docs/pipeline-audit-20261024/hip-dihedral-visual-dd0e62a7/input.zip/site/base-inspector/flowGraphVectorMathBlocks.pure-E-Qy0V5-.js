import { t as e } from "./math.scalar.functions-D7lyzZPV.js";
import { a as t, d as n, l as r, o as i, u as a } from "./math.color.pure-CPmbqLkh.js";
import { n as o } from "./typeStore-pENEWnX2.js";
import { t as s } from "./flowGraphBlock-BTSj91tT.js";
import { i as c } from "./utils-Cc6lHVNn.js";
import { a as l, c as u, d, f, g as p, l as m, n as h, r as g } from "./flowGraphRichTypes.pure-BpKU4EZT.js";
import { t as _ } from "./flowGraphCachedOperationBlock-BsIcMusH.js";
import { t as v } from "./flowGraphBinaryOperationBlock-CDgwbjsR.js";
import { t as y } from "./flowGraphUnaryOperationBlock-CzhraRE5.js";
import { t as b } from "./flowGraphTernaryOperationBlock-BSG-deqh.js";
//#region node_modules/@babylonjs/core/Maths/math.vector.functions.js
function x(e, t) {
	return e.x * t.x + e.y * t.y + e.z * t.z;
}
function S(e, t) {
	return e.x * t.x + e.y * t.y + e.z * t.z + e.w * t.w;
}
//#endregion
//#region node_modules/@babylonjs/core/FlowGraph/flowGraphMath.js
var C = 1e-6;
function w(e) {
	let t = Math.abs(e.x), n = Math.abs(e.y), r = Math.abs(e.z), i;
	return i = t <= n && t <= r ? a.RightReadOnly : n <= r ? a.UpReadOnly : a.LeftHandedForwardReadOnly, a.Cross(e, i).normalize();
}
function T(t, n) {
	return Math.acos(e(S(t, n), -1, 1)) * 2;
}
function E(e, t) {
	let n = new i();
	return D(e, t, n), n;
}
function D(e, t, n) {
	let r = x(e, t);
	if (Number.isFinite(r) && r > .999999) return n.copyFromFloats(0, 0, 0, 1), n;
	if (Number.isFinite(r) && r < -.999999) {
		let t = w(e);
		return n.copyFromFloats(t.x, t.y, t.z, 0), n;
	}
	let i = a.Cross(e, t).normalize(), o = Math.sqrt(.5 - .5 * r);
	return n.copyFromFloats(i.x * o, i.y * o, i.z * o, Math.sqrt(.5 + .5 * r)), n;
}
function O(t, n, i) {
	let a = Math.sqrt(t.x * t.x + t.y * t.y), o = Math.sqrt(n.x * n.x + n.y * n.y);
	if (a < C || o < C) return new r((1 - i) * t.x + i * n.x, (1 - i) * t.y + i * n.y);
	let s = t.x / a, c = t.y / a, l = n.x / o, u = n.y / o, d = Math.acos(e(s * l + c * u, -1, 1));
	s * u - c * l < 0 && (d = -d);
	let f = (1 - i) * a + i * o, p = Math.cos(i * d), m = Math.sin(i * d);
	return new r((s * p - c * m) * f, (s * m + c * p) * f);
}
function k(t, n, r) {
	let o = t.length(), s = n.length(), c = () => new a((1 - r) * t.x + r * n.x, (1 - r) * t.y + r * n.y, (1 - r) * t.z + r * n.z);
	if (o < C || s < C) return c();
	let l = new a(t.x / o, t.y / o, t.z / o), u = new a(n.x / s, n.y / s, n.z / s), d = x(l, u);
	if (d > .999999) return c();
	let f;
	f = d < -.999999 ? w(l) : a.Cross(l, u).normalize();
	let p = r * Math.acos(e(d, -1, 1)), m = i.RotationAxis(f, p), h = (1 - r) * o + r * s;
	return l.applyRotationQuaternion(m).scaleInPlace(h);
}
function A(e, n) {
	let r = new a(n.x, n.y, n.z), o = a.Cross(e, r);
	o.lengthSquared() < C * C ? o = w(r) : o.normalize();
	let s = a.Cross(r, o), c = t.FromValues(o.x, o.y, o.z, 0, s.x, s.y, s.z, 0, r.x, r.y, r.z, 0, 0, 0, 0, 1);
	return i.FromRotationMatrix(c);
}
var j = [
	"xyz",
	"xzy",
	"yxz",
	"yzx",
	"zxy",
	"zyx"
];
function M(e, t, n, r) {
	let o = i.RotationAxis(a.RightReadOnly, t), s = i.RotationAxis(a.UpReadOnly, n), c = i.RotationAxis(a.LeftHandedForwardReadOnly, r);
	switch (e) {
		case "xyz": return o.multiplyInPlace(s).multiplyInPlace(c);
		case "xzy": return o.multiplyInPlace(c).multiplyInPlace(s);
		case "yzx": return s.multiplyInPlace(c).multiplyInPlace(o);
		case "zxy": return c.multiplyInPlace(o).multiplyInPlace(s);
		case "zyx": return c.multiplyInPlace(s).multiplyInPlace(o);
		default: return s.multiplyInPlace(o).multiplyInPlace(c);
	}
}
//#endregion
//#region node_modules/@babylonjs/core/FlowGraph/Blocks/Data/Math/flowGraphVectorMathBlocks.pure.js
var N = "cachedOperationAxis", P = "cachedOperationAngle", F = "cachedExecutionId", I = class extends y {
	constructor(e) {
		super(h, u, (e) => this._polymorphicLength(e), "FlowGraphLengthBlock", e);
	}
	_polymorphicLength(e) {
		switch (c(e)) {
			case "Vector2":
			case "Vector3":
			case "Vector4":
			case "Quaternion": return e.length();
			default: throw Error(`Cannot compute length of value ${e}`);
		}
	}
}, L = class extends _ {
	constructor(e) {
		super(h, e), this.a = this.registerDataInput("a", h);
	}
	_doOperation(e) {
		return this._polymorphicNormalize(this.a.getValue(e));
	}
	_getInvalidOutputValue(e) {
		let t = this.a.getValue(e);
		switch (c(t)) {
			case "Vector2": return new r(0, 0);
			case "Vector4": return new n(0, 0, 0, 0);
			case "Quaternion": return new i(0, 0, 0, 0);
			default: return new a(0, 0, 0);
		}
	}
	_polymorphicNormalize(e) {
		switch (c(e)) {
			case "Vector2":
			case "Vector3":
			case "Vector4":
			case "Quaternion": {
				let t = e.length();
				if (t === 0 || !Number.isFinite(t)) {
					if (this.config?.nanOnZeroLength) {
						let t = e.normalizeToNew();
						return t.setAll(NaN), t;
					}
					return;
				}
				return e.normalizeToNew();
			}
			default: throw Error(`Cannot normalize value ${e}`);
		}
	}
	getClassName() {
		return "FlowGraphNormalizeBlock";
	}
}, R = class extends v {
	constructor(e) {
		super(h, h, u, (e, t) => this._polymorphicDot(e, t), "FlowGraphDotBlock", e);
	}
	_polymorphicDot(e, t) {
		switch (c(e)) {
			case "Vector2":
			case "Vector3":
			case "Vector4":
			case "Quaternion": return e.dot(t);
			default: throw Error(`Cannot get dot product of ${e} and ${t}`);
		}
	}
}, z = class extends v {
	constructor(e) {
		super(f, f, f, (e, t) => a.Cross(e, t), "FlowGraphCrossBlock", e);
	}
}, B = class extends v {
	constructor(e) {
		super(d, u, d, (e, t) => e.rotate(t), "FlowGraphRotate2DBlock", e);
	}
}, V = class extends v {
	constructor(e) {
		super(f, m, f, (e, t) => e.applyRotationQuaternion(t), "FlowGraphRotate3DBlock", e);
	}
};
function H(e, t) {
	switch (c(e)) {
		case "Vector2": return t.transformVector(e);
		case "Vector3": return t.transformVector(e);
		case "Vector4": return e = e, new n(e.x * t.m[0] + e.y * t.m[4] + e.z * t.m[8] + e.w * t.m[12], e.x * t.m[1] + e.y * t.m[5] + e.z * t.m[9] + e.w * t.m[13], e.x * t.m[2] + e.y * t.m[6] + e.z * t.m[10] + e.w * t.m[14], e.x * t.m[3] + e.y * t.m[7] + e.z * t.m[11] + e.w * t.m[15]);
		default: throw Error(`Cannot transform value ${e}`);
	}
}
var U = class extends v {
	constructor(e) {
		let t = e?.vectorType || "Vector3", n = t === "Vector2" ? "Matrix2D" : t === "Vector3" ? "Matrix3D" : "Matrix";
		super(p(t), p(n), p(t), H, "FlowGraphTransformVectorBlock", e);
	}
}, W = class extends v {
	constructor(e) {
		super(f, l, f, (e, t) => a.TransformCoordinates(e, t), "FlowGraphTransformCoordinatesBlock", e);
	}
}, G = class extends y {
	constructor(e) {
		super(m, m, (e) => e.conjugate(), "FlowGraphConjugateBlock", e);
	}
}, K = class extends v {
	constructor(e) {
		super(m, m, u, (e, t) => T(e, t), "FlowGraphAngleBetweenBlock", e);
	}
}, q = class extends v {
	constructor(e) {
		super(f, u, m, (e, t) => i.RotationAxis(e, t), "FlowGraphQuaternionFromAxisAngleBlock", e);
	}
}, J = class extends s {
	constructor(e) {
		super(e), this.a = this.registerDataInput("a", m), this.axis = this.registerDataOutput("axis", f), this.angle = this.registerDataOutput("angle", u), this.isValid = this.registerDataOutput("isValid", g);
	}
	_updateOutputs(e) {
		let t = e._getExecutionVariable(this, F, -1), n = e._getExecutionVariable(this, N, null), r = e._getExecutionVariable(this, P, null);
		if (n != null && r != null && t === e.executionId) this.axis.setValue(n, e), this.angle.setValue(r, e);
		else try {
			let { axis: t, angle: n } = this.a.getValue(e).toAxisAngle();
			e._setExecutionVariable(this, N, t), e._setExecutionVariable(this, P, n), e._setExecutionVariable(this, F, e.executionId), this.axis.setValue(t, e), this.angle.setValue(n, e), this.isValid.setValue(!0, e);
		} catch {
			this.isValid.setValue(!1, e);
		}
	}
	getClassName() {
		return "FlowGraphAxisAngleFromQuaternionBlock";
	}
}, Y = class extends v {
	constructor(e) {
		super(f, f, m, (e, t) => E(e, t), "FlowGraphQuaternionFromDirectionsBlock", e);
	}
}, X = class extends v {
	constructor(e) {
		super(f, f, m, (e, t) => A(e, t), "FlowGraphQuaternionFromUpForwardBlock", e);
	}
}, Z = class extends b {
	constructor(e) {
		super(h, h, u, h, (e, t, n) => this._polymorphicSlerp(e, t, n), "FlowGraphVectorSlerpBlock", e);
	}
	_polymorphicSlerp(e, t, n) {
		switch (c(e)) {
			case "Vector2": return O(e, t, n);
			case "Vector3": return k(e, t, n);
			default: throw Error(`Cannot slerp value ${e}`);
		}
	}
}, Q = class extends b {
	constructor(e) {
		super(u, u, u, m, (e, t, n) => M(this._order, e, t, n), "FlowGraphQuaternionFromAnglesBlock", e);
		let t = e?.order;
		this._order = typeof t == "string" && j.indexOf(t) !== -1 ? t : "yxz";
	}
}, $ = !1;
function ee() {
	$ || ($ = !0, o("FlowGraphLengthBlock", I), o("FlowGraphNormalizeBlock", L), o("FlowGraphDotBlock", R), o("FlowGraphCrossBlock", z), o("FlowGraphRotate2DBlock", B), o("FlowGraphRotate3DBlock", V), o("FlowGraphTransformVectorBlock", U), o("FlowGraphTransformCoordinatesBlock", W), o("FlowGraphConjugateBlock", G), o("FlowGraphAngleBetweenBlock", K), o("FlowGraphQuaternionFromAxisAngleBlock", q), o("FlowGraphAxisAngleFromQuaternionBlock", J), o("FlowGraphQuaternionFromDirectionsBlock", Y), o("FlowGraphQuaternionFromUpForwardBlock", X), o("FlowGraphQuaternionFromAnglesBlock", Q), o("FlowGraphVectorSlerpBlock", Z));
}
//#endregion
export { K as FlowGraphAngleBetweenBlock, J as FlowGraphAxisAngleFromQuaternionBlock, G as FlowGraphConjugateBlock, z as FlowGraphCrossBlock, R as FlowGraphDotBlock, I as FlowGraphLengthBlock, L as FlowGraphNormalizeBlock, Q as FlowGraphQuaternionFromAnglesBlock, q as FlowGraphQuaternionFromAxisAngleBlock, Y as FlowGraphQuaternionFromDirectionsBlock, X as FlowGraphQuaternionFromUpForwardBlock, B as FlowGraphRotate2DBlock, V as FlowGraphRotate3DBlock, U as FlowGraphTransformBlock, W as FlowGraphTransformCoordinatesBlock, Z as FlowGraphVectorSlerpBlock, ee as RegisterFlowGraphVectorMathBlocks };
