import { n as e, t } from "./engineStore-D0BoPdea.js";
import { t as n } from "./logger-DQIzSR_y.js";
import { t as r } from "./abstractEngine.pure-C608BZav.js";
import { b as i, x as a } from "./tools.functions-DEecYKlu.js";
import { l as o } from "./thinEngine.pure-CFnvxmRZ.js";
import { n as s } from "./buffer.pure-CgsgX1aa.js";
import { a as c, c as l, g as u, m as d, u as f } from "./math.color.pure-CPmbqLkh.js";
import { t as p } from "./math.plane-wePi4N1d.js";
import { b as m, i as h, r as g, y as _ } from "./decorators-BldPRAAT.js";
import { t as v } from "./decorators.serialization-CGAHzP43.js";
import { r as y } from "./tools.pure-Dy2G52NL.js";
import { n as b, t as x } from "./lightConstants-Dqs8OH2d.js";
import { i as ee } from "./sceneComponent-C2CdEKig.js";
import { t as te } from "./drawWrapper-DZNPKXXG.js";
//#region node_modules/@babylonjs/core/Collisions/intersectionInfo.js
var S = class {
	constructor(e, t, n) {
		this.bu = e, this.bv = t, this.distance = n, this.faceId = 0, this.subMeshId = 0, this._internalSubMeshId = 0;
	}
}, C = class e {
	constructor(e, t, n) {
		this.vectors = d(8, f.Zero), this.center = f.Zero(), this.centerWorld = f.Zero(), this.extendSize = f.Zero(), this.extendSizeWorld = f.Zero(), this.directions = d(3, f.Zero), this.vectorsWorld = d(8, f.Zero), this.minimumWorld = f.Zero(), this.maximumWorld = f.Zero(), this.minimum = f.Zero(), this.maximum = f.Zero(), this._drawWrapperFront = null, this._drawWrapperBack = null, this.reConstruct(e, t, n);
	}
	reConstruct(e, t, n) {
		let r = e.x, i = e.y, a = e.z, o = t.x, s = t.y, l = t.z, u = this.vectors;
		this.minimum.copyFromFloats(r, i, a), this.maximum.copyFromFloats(o, s, l), u[0].copyFromFloats(r, i, a), u[1].copyFromFloats(o, s, l), u[2].copyFromFloats(o, i, a), u[3].copyFromFloats(r, s, a), u[4].copyFromFloats(r, i, l), u[5].copyFromFloats(o, s, a), u[6].copyFromFloats(r, s, l), u[7].copyFromFloats(o, i, l), t.addToRef(e, this.center).scaleInPlace(.5), t.subtractToRef(e, this.extendSize).scaleInPlace(.5), this._worldMatrix = n || c.IdentityReadOnly, this._update(this._worldMatrix);
	}
	scale(t) {
		let n = e._TmpVector3, r = this.maximum.subtractToRef(this.minimum, n[0]), i = r.length();
		r.normalizeFromLength(i);
		let a = i * t, o = r.scaleInPlace(a * .5), s = this.center.subtractToRef(o, n[1]), c = this.center.addToRef(o, n[2]);
		return this.reConstruct(s, c, this._worldMatrix), this;
	}
	getWorldMatrix() {
		return this._worldMatrix;
	}
	_update(e) {
		let t = this.minimumWorld, n = this.maximumWorld, r = this.directions, i = this.vectorsWorld, a = this.vectors;
		if (e.isIdentity()) {
			t.copyFrom(this.minimum), n.copyFrom(this.maximum);
			for (let e = 0; e < 8; ++e) i[e].copyFrom(a[e]);
			this.extendSizeWorld.copyFrom(this.extendSize), this.centerWorld.copyFrom(this.center);
		} else {
			t.setAll(Number.MAX_VALUE), n.setAll(-Number.MAX_VALUE);
			for (let r = 0; r < 8; ++r) {
				let o = i[r];
				f.TransformCoordinatesToRef(a[r], e, o), t.minimizeInPlace(o), n.maximizeInPlace(o);
			}
			n.subtractToRef(t, this.extendSizeWorld).scaleInPlace(.5), n.addToRef(t, this.centerWorld).scaleInPlace(.5);
		}
		f.FromArrayToRef(e.m, 0, r[0]), f.FromArrayToRef(e.m, 4, r[1]), f.FromArrayToRef(e.m, 8, r[2]), this._worldMatrix = e;
	}
	isInFrustum(t) {
		return e.IsInFrustum(this.vectorsWorld, t);
	}
	isCompletelyInFrustum(t) {
		return e.IsCompletelyInFrustum(this.vectorsWorld, t);
	}
	intersectsPoint(e) {
		let t = this.minimumWorld, n = this.maximumWorld, r = t.x, i = t.y, a = t.z, o = n.x, s = n.y, c = n.z, l = e.x, d = e.y, f = e.z, p = -u;
		return !(o - l < p || p > l - r || s - d < p || p > d - i || c - f < p || p > f - a);
	}
	intersectsSphere(t) {
		return e.IntersectsSphere(this.minimumWorld, this.maximumWorld, t.centerWorld, t.radiusWorld);
	}
	intersectsMinMax(e, t) {
		let n = this.minimumWorld, r = this.maximumWorld, i = n.x, a = n.y, o = n.z, s = r.x, c = r.y, l = r.z, u = e.x, d = e.y, f = e.z, p = t.x, m = t.y, h = t.z;
		return !(s < u || i > p || c < d || a > m || l < f || o > h);
	}
	dispose() {
		this._drawWrapperFront?.dispose(), this._drawWrapperBack?.dispose();
	}
	static Intersects(e, t) {
		return e.intersectsMinMax(t.minimumWorld, t.maximumWorld);
	}
	static IntersectsSphere(t, n, r, i) {
		let a = e._TmpVector3[0];
		return f.ClampToRef(r, t, n, a), f.DistanceSquared(r, a) <= i * i;
	}
	static IsCompletelyInFrustum(e, t) {
		for (let n = 0; n < 6; ++n) {
			let r = t[n];
			for (let t = 0; t < 8; ++t) if (r.dotCoordinate(e[t]) < 0) return !1;
		}
		return !0;
	}
	static IsInFrustum(e, t) {
		for (let n = 0; n < 6; ++n) {
			let r = !0, i = t[n];
			for (let t = 0; t < 8; ++t) if (i.dotCoordinate(e[t]) >= 0) {
				r = !1;
				break;
			}
			if (r) return !1;
		}
		return !0;
	}
};
C._TmpVector3 = d(3, f.Zero);
//#endregion
//#region node_modules/@babylonjs/core/Culling/boundingSphere.js
var w = class e {
	constructor(e, t, n) {
		this.center = f.Zero(), this.centerWorld = f.Zero(), this.minimum = f.Zero(), this.maximum = f.Zero(), this.reConstruct(e, t, n);
	}
	reConstruct(e, t, n) {
		this.minimum.copyFrom(e), this.maximum.copyFrom(t);
		let r = f.Distance(e, t);
		t.addToRef(e, this.center).scaleInPlace(.5), this.radius = r * .5, this._update(n || c.IdentityReadOnly);
	}
	scale(t) {
		let n = e._TmpVector3, r = this.maximum.subtractToRef(this.minimum, n[0]), i = r.length();
		r.normalizeFromLength(i);
		let a = i * t, o = r.scaleInPlace(a * .5), s = this.center.subtractToRef(o, n[1]), c = this.center.addToRef(o, n[2]);
		return this.reConstruct(s, c, this._worldMatrix), this;
	}
	getWorldMatrix() {
		return this._worldMatrix;
	}
	_update(t) {
		if (t.isIdentity()) this.centerWorld.copyFrom(this.center), this.radiusWorld = this.radius;
		else {
			f.TransformCoordinatesToRef(this.center, t, this.centerWorld);
			let n = e._TmpVector3[0];
			f.TransformNormalFromFloatsToRef(1, 1, 1, t, n), this.radiusWorld = Math.max(Math.abs(n.x), Math.abs(n.y), Math.abs(n.z)) * this.radius;
		}
	}
	isInFrustum(e) {
		let t = this.centerWorld, n = this.radiusWorld;
		for (let r = 0; r < 6; r++) if (e[r].dotCoordinate(t) <= -n) return !1;
		return !0;
	}
	isCenterInFrustum(e) {
		let t = this.centerWorld;
		for (let n = 0; n < 6; n++) if (e[n].dotCoordinate(t) < 0) return !1;
		return !0;
	}
	intersectsPoint(e) {
		let t = f.DistanceSquared(this.centerWorld, e);
		return !(this.radiusWorld * this.radiusWorld < t);
	}
	static Intersects(e, t) {
		let n = f.DistanceSquared(e.centerWorld, t.centerWorld), r = e.radiusWorld + t.radiusWorld;
		return !(r * r < n);
	}
	static CreateFromCenterAndRadius(t, n, r) {
		this._TmpVector3[0].copyFrom(t), this._TmpVector3[1].copyFromFloats(0, 0, n), this._TmpVector3[2].copyFrom(t), this._TmpVector3[0].addInPlace(this._TmpVector3[1]), this._TmpVector3[2].subtractInPlace(this._TmpVector3[1]);
		let i = new e(this._TmpVector3[0], this._TmpVector3[2]);
		return i._worldMatrix = r || c.Identity(), i;
	}
};
w._TmpVector3 = d(3, f.Zero);
//#endregion
//#region node_modules/@babylonjs/core/Culling/boundingInfo.js
var T = {
	min: 0,
	max: 0
}, E = {
	min: 0,
	max: 0
}, D = (e, t, n) => {
	let r = f.Dot(t.centerWorld, e), i = Math.abs(f.Dot(t.directions[0], e)) * t.extendSize.x, a = Math.abs(f.Dot(t.directions[1], e)) * t.extendSize.y, o = Math.abs(f.Dot(t.directions[2], e)) * t.extendSize.z, s = i + a + o;
	n.min = r - s, n.max = r + s;
}, O = (e, t, n) => (D(e, t, T), D(e, n, E), !(T.min > E.max || E.min > T.max)), k = class e {
	constructor(e, t, n) {
		this._isLocked = !1, this.boundingBox = new C(e, t, n), this.boundingSphere = new w(e, t, n);
	}
	reConstruct(e, t, n) {
		this.boundingBox.reConstruct(e, t, n), this.boundingSphere.reConstruct(e, t, n);
	}
	get minimum() {
		return this.boundingBox.minimum;
	}
	get maximum() {
		return this.boundingBox.maximum;
	}
	get isLocked() {
		return this._isLocked;
	}
	set isLocked(e) {
		this._isLocked = e;
	}
	update(e) {
		this._isLocked || (this.boundingBox._update(e), this.boundingSphere._update(e));
	}
	centerOn(t, n) {
		let r = e._TmpVector3[0].copyFrom(t).subtractInPlace(n), i = e._TmpVector3[1].copyFrom(t).addInPlace(n);
		return this.boundingBox.reConstruct(r, i, this.boundingBox.getWorldMatrix()), this.boundingSphere.reConstruct(r, i, this.boundingBox.getWorldMatrix()), this;
	}
	encapsulate(e) {
		let t = f.Minimize(this.minimum, e), n = f.Maximize(this.maximum, e);
		return this.reConstruct(t, n, this.boundingBox.getWorldMatrix()), this;
	}
	encapsulateBoundingInfo(e) {
		let t = l.Matrix[0];
		this.boundingBox.getWorldMatrix().invertToRef(t);
		let n = l.Vector3[0];
		return f.TransformCoordinatesToRef(e.boundingBox.minimumWorld, t, n), this.encapsulate(n), f.TransformCoordinatesToRef(e.boundingBox.maximumWorld, t, n), this.encapsulate(n), this;
	}
	scale(e) {
		return this.boundingBox.scale(e), this.boundingSphere.scale(e), this;
	}
	isInFrustum(e, t = 0) {
		return (t === 2 || t === 3) && this.boundingSphere.isCenterInFrustum(e) ? !0 : this.boundingSphere.isInFrustum(e) ? t === 1 || t === 3 || this.boundingBox.isInFrustum(e) : !1;
	}
	get diagonalLength() {
		let t = this.boundingBox;
		return t.maximumWorld.subtractToRef(t.minimumWorld, e._TmpVector3[0]).length();
	}
	isCompletelyInFrustum(e) {
		return this.boundingBox.isCompletelyInFrustum(e);
	}
	_checkCollision(e) {
		return e._canDoCollision(this.boundingSphere.centerWorld, this.boundingSphere.radiusWorld, this.boundingBox.minimumWorld, this.boundingBox.maximumWorld);
	}
	intersectsPoint(e) {
		return !(!this.boundingSphere.centerWorld || !this.boundingSphere.intersectsPoint(e) || !this.boundingBox.intersectsPoint(e));
	}
	intersects(e, t) {
		if (!w.Intersects(this.boundingSphere, e.boundingSphere) || !C.Intersects(this.boundingBox, e.boundingBox)) return !1;
		if (!t) return !0;
		let n = this.boundingBox, r = e.boundingBox;
		return !(!O(n.directions[0], n, r) || !O(n.directions[1], n, r) || !O(n.directions[2], n, r) || !O(r.directions[0], n, r) || !O(r.directions[1], n, r) || !O(r.directions[2], n, r) || !O(f.Cross(n.directions[0], r.directions[0]), n, r) || !O(f.Cross(n.directions[0], r.directions[1]), n, r) || !O(f.Cross(n.directions[0], r.directions[2]), n, r) || !O(f.Cross(n.directions[1], r.directions[0]), n, r) || !O(f.Cross(n.directions[1], r.directions[1]), n, r) || !O(f.Cross(n.directions[1], r.directions[2]), n, r) || !O(f.Cross(n.directions[2], r.directions[0]), n, r) || !O(f.Cross(n.directions[2], r.directions[1]), n, r) || !O(f.Cross(n.directions[2], r.directions[2]), n, r));
	}
};
k._TmpVector3 = d(2, f.Zero);
//#endregion
//#region node_modules/@babylonjs/core/Maths/math.functions.js
var A = (() => {
	var e;
	let t = [], n, r;
	return e = class {
		static extractMinAndMaxIndexed(e, t, n, r, i, a) {
			for (let o = n; o < n + r; o++) {
				let n = t[o] * 3, r = e[n], s = e[n + 1], c = e[n + 2];
				i.minimizeInPlaceFromFloats(r, s, c), a.maximizeInPlaceFromFloats(r, s, c);
			}
		}
		static extractMinAndMax(e, t, n, r, i, a) {
			for (let o = t, s = t * r; o < t + n; o++, s += r) {
				let t = e[s], n = e[s + 1], r = e[s + 2];
				i.minimizeInPlaceFromFloats(t, n, r), a.maximizeInPlaceFromFloats(t, n, r);
			}
		}
	}, (() => {
		let i = typeof Symbol == "function" && Symbol.metadata ? Object.create(null) : void 0;
		n = [g.filter((...e) => !Array.isArray(e[0]) && !Array.isArray(e[1]))], r = [g.filter((...e) => !Array.isArray(e[0]))], _(e, null, n, {
			kind: "method",
			name: "extractMinAndMaxIndexed",
			static: !0,
			private: !1,
			access: {
				has: (e) => "extractMinAndMaxIndexed" in e,
				get: (e) => e.extractMinAndMaxIndexed
			},
			metadata: i
		}, null, t), _(e, null, r, {
			kind: "method",
			name: "extractMinAndMax",
			static: !0,
			private: !1,
			access: {
				has: (e) => "extractMinAndMax" in e,
				get: (e) => e.extractMinAndMax
			},
			metadata: i
		}, null, t), i && Object.defineProperty(e, Symbol.metadata, {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: i
		}), m(e, t);
	})(), e;
})();
function j(e, t, n, r, i = null) {
	let a = new f(Number.MAX_VALUE, Number.MAX_VALUE, Number.MAX_VALUE), o = new f(-Number.MAX_VALUE, -Number.MAX_VALUE, -Number.MAX_VALUE);
	return A.extractMinAndMaxIndexed(e, t, n, r, a, o), i && (a.x -= a.x * i.x + i.y, a.y -= a.y * i.x + i.y, a.z -= a.z * i.x + i.y, o.x += o.x * i.x + i.y, o.y += o.y * i.x + i.y, o.z += o.z * i.x + i.y), {
		minimum: a,
		maximum: o
	};
}
function M(e, t, n, r = null, i) {
	let a = new f(Number.MAX_VALUE, Number.MAX_VALUE, Number.MAX_VALUE), o = new f(-Number.MAX_VALUE, -Number.MAX_VALUE, -Number.MAX_VALUE);
	return i ||= 3, A.extractMinAndMax(e, t, n, i, a, o), r && (a.x -= a.x * r.x + r.y, a.y -= a.y * r.x + r.y, a.z -= a.z * r.x + r.y, o.x += o.x * r.x + r.y, o.y += o.y * r.x + r.y, o.z += o.z * r.x + r.y), {
		minimum: a,
		maximum: o
	};
}
//#endregion
//#region node_modules/@babylonjs/core/Meshes/subMesh.pure.js
var N, ne = class e {
	get materialDefines() {
		let e = this._mainDrawWrapperOverride ? this._mainDrawWrapperOverride.defines : this._getDrawWrapper()?.defines;
		return typeof e == "string" ? null : e;
	}
	set materialDefines(e) {
		let t = this._mainDrawWrapperOverride ?? this._getDrawWrapper(void 0, !0);
		t.defines = e;
	}
	_getDrawWrapper(e, t = !1) {
		e ??= this._engine.currentRenderPassId;
		let n = this._drawWrappers[e];
		return !n && t && (this._drawWrappers[e] = n = new te(this._mesh.getScene().getEngine())), n;
	}
	_removeDrawWrapper(e, t = !0, n = !1) {
		t && this._drawWrappers[e]?.dispose(n), this._drawWrappers[e] = void 0, this._currentMaterials[e] = void 0;
	}
	get effect() {
		return this._mainDrawWrapperOverride ? this._mainDrawWrapperOverride.effect : this._getDrawWrapper()?.effect ?? null;
	}
	get _drawWrapper() {
		return this._mainDrawWrapperOverride ?? this._getDrawWrapper(void 0, !0);
	}
	get _drawWrapperOverride() {
		return this._mainDrawWrapperOverride;
	}
	_setMainDrawWrapperOverride(e) {
		this._mainDrawWrapperOverride = e;
	}
	setEffect(e, t = null, n, r = !0) {
		let i = this._drawWrapper;
		i.setEffect(e, t, r), n !== void 0 && (i.materialContext = n), e || (i.defines = null, i.materialContext = void 0);
	}
	resetDrawCache(e, t = !1) {
		if (this._drawWrappers) {
			if (e !== void 0) {
				this._removeDrawWrapper(e, !0, t);
				return;
			}
			for (let e of this._drawWrappers) e?.dispose(t);
		}
		this._drawWrappers = [], this._currentMaterials = [];
	}
	static AddToMesh(t, n, r, i, a, o, s, c = !0) {
		return new e(t, n, r, i, a, o, s, c);
	}
	constructor(e, t, n, r, i, a, o, s = !0, c = !0) {
		this.materialIndex = e, this.verticesStart = t, this.verticesCount = n, this.indexStart = r, this.indexCount = i, this._mainDrawWrapperOverride = null, this._linesIndexCount = 0, this._linesIndexBuffer = null, this._lastColliderWorldVertices = null, this._lastColliderTransformMatrix = null, this._wasDispatched = !1, this._renderId = 0, this._alphaIndex = 0, this._distanceToCamera = 0, this._mesh = a, this._renderingMesh = o || a, c && a.subMeshes.push(this), this._engine = this._mesh.getScene().getEngine(), this.resetDrawCache(), this._trianglePlanes = [], this._id = a.subMeshes.length - 1, s && (this.refreshBoundingInfo(), a.computeWorldMatrix(!0));
	}
	get IsGlobal() {
		return this.verticesStart === 0 && this.verticesCount === this._mesh.getTotalVertices() && this.indexStart === 0 && this.indexCount === this._mesh.getTotalIndices();
	}
	getBoundingInfo() {
		return this.IsGlobal || this._mesh.hasThinInstances ? this._mesh.getBoundingInfo() : this._boundingInfo;
	}
	setBoundingInfo(e) {
		return this._boundingInfo = e, this;
	}
	getMesh() {
		return this._mesh;
	}
	getRenderingMesh() {
		return this._renderingMesh;
	}
	getReplacementMesh() {
		return this._mesh._internalAbstractMeshDataInfo._actAsRegularMesh ? this._mesh : null;
	}
	getEffectiveMesh() {
		return (this._mesh._internalAbstractMeshDataInfo._actAsRegularMesh ? this._mesh : null) || this._renderingMesh;
	}
	getMaterial(e = !0, t) {
		t === void 0 && (t = this._engine.currentRenderPassId);
		let n = this._renderingMesh.getMaterialForRenderPass(t) ?? this._renderingMesh.material;
		if (!n) return e && this._mesh.getScene()._hasDefaultMaterial ? this._mesh.getScene().defaultMaterial : null;
		if (this._isMultiMaterial(n)) {
			let e = n.getSubMaterial(this.materialIndex);
			return this._currentMaterials[t] !== e && (this.resetDrawCache(t), this._currentMaterials[t] = e), e;
		}
		return n;
	}
	_mayRenderWithMaterial(t) {
		return this.getMaterial !== e.prototype.getMaterial || this._renderingMesh._mayRenderWithMaterial(t, this._drawWrappers);
	}
	_isMultiMaterial(e) {
		return e.getSubMaterial !== void 0;
	}
	refreshBoundingInfo(e = null) {
		if (this._lastColliderWorldVertices = null, this.IsGlobal || !this._renderingMesh || !this._renderingMesh.geometry) return this;
		if (e ||= this._renderingMesh.getVerticesData(s.PositionKind), !e) return this._boundingInfo = this._mesh.getBoundingInfo(), this;
		let t = this._renderingMesh.getIndices(), n;
		if (this.indexStart === 0 && this.indexCount === t.length) {
			let e = this._renderingMesh.getBoundingInfo();
			n = {
				minimum: e.minimum.clone(),
				maximum: e.maximum.clone()
			};
		} else n = j(e, t, this.indexStart, this.indexCount, this._renderingMesh.geometry.boundingBias);
		return this._boundingInfo ? this._boundingInfo.reConstruct(n.minimum, n.maximum) : this._boundingInfo = new k(n.minimum, n.maximum), this;
	}
	_checkCollision(e) {
		return this.getBoundingInfo()._checkCollision(e);
	}
	updateBoundingInfo(e) {
		let t = this.getBoundingInfo();
		return t ||= (this.refreshBoundingInfo(), this.getBoundingInfo()), t && t.update(e), this;
	}
	isInFrustum(e) {
		let t = this.getBoundingInfo();
		return t ? t.isInFrustum(e, this._mesh.cullingStrategy) : !1;
	}
	isCompletelyInFrustum(e) {
		let t = this.getBoundingInfo();
		return t ? t.isCompletelyInFrustum(e) : !1;
	}
	render(e) {
		return this._renderingMesh.render(this, e, this._mesh._internalAbstractMeshDataInfo._actAsRegularMesh ? this._mesh : void 0), this;
	}
	_getLinesIndexBuffer(e, t) {
		if (!this._linesIndexBuffer) {
			let n = Math.floor(this.indexCount / 3) * 6, r = this.verticesStart + this.verticesCount > 65535 ? new Uint32Array(n) : new Uint16Array(n), i = 0;
			if (e.length === 0) for (let e = this.indexStart; e < this.indexStart + this.indexCount; e += 3) r[i++] = e, r[i++] = e + 1, r[i++] = e + 1, r[i++] = e + 2, r[i++] = e + 2, r[i++] = e;
			else for (let t = this.indexStart; t < this.indexStart + this.indexCount; t += 3) r[i++] = e[t], r[i++] = e[t + 1], r[i++] = e[t + 1], r[i++] = e[t + 2], r[i++] = e[t + 2], r[i++] = e[t];
			this._linesIndexBuffer = t.createIndexBuffer(r), this._linesIndexCount = r.length;
		}
		return this._linesIndexBuffer;
	}
	canIntersects(e) {
		let t = this.getBoundingInfo();
		return t ? e.intersectsBox(t.boundingBox) : !1;
	}
	intersects(e, t, n, r, i) {
		let a = this.getMaterial();
		if (!a) return null;
		let o = 3, s = !1;
		switch (a.fillMode) {
			case 3:
			case 5:
			case 6:
			case 8: return null;
			case 7: o = 1, s = !0;
		}
		return a.fillMode === 4 ? n.length ? this._intersectLines(e, t, n, this._mesh.intersectionThreshold, r) : this._intersectUnIndexedLines(e, t, n, this._mesh.intersectionThreshold, r) : !n.length && this._mesh._unIndexed ? this._intersectUnIndexedTriangles(e, t, n, r, i) : this._intersectTriangles(e, t, n, o, s, r, i);
	}
	_intersectLines(e, t, n, r, i) {
		let a = null;
		for (let o = this.indexStart; o < this.indexStart + this.indexCount; o += 2) {
			let s = t[n[o]], c = t[n[o + 1]], l = e.intersectionSegment(s, c, r);
			if (!(l < 0) && (i || !a || l < a.distance) && (a = new S(null, null, l), a.faceId = o / 2, i)) break;
		}
		return a;
	}
	_intersectUnIndexedLines(e, t, n, r, i) {
		let a = null;
		for (let n = this.verticesStart; n < this.verticesStart + this.verticesCount; n += 2) {
			let o = t[n], s = t[n + 1], c = e.intersectionSegment(o, s, r);
			if (!(c < 0) && (i || !a || c < a.distance) && (a = new S(null, null, c), a.faceId = n / 2, i)) break;
		}
		return a;
	}
	_intersectTriangles(e, t, n, r, i, a, o) {
		let s = null, c = -1;
		for (let l = this.indexStart; l < this.indexStart + this.indexCount - (3 - r); l += r) {
			c++;
			let r = n[l], u = n[l + 1], d = n[l + 2];
			if (i && d === 4294967295) {
				l += 2;
				continue;
			}
			let f = t[r], p = t[u], m = t[d];
			if (!f || !p || !m || o && !o(f, p, m, e, r, u, d)) continue;
			let h = e.intersectsTriangle(f, p, m);
			if (h) {
				if (h.distance < 0) continue;
				if ((a || !s || h.distance < s.distance) && (s = h, s.faceId = c, a)) break;
			}
		}
		return s;
	}
	_intersectUnIndexedTriangles(e, t, n, r, i) {
		let a = null;
		for (let n = this.verticesStart; n < this.verticesStart + this.verticesCount; n += 3) {
			let o = t[n], s = t[n + 1], c = t[n + 2];
			if (i && !i(o, s, c, e, -1, -1, -1)) continue;
			let l = e.intersectsTriangle(o, s, c);
			if (l) {
				if (l.distance < 0) continue;
				if ((r || !a || l.distance < a.distance) && (a = l, a.faceId = n / 3, r)) break;
			}
		}
		return a;
	}
	_rebuild() {
		this._linesIndexBuffer &&= null;
	}
	clone(t, n) {
		let r = new e(this.materialIndex, this.verticesStart, this.verticesCount, this.indexStart, this.indexCount, t, n, !1);
		if (!this.IsGlobal) {
			let e = this.getBoundingInfo();
			if (!e) return r;
			r._boundingInfo = new k(e.minimum, e.maximum);
		}
		return r;
	}
	dispose(e = !1) {
		this._linesIndexBuffer &&= (this._mesh.getScene().getEngine()._releaseBuffer(this._linesIndexBuffer), null);
		let t = this._mesh.subMeshes.indexOf(this);
		this._mesh.subMeshes.splice(t, 1), this.resetDrawCache(void 0, e);
	}
	getClassName() {
		return "SubMesh";
	}
	static CreateFromIndices(t, n, r, i, a, o = !0) {
		let s = Number.MAX_VALUE, c = -Number.MAX_VALUE, l = (a || i).getIndices();
		for (let e = n; e < n + r; e++) {
			let t = l[e];
			t < s && (s = t), t > c && (c = t);
		}
		return new e(t, s, c - s + 1, n, r, i, a, o);
	}
};
(N = ne.prototype).projectToRef ?? (N.projectToRef = i("SubMesh", "projectToRef"));
//#endregion
//#region node_modules/@babylonjs/core/Materials/materialStencilState.js
var re = (() => {
	var e;
	let t = [], n, r, i, a, o, s, c, l, u, d, f, p;
	return e = class {
		constructor() {
			this._func = m(this, t), this.reset();
		}
		reset() {
			this.enabled = !1, this.mask = 255, this.funcRef = 1, this.funcMask = 255, this.func = 519, this.opStencilFail = 7680, this.opDepthFail = 7680, this.opStencilDepthPass = 7681, this.backFunc = 519, this.backOpStencilFail = 7680, this.backOpDepthFail = 7680, this.backOpStencilDepthPass = 7681;
		}
		get func() {
			return this._func;
		}
		set func(e) {
			this._func = e;
		}
		get backFunc() {
			return this._backFunc;
		}
		set backFunc(e) {
			this._backFunc = e;
		}
		get funcRef() {
			return this._funcRef;
		}
		set funcRef(e) {
			this._funcRef = e;
		}
		get funcMask() {
			return this._funcMask;
		}
		set funcMask(e) {
			this._funcMask = e;
		}
		get opStencilFail() {
			return this._opStencilFail;
		}
		set opStencilFail(e) {
			this._opStencilFail = e;
		}
		get opDepthFail() {
			return this._opDepthFail;
		}
		set opDepthFail(e) {
			this._opDepthFail = e;
		}
		get opStencilDepthPass() {
			return this._opStencilDepthPass;
		}
		set opStencilDepthPass(e) {
			this._opStencilDepthPass = e;
		}
		get backOpStencilFail() {
			return this._backOpStencilFail;
		}
		set backOpStencilFail(e) {
			this._backOpStencilFail = e;
		}
		get backOpDepthFail() {
			return this._backOpDepthFail;
		}
		set backOpDepthFail(e) {
			this._backOpDepthFail = e;
		}
		get backOpStencilDepthPass() {
			return this._backOpStencilDepthPass;
		}
		set backOpStencilDepthPass(e) {
			this._backOpStencilDepthPass = e;
		}
		get mask() {
			return this._mask;
		}
		set mask(e) {
			this._mask = e;
		}
		get enabled() {
			return this._enabled;
		}
		set enabled(e) {
			this._enabled = e;
		}
		getClassName() {
			return "MaterialStencilState";
		}
		copyTo(e) {
			v.Clone(() => e, this);
		}
		serialize() {
			return v.Serialize(this);
		}
		parse(e, t, n) {
			v.Parse(() => this, e, t, n);
		}
	}, (() => {
		let m = typeof Symbol == "function" && Symbol.metadata ? Object.create(null) : void 0;
		n = [h()], r = [h()], i = [h()], a = [h()], o = [h()], s = [h()], c = [h()], l = [h()], u = [h()], d = [h()], f = [h()], p = [h()], _(e, null, n, {
			kind: "getter",
			name: "func",
			static: !1,
			private: !1,
			access: {
				has: (e) => "func" in e,
				get: (e) => e.func
			},
			metadata: m
		}, null, t), _(e, null, r, {
			kind: "getter",
			name: "backFunc",
			static: !1,
			private: !1,
			access: {
				has: (e) => "backFunc" in e,
				get: (e) => e.backFunc
			},
			metadata: m
		}, null, t), _(e, null, i, {
			kind: "getter",
			name: "funcRef",
			static: !1,
			private: !1,
			access: {
				has: (e) => "funcRef" in e,
				get: (e) => e.funcRef
			},
			metadata: m
		}, null, t), _(e, null, a, {
			kind: "getter",
			name: "funcMask",
			static: !1,
			private: !1,
			access: {
				has: (e) => "funcMask" in e,
				get: (e) => e.funcMask
			},
			metadata: m
		}, null, t), _(e, null, o, {
			kind: "getter",
			name: "opStencilFail",
			static: !1,
			private: !1,
			access: {
				has: (e) => "opStencilFail" in e,
				get: (e) => e.opStencilFail
			},
			metadata: m
		}, null, t), _(e, null, s, {
			kind: "getter",
			name: "opDepthFail",
			static: !1,
			private: !1,
			access: {
				has: (e) => "opDepthFail" in e,
				get: (e) => e.opDepthFail
			},
			metadata: m
		}, null, t), _(e, null, c, {
			kind: "getter",
			name: "opStencilDepthPass",
			static: !1,
			private: !1,
			access: {
				has: (e) => "opStencilDepthPass" in e,
				get: (e) => e.opStencilDepthPass
			},
			metadata: m
		}, null, t), _(e, null, l, {
			kind: "getter",
			name: "backOpStencilFail",
			static: !1,
			private: !1,
			access: {
				has: (e) => "backOpStencilFail" in e,
				get: (e) => e.backOpStencilFail
			},
			metadata: m
		}, null, t), _(e, null, u, {
			kind: "getter",
			name: "backOpDepthFail",
			static: !1,
			private: !1,
			access: {
				has: (e) => "backOpDepthFail" in e,
				get: (e) => e.backOpDepthFail
			},
			metadata: m
		}, null, t), _(e, null, d, {
			kind: "getter",
			name: "backOpStencilDepthPass",
			static: !1,
			private: !1,
			access: {
				has: (e) => "backOpStencilDepthPass" in e,
				get: (e) => e.backOpStencilDepthPass
			},
			metadata: m
		}, null, t), _(e, null, f, {
			kind: "getter",
			name: "mask",
			static: !1,
			private: !1,
			access: {
				has: (e) => "mask" in e,
				get: (e) => e.mask
			},
			metadata: m
		}, null, t), _(e, null, p, {
			kind: "getter",
			name: "enabled",
			static: !1,
			private: !1,
			access: {
				has: (e) => "enabled" in e,
				get: (e) => e.enabled
			},
			metadata: m
		}, null, t), m && Object.defineProperty(e, Symbol.metadata, {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: m
		});
	})(), e;
})();
//#endregion
//#region node_modules/@babylonjs/core/Materials/clipPlaneMaterialHelper.js
function ie(e) {
	e.indexOf("vClipPlane") === -1 && e.push("vClipPlane"), e.indexOf("vClipPlane2") === -1 && e.push("vClipPlane2"), e.indexOf("vClipPlane3") === -1 && e.push("vClipPlane3"), e.indexOf("vClipPlane4") === -1 && e.push("vClipPlane4"), e.indexOf("vClipPlane5") === -1 && e.push("vClipPlane5"), e.indexOf("vClipPlane6") === -1 && e.push("vClipPlane6");
}
function ae(e, t, n) {
	let r = !!(e.clipPlane ?? t.clipPlane), i = !!(e.clipPlane2 ?? t.clipPlane2), a = !!(e.clipPlane3 ?? t.clipPlane3), o = !!(e.clipPlane4 ?? t.clipPlane4), s = !!(e.clipPlane5 ?? t.clipPlane5), c = !!(e.clipPlane6 ?? t.clipPlane6);
	r && n.push("#define CLIPPLANE"), i && n.push("#define CLIPPLANE2"), a && n.push("#define CLIPPLANE3"), o && n.push("#define CLIPPLANE4"), s && n.push("#define CLIPPLANE5"), c && n.push("#define CLIPPLANE6");
}
function oe(e, t, n) {
	let r = !1, i = !!(e.clipPlane ?? t.clipPlane), a = !!(e.clipPlane2 ?? t.clipPlane2), o = !!(e.clipPlane3 ?? t.clipPlane3), s = !!(e.clipPlane4 ?? t.clipPlane4), c = !!(e.clipPlane5 ?? t.clipPlane5), l = !!(e.clipPlane6 ?? t.clipPlane6);
	return n.CLIPPLANE !== i && (n.CLIPPLANE = i, r = !0), n.CLIPPLANE2 !== a && (n.CLIPPLANE2 = a, r = !0), n.CLIPPLANE3 !== o && (n.CLIPPLANE3 = o, r = !0), n.CLIPPLANE4 !== s && (n.CLIPPLANE4 = s, r = !0), n.CLIPPLANE5 !== c && (n.CLIPPLANE5 = c, r = !0), n.CLIPPLANE6 !== l && (n.CLIPPLANE6 = l, r = !0), r;
}
function P(e, t, n) {
	let r = t.clipPlane ?? n.clipPlane;
	F(e, "vClipPlane", r), r = t.clipPlane2 ?? n.clipPlane2, F(e, "vClipPlane2", r), r = t.clipPlane3 ?? n.clipPlane3, F(e, "vClipPlane3", r), r = t.clipPlane4 ?? n.clipPlane4, F(e, "vClipPlane4", r), r = t.clipPlane5 ?? n.clipPlane5, F(e, "vClipPlane5", r), r = t.clipPlane6 ?? n.clipPlane6, F(e, "vClipPlane6", r);
}
function F(e, t, n) {
	if (n) {
		let r = ee.getScene()?.floatingOriginOffset || f.ZeroReadOnly;
		e.setFloat4(t, n.normal.x, n.normal.y, n.normal.z, n.d + f.Dot(n.normal, r));
	}
}
//#endregion
//#region node_modules/@babylonjs/core/Materials/materialFlags.js
var I = class {
	static get DiffuseTextureEnabled() {
		return this._DiffuseTextureEnabled;
	}
	static set DiffuseTextureEnabled(e) {
		this._DiffuseTextureEnabled !== e && (this._DiffuseTextureEnabled = e, r.MarkAllMaterialsAsDirty(1));
	}
	static get BaseWeightTextureEnabled() {
		return this._BaseWeightTextureEnabled;
	}
	static set BaseWeightTextureEnabled(e) {
		this._BaseWeightTextureEnabled !== e && (this._BaseWeightTextureEnabled = e, r.MarkAllMaterialsAsDirty(1));
	}
	static get BaseDiffuseRoughnessTextureEnabled() {
		return this._BaseDiffuseRoughnessTextureEnabled;
	}
	static set BaseDiffuseRoughnessTextureEnabled(e) {
		this._BaseDiffuseRoughnessTextureEnabled !== e && (this._BaseDiffuseRoughnessTextureEnabled = e, r.MarkAllMaterialsAsDirty(1));
	}
	static get DetailTextureEnabled() {
		return this._DetailTextureEnabled;
	}
	static set DetailTextureEnabled(e) {
		this._DetailTextureEnabled !== e && (this._DetailTextureEnabled = e, r.MarkAllMaterialsAsDirty(1));
	}
	static get DecalMapEnabled() {
		return this._DecalMapEnabled;
	}
	static set DecalMapEnabled(e) {
		this._DecalMapEnabled !== e && (this._DecalMapEnabled = e, r.MarkAllMaterialsAsDirty(1));
	}
	static get AmbientTextureEnabled() {
		return this._AmbientTextureEnabled;
	}
	static set AmbientTextureEnabled(e) {
		this._AmbientTextureEnabled !== e && (this._AmbientTextureEnabled = e, r.MarkAllMaterialsAsDirty(1));
	}
	static get OpacityTextureEnabled() {
		return this._OpacityTextureEnabled;
	}
	static set OpacityTextureEnabled(e) {
		this._OpacityTextureEnabled !== e && (this._OpacityTextureEnabled = e, r.MarkAllMaterialsAsDirty(1));
	}
	static get ReflectionTextureEnabled() {
		return this._ReflectionTextureEnabled;
	}
	static set ReflectionTextureEnabled(e) {
		this._ReflectionTextureEnabled !== e && (this._ReflectionTextureEnabled = e, r.MarkAllMaterialsAsDirty(1));
	}
	static get EmissiveTextureEnabled() {
		return this._EmissiveTextureEnabled;
	}
	static set EmissiveTextureEnabled(e) {
		this._EmissiveTextureEnabled !== e && (this._EmissiveTextureEnabled = e, r.MarkAllMaterialsAsDirty(1));
	}
	static get SpecularTextureEnabled() {
		return this._SpecularTextureEnabled;
	}
	static set SpecularTextureEnabled(e) {
		this._SpecularTextureEnabled !== e && (this._SpecularTextureEnabled = e, r.MarkAllMaterialsAsDirty(1));
	}
	static get BumpTextureEnabled() {
		return this._BumpTextureEnabled;
	}
	static set BumpTextureEnabled(e) {
		this._BumpTextureEnabled !== e && (this._BumpTextureEnabled = e, r.MarkAllMaterialsAsDirty(1));
	}
	static get LightmapTextureEnabled() {
		return this._LightmapTextureEnabled;
	}
	static set LightmapTextureEnabled(e) {
		this._LightmapTextureEnabled !== e && (this._LightmapTextureEnabled = e, r.MarkAllMaterialsAsDirty(1));
	}
	static get RefractionTextureEnabled() {
		return this._RefractionTextureEnabled;
	}
	static set RefractionTextureEnabled(e) {
		this._RefractionTextureEnabled !== e && (this._RefractionTextureEnabled = e, r.MarkAllMaterialsAsDirty(1));
	}
	static get ColorGradingTextureEnabled() {
		return this._ColorGradingTextureEnabled;
	}
	static set ColorGradingTextureEnabled(e) {
		this._ColorGradingTextureEnabled !== e && (this._ColorGradingTextureEnabled = e, r.MarkAllMaterialsAsDirty(1));
	}
	static get FresnelEnabled() {
		return this._FresnelEnabled;
	}
	static set FresnelEnabled(e) {
		this._FresnelEnabled !== e && (this._FresnelEnabled = e, r.MarkAllMaterialsAsDirty(4));
	}
	static get ClearCoatTextureEnabled() {
		return this._ClearCoatTextureEnabled;
	}
	static set ClearCoatTextureEnabled(e) {
		this._ClearCoatTextureEnabled !== e && (this._ClearCoatTextureEnabled = e, r.MarkAllMaterialsAsDirty(1));
	}
	static get ClearCoatBumpTextureEnabled() {
		return this._ClearCoatBumpTextureEnabled;
	}
	static set ClearCoatBumpTextureEnabled(e) {
		this._ClearCoatBumpTextureEnabled !== e && (this._ClearCoatBumpTextureEnabled = e, r.MarkAllMaterialsAsDirty(1));
	}
	static get ClearCoatTintTextureEnabled() {
		return this._ClearCoatTintTextureEnabled;
	}
	static set ClearCoatTintTextureEnabled(e) {
		this._ClearCoatTintTextureEnabled !== e && (this._ClearCoatTintTextureEnabled = e, r.MarkAllMaterialsAsDirty(1));
	}
	static get SheenTextureEnabled() {
		return this._SheenTextureEnabled;
	}
	static set SheenTextureEnabled(e) {
		this._SheenTextureEnabled !== e && (this._SheenTextureEnabled = e, r.MarkAllMaterialsAsDirty(1));
	}
	static get AnisotropicTextureEnabled() {
		return this._AnisotropicTextureEnabled;
	}
	static set AnisotropicTextureEnabled(e) {
		this._AnisotropicTextureEnabled !== e && (this._AnisotropicTextureEnabled = e, r.MarkAllMaterialsAsDirty(1));
	}
	static get ThicknessTextureEnabled() {
		return this._ThicknessTextureEnabled;
	}
	static set ThicknessTextureEnabled(e) {
		this._ThicknessTextureEnabled !== e && (this._ThicknessTextureEnabled = e, r.MarkAllMaterialsAsDirty(1));
	}
	static get RefractionIntensityTextureEnabled() {
		return this._ThicknessTextureEnabled;
	}
	static set RefractionIntensityTextureEnabled(e) {
		this._RefractionIntensityTextureEnabled !== e && (this._RefractionIntensityTextureEnabled = e, r.MarkAllMaterialsAsDirty(1));
	}
	static get TranslucencyIntensityTextureEnabled() {
		return this._TranslucencyIntensityTextureEnabled;
	}
	static set TranslucencyIntensityTextureEnabled(e) {
		this._TranslucencyIntensityTextureEnabled !== e && (this._TranslucencyIntensityTextureEnabled = e, r.MarkAllMaterialsAsDirty(1));
	}
	static get TranslucencyColorTextureEnabled() {
		return this._TranslucencyColorTextureEnabled;
	}
	static set TranslucencyColorTextureEnabled(e) {
		this._TranslucencyColorTextureEnabled !== e && (this._TranslucencyColorTextureEnabled = e, r.MarkAllMaterialsAsDirty(1));
	}
	static get IridescenceTextureEnabled() {
		return this._IridescenceTextureEnabled;
	}
	static set IridescenceTextureEnabled(e) {
		this._IridescenceTextureEnabled !== e && (this._IridescenceTextureEnabled = e, r.MarkAllMaterialsAsDirty(1));
	}
};
I._DiffuseTextureEnabled = !0, I._BaseWeightTextureEnabled = !0, I._BaseDiffuseRoughnessTextureEnabled = !0, I._DetailTextureEnabled = !0, I._DecalMapEnabled = !0, I._AmbientTextureEnabled = !0, I._OpacityTextureEnabled = !0, I._ReflectionTextureEnabled = !0, I._EmissiveTextureEnabled = !0, I._SpecularTextureEnabled = !0, I._BumpTextureEnabled = !0, I._LightmapTextureEnabled = !0, I._RefractionTextureEnabled = !0, I._ColorGradingTextureEnabled = !0, I._FresnelEnabled = !0, I._ClearCoatTextureEnabled = !0, I._ClearCoatBumpTextureEnabled = !0, I._ClearCoatTintTextureEnabled = !0, I._SheenTextureEnabled = !0, I._AnisotropicTextureEnabled = !0, I._ThicknessTextureEnabled = !0, I._RefractionIntensityTextureEnabled = !0, I._TranslucencyIntensityTextureEnabled = !0, I._TranslucencyColorTextureEnabled = !0, I._IridescenceTextureEnabled = !0;
//#endregion
//#region node_modules/@babylonjs/core/Materials/materialHelper.functions.js
function L(e, t, r) {
	if (!e || e.LOGARITHMICDEPTH || e.indexOf && e.indexOf("LOGARITHMICDEPTH") >= 0) {
		let e = r.activeCamera;
		e.mode === 1 && n.Error("Logarithmic depth is not compatible with orthographic cameras!", 20), t.setFloat("logarithmicDepthConstant", 2 / (Math.log(e.maxZ + 1) / Math.LN2));
	}
}
var R = {
	r: 0,
	g: 0,
	b: 0
}, z = {
	NUM_MORPH_INFLUENCERS: 0,
	NORMAL: !1,
	TANGENT: !1,
	UV: !1,
	UV2: !1,
	COLOR: !1
};
function B(e, t, n, r = !1) {
	n && e.fogEnabled && (!t || t.applyFog) && e.fogMode !== 0 && (n.setFloat4("vFogInfos", e.fogMode, e.fogStart, e.fogEnd, e.fogDensity), r ? (e.fogColor.toLinearSpaceToRef(R, e.getEngine().useExactSrgbConversions), n.setColor3("vFogColor", R)) : n.setColor3("vFogColor", e.fogColor));
}
function V(e, t, n, r, i, a, o, s, c, l) {
	let u = e.numMaxInfluencers || e.numInfluencers;
	return u <= 0 ? 0 : (t.push("#define MORPHTARGETS"), e.hasPositions && t.push("#define MORPHTARGETTEXTURE_HASPOSITIONS"), e.hasNormals && t.push("#define MORPHTARGETTEXTURE_HASNORMALS"), e.hasTangents && t.push("#define MORPHTARGETTEXTURE_HASTANGENTS"), e.hasUVs && t.push("#define MORPHTARGETTEXTURE_HASUVS"), e.hasUV2s && t.push("#define MORPHTARGETTEXTURE_HASUV2S"), e.hasColors && t.push("#define MORPHTARGETTEXTURE_HASCOLORS"), e.supportsPositions && i && t.push("#define MORPHTARGETS_POSITION"), e.supportsNormals && a && t.push("#define MORPHTARGETS_NORMAL"), e.supportsTangents && o && t.push("#define MORPHTARGETS_TANGENT"), e.supportsUVs && s && t.push("#define MORPHTARGETS_UV"), e.supportsUV2s && c && t.push("#define MORPHTARGETS_UV2"), e.supportsColors && l && t.push("#define MORPHTARGETS_COLOR"), t.push("#define NUM_MORPH_INFLUENCERS " + u), e.isUsingTextureForTargets && t.push("#define MORPHTARGETS_TEXTURE"), z.NUM_MORPH_INFLUENCERS = u, z.NORMAL = a, z.TANGENT = o, z.UV = s, z.UV2 = c, z.COLOR = l, H(n, r, z, i), u);
}
function H(e, r, i, a = !0) {
	let o = i.NUM_MORPH_INFLUENCERS;
	if (o > 0 && t.LastCreatedEngine) {
		let s = t.LastCreatedEngine.getCaps().maxVertexAttribs, c = r.morphTargetManager;
		if (c?.isUsingTextureForTargets) return;
		let l = c && c.supportsPositions && a, u = c && c.supportsNormals && i.NORMAL, d = c && c.supportsTangents && i.TANGENT, f = c && c.supportsUVs && i.UV1, p = c && c.supportsUV2s && i.UV2, m = c && c.supportsColors && i.VERTEXCOLOR;
		for (let t = 0; t < o; t++) l && e.push("position" + t), u && e.push("normal" + t), d && e.push("tangent" + t), f && e.push("uv_" + t), p && e.push("uv2_" + t), m && e.push("color" + t), e.length > s && n.Error("Cannot add more vertex attributes for mesh " + r.name);
	}
}
function U(e, t = !1) {
	e.push("world0"), e.push("world1"), e.push("world2"), e.push("world3"), t && (e.push("previousWorld0"), e.push("previousWorld1"), e.push("previousWorld2"), e.push("previousWorld3"));
}
function W(e, t) {
	let n = e.morphTargetManager;
	e && n && t.setFloatArray("morphTargetInfluences", n.influences);
}
function se(e, t) {
	t.bindToEffect(e, "Scene");
}
function G(e, t, n, r, i = null, a = !1, o = !1, s = !1, c = !1, l = !1, u = !1, d = 0) {
	if (e.texturesEnabled && i && I.ReflectionTextureEnabled) {
		if (n.updateMatrix("reflectionMatrix", i.getReflectionTextureMatrix()), n.updateFloat2("vReflectionInfos", i.level * e.iblIntensity, d), s && i.boundingBoxSize) {
			let e = i;
			n.updateVector3("vReflectionPosition", e.boundingBoxPosition), n.updateVector3("vReflectionSize", e.boundingBoxSize);
		}
		if (a) {
			let e = i.getSize().width;
			n.updateFloat2("vReflectionFilteringInfo", e, Math.log2(e));
		}
		if (l && !t.USEIRRADIANCEMAP) {
			let e = i.sphericalPolynomial;
			if (t.USESPHERICALFROMREFLECTIONMAP && e) {
				if (t.SPHERICAL_HARMONICS) {
					let t = e.preScaledHarmonics;
					n.updateVector3("vSphericalL00", t.l00), n.updateVector3("vSphericalL1_1", t.l1_1), n.updateVector3("vSphericalL10", t.l10), n.updateVector3("vSphericalL11", t.l11), n.updateVector3("vSphericalL2_2", t.l2_2), n.updateVector3("vSphericalL2_1", t.l2_1), n.updateVector3("vSphericalL20", t.l20), n.updateVector3("vSphericalL21", t.l21), n.updateVector3("vSphericalL22", t.l22);
				} else n.updateFloat3("vSphericalX", e.x.x, e.x.y, e.x.z), n.updateFloat3("vSphericalY", e.y.x, e.y.y, e.y.z), n.updateFloat3("vSphericalZ", e.z.x, e.z.y, e.z.z), n.updateFloat3("vSphericalXX_ZZ", e.xx.x - e.zz.x, e.xx.y - e.zz.y, e.xx.z - e.zz.z), n.updateFloat3("vSphericalYY_ZZ", e.yy.x - e.zz.x, e.yy.y - e.zz.y, e.yy.z - e.zz.z), n.updateFloat3("vSphericalZZ", e.zz.x, e.zz.y, e.zz.z), n.updateFloat3("vSphericalXY", e.xy.x, e.xy.y, e.xy.z), n.updateFloat3("vSphericalYZ", e.yz.x, e.yz.y, e.yz.z), n.updateFloat3("vSphericalZX", e.zx.x, e.zx.y, e.zx.z);
			}
		} else c && t.USEIRRADIANCEMAP && t.USE_IRRADIANCE_DOMINANT_DIRECTION && i.irradianceTexture && n.updateVector3("vReflectionDominantDirection", i.irradianceTexture._dominantDirection);
		o && n.updateFloat3("vReflectionMicrosurfaceInfos", i.getSize().width, i.lodGenerationScale, i.lodGenerationOffset);
	}
	u && n.updateColor3("vReflectionColor", r);
}
function K(e, t, n, r = null, i = !1) {
	if (r && I.ReflectionTextureEnabled) {
		t.LODBASEDMICROSFURACE ? n.setTexture("reflectionSampler", r) : (n.setTexture("reflectionSampler", r._lodTextureMid || r), n.setTexture("reflectionSamplerLow", r._lodTextureLow || r), n.setTexture("reflectionSamplerHigh", r._lodTextureHigh || r)), t.USEIRRADIANCEMAP && n.setTexture("irradianceSampler", r.irradianceTexture);
		let a = e.iblCdfGenerator;
		i && a && n.setTexture("icdfSampler", a.getIcdfTexture());
	}
}
function q(e, t, n) {
	t._needUVs = !0, t[n] = !0, e.optimizeUVAllocation && e.getTextureMatrix().isIdentityAs3x2() ? (t[n + "DIRECTUV"] = e.coordinatesIndex + 1, t["MAINUV" + (e.coordinatesIndex + 1)] = !0) : t[n + "DIRECTUV"] = 0;
}
function ce(e, t, n) {
	let r = e.getTextureMatrix();
	t.updateMatrix(n + "Matrix", r);
}
function le(e, t, n) {
	n.BAKED_VERTEX_ANIMATION_TEXTURE && n.INSTANCES && e.push("bakedVertexAnimationSettingsInstanced");
}
function ue(e, t) {
	return t.set(e), t;
}
function de(e, t, n) {
	if (t && e && (e.computeBonesUsingShaders && t._bonesComputationForcedToCPU && (e.computeBonesUsingShaders = !1), e.useBones && e.computeBonesUsingShaders && e.skeleton)) {
		let r = e.skeleton;
		if (r.isUsingTextureForMatrices && t.getUniformIndex("boneTextureInfo") > -1) {
			let n = r.getTransformMatrixTexture(e);
			t.setTexture("boneSampler", n), t.setFloat2("boneTextureInfo", r._textureWidth, r._textureHeight);
		} else {
			let i = r.getTransformMatrices(e);
			i && (t.setMatrices("mBones", i), n && e.getScene().prePassRenderer && e.getScene().prePassRenderer.getIndex(2) && (n.previousBones[e.uniqueId] || (n.previousBones[e.uniqueId] = i.slice()), t.setMatrices("mPreviousBones", n.previousBones[e.uniqueId]), ue(i, n.previousBones[e.uniqueId])));
		}
	}
}
function fe(e, t, n, r, i, a = !0) {
	e._bindLight(t, n, r, i, a);
}
var J = 4, Y = /* @__PURE__ */ new WeakMap();
function pe(e, t) {
	let n = e.getEngine().getCaps().maxUniformBuffersPerShaderStage;
	if (n == null) return t;
	let r = Math.max(n - J, 1);
	return Math.min(t, r);
}
function me(e, t, r, i) {
	let a = Y.get(e);
	a || (a = /* @__PURE__ */ new Set(), Y.set(e, a)), !a.has(i) && (a.add(i), n.Warn(`maxSimultaneousLights is ${t} but this engine supports at most ${r} simultaneous lights. Each light declares its own uniform buffer in the vertex shader, so the ${i} lights affecting this mesh plus the scene, mesh, material and leftover buffers would need ${i + J} uniform buffers, over the device limit of ${e.getCaps().maxUniformBuffersPerShaderStage} per shader stage. The light count has been clamped to ${r}, so the extra lights will not contribute to the render. Set maxSimultaneousLights to ${r} or less to silence this warning.`));
}
function he(e, t, n, r, i = 4) {
	let a = Math.min(t.lightSources.length, i);
	for (let i = 0; i < a; i++) {
		let a = t.lightSources[i];
		fe(a, i, e, n, typeof r == "boolean" ? r : r.SPECULARTERM, t.receiveShadows);
	}
}
function ge(e, t, n, r) {
	n.NUM_BONE_INFLUENCERS > 0 && (r.addCPUSkinningFallback(0, t), e.push("matricesIndices"), e.push("matricesWeights"), n.NUM_BONE_INFLUENCERS > 4 && (e.push("matricesIndicesExtra"), e.push("matricesWeightsExtra")));
}
function _e(e, t) {
	(t.INSTANCES || t.THIN_INSTANCES) && U(e, !!t.PREPASS_VELOCITY), t.INSTANCESCOLOR && e.push("instanceColor");
}
function ve(e, t, n = 4, r = 0) {
	let i = 0;
	for (let a = 0; a < n && e["LIGHT" + a]; a++) a > 0 && (i = r + a, t.addFallback(i, "LIGHT" + a)), e.SHADOWS || (e["SHADOW" + a] && t.addFallback(r, "SHADOW" + a), e["SHADOWPCF" + a] && t.addFallback(r, "SHADOWPCF" + a), e["SHADOWPCSS" + a] && t.addFallback(r, "SHADOWPCSS" + a), e["SHADOWPOISSON" + a] && t.addFallback(r, "SHADOWPOISSON" + a), e["SHADOWESM" + a] && t.addFallback(r, "SHADOWESM" + a), e["SHADOWCLOSEESM" + a] && t.addFallback(r, "SHADOWCLOSEESM" + a));
	return i;
}
function ye(e, t) {
	return t.fogEnabled && e.applyFog && t.fogMode !== 0;
}
function be(e, t, n, r, i, a, o, s = !1, c = !1, l, u) {
	if (o._areMiscDirty) {
		o.LOGARITHMICDEPTH = n, o.POINTSIZE = r, o.FOG = i && ye(e, t), o.NONUNIFORMSCALING = e.nonUniformScaling, o.ALPHATEST = a, o.DECAL_AFTER_DETAIL = s, o.USE_VERTEX_PULLING = c, o.RIGHT_HANDED = t.useRightHandedSystem;
		let d = l?.geometry?.getIndexBuffer(), f = l ? l.isUnIndexed : !1;
		o.VERTEX_PULLING_USE_INDEX_BUFFER = !!d && !f, o.VERTEX_PULLING_INDEX_BUFFER_32BITS = d && !f ? d.is32Bits : !1, o.VERTEXOUTPUT_INVARIANT = !!u;
	}
}
function xe(e, t, n, r = !1) {
	if (!e.lightsEnabled || r) return !0;
	let i = t.lightSources, a = Math.min(i.length, n);
	for (let e = 0; e < a; e++) if (!i[e].areLightTexturesReady()) return !1;
	return !0;
}
function Se(e, t, n, r, i = 4, a = !1) {
	if (!n._areLightsDirty) return n._needNormals;
	let o = i;
	i = pe(e, i);
	let s = 0, c = {
		needNormals: n._needNormals,
		needRebuild: !1,
		lightmapMode: !1,
		shadowEnabled: !1,
		specularEnabled: !1
	};
	if (e.lightsEnabled && !a) {
		t.lightSources.length > i && i < o && me(e.getEngine(), o, i, Math.min(t.lightSources.length, o));
		for (let a of t.lightSources) if (we(e, t, a, s, n, r, c), s++, s === i) break;
	}
	n.SPECULARTERM = c.specularEnabled, n.SHADOWS = c.shadowEnabled;
	let l = Math.max(i, n.MAXLIGHTCOUNT || 0);
	for (let e = s; e < l; e++) n["LIGHT" + e] !== void 0 && (n["LIGHT" + e] = !1, n["HEMILIGHT" + e] = !1, n["POINTLIGHT" + e] = !1, n["DIRLIGHT" + e] = !1, n["SPOTLIGHT" + e] = !1, n["AREALIGHT" + e] = !1, n["CLUSTLIGHT" + e] = !1, n["SHADOW" + e] = !1, n["SHADOWCSM" + e] = !1, n["SHADOWCSMDEBUG" + e] = !1, n["SHADOWCSMNUM_CASCADES" + e] = !1, n["SHADOWCSMUSESHADOWMAXZ" + e] = !1, n["SHADOWCSMNOBLEND" + e] = !1, n["SHADOWCSM_RIGHTHANDED" + e] = !1, n["SHADOWPCF" + e] = !1, n["SHADOWPCSS" + e] = !1, n["SHADOWPOISSON" + e] = !1, n["SHADOWESM" + e] = !1, n["SHADOWCLOSEESM" + e] = !1, n["SHADOWCUBE" + e] = !1, n["SHADOWLOWQUALITY" + e] = !1, n["SHADOWMEDIUMQUALITY" + e] = !1);
	n.LIGHTCOUNT = s, n.MAXLIGHTCOUNT = i;
	let u = e.getEngine().getCaps();
	return n.SHADOWFLOAT === void 0 && (c.needRebuild = !0), n.SHADOWFLOAT = c.shadowEnabled && (u.textureFloatRender && u.textureFloatLinearFiltering || u.textureHalfFloatRender && u.textureHalfFloatLinearFiltering), n.LIGHTMAPEXCLUDED = c.lightmapMode, c.needRebuild && n.rebuild(), c.needNormals;
}
function Ce(e, t, n, r = !1, i = 8, a = !1) {
	if (t && I.ReflectionTextureEnabled) {
		if (!t.isReadyOrNotBlocking()) return !1;
		n._needNormals = !0, n.REFLECTION = !0, n.GAMMAREFLECTION = t.gammaSpace, n.RGBDREFLECTION = t.isRGBD, n.LODINREFLECTIONALPHA = t.lodLevelInAlpha, n.LINEARSPECULARREFLECTION = t.linearSpecularLOD, n.USEIRRADIANCEMAP = !1, n.LODBASEDMICROSFURACE = e.getEngine().getCaps().textureLOD;
		let o = e.getEngine();
		switch (r && i > 0 ? (n.NUM_SAMPLES = "" + i, o._features.needTypeSuffixInShaderConstants && (n.NUM_SAMPLES += "u"), n.REALTIME_FILTERING = !0, e.iblCdfGenerator && (n.IBL_CDF_FILTERING = !0)) : n.REALTIME_FILTERING = !1, n.INVERTCUBICMAP = t.coordinatesMode === 6, n.REFLECTIONMAP_3D = t.isCube, n.REFLECTIONMAP_OPPOSITEZ = n.REFLECTIONMAP_3D && e.useRightHandedSystem ? !t.invertZ : t.invertZ, n.REFLECTIONMAP_CUBIC = !1, n.REFLECTIONMAP_EXPLICIT = !1, n.REFLECTIONMAP_PLANAR = !1, n.REFLECTIONMAP_PROJECTION = !1, n.REFLECTIONMAP_SKYBOX = !1, n.REFLECTIONMAP_SPHERICAL = !1, n.REFLECTIONMAP_EQUIRECTANGULAR = !1, n.REFLECTIONMAP_EQUIRECTANGULAR_FIXED = !1, n.REFLECTIONMAP_MIRROREDEQUIRECTANGULAR_FIXED = !1, t.coordinatesMode) {
			case 0:
				n.REFLECTIONMAP_EXPLICIT = !0;
				break;
			case 2:
				n.REFLECTIONMAP_PLANAR = !0;
				break;
			case 4:
				n.REFLECTIONMAP_PROJECTION = !0;
				break;
			case 5:
				n.REFLECTIONMAP_SKYBOX = !0;
				break;
			case 1:
				n.REFLECTIONMAP_SPHERICAL = !0;
				break;
			case 7:
				n.REFLECTIONMAP_EQUIRECTANGULAR = !0;
				break;
			case 8:
				n.REFLECTIONMAP_EQUIRECTANGULAR_FIXED = !0;
				break;
			case 9:
				n.REFLECTIONMAP_MIRROREDEQUIRECTANGULAR_FIXED = !0;
				break;
			default: n.REFLECTIONMAP_CUBIC = !0, n.USE_LOCAL_REFLECTIONMAP_CUBIC = !!t.boundingBoxSize;
		}
		t.coordinatesMode !== 5 && (t.irradianceTexture ? (n.USEIRRADIANCEMAP = !0, n.USESPHERICALFROMREFLECTIONMAP = !1, n.USESPHERICALINVERTEX = !1, n.USE_IRRADIANCE_DOMINANT_DIRECTION = !!t.irradianceTexture._dominantDirection) : t.isCube && (n.USESPHERICALFROMREFLECTIONMAP = !0, n.USEIRRADIANCEMAP = !1, n.USE_IRRADIANCE_DOMINANT_DIRECTION = !1, n.USESPHERICALINVERTEX = a));
	} else n.REFLECTION = !1, n.REFLECTIONMAP_3D = !1, n.REFLECTIONMAP_SPHERICAL = !1, n.REFLECTIONMAP_PLANAR = !1, n.REFLECTIONMAP_CUBIC = !1, n.USE_LOCAL_REFLECTIONMAP_CUBIC = !1, n.REFLECTIONMAP_PROJECTION = !1, n.REFLECTIONMAP_SKYBOX = !1, n.REFLECTIONMAP_EXPLICIT = !1, n.REFLECTIONMAP_EQUIRECTANGULAR = !1, n.REFLECTIONMAP_EQUIRECTANGULAR_FIXED = !1, n.REFLECTIONMAP_MIRROREDEQUIRECTANGULAR_FIXED = !1, n.INVERTCUBICMAP = !1, n.USESPHERICALFROMREFLECTIONMAP = !1, n.USEIRRADIANCEMAP = !1, n.USE_IRRADIANCE_DOMINANT_DIRECTION = !1, n.USESPHERICALINVERTEX = !1, n.REFLECTIONMAP_OPPOSITEZ = !1, n.LODINREFLECTIONALPHA = !1, n.GAMMAREFLECTION = !1, n.RGBDREFLECTION = !1, n.LINEARSPECULARREFLECTION = !1;
	return !0;
}
function we(e, t, n, r, i, a, o) {
	switch (o.needNormals = !0, i["LIGHT" + r] === void 0 && (o.needRebuild = !0), i["LIGHT" + r] = !0, i["SPOTLIGHT" + r] = !1, i["HEMILIGHT" + r] = !1, i["POINTLIGHT" + r] = !1, i["DIRLIGHT" + r] = !1, i["AREALIGHT" + r] = !1, i["CLUSTLIGHT" + r] = !1, n.prepareLightSpecificDefines(i, r), i["LIGHT_FALLOFF_PHYSICAL" + r] = !1, i["LIGHT_FALLOFF_GLTF" + r] = !1, i["LIGHT_FALLOFF_STANDARD" + r] = !1, n.falloffType) {
		case x.FALLOFF_GLTF:
			i["LIGHT_FALLOFF_GLTF" + r] = !0;
			break;
		case x.FALLOFF_PHYSICAL:
			i["LIGHT_FALLOFF_PHYSICAL" + r] = !0;
			break;
		case x.FALLOFF_STANDARD: i["LIGHT_FALLOFF_STANDARD" + r] = !0;
	}
	if (a && !n.specular.equalsFloats(0, 0, 0) && (o.specularEnabled = !0), i["SHADOW" + r] = !1, i["SHADOWCSM" + r] = !1, i["SHADOWCSMDEBUG" + r] = !1, i["SHADOWCSMNUM_CASCADES" + r] = !1, i["SHADOWCSMUSESHADOWMAXZ" + r] = !1, i["SHADOWCSMNOBLEND" + r] = !1, i["SHADOWCSM_RIGHTHANDED" + r] = !1, i["SHADOWPCF" + r] = !1, i["SHADOWPCSS" + r] = !1, i["SHADOWPOISSON" + r] = !1, i["SHADOWESM" + r] = !1, i["SHADOWCLOSEESM" + r] = !1, i["SHADOWCUBE" + r] = !1, i["SHADOWLOWQUALITY" + r] = !1, i["SHADOWMEDIUMQUALITY" + r] = !1, t && t.receiveShadows && e.shadowsEnabled && n.shadowEnabled) {
		let t = n.getShadowGenerator(e.activeCamera) ?? n.getShadowGenerator();
		if (t) {
			let e = t.getShadowMap();
			e && e.renderList && e.renderList.length > 0 && (o.shadowEnabled = !0, t.prepareDefines(i, r));
		}
	}
	n.lightmapMode == x.LIGHTMAP_DEFAULT ? (i["LIGHTMAPEXCLUDED" + r] = !1, i["LIGHTMAPNOSPECULAR" + r] = !1) : (o.lightmapMode = !0, i["LIGHTMAPEXCLUDED" + r] = !0, i["LIGHTMAPNOSPECULAR" + r] = n.lightmapMode == x.LIGHTMAP_SHADOWSONLY);
}
function Te(e, t, n, r, i, a = null, o = !1) {
	let s = Fe(e, r);
	a !== !1 && (s = oe(n, e, r)), r.DEPTHPREPASS !== !t.getColorWrite() && (r.DEPTHPREPASS = !r.DEPTHPREPASS, s = !0), r.INSTANCES !== i && (r.INSTANCES = i, s = !0), r.THIN_INSTANCES !== o && (r.THIN_INSTANCES = o, s = !0), s && r.markAsUnprocessed();
}
var Ee = 40, De = 64, X = /* @__PURE__ */ new WeakMap(), Z = /* @__PURE__ */ new WeakSet();
function Oe(e, t) {
	if (e.useBones && e.computeBonesUsingShaders && e.skeleton) {
		t.NUM_BONE_INFLUENCERS = e.numBoneInfluencers;
		let r = t.BONETEXTURE !== void 0;
		if (e.skeleton.isUsingTextureForMatrices && r) t.BONETEXTURE = !0;
		else {
			t.BonesPerMesh = e.skeleton.bones.length + 1, t.BONETEXTURE = !r && void 0;
			let i = e.getScene(), a = i.prePassRenderer;
			a && a.enabled && (t.BONES_VELOCITY_ENABLED = a.excludedSkinnedMesh.indexOf(e) === -1);
			let o = t.MULTIVIEW === !0, s = t.BonesPerMesh * 2 + +!!o;
			if (X.get(e.skeleton) !== s) {
				X.set(e.skeleton, s);
				let r = i.getEngine().getCaps().maxVertexUniformVectors;
				if (r && !Z.has(e.skeleton)) {
					let i = t.BonesPerMesh * 4, a = Math.max(r - (o ? De : Ee), 0);
					(i > a || o && i * 3 > r) && (Z.add(e.skeleton), n.Warn(`Skeleton "${e.skeleton.name}": ${e.skeleton.bones.length} bones stored as vertex uniforms use ${i} of ~${a} usable uniform vectors${o ? " (multiview)" : ""} on a device reporting ${r}. This can exceed the GPU vertex-uniform limit and make the mesh silently fail to render. Set skeleton.useTextureToStoreBoneMatrices = true to store bone matrices in a texture.`));
				}
			}
		}
	} else t.NUM_BONE_INFLUENCERS = 0, t.BonesPerMesh = 0, t.BONETEXTURE !== void 0 && (t.BONETEXTURE = !1);
}
function ke(e, t) {
	let n = e.morphTargetManager;
	n ? (t.MORPHTARGETS_UV = n.supportsUVs && t.UV1, t.MORPHTARGETS_UV2 = n.supportsUV2s && t.UV2, t.MORPHTARGETS_TANGENT = n.supportsTangents && t.TANGENT, t.MORPHTARGETS_NORMAL = n.supportsNormals && t.NORMAL, t.MORPHTARGETS_POSITION = n.supportsPositions, t.MORPHTARGETS_COLOR = n.supportsColors, t.MORPHTARGETTEXTURE_HASUVS = n.hasUVs, t.MORPHTARGETTEXTURE_HASUV2S = n.hasUV2s, t.MORPHTARGETTEXTURE_HASTANGENTS = n.hasTangents, t.MORPHTARGETTEXTURE_HASNORMALS = n.hasNormals, t.MORPHTARGETTEXTURE_HASPOSITIONS = n.hasPositions, t.MORPHTARGETTEXTURE_HASCOLORS = n.hasColors, t.NUM_MORPH_INFLUENCERS = n.numMaxInfluencers || n.numInfluencers, t.MORPHTARGETS = t.NUM_MORPH_INFLUENCERS > 0, t.MORPHTARGETS_TEXTURE = n.isUsingTextureForTargets) : (t.MORPHTARGETS_UV = !1, t.MORPHTARGETS_UV2 = !1, t.MORPHTARGETS_TANGENT = !1, t.MORPHTARGETS_NORMAL = !1, t.MORPHTARGETS_POSITION = !1, t.MORPHTARGETS_COLOR = !1, t.MORPHTARGETTEXTURE_HASUVS = !1, t.MORPHTARGETTEXTURE_HASUV2S = !1, t.MORPHTARGETTEXTURE_HASTANGENTS = !1, t.MORPHTARGETTEXTURE_HASNORMALS = !1, t.MORPHTARGETTEXTURE_HASPOSITIONS = !1, t.MORPHTARGETTEXTURE_HAS_COLORS = !1, t.MORPHTARGETS = !1, t.NUM_MORPH_INFLUENCERS = 0);
}
function Ae(e, t) {
	let n = e.bakedVertexAnimationManager;
	t.BAKED_VERTEX_ANIMATION_TEXTURE = !!(n && n.isEnabled);
}
function je(e, t, n, r, i = !1, a = !0, o = !0) {
	if (!t._areAttributesDirty && t._needNormals === t._normals && t._needUVs === t._uvs) return !1;
	t._normals = t._needNormals, t._uvs = t._needUVs, t.NORMAL = t._needNormals && e.isVerticesDataPresent("normal"), t._needNormals && e.isVerticesDataPresent("tangent") && (t.TANGENT = !0);
	for (let n = 1; n <= 6; ++n) t["UV" + n] = t._needUVs ? e.isVerticesDataPresent(`uv${n === 1 ? "" : n}`) : !1;
	if (n) {
		let n = e.useVertexColors && e.isVerticesDataPresent("color");
		t.VERTEXCOLOR = n, t.VERTEXALPHA = e.hasVertexAlpha && n && a;
	}
	return e.isVerticesDataPresent("instanceColor") && (e.hasInstances || e.hasThinInstances) && (t.INSTANCESCOLOR = !0), r && Oe(e, t), i && ke(e, t), o && Ae(e, t), !0;
}
function Me(e, t) {
	if (e.activeCamera) {
		let n = t.MULTIVIEW;
		t.MULTIVIEW = e.activeCamera.outputRenderTarget !== null && e.activeCamera.outputRenderTarget.getViewCount() > 1, t.MULTIVIEW != n && t.markAsUnprocessed();
	}
}
function Ne(e, t, n) {
	let r = t.ORDER_INDEPENDENT_TRANSPARENCY, i = t.ORDER_INDEPENDENT_TRANSPARENCY_16BITS;
	t.ORDER_INDEPENDENT_TRANSPARENCY = e.useOrderIndependentTransparency && n, t.ORDER_INDEPENDENT_TRANSPARENCY_16BITS = !e.getEngine().getCaps().textureFloatLinearFiltering, (r !== t.ORDER_INDEPENDENT_TRANSPARENCY || i !== t.ORDER_INDEPENDENT_TRANSPARENCY_16BITS) && t.markAsUnprocessed();
}
function Pe(e, t, n) {
	let r = t.PREPASS;
	if (!t._arePrePassDirty) return;
	let i = [
		{
			type: 1,
			define: "PREPASS_POSITION",
			index: "PREPASS_POSITION_INDEX"
		},
		{
			type: 9,
			define: "PREPASS_LOCAL_POSITION",
			index: "PREPASS_LOCAL_POSITION_INDEX"
		},
		{
			type: 2,
			define: "PREPASS_VELOCITY",
			index: "PREPASS_VELOCITY_INDEX"
		},
		{
			type: 11,
			define: "PREPASS_VELOCITY_LINEAR",
			index: "PREPASS_VELOCITY_LINEAR_INDEX"
		},
		{
			type: 3,
			define: "PREPASS_REFLECTIVITY",
			index: "PREPASS_REFLECTIVITY_INDEX"
		},
		{
			type: 0,
			define: "PREPASS_IRRADIANCE_LEGACY",
			index: "PREPASS_IRRADIANCE_LEGACY_INDEX"
		},
		{
			type: 7,
			define: "PREPASS_ALBEDO_SQRT",
			index: "PREPASS_ALBEDO_SQRT_INDEX"
		},
		{
			type: 5,
			define: "PREPASS_DEPTH",
			index: "PREPASS_DEPTH_INDEX"
		},
		{
			type: 10,
			define: "PREPASS_SCREENSPACE_DEPTH",
			index: "PREPASS_SCREENSPACE_DEPTH_INDEX"
		},
		{
			type: 6,
			define: "PREPASS_NORMAL",
			index: "PREPASS_NORMAL_INDEX"
		},
		{
			type: 8,
			define: "PREPASS_WORLD_NORMAL",
			index: "PREPASS_WORLD_NORMAL_INDEX"
		},
		{
			type: 14,
			define: "PREPASS_IRRADIANCE",
			index: "PREPASS_IRRADIANCE_INDEX"
		}
	];
	if (e.prePassRenderer && e.prePassRenderer.enabled && n) {
		t.PREPASS = !0, t.SCENE_MRT_COUNT = e.prePassRenderer.mrtCount, t.PREPASS_NORMAL_WORLDSPACE = e.prePassRenderer.generateNormalsInWorldSpace, t.PREPASS_COLOR = !0, t.PREPASS_COLOR_INDEX = 0;
		for (let n = 0; n < i.length; n++) {
			let r = e.prePassRenderer.getIndex(i[n].type);
			r === -1 ? t[i[n].define] = !1 : (t[i[n].define] = !0, t[i[n].index] = r);
		}
	} else {
		t.PREPASS = !1;
		for (let e = 0; e < i.length; e++) t[i[e].define] = !1;
	}
	t.PREPASS != r && (t.markAsUnprocessed(), t.markAsImageProcessingDirty());
}
function Fe(e, t) {
	let n = !1;
	if (e.activeCamera) {
		let r = +!!t.CAMERA_ORTHOGRAPHIC, i = +!!t.CAMERA_PERSPECTIVE, a = +(e.activeCamera.mode === 1), o = +(e.activeCamera.mode === 0);
		(r ^ a || i ^ o) && (t.CAMERA_ORTHOGRAPHIC = a === 1, t.CAMERA_PERSPECTIVE = o === 1, n = !0);
	}
	return n;
}
function Q(e, t, n, r, i = null, a = !1, o = !1, s = !1, c = !1, l = !1) {
	i && i.push("Light" + e), !a && (t.push("vLightData" + e, "vLightDiffuse" + e, "vLightSpecular" + e, "vLightDirection" + e, "vLightWidth" + e, "vLightHeight" + e, "vLightFalloff" + e, "vLightGround" + e, "vSliceData" + e, "vSliceRanges" + e, "lightMatrix" + e, "shadowsInfo" + e, "depthValues" + e), n.push("shadowTexture" + e), n.push("depthTexture" + e), t.push("viewFrustumZ" + e, "cascadeBlendFactor" + e, "lightSizeUVCorrection" + e, "depthCorrection" + e, "penumbraDarkness" + e, "frustumLengths" + e), r && (n.push("projectionLightTexture" + e), t.push("textureProjectionMatrix" + e)), o && n.push("iesLightTexture" + e), c && n.push("rectAreaLightEmissionTexture" + e), s && (n.push("lightDataTexture" + e), l || n.push("tileMaskTexture" + e)));
}
function Ie(e, t, n) {
	let r = [
		"vReflectionMicrosurfaceInfos",
		"vReflectionDominantDirection",
		"reflectionMatrix",
		"vReflectionInfos",
		"vReflectionPosition",
		"vReflectionSize",
		"vReflectionColor",
		"vReflectionFilteringInfo"
	];
	n && r.push("vSphericalX", "vSphericalY", "vSphericalZ", "vSphericalXX_ZZ", "vSphericalYY_ZZ", "vSphericalZZ", "vSphericalXY", "vSphericalYZ", "vSphericalZX", "vSphericalL00", "vSphericalL1_1", "vSphericalL10", "vSphericalL11", "vSphericalL2_2", "vSphericalL2_1", "vSphericalL20", "vSphericalL21", "vSphericalL22"), e.push(...r), t.push("reflectionSampler", "reflectionSamplerLow", "reflectionSamplerHigh", "irradianceSampler", "icdfSampler");
}
function Le(e, t, n, r = 4) {
	let i, a, o = null;
	if (e.uniformsNames) {
		let s = e;
		i = s.uniformsNames, a = s.uniformBuffersNames, t = s.samplers, n = s.defines, r = s.maxSimultaneousLights || 0, o = s.shaderLanguage ?? null;
	} else i = e, t ||= [];
	for (let e = 0; e < r && n["LIGHT" + e]; e++) Q(e, i, t, n["PROJECTEDLIGHTTEXTURE" + e], a, !1, n["IESLIGHTTEXTURE" + e], n["CLUSTLIGHT" + e], n["RECTAREALIGHTEMISSIONTEXTURE" + e], o === 1);
	n.NUM_MORPH_INFLUENCERS && (i.push("morphTargetInfluences"), i.push("morphTargetCount")), n.BAKED_VERTEX_ANIMATION_TEXTURE && (i.push("bakedVertexAnimationSettings"), i.push("bakedVertexAnimationTextureSizeInverted"), i.push("bakedVertexAnimationTime"), t.push("bakedVertexAnimationTexture"));
}
function Re(e, t = !1, n = !1, r = !1, i = !1, a = !1) {
	e.addUniform("vReflectionInfos", 2), e.addUniform("reflectionMatrix", 16), t && e.addUniform("vReflectionMicrosurfaceInfos", 3), n && (e.addUniform("vReflectionPosition", 3), e.addUniform("vReflectionSize", 3)), r && (e.addUniform("vReflectionFilteringInfo", 2), e.addUniform("vReflectionDominantDirection", 3)), a && e.addUniform("vReflectionColor", 3), i && (e.addUniform("vSphericalL00", 3), e.addUniform("vSphericalL1_1", 3), e.addUniform("vSphericalL10", 3), e.addUniform("vSphericalL11", 3), e.addUniform("vSphericalL2_2", 3), e.addUniform("vSphericalL2_1", 3), e.addUniform("vSphericalL20", 3), e.addUniform("vSphericalL21", 3), e.addUniform("vSphericalL22", 3), e.addUniform("vSphericalX", 3), e.addUniform("vSphericalY", 3), e.addUniform("vSphericalZ", 3), e.addUniform("vSphericalXX_ZZ", 3), e.addUniform("vSphericalYY_ZZ", 3), e.addUniform("vSphericalZZ", 3), e.addUniform("vSphericalXY", 3), e.addUniform("vSphericalYZ", 3), e.addUniform("vSphericalZX", 3));
}
//#endregion
//#region node_modules/@babylonjs/core/Materials/material.pure.js
var $ = (() => {
	var r;
	let i = [], a, s = [], c = [], l, u = [], d = [], f, g = [], x = [], ee, S = [], C = [], w, T = [], E = [], D, O = [], k = [], A, j = [], M = [], N, ie = [], ae = [], oe, P = [], F = [], I, L = [], R = [], z, B = [], V = [], H, U = [], W = [], G, K = [], q = [], ce, le = [], ue = [], de, fe = [], J = [], Y, pe = [], me = [], he, ge = [], _e = [], ve, ye = [], be = [], xe, Se = [], Ce = [], we, Te = [], Ee = [], De, X = [], Z = [], Oe, ke = [], Ae = [], je, Me = [], Ne = [], Pe, Fe = [], Q = [], Ie, Le, Re, $, ze = [], Be = [], Ve;
	return r = class {
		get useVertexPulling() {
			return this._useVertexPulling;
		}
		set useVertexPulling(e) {
			this._useVertexPulling !== e && (this._useVertexPulling = e, this.markAsDirty(r.MiscDirtyFlag));
		}
		get _supportGlowLayer() {
			return !1;
		}
		set _glowModeEnabled(e) {}
		get shaderLanguage() {
			return this._shaderLanguage;
		}
		get canRenderToMRT() {
			return !1;
		}
		set alpha(e) {
			if (this._alpha === e) return;
			let t = this._alpha;
			this._alpha = e, (t === 1 || e === 1) && this.markAsDirty(r.MiscDirtyFlag + r.PrePassDirtyFlag);
		}
		get alpha() {
			return this._alpha;
		}
		set backFaceCulling(e) {
			this._backFaceCulling !== e && (this._backFaceCulling = e, this.markAsDirty(r.TextureDirtyFlag));
		}
		get backFaceCulling() {
			return this._backFaceCulling;
		}
		set textureRepetitionMode(e) {
			let t = Math.max(0, Math.min(e | 0, 4));
			this._textureRepetitionMode !== t && (this._textureRepetitionMode = t, this.markAsDirty(r.TextureDirtyFlag));
		}
		get textureRepetitionMode() {
			return this._textureRepetitionMode;
		}
		set cullBackFaces(e) {
			this._cullBackFaces !== e && (this._cullBackFaces = e, this.markAsDirty(r.TextureDirtyFlag));
		}
		get cullBackFaces() {
			return this._cullBackFaces;
		}
		get blockDirtyMechanism() {
			return this._blockDirtyMechanism;
		}
		set blockDirtyMechanism(e) {
			this._blockDirtyMechanism !== e && (this._blockDirtyMechanism = e, e || this.markDirty());
		}
		atomicMaterialsUpdate(e) {
			this.blockDirtyMechanism = !0;
			try {
				e(this);
			} finally {
				this.blockDirtyMechanism = !1;
			}
		}
		get hasRenderTargetTextures() {
			return this._eventInfo.hasRenderTargetTextures = !1, this._callbackPluginEventHasRenderTargetTextures(this._eventInfo), this._eventInfo.hasRenderTargetTextures;
		}
		set onDispose(e) {
			this._onDisposeObserver && this.onDisposeObservable.remove(this._onDisposeObserver), this._onDisposeObserver = this.onDisposeObservable.add(e);
		}
		get onBindObservable() {
			return this._onBindObservable ||= new e(), this._onBindObservable;
		}
		set onBind(e) {
			this._onBindObserver && this.onBindObservable.remove(this._onBindObserver), this._onBindObserver = this.onBindObservable.add(e);
		}
		get onUnBindObservable() {
			return this._onUnBindObservable ||= new e(), this._onUnBindObservable;
		}
		get onEffectCreatedObservable() {
			return this._onEffectCreatedObservable ||= new e(), this._onEffectCreatedObservable;
		}
		set alphaMode(e) {
			this._alphaMode[0] !== e && (this._alphaMode[0] = e, this.markAsDirty(r.TextureDirtyFlag));
		}
		get alphaMode() {
			return this._alphaMode[0];
		}
		get alphaModes() {
			return this._alphaMode;
		}
		setAlphaMode(e, t = 0) {
			this._alphaMode[t] !== e && (this._alphaMode[t] = e, this.markAsDirty(r.TextureDirtyFlag));
		}
		set needDepthPrePass(e) {
			this._needDepthPrePass !== e && (this._needDepthPrePass = e, this._needDepthPrePass && (this.checkReadyOnEveryCall = !0));
		}
		get needDepthPrePass() {
			return this._needDepthPrePass;
		}
		get isPrePassCapable() {
			return !1;
		}
		set fogEnabled(e) {
			this._fogEnabled !== e && (this._fogEnabled = e, this.markAsDirty(r.MiscDirtyFlag));
		}
		get fogEnabled() {
			return this._fogEnabled;
		}
		get wireframe() {
			switch (this._fillMode) {
				case r.WireFrameFillMode:
				case r.LineListDrawMode:
				case r.LineLoopDrawMode:
				case r.LineStripDrawMode: return !0;
			}
			return this._scene.forceWireframe;
		}
		set wireframe(e) {
			this.fillMode = e ? r.WireFrameFillMode : r.TriangleFillMode;
		}
		get pointsCloud() {
			switch (this._fillMode) {
				case r.PointFillMode:
				case r.PointListDrawMode: return !0;
			}
			return this._scene.forcePointsCloud;
		}
		set pointsCloud(e) {
			this.fillMode = e ? r.PointFillMode : r.TriangleFillMode;
		}
		get fillMode() {
			return this._fillMode;
		}
		set fillMode(e) {
			this._fillMode !== e && (this._fillMode = e, this.markAsDirty(r.MiscDirtyFlag));
		}
		get useLogarithmicDepth() {
			return this._useLogarithmicDepth;
		}
		set useLogarithmicDepth(e) {
			let t = this.getScene().getEngine().getCaps().fragmentDepthSupported;
			e && !t && n.Warn("Logarithmic depth has been requested for a material on a device that doesn't support it."), this._useLogarithmicDepth = e && t, this._markAllSubMeshesAsMiscDirty();
		}
		get isVertexOutputInvariant() {
			return this._isVertexOutputInvariant;
		}
		set isVertexOutputInvariant(e) {
			this._isVertexOutputInvariant !== e && (this._isVertexOutputInvariant = e, this._markAllSubMeshesAsMiscDirty());
		}
		_getDrawWrapper() {
			return this._drawWrapper;
		}
		_setDrawWrapper(e) {
			this._drawWrapper = e;
		}
		constructor(n, a, o, l = !1) {
			this.customShaderNameResolve = m(this, i), this.shadowDepthWrapper = null, this.allowShaderHotSwapping = !0, this._shaderLanguage = 0, this._forceGLSL = !1, this._useVertexPulling = !1, this.id = m(this, s, void 0), this.uniqueId = (m(this, c), m(this, u, void 0)), this._loadedUniqueId = m(this, d), this.name = m(this, g, void 0), this.metadata = (m(this, x), m(this, S, null)), this._internalMetadata = m(this, C), this.reservedDataStore = null, this.checkReadyOnEveryCall = m(this, T, !1), this.checkReadyOnlyOnce = (m(this, E), m(this, O, !1)), this.state = (m(this, k), m(this, j, "")), this._alpha = (m(this, M), m(this, ie, 1)), this.inspectableCustomProperties = m(this, ae), this._backFaceCulling = m(this, P, !0), this._textureRepetitionMode = (m(this, F), m(this, L, 0)), this.textureRepetitionHexTilingParams = (m(this, R), m(this, B, [
				1,
				.6,
				7,
				.5
			])), this._cullBackFaces = (m(this, V), m(this, U, !0)), this._blockDirtyMechanism = (m(this, W), !1), this.sideOrientation = m(this, K, null), this.onCompiled = (m(this, q), null), this.onError = null, this.getRenderTargetTextures = null, this.doNotSerialize = !1, this._storeEffectOnSubMeshes = !1, this.animations = null, this.onDisposeObservable = new e(), this._onDisposeObserver = null, this._onUnBindObservable = null, this._onBindObserver = null, this._alphaMode = m(this, le, [2]), this._needDepthPrePass = (m(this, ue), m(this, fe, !1)), this.disableDepthWrite = (m(this, J), m(this, pe, !1)), this.disableColorWrite = (m(this, me), m(this, ge, !1)), this.forceDepthWrite = (m(this, _e), m(this, ye, !1)), this.depthFunction = (m(this, be), m(this, Se, 0)), this.separateCullingPass = (m(this, Ce), m(this, Te, !1)), this._fogEnabled = (m(this, Ee), m(this, X, !0)), this.pointSize = (m(this, Z), m(this, ke, 1)), this.zOffset = (m(this, Ae), m(this, Me, 0)), this.zOffsetUnits = (m(this, Ne), m(this, Fe, 0)), this.clipPlane = m(this, Q), this.stencil = new re(), this._isVertexOutputInvariant = m(this, ze, r.ForceVertexOutputInvariant), this._materialContext = m(this, Be), this._useUBO = !1, this._fillMode = r.TriangleFillMode, this._cachedDepthWriteState = !1, this._cachedColorWriteState = !1, this._cachedDepthFunctionState = 0, this._indexInSceneMaterialArray = -1, this.meshMap = null, this._parentContainer = null, this._uniformBufferLayoutBuilt = !1, this._eventInfo = {}, this._callbackPluginEventGeneric = () => void 0, this._callbackPluginEventIsReadyForSubMesh = () => void 0, this._callbackPluginEventPrepareDefines = () => void 0, this._callbackPluginEventPrepareDefinesBeforeAttributes = () => void 0, this._callbackPluginEventHardBindForSubMesh = () => void 0, this._callbackPluginEventBindForSubMesh = () => void 0, this._callbackPluginEventHasRenderTargetTextures = () => void 0, this._callbackPluginEventFillRenderTargetTextures = () => void 0, this._transparencyMode = null, this.name = n;
			let f = a || t.LastCreatedScene;
			f && (this._scene = f, this._dirtyCallbacks = {}, this._forceGLSL = l, this._dirtyCallbacks[1] = this._markAllSubMeshesAsTexturesDirty.bind(this), this._dirtyCallbacks[2] = this._markAllSubMeshesAsLightsDirty.bind(this), this._dirtyCallbacks[4] = this._markAllSubMeshesAsFresnelDirty.bind(this), this._dirtyCallbacks[8] = this._markAllSubMeshesAsAttributesDirty.bind(this), this._dirtyCallbacks[16] = this._markAllSubMeshesAsMiscDirty.bind(this), this._dirtyCallbacks[32] = this._markAllSubMeshesAsPrePassDirty.bind(this), this._dirtyCallbacks[127] = this._markAllSubMeshesAsAllDirty.bind(this), this.id = n || y.RandomId(), this.uniqueId = this._scene.getUniqueId(), this._materialContext = this._scene.getEngine().createMaterialContext(), this._drawWrapper = new te(this._scene.getEngine(), !1), this._drawWrapper.materialContext = this._materialContext, this._uniformBuffer = new b(this._scene.getEngine(), void 0, void 0, n), this._useUBO = this.getScene().getEngine().supportsUniformBuffers, this._createUniformBuffer(), o || this._scene.addMaterial(this), this._scene.useMaterialMeshMap && (this.meshMap = {}), r.OnEventObservable.notifyObservers(this, 1));
		}
		_createUniformBuffer() {
			let e = this.getScene().getEngine();
			this._uniformBuffer?.dispose(), e.isWebGPU && !this._forceGLSL ? (this._uniformBuffer = new b(e, void 0, void 0, this.name, !0), this._shaderLanguage = 1) : this._uniformBuffer = new b(this._scene.getEngine(), void 0, void 0, this.name), this._uniformBufferLayoutBuilt = !1;
		}
		toString(e) {
			return "Name: " + this.name;
		}
		getClassName() {
			return "Material";
		}
		get _isMaterial() {
			return !0;
		}
		get isFrozen() {
			return this.checkReadyOnlyOnce;
		}
		freeze() {
			this.markDirty(), this.checkReadyOnlyOnce = !0;
		}
		unfreeze() {
			this.markDirty(), this.checkReadyOnlyOnce = !1;
		}
		isReady(e, t) {
			return !0;
		}
		isReadyForSubMesh(e, t, n) {
			let r = t.materialDefines;
			return r ? (this._eventInfo.isReadyForSubMesh = !0, this._eventInfo.defines = r, this._callbackPluginEventIsReadyForSubMesh(this._eventInfo), this._eventInfo.isReadyForSubMesh) : !1;
		}
		getEffect() {
			return this._drawWrapper.effect;
		}
		getScene() {
			return this._scene;
		}
		_getEffectiveOrientation(e) {
			return this.sideOrientation === null ? e.sideOrientation : this.sideOrientation;
		}
		get transparencyMode() {
			return this._transparencyMode;
		}
		set transparencyMode(e) {
			this._transparencyMode !== e && (this._transparencyMode = e, this._markAllSubMeshesAsTexturesAndMiscDirty());
		}
		get _hasTransparencyMode() {
			return this._transparencyMode != null;
		}
		get _transparencyModeIsBlend() {
			return this._transparencyMode === r.MATERIAL_ALPHABLEND || this._transparencyMode === r.MATERIAL_ALPHATESTANDBLEND;
		}
		get _transparencyModeIsTest() {
			return this._transparencyMode === r.MATERIAL_ALPHATEST || this._transparencyMode === r.MATERIAL_ALPHATESTANDBLEND;
		}
		get _disableAlphaBlending() {
			return this._transparencyMode === r.MATERIAL_OPAQUE || this._transparencyMode === r.MATERIAL_ALPHATEST;
		}
		needAlphaBlending() {
			return this._hasTransparencyMode ? this._transparencyModeIsBlend : !this._disableAlphaBlending && this.alpha < 1;
		}
		needAlphaBlendingForMesh(e) {
			return this._hasTransparencyMode ? this._transparencyModeIsBlend : e.visibility < 1 ? !0 : this._disableAlphaBlending ? !1 : e.hasVertexAlpha || this.needAlphaBlending();
		}
		needAlphaTesting() {
			return this._hasTransparencyMode ? this._transparencyModeIsTest : !1;
		}
		needAlphaTestingForMesh(e) {
			return this._hasTransparencyMode ? this._transparencyModeIsTest : !this.needAlphaBlendingForMesh(e) && this.needAlphaTesting();
		}
		getAlphaTestTexture() {
			return null;
		}
		markDirty(e = !1) {
			let t = this.getScene().meshes;
			for (let n of t) if (n.subMeshes) for (let t of n.subMeshes) for (let n = 0; n < t._drawWrappers.length; n++) {
				let r = t._drawWrappers[n];
				r && t.getMaterial(!0, n) === this && this._materialContext === r.materialContext && (r._wasPreviouslyReady = !1, r._wasPreviouslyUsingInstances = null, r._forceRebindOnNextCall = e);
			}
			e && this.markAsDirty(r.AllDirtyFlag);
		}
		_preBind(e, t = null) {
			let n = this._scene.getEngine(), i = (t ?? this.sideOrientation) === r.ClockWiseSideOrientation, a = e || this._getDrawWrapper();
			return o(a) && a.materialContext && (a.materialContext.useVertexPulling = this.useVertexPulling), n.enableEffect(a), n.setState(this.backFaceCulling, this.zOffset, !1, i, this._scene._mirroredCameraPosition ? !this.cullBackFaces : this.cullBackFaces, this.stencil, this.zOffsetUnits), i;
		}
		bind(e, t) {}
		buildUniformLayout() {
			let e = this._uniformBuffer;
			this._eventInfo.ubo = e, this._callbackPluginEventGeneric(8, this._eventInfo), e.create(), this._uniformBufferLayoutBuilt = !0;
		}
		bindForSubMesh(e, t, n) {
			let r = n._drawWrapper;
			this._eventInfo.subMesh = n, this._callbackPluginEventBindForSubMesh(this._eventInfo), r._forceRebindOnNextCall = !1;
		}
		bindOnlyWorldMatrix(e) {}
		bindView(e) {
			this._useUBO ? this._needToBindSceneUbo = !0 : e.setMatrix("view", this.getScene().getViewMatrix());
		}
		bindViewProjection(e) {
			this._useUBO ? this._needToBindSceneUbo = !0 : (e.setMatrix("viewProjection", this.getScene().getTransformMatrix()), e.setMatrix("projection", this.getScene().getProjectionMatrix()), e.setMatrix("inverseProjection", this.getScene().getInverseProjectionMatrix()));
		}
		bindEyePosition(e, t) {
			this._useUBO ? this._needToBindSceneUbo = !0 : this._scene.bindEyePosition(e, t);
		}
		_afterBind(e, t = null, n) {
			if (this._scene._cachedMaterial = this, this._needToBindSceneUbo && t && (this._needToBindSceneUbo = !1, se(t, this.getScene().getSceneUniformBuffer()), this._scene.finalizeSceneUbo()), e ? this._scene._cachedVisibility = e.visibility : this._scene._cachedVisibility = 1, this._onBindObservable && e && this._onBindObservable.notifyObservers(e), this.disableDepthWrite) {
				let e = this._scene.getEngine();
				this._cachedDepthWriteState = e.getDepthWrite(), e.setDepthWrite(!1);
			}
			if (this.disableColorWrite) {
				let e = this._scene.getEngine();
				this._cachedColorWriteState = e.getColorWrite(), e.setColorWrite(!1);
			}
			if (this.depthFunction !== 0) {
				let e = this._scene.getEngine();
				this._cachedDepthFunctionState = e.getDepthFunction() || 0, e.setDepthFunction(this.depthFunction);
			}
		}
		unbind() {
			this._scene.getSceneUniformBuffer().unbindEffect(), this._onUnBindObservable && this._onUnBindObservable.notifyObservers(this), this.depthFunction !== 0 && this._scene.getEngine().setDepthFunction(this._cachedDepthFunctionState), this.disableDepthWrite && this._scene.getEngine().setDepthWrite(this._cachedDepthWriteState), this.disableColorWrite && this._scene.getEngine().setColorWrite(this._cachedColorWriteState);
		}
		getAnimatables() {
			return this._eventInfo.animatables = [], this._callbackPluginEventGeneric(256, this._eventInfo), this._eventInfo.animatables;
		}
		getActiveTextures() {
			return this._eventInfo.activeTextures = [], this._callbackPluginEventGeneric(512, this._eventInfo), this._eventInfo.activeTextures;
		}
		hasTexture(e) {
			return this._eventInfo.hasTexture = !1, this._eventInfo.texture = e, this._callbackPluginEventGeneric(1024, this._eventInfo), this._eventInfo.hasTexture;
		}
		clone(e) {
			return null;
		}
		_clonePlugins(e, t) {
			let n = {};
			if (this._serializePlugins(n), r._ParsePlugins(n, e, this._scene, t), this.pluginManager) for (let t of this.pluginManager._plugins) {
				let n = e.pluginManager.getPlugin(t.name);
				n && t.copyTo(n);
			}
		}
		getBindedMeshes() {
			if (this.meshMap) {
				let e = [];
				for (let t in this.meshMap) {
					let n = this.meshMap[t];
					n && e.push(n);
				}
				return e;
			}
			return this._scene.meshes.filter((e) => e.material === this);
		}
		forceCompilation(e, t, n, r) {
			let i = {
				clipPlane: !1,
				useInstances: !1,
				...n
			}, a = this.getScene(), o = this.allowShaderHotSwapping;
			this.allowShaderHotSwapping = !1;
			let s = () => {
				if (!this._scene || !this._scene.getEngine()) return;
				let n = a.clipPlane;
				if (i.clipPlane && (a.clipPlane = new p(0, 0, 0, 1)), this._storeEffectOnSubMeshes) {
					let n = !0, a = null;
					if (e.subMeshes) {
						let t = new ne(0, 0, 0, 0, 0, e, void 0, !1, !1);
						t.materialDefines && (t.materialDefines._renderId = -1), this.isReadyForSubMesh(e, t, i.useInstances) || (t.effect && t.effect.getCompilationError() && t.effect.allFallbacksProcessed() ? a = t.effect.getCompilationError() : (n = !1, setTimeout(s, 16)));
					}
					n && (this.allowShaderHotSwapping = o, a && r && r(a), t && t(this));
				} else this.isReady() ? (this.allowShaderHotSwapping = o, t && t(this)) : setTimeout(s, 16);
				i.clipPlane && (a.clipPlane = n);
			};
			s();
		}
		async forceCompilationAsync(e, t) {
			return await new Promise((n, r) => {
				this.forceCompilation(e, () => {
					n();
				}, t, (e) => {
					r(e);
				});
			});
		}
		markAsDirty(e) {
			this.getScene().blockMaterialDirtyMechanism || this._blockDirtyMechanism || (r._DirtyCallbackArray.length = 0, e & r.ImageProcessingDirtyFlag && r._DirtyCallbackArray.push(r._ImageProcessingDirtyCallBack), e & r.TextureDirtyFlag && r._DirtyCallbackArray.push(r._TextureDirtyCallBack), e & r.LightDirtyFlag && r._DirtyCallbackArray.push(r._LightsDirtyCallBack), e & r.FresnelDirtyFlag && r._DirtyCallbackArray.push(r._FresnelDirtyCallBack), e & r.AttributesDirtyFlag && r._DirtyCallbackArray.push(r._AttributeDirtyCallBack), e & r.MiscDirtyFlag && r._DirtyCallbackArray.push(r._MiscDirtyCallBack), e & r.PrePassDirtyFlag && r._DirtyCallbackArray.push(r._PrePassDirtyCallBack), r._DirtyCallbackArray.length && this._markAllSubMeshesAsDirty(r._RunDirtyCallBacks), this.getScene().resetCachedMaterial());
		}
		resetDrawCache() {
			let e = this.getScene().meshes;
			for (let t of e) if (t.subMeshes) for (let e of t.subMeshes) for (let t = 0; t < e._drawWrappers.length; t++) e._drawWrappers[t] && e.getMaterial(!0, t) === this && e.resetDrawCache(t);
		}
		_markAllSubMeshesAsDirty(e) {
			let t = this.getScene();
			if (t.blockMaterialDirtyMechanism || this._blockDirtyMechanism) return;
			let n = t.meshes;
			for (let t of n) if (t.subMeshes) for (let n of t.subMeshes) {
				let t = n._drawWrappers;
				if (t.length && n._mayRenderWithMaterial(this)) for (let r = 0; r < t.length; r++) {
					let i = t[r];
					i && n.getMaterial(!0, r) === this && i.defines && i.defines.markAllAsDirty && this._materialContext === i.materialContext && e(i.defines);
				}
			}
		}
		_markScenePrePassDirty() {
			if (this.getScene().blockMaterialDirtyMechanism || this._blockDirtyMechanism) return;
			let e = this.getScene().enablePrePassRenderer();
			e && e.markAsDirty();
		}
		_markAllSubMeshesAsAllDirty() {
			this._markAllSubMeshesAsDirty(r._AllDirtyCallBack);
		}
		_markAllSubMeshesAsImageProcessingDirty() {
			this._markAllSubMeshesAsDirty(r._ImageProcessingDirtyCallBack);
		}
		_markAllSubMeshesAsTexturesDirty() {
			this._markAllSubMeshesAsDirty(r._TextureDirtyCallBack);
		}
		_markAllSubMeshesAsFresnelDirty() {
			this._markAllSubMeshesAsDirty(r._FresnelDirtyCallBack);
		}
		_markAllSubMeshesAsFresnelAndMiscDirty() {
			this._markAllSubMeshesAsDirty(r._FresnelAndMiscDirtyCallBack);
		}
		_markAllSubMeshesAsLightsDirty() {
			this._markAllSubMeshesAsDirty(r._LightsDirtyCallBack);
		}
		_markAllSubMeshesAsAttributesDirty() {
			this._markAllSubMeshesAsDirty(r._AttributeDirtyCallBack);
		}
		_markAllSubMeshesAsMiscDirty() {
			this._markAllSubMeshesAsDirty(r._MiscDirtyCallBack);
		}
		_markAllSubMeshesAsPrePassDirty() {
			this._markAllSubMeshesAsDirty(r._PrePassDirtyCallBack);
		}
		_markAllSubMeshesAsTexturesAndMiscDirty() {
			this._markAllSubMeshesAsDirty(r._TextureAndMiscDirtyCallBack);
		}
		_checkScenePerformancePriority() {
			if (this._scene.performancePriority !== 0) {
				this.checkReadyOnlyOnce = !0;
				let e = this._scene.onScenePerformancePriorityChangedObservable.addOnce(() => {
					this.checkReadyOnlyOnce = !1;
				});
				this.onDisposeObservable.add(() => {
					this._scene.onScenePerformancePriorityChangedObservable.remove(e);
				});
			}
		}
		setPrePassRenderer(e) {
			return !1;
		}
		dispose(e, t, n) {
			let r = this.getScene();
			if (r.stopAnimation(this), r.freeProcessedMaterials(), r.removeMaterial(this), this._eventInfo.forceDisposeTextures = t, this._callbackPluginEventGeneric(2, this._eventInfo), this._parentContainer) {
				let e = this._parentContainer.materials.indexOf(this);
				e > -1 && this._parentContainer.materials.splice(e, 1), this._parentContainer = null;
			}
			if (n !== !0) {
				if (this.meshMap) for (let e in this.meshMap) {
					let t = this.meshMap[e];
					this._disposeMeshResources(t);
				}
				else {
					let e = r.meshes;
					for (let t of e) this._disposeMeshResources(t);
				}
			}
			this._uniformBuffer.dispose(), this._drawWrapper.effect && (this._storeEffectOnSubMeshes || this._drawWrapper.effect.dispose(), this._drawWrapper.effect = null), this.metadata = null, this.onDisposeObservable.notifyObservers(this), this.onDisposeObservable.clear(), this._onBindObservable && this._onBindObservable.clear(), this._onUnBindObservable && this._onUnBindObservable.clear(), this._onEffectCreatedObservable && this._onEffectCreatedObservable.clear(), this._eventInfo &&= {};
		}
		_disposeMeshResources(e) {
			if (!e) return;
			let t = e.geometry, n = e._internalAbstractMeshDataInfo._materialForRenderPass;
			if (this._storeEffectOnSubMeshes) {
				if (e.subMeshes && n) for (let r of e.subMeshes) {
					let e = r._drawWrappers;
					for (let i = 0; i < e.length; i++) {
						let a = e[i]?.effect;
						a && n[i] === this && (t?._releaseVertexArrayObject(a), r._removeDrawWrapper(i, !0, !0));
					}
				}
			} else t?._releaseVertexArrayObject(this._drawWrapper.effect);
			e.material === this && !e.sourceMesh && (e.material = null);
		}
		serialize() {
			let e = v.Serialize(this);
			return e.stencil = this.stencil.serialize(), e.uniqueId = this.uniqueId, this._serializePlugins(e), e;
		}
		_serializePlugins(e) {
			if (e.plugins = {}, this.pluginManager) for (let t of this.pluginManager._plugins) t.doNotSerialize || (e.plugins[t.getClassName()] = t.serialize());
		}
		static ParseAlphaMode(e, t) {
			t._alphaMode = e._alphaMode === void 0 ? e.alphaMode === void 0 ? [2] : Array.isArray(e.alphaMode) ? [...e.alphaMode] : [e.alphaMode] : Array.isArray(e._alphaMode) ? [...e._alphaMode] : [e._alphaMode];
		}
		static Parse(e, t, i) {
			if (!e.customType) e.customType = "BABYLON.StandardMaterial";
			else if (e.customType === "BABYLON.PBRMaterial" && e.overloadedAlbedo && (e.customType = "BABYLON.LegacyPBRMaterial", !BABYLON.LegacyPBRMaterial)) return n.Error("Your scene is trying to load a legacy version of the PBRMaterial, please, include it from the materials library."), null;
			let a = y.Instantiate(e.customType).Parse(e, t, i);
			return a._loadedUniqueId = e.uniqueId, r.ParseAlphaMode(e, a), a;
		}
		static _ParsePlugins(e, t, n, r) {
			if (e.plugins) for (let i in e.plugins) {
				let a = e.plugins[i], o = t.pluginManager?.getPlugin(a.name);
				if (!o) {
					let e = y.Instantiate("BABYLON." + i);
					e && (o = new e(t));
				}
				o?.parse(a, n, r);
			}
		}
	}, (() => {
		let e = typeof Symbol == "function" && Symbol.metadata ? Object.create(null) : void 0;
		a = [h()], l = [h()], f = [h()], ee = [h()], w = [h()], D = [h()], A = [h()], N = [h("alpha")], oe = [h("backFaceCulling")], I = [h("textureRepetitionMode")], z = [h("textureRepetitionHexTilingParams")], H = [h("cullBackFaces")], G = [h()], ce = [h()], de = [h()], Y = [h()], he = [h()], ve = [h()], xe = [h()], we = [h()], De = [h("fogEnabled")], Oe = [h()], je = [h()], Pe = [h()], Ie = [h()], Le = [h()], Re = [h()], $ = [h()], Ve = [h()], _(r, null, Ie, {
			kind: "getter",
			name: "pointsCloud",
			static: !1,
			private: !1,
			access: {
				has: (e) => "pointsCloud" in e,
				get: (e) => e.pointsCloud
			},
			metadata: e
		}, null, i), _(r, null, Le, {
			kind: "getter",
			name: "fillMode",
			static: !1,
			private: !1,
			access: {
				has: (e) => "fillMode" in e,
				get: (e) => e.fillMode
			},
			metadata: e
		}, null, i), _(r, null, Re, {
			kind: "getter",
			name: "useLogarithmicDepth",
			static: !1,
			private: !1,
			access: {
				has: (e) => "useLogarithmicDepth" in e,
				get: (e) => e.useLogarithmicDepth
			},
			metadata: e
		}, null, i), _(r, null, Ve, {
			kind: "getter",
			name: "transparencyMode",
			static: !1,
			private: !1,
			access: {
				has: (e) => "transparencyMode" in e,
				get: (e) => e.transparencyMode
			},
			metadata: e
		}, null, i), _(null, null, a, {
			kind: "field",
			name: "id",
			static: !1,
			private: !1,
			access: {
				has: (e) => "id" in e,
				get: (e) => e.id,
				set: (e, t) => {
					e.id = t;
				}
			},
			metadata: e
		}, s, c), _(null, null, l, {
			kind: "field",
			name: "uniqueId",
			static: !1,
			private: !1,
			access: {
				has: (e) => "uniqueId" in e,
				get: (e) => e.uniqueId,
				set: (e, t) => {
					e.uniqueId = t;
				}
			},
			metadata: e
		}, u, d), _(null, null, f, {
			kind: "field",
			name: "name",
			static: !1,
			private: !1,
			access: {
				has: (e) => "name" in e,
				get: (e) => e.name,
				set: (e, t) => {
					e.name = t;
				}
			},
			metadata: e
		}, g, x), _(null, null, ee, {
			kind: "field",
			name: "metadata",
			static: !1,
			private: !1,
			access: {
				has: (e) => "metadata" in e,
				get: (e) => e.metadata,
				set: (e, t) => {
					e.metadata = t;
				}
			},
			metadata: e
		}, S, C), _(null, null, w, {
			kind: "field",
			name: "checkReadyOnEveryCall",
			static: !1,
			private: !1,
			access: {
				has: (e) => "checkReadyOnEveryCall" in e,
				get: (e) => e.checkReadyOnEveryCall,
				set: (e, t) => {
					e.checkReadyOnEveryCall = t;
				}
			},
			metadata: e
		}, T, E), _(null, null, D, {
			kind: "field",
			name: "checkReadyOnlyOnce",
			static: !1,
			private: !1,
			access: {
				has: (e) => "checkReadyOnlyOnce" in e,
				get: (e) => e.checkReadyOnlyOnce,
				set: (e, t) => {
					e.checkReadyOnlyOnce = t;
				}
			},
			metadata: e
		}, O, k), _(null, null, A, {
			kind: "field",
			name: "state",
			static: !1,
			private: !1,
			access: {
				has: (e) => "state" in e,
				get: (e) => e.state,
				set: (e, t) => {
					e.state = t;
				}
			},
			metadata: e
		}, j, M), _(null, null, N, {
			kind: "field",
			name: "_alpha",
			static: !1,
			private: !1,
			access: {
				has: (e) => "_alpha" in e,
				get: (e) => e._alpha,
				set: (e, t) => {
					e._alpha = t;
				}
			},
			metadata: e
		}, ie, ae), _(null, null, oe, {
			kind: "field",
			name: "_backFaceCulling",
			static: !1,
			private: !1,
			access: {
				has: (e) => "_backFaceCulling" in e,
				get: (e) => e._backFaceCulling,
				set: (e, t) => {
					e._backFaceCulling = t;
				}
			},
			metadata: e
		}, P, F), _(null, null, I, {
			kind: "field",
			name: "_textureRepetitionMode",
			static: !1,
			private: !1,
			access: {
				has: (e) => "_textureRepetitionMode" in e,
				get: (e) => e._textureRepetitionMode,
				set: (e, t) => {
					e._textureRepetitionMode = t;
				}
			},
			metadata: e
		}, L, R), _(null, null, z, {
			kind: "field",
			name: "textureRepetitionHexTilingParams",
			static: !1,
			private: !1,
			access: {
				has: (e) => "textureRepetitionHexTilingParams" in e,
				get: (e) => e.textureRepetitionHexTilingParams,
				set: (e, t) => {
					e.textureRepetitionHexTilingParams = t;
				}
			},
			metadata: e
		}, B, V), _(null, null, H, {
			kind: "field",
			name: "_cullBackFaces",
			static: !1,
			private: !1,
			access: {
				has: (e) => "_cullBackFaces" in e,
				get: (e) => e._cullBackFaces,
				set: (e, t) => {
					e._cullBackFaces = t;
				}
			},
			metadata: e
		}, U, W), _(null, null, G, {
			kind: "field",
			name: "sideOrientation",
			static: !1,
			private: !1,
			access: {
				has: (e) => "sideOrientation" in e,
				get: (e) => e.sideOrientation,
				set: (e, t) => {
					e.sideOrientation = t;
				}
			},
			metadata: e
		}, K, q), _(null, null, ce, {
			kind: "field",
			name: "_alphaMode",
			static: !1,
			private: !1,
			access: {
				has: (e) => "_alphaMode" in e,
				get: (e) => e._alphaMode,
				set: (e, t) => {
					e._alphaMode = t;
				}
			},
			metadata: e
		}, le, ue), _(null, null, de, {
			kind: "field",
			name: "_needDepthPrePass",
			static: !1,
			private: !1,
			access: {
				has: (e) => "_needDepthPrePass" in e,
				get: (e) => e._needDepthPrePass,
				set: (e, t) => {
					e._needDepthPrePass = t;
				}
			},
			metadata: e
		}, fe, J), _(null, null, Y, {
			kind: "field",
			name: "disableDepthWrite",
			static: !1,
			private: !1,
			access: {
				has: (e) => "disableDepthWrite" in e,
				get: (e) => e.disableDepthWrite,
				set: (e, t) => {
					e.disableDepthWrite = t;
				}
			},
			metadata: e
		}, pe, me), _(null, null, he, {
			kind: "field",
			name: "disableColorWrite",
			static: !1,
			private: !1,
			access: {
				has: (e) => "disableColorWrite" in e,
				get: (e) => e.disableColorWrite,
				set: (e, t) => {
					e.disableColorWrite = t;
				}
			},
			metadata: e
		}, ge, _e), _(null, null, ve, {
			kind: "field",
			name: "forceDepthWrite",
			static: !1,
			private: !1,
			access: {
				has: (e) => "forceDepthWrite" in e,
				get: (e) => e.forceDepthWrite,
				set: (e, t) => {
					e.forceDepthWrite = t;
				}
			},
			metadata: e
		}, ye, be), _(null, null, xe, {
			kind: "field",
			name: "depthFunction",
			static: !1,
			private: !1,
			access: {
				has: (e) => "depthFunction" in e,
				get: (e) => e.depthFunction,
				set: (e, t) => {
					e.depthFunction = t;
				}
			},
			metadata: e
		}, Se, Ce), _(null, null, we, {
			kind: "field",
			name: "separateCullingPass",
			static: !1,
			private: !1,
			access: {
				has: (e) => "separateCullingPass" in e,
				get: (e) => e.separateCullingPass,
				set: (e, t) => {
					e.separateCullingPass = t;
				}
			},
			metadata: e
		}, Te, Ee), _(null, null, De, {
			kind: "field",
			name: "_fogEnabled",
			static: !1,
			private: !1,
			access: {
				has: (e) => "_fogEnabled" in e,
				get: (e) => e._fogEnabled,
				set: (e, t) => {
					e._fogEnabled = t;
				}
			},
			metadata: e
		}, X, Z), _(null, null, Oe, {
			kind: "field",
			name: "pointSize",
			static: !1,
			private: !1,
			access: {
				has: (e) => "pointSize" in e,
				get: (e) => e.pointSize,
				set: (e, t) => {
					e.pointSize = t;
				}
			},
			metadata: e
		}, ke, Ae), _(null, null, je, {
			kind: "field",
			name: "zOffset",
			static: !1,
			private: !1,
			access: {
				has: (e) => "zOffset" in e,
				get: (e) => e.zOffset,
				set: (e, t) => {
					e.zOffset = t;
				}
			},
			metadata: e
		}, Me, Ne), _(null, null, Pe, {
			kind: "field",
			name: "zOffsetUnits",
			static: !1,
			private: !1,
			access: {
				has: (e) => "zOffsetUnits" in e,
				get: (e) => e.zOffsetUnits,
				set: (e, t) => {
					e.zOffsetUnits = t;
				}
			},
			metadata: e
		}, Fe, Q), _(null, null, $, {
			kind: "field",
			name: "_isVertexOutputInvariant",
			static: !1,
			private: !1,
			access: {
				has: (e) => "_isVertexOutputInvariant" in e,
				get: (e) => e._isVertexOutputInvariant,
				set: (e, t) => {
					e._isVertexOutputInvariant = t;
				}
			},
			metadata: e
		}, ze, Be), e && Object.defineProperty(r, Symbol.metadata, {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: e
		});
	})(), r.TriangleFillMode = 0, r.WireFrameFillMode = 1, r.PointFillMode = 2, r.PointListDrawMode = 3, r.LineListDrawMode = 4, r.LineLoopDrawMode = 5, r.LineStripDrawMode = 6, r.TriangleStripDrawMode = 7, r.TriangleFanDrawMode = 8, r.ClockWiseSideOrientation = 0, r.CounterClockWiseSideOrientation = 1, r.ImageProcessingDirtyFlag = 64, r.TextureDirtyFlag = 1, r.LightDirtyFlag = 2, r.FresnelDirtyFlag = 4, r.AttributesDirtyFlag = 8, r.MiscDirtyFlag = 16, r.PrePassDirtyFlag = 32, r.AllDirtyFlag = 127, r.MATERIAL_OPAQUE = 0, r.MATERIAL_ALPHATEST = 1, r.MATERIAL_ALPHABLEND = 2, r.MATERIAL_ALPHATESTANDBLEND = 3, r.MATERIAL_NORMALBLENDMETHOD_WHITEOUT = 0, r.MATERIAL_NORMALBLENDMETHOD_RNM = 1, r.LIGHTFALLOFF_PHYSICAL = 0, r.LIGHTFALLOFF_GLTF = 1, r.LIGHTFALLOFF_STANDARD = 2, r.OnEventObservable = new e(), r.ForceVertexOutputInvariant = !1, r._AllDirtyCallBack = (e) => e.markAllAsDirty(), r._ImageProcessingDirtyCallBack = (e) => e.markAsImageProcessingDirty(), r._TextureDirtyCallBack = (e) => e.markAsTexturesDirty(), r._FresnelDirtyCallBack = (e) => e.markAsFresnelDirty(), r._MiscDirtyCallBack = (e) => e.markAsMiscDirty(), r._PrePassDirtyCallBack = (e) => e.markAsPrePassDirty(), r._LightsDirtyCallBack = (e) => e.markAsLightDirty(), r._AttributeDirtyCallBack = (e) => e.markAsAttributesDirty(), r._FresnelAndMiscDirtyCallBack = (e) => {
		r._FresnelDirtyCallBack(e), r._MiscDirtyCallBack(e);
	}, r._TextureAndMiscDirtyCallBack = (e) => {
		r._TextureDirtyCallBack(e), r._MiscDirtyCallBack(e);
	}, r._DirtyCallbackArray = [], r._RunDirtyCallBacks = (e) => {
		for (let t of r._DirtyCallbackArray) t(e);
	}, r;
})();
Object.getOwnPropertyDescriptor($.prototype, "pluginManager") || Object.defineProperty($.prototype, "pluginManager", a("Material", "pluginManager"));
//#endregion
export { U as A, be as C, Re as D, Pe as E, ne as F, M as I, k as L, ie as M, P as N, Ie as O, ae as P, q as S, Ne as T, V as _, G as a, Ce as b, L as c, ce as d, ve as f, H as g, _e as h, B as i, I as j, Le as k, W as l, ge as m, xe as n, K as o, le as p, de as r, he as s, $ as t, se as u, je as v, Me as w, Se as x, Te as y };
