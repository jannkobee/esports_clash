//#region node_modules/@babylonjs/core/Misc/bitArray.js
function e(e) {
	return Math.floor(e / 8);
}
function t(e) {
	return 1 << e % 8;
}
var n = class {
	constructor(e) {
		this.size = e, this._byteArray = new Uint8Array(Math.ceil(this.size / 8));
	}
	get(n) {
		if (n >= this.size) throw RangeError("Bit index out of range");
		let r = e(n), i = t(n);
		return (this._byteArray[r] & i) !== 0;
	}
	set(n, r) {
		if (n >= this.size) throw RangeError("Bit index out of range");
		let i = e(n), a = t(n);
		r ? this._byteArray[i] |= a : this._byteArray[i] &= ~a;
	}
};
//#endregion
//#region node_modules/@babylonjs/core/Meshes/mesh.vertexData.functions.js
function r(e) {
	let t = [], r = e.length / 3;
	for (let n = 0; n < r; n++) t.push([
		e[n * 3],
		e[n * 3 + 1],
		e[n * 3 + 2]
	]);
	let i = /* @__PURE__ */ new Map();
	for (let e = 0; e < t.length; e++) {
		let n = t[e];
		for (let t of n) {
			let n = i.get(t);
			n || i.set(t, n = []), n.push(e);
		}
	}
	let a = new n(r), o = [], s = (e) => {
		let n = [e];
		for (; n.length > 0;) {
			let e = n.pop();
			if (!a.get(e)) {
				a.set(e, !0), o.push(t[e]);
				for (let r of t[e]) {
					let e = i.get(r);
					if (!e) return;
					for (let t of e) a.get(t) || n.push(t);
				}
			}
		}
	};
	for (let e = 0; e < r; e++) a.get(e) || s(e);
	let c = 0;
	for (let t of o) e[c++] = t[0], e[c++] = t[1], e[c++] = t[2];
}
//#endregion
export { r as OptimizeIndices };
