import { n as e } from "./engineStore-D0BoPdea.js";
import { t } from "./logger-DQIzSR_y.js";
import { n } from "./typeStore-pENEWnX2.js";
import { t as r } from "./flowGraphInteger.pure-DqL1vt3x.js";
import { t as i } from "./flowGraphAsyncExecutionBlock-y06fnRVP.js";
import { c as a, i as o } from "./flowGraphRichTypes.pure-BpKU4EZT.js";
import { n as s, r as c, t as l } from "./flowGraphDelayRegistry-DO7wtljZ.js";
//#region node_modules/@babylonjs/core/Misc/timer.js
var u;
(function(e) {
	e[e.INIT = 0] = "INIT", e[e.STARTED = 1] = "STARTED", e[e.ENDED = 2] = "ENDED";
})(u ||= {});
var d = class {
	constructor(t) {
		this.onEachCountObservable = new e(), this.onTimerAbortedObservable = new e(), this.onTimerEndedObservable = new e(), this.onStateChangedObservable = new e(), this._observer = null, this._breakOnNextTick = !1, this._tick = (e) => {
			let t = Date.now();
			this._timer = t - this._startTime;
			let n = {
				startTime: this._startTime,
				currentTime: t,
				deltaTime: this._timer,
				completeRate: this._timer / this._timeToEnd,
				payload: e
			}, r = this._breakOnNextTick || this._breakCondition(n);
			r || this._timer >= this._timeToEnd ? this._stop(n, r) : this.onEachCountObservable.notifyObservers(n);
		}, this._setState(0), this._contextObservable = t.contextObservable, this._observableParameters = t.observableParameters ?? {}, this._breakCondition = t.breakCondition ?? (() => !1), this._timeToEnd = t.timeout, t.onEnded && this.onTimerEndedObservable.add(t.onEnded), t.onTick && this.onEachCountObservable.add(t.onTick), t.onAborted && this.onTimerAbortedObservable.add(t.onAborted);
	}
	set breakCondition(e) {
		this._breakCondition = e;
	}
	clearObservables() {
		this.onEachCountObservable.clear(), this.onTimerAbortedObservable.clear(), this.onTimerEndedObservable.clear(), this.onStateChangedObservable.clear();
	}
	start(e = this._timeToEnd) {
		if (this._state === 1) throw Error("Timer already started. Please stop it before starting again");
		this._timeToEnd = e, this._startTime = Date.now(), this._timer = 0, this._observer = this._contextObservable.add(this._tick, this._observableParameters.mask, this._observableParameters.insertFirst, this._observableParameters.scope), this._setState(1);
	}
	stop() {
		this._state === 1 && (this._breakOnNextTick = !0);
	}
	dispose() {
		this._observer && this._contextObservable.remove(this._observer), this.clearObservables();
	}
	_setState(e) {
		this._state = e, this.onStateChangedObservable.notifyObservers(this._state);
	}
	_stop(e, t = !1) {
		this._contextObservable.remove(this._observer), this._setState(2), t ? this.onTimerAbortedObservable.notifyObservers(e) : this.onTimerEndedObservable.notifyObservers(e);
	}
}, f = class e extends i {
	constructor(e) {
		super(e), this.cancel = this._registerSignalInput("cancel"), this.duration = this.registerDataInput("duration", a), this.lastDelayIndex = this.registerDataOutput("lastDelayIndex", o, new r(-1));
	}
	_preparePendingTasks(t) {
		let n = this.duration.getValue(t);
		if (n < 0 || isNaN(n) || !isFinite(n)) return this._reportError(t, "Invalid duration in SetDelay block");
		if (t._getGlobalContextVariable("activeDelays", 0) >= e.MaxParallelDelayCount) return this._reportError(t, "Max parallel delays reached");
		let i = t._getGlobalContextVariable("lastDelayIndex", -1), a = t._getExecutionVariable(this, "pendingDelays", []), o = t.configuration.scene, c = new d({
			timeout: n * 1e3,
			contextObservable: o.onBeforeRenderObservable,
			onEnded: () => this._onEnded(c, t)
		});
		c.start();
		let l = i + 1;
		this.lastDelayIndex.setValue(new r(l), t), t._setGlobalContextVariable("lastDelayIndex", l), s(t, l), a[l] = c, t._setExecutionVariable(this, "pendingDelays", a), this._updateGlobalTimers(t);
	}
	_cancelPendingTasks(e) {
		let t = e._getExecutionVariable(this, "pendingDelays", []), n = e._getGlobalContextVariable("pendingDelays", []);
		for (let r = 0; r < t.length; r++) {
			let i = t[r];
			i && (i.dispose(), c(e, r), delete n[r]);
		}
		e._setGlobalContextVariable("pendingDelays", n), e._deleteExecutionVariable(this, "pendingDelays"), this.lastDelayIndex.setValue(new r(-1), e), this._updateGlobalTimers(e);
	}
	_execute(e, t) {
		t === this.cancel ? this._cancelPendingTasks(e) : (this._preparePendingTasks(e), this.out._activateSignal(e));
	}
	getClassName() {
		return "FlowGraphSetDelayBlock";
	}
	_onEnded(e, n) {
		let r = n._getExecutionVariable(this, "pendingDelays", []), i = r.indexOf(e);
		if (i !== -1) {
			delete r[i];
			let e = n._getGlobalContextVariable("pendingDelays", []);
			delete e[i], n._setGlobalContextVariable("pendingDelays", e), c(n, i);
		} else t.Warn("FlowGraphTimerBlock: Timer ended but was not found in the running timers list");
		n._removePendingBlock(this), this.done._activateSignal(n), this._updateGlobalTimers(n);
	}
	_updateGlobalTimers(e) {
		let n = e._getExecutionVariable(this, "pendingDelays", []), r = e._getGlobalContextVariable("pendingDelays", []);
		for (let i = 0; i < n.length; i++) {
			if (!n[i] || !l(e, i)) continue;
			let a = n[i];
			r[i] && r[i] !== a ? t.Warn("FlowGraphTimerBlock: Timer ended but was not found in the running timers list") : r[i] = a;
		}
		e._setGlobalContextVariable("pendingDelays", r);
	}
};
f.MaxParallelDelayCount = 100;
var p = !1;
function m() {
	p || (p = !0, n("FlowGraphSetDelayBlock", f));
}
//#endregion
export { f as FlowGraphSetDelayBlock, m as RegisterFlowGraphSetDelayBlock };
