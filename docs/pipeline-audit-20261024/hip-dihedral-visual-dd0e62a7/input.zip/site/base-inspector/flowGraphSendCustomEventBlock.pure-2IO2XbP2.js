import { n as e } from "./typeStore-pENEWnX2.js";
import { a as t } from "./flowGraphBlock-BTSj91tT.js";
import { t as n } from "./flowGraphExecutionBlockWithOutSignal-XngQvXka.js";
import { g as r } from "./flowGraphRichTypes.pure-BpKU4EZT.js";
//#region node_modules/@babylonjs/core/FlowGraph/Blocks/Event/flowGraphSendCustomEventBlock.pure.js
var i = class extends n {
	constructor(e) {
		super(e), this.config = e;
		for (let e of Object.keys(this.config.eventData ?? {})) {
			let t = this.config.eventData[e], n = typeof t.type == "string" ? t.type : t.type?.typeName, i = typeof t.type?.serialize == "function" ? t.type : r(n);
			t.type = i, this.registerDataInput(e, i, t.value);
		}
	}
	_execute(e) {
		let t = this.config.eventId, n = Object.create(null);
		for (let t of this.dataInputs) Object.defineProperty(n, t.name, {
			configurable: !0,
			enumerable: !0,
			value: t.getValue(e),
			writable: !0
		});
		e.configuration.coordinator.notifyCustomEvent(t, n), this.out._activateSignal(e);
	}
	serialize(e = {}) {
		super.serialize(e);
		let n = Object.create(null);
		for (let e of Object.keys(this.config.eventData ?? {})) {
			let r = this.config.eventData[e], i = { type: r.type.typeName };
			r.value !== void 0 && t("value", r.value, i), Object.defineProperty(n, e, {
				configurable: !0,
				enumerable: !0,
				value: i,
				writable: !0
			});
		}
		e.config.eventData = n;
	}
	getClassName() {
		return "FlowGraphSendCustomEventBlock";
	}
}, a = !1;
function o() {
	a || (a = !0, e("FlowGraphSendCustomEventBlock", i));
}
//#endregion
export { i as FlowGraphSendCustomEventBlock, o as RegisterFlowGraphSendCustomEventBlock };
