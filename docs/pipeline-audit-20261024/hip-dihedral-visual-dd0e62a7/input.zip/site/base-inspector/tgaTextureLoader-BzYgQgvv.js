import { t as e } from "./logger-DQIzSR_y.js";
//#region node_modules/@babylonjs/core/Misc/tga.js
var t = 1, n = 2, r = 3, i = 9, a = 10, o = 11, s = 48, c = 4, l = 0, u = 1, d = 2, f = 3;
function p(e) {
	let t = 0;
	return {
		id_length: e[t++],
		colormap_type: e[t++],
		image_type: e[t++],
		colormap_index: e[t++] | e[t++] << 8,
		colormap_length: e[t++] | e[t++] << 8,
		colormap_size: e[t++],
		origin: [e[t++] | e[t++] << 8, e[t++] | e[t++] << 8],
		width: e[t++] | e[t++] << 8,
		height: e[t++] | e[t++] << 8,
		pixel_size: e[t++],
		flags: e[t]
	};
}
function m(m, h) {
	if (h.length < 19) {
		e.Error("Unable to load TGA file - Not enough data to contain header");
		return;
	}
	let g = 18, _ = p(h);
	if (_.id_length + g > h.length) {
		e.Error("Unable to load TGA file - Not enough data");
		return;
	}
	g += _.id_length;
	let v = !1, y = !1, b = !1;
	switch (_.image_type) {
		case i: v = !0;
		case t:
			y = !0;
			break;
		case a: v = !0;
		case n: break;
		case o: v = !0;
		case r: b = !0;
	}
	let S, C = _.pixel_size >> 3, w = _.width * _.height * C, T;
	if (y && (T = h.subarray(g, g += _.colormap_length * (_.colormap_size >> 3))), v) {
		S = new Uint8Array(w);
		let e, t, n, r = 0, i = new Uint8Array(C);
		for (; g < w && r < w;) if (e = h[g++], t = (e & 127) + 1, e & 128) {
			for (n = 0; n < C; ++n) i[n] = h[g++];
			for (n = 0; n < t; ++n) S.set(i, r + n * C);
			r += C * t;
		} else {
			for (t *= C, n = 0; n < t; ++n) S[r + n] = h[g++];
			r += t;
		}
	} else S = h.subarray(g, g + (y ? _.width * _.height : w));
	let E, D, O, k, A, j;
	switch ((_.flags & s) >> c) {
		default:
		case d:
			E = 0, O = 1, j = _.width, D = 0, k = 1, A = _.height;
			break;
		case l:
			E = 0, O = 1, j = _.width, D = _.height - 1, k = -1, A = -1;
			break;
		case f:
			E = _.width - 1, O = -1, j = -1, D = 0, k = 1, A = _.height;
			break;
		case u: E = _.width - 1, O = -1, j = -1, D = _.height - 1, k = -1, A = -1;
	}
	let M = x["_getImageData" + (b ? "Grey" : "") + _.pixel_size + "bits"](_, T, S, D, k, A, E, O, j);
	m.getEngine()._uploadDataToTextureDirectly(m, M);
}
function h(e, t, n, r, i, a, o, s, c) {
	let l = n, u = t, d = e.width, f = e.height, p, m = 0, h, g, _ = new Uint8Array(d * f * 4);
	for (g = r; g !== a; g += i) for (h = o; h !== c; h += s, m++) p = l[m], _[(h + d * g) * 4 + 3] = 255, _[(h + d * g) * 4 + 2] = u[p * 3 + 0], _[(h + d * g) * 4 + 1] = u[p * 3 + 1], _[(h + d * g) * 4 + 0] = u[p * 3 + 2];
	return _;
}
function g(e, t, n, r, i, a, o, s, c) {
	let l = n, u = e.width, d = e.height, f, p = 0, m, h, g = new Uint8Array(u * d * 4);
	for (h = r; h !== a; h += i) for (m = o; m !== c; m += s, p += 2) {
		f = l[p + 0] + (l[p + 1] << 8);
		let e = ((f & 31744) >> 10) * 255 / 31 | 0, t = ((f & 992) >> 5) * 255 / 31 | 0, n = (f & 31) * 255 / 31 | 0;
		g[(m + u * h) * 4 + 0] = e, g[(m + u * h) * 4 + 1] = t, g[(m + u * h) * 4 + 2] = n, g[(m + u * h) * 4 + 3] = f & 32768 ? 0 : 255;
	}
	return g;
}
function _(e, t, n, r, i, a, o, s, c) {
	let l = n, u = e.width, d = e.height, f = 0, p, m, h = new Uint8Array(u * d * 4);
	for (m = r; m !== a; m += i) for (p = o; p !== c; p += s, f += 3) h[(p + u * m) * 4 + 3] = 255, h[(p + u * m) * 4 + 2] = l[f + 0], h[(p + u * m) * 4 + 1] = l[f + 1], h[(p + u * m) * 4 + 0] = l[f + 2];
	return h;
}
function v(e, t, n, r, i, a, o, s, c) {
	let l = n, u = e.width, d = e.height, f = 0, p, m, h = new Uint8Array(u * d * 4);
	for (m = r; m !== a; m += i) for (p = o; p !== c; p += s, f += 4) h[(p + u * m) * 4 + 2] = l[f + 0], h[(p + u * m) * 4 + 1] = l[f + 1], h[(p + u * m) * 4 + 0] = l[f + 2], h[(p + u * m) * 4 + 3] = l[f + 3];
	return h;
}
function y(e, t, n, r, i, a, o, s, c) {
	let l = n, u = e.width, d = e.height, f, p = 0, m, h, g = new Uint8Array(u * d * 4);
	for (h = r; h !== a; h += i) for (m = o; m !== c; m += s, p++) f = l[p], g[(m + u * h) * 4 + 0] = f, g[(m + u * h) * 4 + 1] = f, g[(m + u * h) * 4 + 2] = f, g[(m + u * h) * 4 + 3] = 255;
	return g;
}
function b(e, t, n, r, i, a, o, s, c) {
	let l = n, u = e.width, d = e.height, f = 0, p, m, h = new Uint8Array(u * d * 4);
	for (m = r; m !== a; m += i) for (p = o; p !== c; p += s, f += 2) h[(p + u * m) * 4 + 0] = l[f + 0], h[(p + u * m) * 4 + 1] = l[f + 0], h[(p + u * m) * 4 + 2] = l[f + 0], h[(p + u * m) * 4 + 3] = l[f + 1];
	return h;
}
var x = {
	GetTGAHeader: p,
	UploadContent: m,
	_getImageData8bits: h,
	_getImageData16bits: g,
	_getImageData24bits: _,
	_getImageData32bits: v,
	_getImageDataGrey8bits: y,
	_getImageDataGrey16bits: b
}, S = class {
	constructor() {
		this.supportCascades = !1;
	}
	loadCubeData() {
		throw ".env not supported in Cube.";
	}
	loadData(e, t, n) {
		let r = new Uint8Array(e.buffer, e.byteOffset, e.byteLength), i = p(r);
		n(i.width, i.height, t.generateMipMaps, !1, () => {
			m(t, r);
		});
	}
};
//#endregion
export { S as _TGATextureLoader };
