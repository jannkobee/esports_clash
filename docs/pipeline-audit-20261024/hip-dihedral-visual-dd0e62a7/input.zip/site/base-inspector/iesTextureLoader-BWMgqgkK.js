import { a as e } from "./math.scalar.functions-D7lyzZPV.js";
//#region node_modules/@babylonjs/core/Lights/IES/iesLoader.js
function t(e) {
	return e.split(" ").filter((e) => e !== "").map((e) => parseFloat(e));
}
function n(e, n, r) {
	for (; r.length !== n;) {
		let n = t(e.lines[e.index++]);
		r.push(...n);
	}
}
function r(t, n, r) {
	let i = 0, a = 0, o = 0, s = 0, c = 0, l = 0;
	for (let e = 0; e < t.numberOfHorizontalAngles - 1; e++) if (r < t.horizontalAngles[e + 1] || e === t.numberOfHorizontalAngles - 2) {
		a = e, o = t.horizontalAngles[e], s = t.horizontalAngles[e + 1];
		break;
	}
	for (let e = 0; e < t.numberOfVerticalAngles - 1; e++) if (n < t.verticalAngles[e + 1] || e === t.numberOfVerticalAngles - 2) {
		i = e, c = t.verticalAngles[e], l = t.verticalAngles[e + 1];
		break;
	}
	let u = s - o, d = l - c;
	if (d === 0) return 0;
	let f = u === 0 ? 0 : (r - o) / u, p = (n - c) / d, m = u === 0 ? a : a + 1, h = e(t.candelaValues[a][i], t.candelaValues[m][i], f), g = e(t.candelaValues[a][i + 1], t.candelaValues[m][i + 1], f);
	return e(h, g, p);
}
function i(e) {
	let i = {
		lines: new TextDecoder("utf-8").decode(e).split("\n"),
		index: 0
	}, a = {
		version: i.lines[0],
		candelaValues: [],
		horizontalAngles: [],
		verticalAngles: [],
		numberOfHorizontalAngles: 0,
		numberOfVerticalAngles: 0
	};
	for (i.index = 1; i.lines.length > 0 && !i.lines[i.index].includes("TILT=");) i.index++;
	i.lines[i.index].includes("INCLUDE"), i.index++;
	let o = t(i.lines[i.index++]);
	a.numberOfLights = o[0], a.lumensPerLamp = o[1], a.numberOfVerticalAngles = o[3], a.numberOfHorizontalAngles = o[4], a.photometricType = o[5], a.unitsType = o[6], a.width = o[7], a.length = o[8], a.height = o[9], i.index++;
	for (let e = 0; e < a.numberOfHorizontalAngles; e++) a.candelaValues[e] = [];
	n(i, a.numberOfVerticalAngles, a.verticalAngles), n(i, a.numberOfHorizontalAngles, a.horizontalAngles);
	for (let e = 0; e < a.numberOfHorizontalAngles; e++) n(i, a.numberOfVerticalAngles, a.candelaValues[e]);
	let s = -1;
	for (let e = 0; e < a.numberOfHorizontalAngles; e++) for (let t = 0; t < a.numberOfVerticalAngles; t++) s = Math.max(s, a.candelaValues[e][t]);
	if (s > 0) for (let e = 0; e < a.numberOfHorizontalAngles; e++) for (let t = 0; t < a.numberOfVerticalAngles; t++) a.candelaValues[e][t] /= s;
	let c = /* @__PURE__ */ new Float32Array(64800), l = a.horizontalAngles[0], u = a.horizontalAngles[a.numberOfHorizontalAngles - 1];
	for (let e = 0; e < 64800; e++) {
		let t = e % 360, n = Math.floor(e / 360);
		u - l !== 0 && (t < l || t >= u) && (t %= u * 2, t > u && (t = u * 2 - t)), c[n + t * 180] = r(a, n, t);
	}
	return {
		width: 180,
		height: 1,
		data: c
	};
}
//#endregion
//#region node_modules/@babylonjs/core/Materials/Textures/Loaders/iesTextureLoader.js
var a = class {
	constructor() {
		this.supportCascades = !1;
	}
	loadCubeData() {
		throw ".ies not supported in Cube.";
	}
	loadData(e, t, n) {
		let r = i(new Uint8Array(e.buffer, e.byteOffset, e.byteLength));
		n(r.width, r.height, !!t.useMipMaps, !1, () => {
			let e = t.getEngine();
			t.type = 1, t.format = 6, t._gammaSpace = !1, e._uploadDataToTextureDirectly(t, r.data);
		});
	}
};
//#endregion
export { a as _IESTextureLoader };
