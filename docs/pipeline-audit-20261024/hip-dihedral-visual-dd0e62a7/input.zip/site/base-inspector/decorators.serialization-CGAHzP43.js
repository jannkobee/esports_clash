import { S as e } from "./tools.functions-DEecYKlu.js";
import { a as t, d as n, l as r, n as i, o as a, t as o, u as s } from "./math.color.pure-CPmbqLkh.js";
import { g as c } from "./decorators-BldPRAAT.js";
//#region node_modules/@babylonjs/core/Misc/andOrNotEvaluator.js
var l = class e {
	static Eval(t, n) {
		return t = t.match(/\([^()]*\)/g) ? t.replace(/\([^()]*\)/g, (t) => (t = t.slice(1, t.length - 1), e._HandleParenthesisContent(t, n))) : e._HandleParenthesisContent(t, n), t === "true" || t !== "false" && e.Eval(t, n);
	}
	static _HandleParenthesisContent(t, n) {
		n ||= ((e) => e === "true");
		let r, i = t.split("||");
		for (let t in i) {
			if (r) break;
			if (Object.prototype.hasOwnProperty.call(i, t)) {
				let a = e._SimplifyNegation(i[t].trim()), o = a.split("&&");
				if (o.length > 1) for (let t = 0; t < o.length; ++t) {
					let i = e._SimplifyNegation(o[t].trim());
					if (r = i !== "true" && i !== "false" ? i[0] === "!" ? !n(i.substring(1)) : n(i) : i === "true", !r) {
						a = "false";
						break;
					}
				}
				if (r || a === "true") {
					r = !0;
					break;
				}
				r = a !== "true" && a !== "false" ? a[0] === "!" ? !n(a.substring(1)) : n(a) : a === "true";
			}
		}
		return r ? "true" : "false";
	}
	static _SimplifyNegation(e) {
		return e = e.replace(/^[\s!]+/, (e) => (e = e.replace(/[\s]/g, () => ""), e.length % 2 ? "!" : "")), e = e.trim(), e === "!true" ? e = "false" : e === "!false" && (e = "true"), e;
	}
}, u = class e {
	static EnableFor(t) {
		t._tags = t._tags || {}, t.hasTags = () => e.HasTags(t), t.addTags = (n) => e.AddTagsTo(t, n), t.removeTags = (n) => e.RemoveTagsFrom(t, n), t.matchesTagsQuery = (n) => e.MatchesQuery(t, n);
	}
	static DisableFor(e) {
		delete e._tags, delete e.hasTags, delete e.addTags, delete e.removeTags, delete e.matchesTagsQuery;
	}
	static HasTags(e) {
		if (!e._tags) return !1;
		let t = e._tags;
		for (let e in t) if (Object.prototype.hasOwnProperty.call(t, e)) return !0;
		return !1;
	}
	static GetTags(e, t = !0) {
		if (!e._tags) return null;
		if (t) {
			let t = [];
			for (let n in e._tags) Object.prototype.hasOwnProperty.call(e._tags, n) && e._tags[n] === !0 && t.push(n);
			return t.join(" ");
		}
		return e._tags;
	}
	static AddTagsTo(t, n) {
		if (!n || typeof n != "string") return;
		let r = n.split(" ");
		for (let n of r) e._AddTagTo(t, n);
	}
	static _AddTagTo(t, n) {
		n = n.trim(), n !== "" && n !== "true" && n !== "false" && (n.match(/[\s]/) || n.match(/^([!]|([|]|[&]){2})/) || (e.EnableFor(t), t._tags[n] = !0));
	}
	static RemoveTagsFrom(t, n) {
		if (!e.HasTags(t)) return;
		let r = n.split(" ");
		for (let n in r) e._RemoveTagFrom(t, r[n]);
	}
	static _RemoveTagFrom(e, t) {
		delete e._tags[t];
	}
	static MatchesQuery(t, n) {
		return n === void 0 ? !0 : n === "" ? e.HasTags(t) : l.Eval(n, (n) => e.HasTags(t) && t._tags[n]);
	}
}, d = function(e, t, n, r = {}) {
	let i = e();
	u && u.HasTags(t) && u.AddTagsTo(i, u.GetTags(t, !0));
	let a = c(i), o = {};
	for (let e in a) {
		let s = a[e], c = t[e], l = s.type;
		if (c != null && (e !== "uniqueId" || f.AllowLoadingUniqueId)) switch (l) {
			case 0:
			case 6:
			case 9:
			case 11:
				i[e] = typeof c.slice == "function" ? c.slice() : c;
				break;
			case 1:
				r.cloneTexturesOnlyOnce && o[c.uniqueId] ? i[e] = o[c.uniqueId] : (i[e] = n || c.isRenderTarget ? c : c.clone(), o[c.uniqueId] = i[e]);
				break;
			case 2:
			case 3:
			case 4:
			case 5:
			case 7:
			case 8:
			case 10:
			case 12:
			case 13: i[e] = n ? c : c.clone();
		}
	}
	return i;
}, f = class e {
	static AppendSerializedAnimations(e, t) {
		if (e.animations) {
			t.animations = [];
			for (let n = 0; n < e.animations.length; n++) {
				let r = e.animations[n];
				t.animations.push(r.serialize());
			}
		}
	}
	static Serialize(t, n) {
		n ||= {}, u && (n.tags = u.GetTags(t));
		let r = c(t);
		for (let i in r) {
			let a = r[i], o = a.sourceName || i, s = a.type, c = t[i];
			if (c != null && (i !== "uniqueId" || e.AllowLoadingUniqueId)) switch (s) {
				case 0:
					Array.isArray(c) ? n[o] = c.slice() : n[o] = c;
					break;
				case 1:
					n[o] = c.serialize();
					break;
				case 2:
					n[o] = c.asArray();
					break;
				case 3:
					n[o] = c.serialize();
					break;
				case 4:
					n[o] = c.asArray();
					break;
				case 5:
					n[o] = c.asArray();
					break;
				case 6:
					n[o] = c.id;
					break;
				case 7:
					n[o] = c.serialize();
					break;
				case 8:
					n[o] = c.asArray();
					break;
				case 9:
					n[o] = c.serialize();
					break;
				case 10:
					n[o] = c.asArray();
					break;
				case 11:
					n[o] = c.id;
					break;
				case 12:
					n[o] = c.asArray();
					break;
				case 13: n[o] = c.asArray();
			}
		}
		return n;
	}
	static ParseProperties(l, u, d, f) {
		f ||= "";
		let p = c(u);
		for (let c in p) {
			let m = p[c], h = l[m.sourceName || c], g = m.type;
			if (h != null && (c !== "uniqueId" || e.AllowLoadingUniqueId)) {
				let l = u;
				switch (g) {
					case 0:
						l[c] = h;
						break;
					case 1:
						d && (l[c] = e._TextureParser(h, d, f));
						break;
					case 2:
						l[c] = o.FromArray(h);
						break;
					case 3:
						l[c] = e._FresnelParametersParser(h);
						break;
					case 4:
						l[c] = r.FromArray(h);
						break;
					case 5:
						l[c] = s.FromArray(h);
						break;
					case 6:
						d && (l[c] = d.getLastMeshById(h));
						break;
					case 7:
						l[c] = e._ColorCurvesParser(h);
						break;
					case 8:
						l[c] = i.FromArray(h);
						break;
					case 9:
						l[c] = e._ImageProcessingConfigurationParser(h);
						break;
					case 10:
						l[c] = a.FromArray(h);
						break;
					case 11:
						d && (l[c] = d.getCameraById(h));
						break;
					case 12:
						l[c] = t.FromArray(h);
						break;
					case 13: l[c] = n.FromArray(h);
				}
			}
		}
	}
	static Parse(t, n, r, i = null) {
		let a = t();
		return u && u.AddTagsTo(a, n.tags), e.ParseProperties(n, a, r, i), a;
	}
	static Clone(e, t, n = {}) {
		return d(e, t, !1, n);
	}
	static Instanciate(e, t) {
		return d(e, t, !0);
	}
};
f.AllowLoadingUniqueId = !1, f._ImageProcessingConfigurationParser = (t) => {
	throw e("ImageProcessingConfiguration");
}, f._FresnelParametersParser = (t) => {
	throw e("FresnelParameters");
}, f._ColorCurvesParser = (t) => {
	throw e("ColorCurves");
}, f._TextureParser = (t, n, r) => {
	throw e("Texture");
};
//#endregion
export { u as n, f as t };
