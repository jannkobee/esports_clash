import { n as e } from "./typeStore-pENEWnX2.js";
import { a as t, c as n, i as r, n as i, r as a, s as o, t as s } from "./easing-Dodn8ZBp.js";
import { t as c } from "./flowGraphBlock-BTSj91tT.js";
import { c as l, n as u } from "./flowGraphRichTypes.pure-BpKU4EZT.js";
//#region node_modules/@babylonjs/core/FlowGraph/Blocks/Execution/Animation/flowGraphEasingBlock.pure.js
var d;
(function(e) {
	e[e.CircleEase = 0] = "CircleEase", e[e.BackEase = 1] = "BackEase", e[e.BounceEase = 2] = "BounceEase", e[e.CubicEase = 3] = "CubicEase", e[e.ElasticEase = 4] = "ElasticEase", e[e.ExponentialEase = 5] = "ExponentialEase", e[e.PowerEase = 6] = "PowerEase", e[e.QuadraticEase = 7] = "QuadraticEase", e[e.QuarticEase = 8] = "QuarticEase", e[e.QuinticEase = 9] = "QuinticEase", e[e.SineEase = 10] = "SineEase", e[e.BezierCurveEase = 11] = "BezierCurveEase";
})(d ||= {});
function f(e, ...c) {
	switch (e) {
		case 11: return new i(...c);
		case 0: return new r();
		case 1: return new s(...c);
		case 2: return new a(...c);
		case 3: return new t();
		case 4: return new o(...c);
		case 5: return new n(...c);
		default: throw Error("Easing type not yet implemented");
	}
}
var p = class extends c {
	constructor(e) {
		super(e), this.config = e, this._easingFunctions = {}, this.type = this.registerDataInput("type", u, 11), this.mode = this.registerDataInput("mode", l, 0), this.parameters = this.registerDataInput("parameters", u, [
			1,
			0,
			0,
			1
		]), this.easingFunction = this.registerDataOutput("easingFunction", u);
	}
	_updateOutputs(e) {
		let t = this.type.getValue(e), n = this.mode.getValue(e), r = this.parameters.getValue(e);
		if (t === void 0 || n === void 0) return;
		let i = `${t}-${n}-${r.join("-")}`;
		if (!this._easingFunctions[i]) {
			let e = f(t, ...r);
			e.setEasingMode(n), this._easingFunctions[i] = e;
		}
		this.easingFunction.setValue(this._easingFunctions[i], e);
	}
	getClassName() {
		return "FlowGraphEasingBlock";
	}
}, m = !1;
function h() {
	m || (m = !0, e("FlowGraphEasingBlock", p));
}
//#endregion
export { d as EasingFunctionType, p as FlowGraphEasingBlock, h as RegisterFlowGraphEasingBlock };
