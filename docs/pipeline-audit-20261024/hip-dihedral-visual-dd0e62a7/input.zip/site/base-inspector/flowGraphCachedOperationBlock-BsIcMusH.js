import { t as e } from "./flowGraphBlock-BTSj91tT.js";
import { r as t } from "./flowGraphRichTypes.pure-BpKU4EZT.js";
//#region node_modules/@babylonjs/core/FlowGraph/Blocks/Data/flowGraphCachedOperationBlock.js
var n = "cachedOperationValue", r = "cachedExecutionId", i = class extends e {
	constructor(e, n) {
		super(n), this._outputRichType = e, this.value = this.registerDataOutput("value", e), this.isValid = this.registerDataOutput("isValid", t);
	}
	_getInvalidOutputValue(e) {
		let t = this._outputRichType.defaultValue, n = t?.clone;
		return typeof n == "function" ? n.call(t) : t;
	}
	_updateOutputs(e) {
		let t = e._getExecutionVariable(this, r, -1), i = e._getExecutionVariable(this, n, null);
		if (i != null && t === e.executionId) this.isValid.setValue(!0, e), this.value.setValue(i, e);
		else try {
			let t = this._doOperation(e);
			if (t == null) {
				this._setInvalid(e);
				return;
			}
			e._setExecutionVariable(this, n, t), e._setExecutionVariable(this, r, e.executionId), this.value.setValue(t, e), this.isValid.setValue(!0, e);
		} catch {
			this._setInvalid(e);
		}
	}
	_setInvalid(e) {
		this.isValid.setValue(!1, e), this.value.setValue(this._getInvalidOutputValue(e), e);
	}
};
//#endregion
export { i as t };
