import { t as e } from "./logger-DQIzSR_y.js";
import { r as t } from "./tools.pure-Dy2G52NL.js";
//#region node_modules/@babylonjs/core/Materials/uniformBuffer.js
var n = class n {
	constructor(e, t, n = !1, r, i = !1, a) {
		this._uniformNames = [], this._valueCache = {}, this._engine = e, this._noUBO = !e.supportsUniformBuffers || i, this._dynamic = n, this._name = r ?? "no-name", this._data = t || [], this._uniformLocations = {}, this._uniformSizes = {}, this._uniformArraySizes = {}, this._uniformLocationPointer = 0, this._needSync = !1, this._dataGeneration = 0, this._trackUBOsInFrame = !1, (a === void 0 && this._engine._features.trackUbosInFrame || a === !0) && (this._buffers = [], this._bufferIndex = -1, this._bufferUpdatedLastFrame = !1, this._createBufferOnWrite = !1, this._currentFrameId = 0, this._trackUBOsInFrame = !0, this._resetOwnerSlots()), this._noUBO ? (this.updateMatrix3x3 = this._updateMatrix3x3ForEffect, this.updateMatrix2x2 = this._updateMatrix2x2ForEffect, this.updateFloat = this._updateFloatForEffect, this.updateFloat2 = this._updateFloat2ForEffect, this.updateFloat3 = this._updateFloat3ForEffect, this.updateFloat4 = this._updateFloat4ForEffect, this.updateFloatArray = this._updateFloatArrayForEffect, this.updateArray = this._updateArrayForEffect, this.updateIntArray = this._updateIntArrayForEffect, this.updateUIntArray = this._updateUIntArrayForEffect, this.updateMatrix = this._updateMatrixForEffect, this.updateMatrices = this._updateMatricesForEffect, this.updateVector3 = this._updateVector3ForEffect, this.updateVector4 = this._updateVector4ForEffect, this.updateColor3 = this._updateColor3ForEffect, this.updateColor4 = this._updateColor4ForEffect, this.updateDirectColor4 = this._updateDirectColor4ForEffect, this.updateInt = this._updateIntForEffect, this.updateInt2 = this._updateInt2ForEffect, this.updateInt3 = this._updateInt3ForEffect, this.updateInt4 = this._updateInt4ForEffect, this.updateUInt = this._updateUIntForEffect, this.updateUInt2 = this._updateUInt2ForEffect, this.updateUInt3 = this._updateUInt3ForEffect, this.updateUInt4 = this._updateUInt4ForEffect) : (this._engine._uniformBuffers.push(this), this.updateMatrix3x3 = this._updateMatrix3x3ForUniform, this.updateMatrix2x2 = this._updateMatrix2x2ForUniform, this.updateFloat = this._updateFloatForUniform, this.updateFloat2 = this._updateFloat2ForUniform, this.updateFloat3 = this._updateFloat3ForUniform, this.updateFloat4 = this._updateFloat4ForUniform, this.updateFloatArray = this._updateFloatArrayForUniform, this.updateArray = this._updateArrayForUniform, this.updateIntArray = this._updateIntArrayForUniform, this.updateUIntArray = this._updateUIntArrayForUniform, this.updateMatrix = this._updateMatrixForUniform, this.updateMatrices = this._updateMatricesForUniform, this.updateVector3 = this._updateVector3ForUniform, this.updateVector4 = this._updateVector4ForUniform, this.updateColor3 = this._updateColor3ForUniform, this.updateColor4 = this._updateColor4ForUniform, this.updateDirectColor4 = this._updateDirectColor4ForUniform, this.updateInt = this._updateIntForUniform, this.updateInt2 = this._updateInt2ForUniform, this.updateInt3 = this._updateInt3ForUniform, this.updateInt4 = this._updateInt4ForUniform, this.updateUInt = this._updateUIntForUniform, this.updateUInt2 = this._updateUInt2ForUniform, this.updateUInt3 = this._updateUInt3ForUniform, this.updateUInt4 = this._updateUInt4ForUniform);
	}
	get useUbo() {
		return !this._noUBO;
	}
	get isSync() {
		return !this._needSync;
	}
	isDynamic() {
		return this._dynamic;
	}
	getData() {
		return this._bufferData;
	}
	getBuffer() {
		return this._buffer;
	}
	getUniformNames() {
		return this._uniformNames;
	}
	_fillAlignment(e) {
		let t;
		if (t = e <= 2 ? e : 4, this._uniformLocationPointer % t !== 0) {
			let e = this._uniformLocationPointer;
			this._uniformLocationPointer += t - this._uniformLocationPointer % t;
			let n = this._uniformLocationPointer - e;
			for (let e = 0; e < n; e++) this._data.push(0);
		}
	}
	addUniform(e, t, n = 0) {
		if (n > 0 && typeof t == "number" && (this._uniformArraySizes[e] = {
			strideSize: t,
			arraySize: n
		}), this._uniformLocations[e] !== void 0 || (this._uniformNames.push(e), this._noUBO)) return;
		let r;
		if (n > 0) {
			if (t instanceof Array) throw "addUniform should not be use with Array in UBO: " + e;
			if (this._fillAlignment(4), t == 16) t *= n;
			else {
				let e = (4 - t) * n;
				t = t * n + e;
			}
			r = [];
			for (let e = 0; e < t; e++) r.push(0);
		} else {
			if (t instanceof Array) r = t, t = r.length;
			else {
				r = [];
				for (let e = 0; e < t; e++) r.push(0);
			}
			this._fillAlignment(t);
		}
		this._uniformSizes[e] = t, this._uniformLocations[e] = this._uniformLocationPointer, this._uniformLocationPointer += t;
		for (let e = 0; e < t; e++) this._data.push(r[e]);
		this._needSync = !0;
	}
	addMatrix(e, t) {
		this.addUniform(e, Array.prototype.slice.call(t.asArray()));
	}
	addFloat2(e, t, n) {
		let r = [t, n];
		this.addUniform(e, r);
	}
	addFloat3(e, t, n, r) {
		let i = [
			t,
			n,
			r
		];
		this.addUniform(e, i);
	}
	addColor3(e, t) {
		let n = [
			t.r,
			t.g,
			t.b
		];
		this.addUniform(e, n);
	}
	addColor4(e, t, n) {
		let r = [
			t.r,
			t.g,
			t.b,
			n
		];
		this.addUniform(e, r);
	}
	addVector3(e, t) {
		let n = [
			t.x,
			t.y,
			t.z
		];
		this.addUniform(e, n);
	}
	addMatrix3x3(e) {
		this.addUniform(e, 12);
	}
	addMatrix2x2(e) {
		this.addUniform(e, 8);
	}
	create() {
		this._noUBO || this._buffer || (this._fillAlignment(4), this._bufferData = new Float32Array(this._data), this._dataGeneration++, this._rebuild(), this._needSync = !0);
	}
	_getNamesDebug() {
		let e = [], t = 0;
		for (let n in this._uniformLocations) if (e.push(n), ++t === 10) break;
		return e.join(",");
	}
	_rebuild() {
		!this._noUBO && this._bufferData && (this._buffer = this._dynamic ? this._engine.createDynamicUniformBuffer(this._bufferData, this._name + "_UniformList:" + this._getNamesDebug()) : this._engine.createUniformBuffer(this._bufferData, this._name + "_UniformList:" + this._getNamesDebug()), this._trackUBOsInFrame && (this._buffers.push([this._buffer, this._engine._features.checkUbosContentBeforeUpload ? this._bufferData.slice() : void 0]), this._bufferIndex = this._buffers.length - 1, this._createBufferOnWrite = !1));
	}
	_rebuildAfterContextLost() {
		this._trackUBOsInFrame && (this._buffers = [], this._currentFrameId = 0, this._resetOwnerSlots()), this._rebuild();
	}
	_resetOwnerSlots() {
		if (this._ownerListsBySlot) for (let e of this._ownerListsBySlot.values()) this._removeOwnerBacklink(e);
		this._ownerListsBySlot = /* @__PURE__ */ new Map(), this._slotByOwner = /* @__PURE__ */ new WeakMap(), this._slotFrameId = [], this._ownerCount = 0, this._freeSlots = [], this._slotGeneration = [];
	}
	get _numBuffers() {
		return this._buffers.length;
	}
	get _indexBuffer() {
		return this._bufferIndex;
	}
	get name() {
		return this._name;
	}
	set name(e) {
		this._name = e;
	}
	get currentEffect() {
		return this._currentEffect;
	}
	_buffersEqual(e, t) {
		for (let n = 0; n < e.length; ++n) if (e[n] !== t[n]) return !1;
		return !0;
	}
	_copyBuffer(e, t) {
		for (let n = 0; n < e.length; ++n) t[n] = e[n];
	}
	update() {
		if (!this._noUBO) {
			if (this.bindUniformBuffer(), !this._buffer) this.create();
			else if (!this._dynamic && !this._needSync) this._createBufferOnWrite = this._trackUBOsInFrame;
			else {
				if (this._buffers && this._buffers.length > 1 && this._buffers[this._bufferIndex][1]) {
					if (this._buffersEqual(this._bufferData, this._buffers[this._bufferIndex][1])) {
						this._needSync = !1, this._createBufferOnWrite = this._trackUBOsInFrame;
						return;
					}
					this._copyBuffer(this._bufferData, this._buffers[this._bufferIndex][1]);
				}
				this._bufferUpdatedLastFrame = !0, this._engine.updateUniformBuffer(this._buffer, this._bufferData), this._needSync = !1, this._createBufferOnWrite = this._trackUBOsInFrame;
			}
		}
	}
	_updateOwnerKeyed(e) {
		if (this._noUBO || !this._trackUBOsInFrame) {
			this.update();
			return;
		}
		this._buffer || this.create(), this._checkNewFrame();
		let t = this._slotByOwner.get(e);
		if (t === void 0 && (t = this._ownerCount === 0 && this._buffers.length === 1 && this._freeSlots.length === 0 ? 0 : this._takeFreeSlot(!0), this._slotByOwner.set(e, t), this._ownerCount++, e._uniformBuffersWithOwnedSlot ||= [], e._uniformBuffersWithOwnedSlot.push(this), this._ownerListsBySlot.set(t, e._uniformBuffersWithOwnedSlot)), this._slotGeneration[t] === this._dataGeneration) {
			this._bufferIndex = t, this._buffer = this._buffers[t][0], this.bindUniformBuffer(), this._slotFrameId[t] = this._currentFrameId, this._needSync = !1, this._createBufferOnWrite = !1;
			return;
		}
		let n = this._buffers[t][1];
		this._slotFrameId[t] === this._currentFrameId && n && !this._buffersEqual(this._bufferData, n) && (t = this._takeFreeSlot(!1)), this._bufferIndex = t, this._buffer = this._buffers[t][0], this.bindUniformBuffer();
		let r = this._buffers[t][1];
		(!r || !this._buffersEqual(this._bufferData, r)) && (r && this._copyBuffer(this._bufferData, r), this._bufferUpdatedLastFrame = !0, this._engine.updateUniformBuffer(this._buffer, this._bufferData)), this._slotFrameId[t] = this._currentFrameId, this._slotGeneration[t] = this._dataGeneration, this._needSync = !1, this._createBufferOnWrite = !1;
	}
	_takeFreeSlot(e) {
		for (let t = 0; t < this._freeSlots.length; ++t) {
			let n = this._freeSlots[t];
			if (this._slotFrameId[n] !== this._currentFrameId) return e && (this._freeSlots[t] = this._freeSlots[this._freeSlots.length - 1], this._freeSlots.pop()), n;
		}
		this._rebuild();
		let t = this._buffers.length - 1;
		return e || this._freeSlots.push(t), t;
	}
	_releaseOwnerSlot(e) {
		let t = this._slotByOwner?.get(e);
		if (t === void 0) return;
		this._slotByOwner.delete(e);
		let n = this._ownerListsBySlot.get(t);
		n && (this._removeOwnerBacklink(n), this._ownerListsBySlot.delete(t)), this._ownerCount--, this._freeSlots.push(t);
	}
	_removeOwnerBacklink(e) {
		let t = e.indexOf(this);
		t !== -1 && (e[t] = e[e.length - 1], e.pop());
	}
	_createNewBuffer() {
		this._bufferIndex + 1 < this._buffers.length ? (this._bufferIndex++, this._buffer = this._buffers[this._bufferIndex][0], this._createBufferOnWrite = !1, this._needSync = !0) : this._rebuild();
	}
	_checkNewFrame() {
		this._trackUBOsInFrame && this._currentFrameId !== this._engine.frameId && (this._currentFrameId = this._engine.frameId, this._createBufferOnWrite = !1, this._buffers && this._buffers.length > 0 ? (this._needSync = this._buffers.length === 1 ? !this._bufferUpdatedLastFrame : this._bufferIndex !== 0, this._bufferIndex = 0, this._buffer = this._buffers[this._bufferIndex][0]) : this._bufferIndex = -1);
	}
	updateUniform(t, n, r) {
		this._checkNewFrame();
		let i = this._uniformLocations[t];
		if (i === void 0) {
			if (this._buffer) {
				e.Error("Cannot add an uniform after UBO has been created. uniformName=" + t);
				return;
			}
			this.addUniform(t, r), i = this._uniformLocations[t];
		}
		if (this._buffer || this.create(), this._dynamic) {
			for (let e = 0; e < r; e++) this._bufferData[i + e] = n[e];
			this._dataGeneration++;
		} else {
			let e = !1;
			for (let t = 0; t < r; t++) (r === 16 && !this._engine._features.uniformBufferHardCheckMatrix || this._bufferData[i + t] !== Math.fround(n[t])) && (e = !0, this._createBufferOnWrite && this._createNewBuffer(), this._bufferData[i + t] = n[t]);
			this._needSync = this._needSync || e, e && this._dataGeneration++;
		}
	}
	updateUniformArray(n, r, i) {
		this._checkNewFrame();
		let a = this._uniformLocations[n];
		if (a === void 0) {
			e.Error("Cannot add an uniform Array dynamically. Please, add it using addUniform and make sure that uniform buffers are supported by the current engine.");
			return;
		}
		this._buffer || this.create();
		let o = this._uniformArraySizes[n];
		if (this._dynamic) {
			for (let e = 0; e < i; e++) this._bufferData[a + e] = r[e];
			this._dataGeneration++;
		} else {
			let e = !1, n = 0, s = 0;
			for (let c = 0; c < i; c++) if (this._bufferData[a + s * 4 + n] !== t.FloatRound(r[c]) && (e = !0, this._createBufferOnWrite && this._createNewBuffer(), this._bufferData[a + s * 4 + n] = r[c]), n++, n === o.strideSize) {
				for (; n < 4; n++) this._bufferData[a + s * 4 + n] = 0;
				n = 0, s++;
			}
			this._needSync = this._needSync || e, e && this._dataGeneration++;
		}
	}
	_cacheMatrix(e, t) {
		this._checkNewFrame();
		let n = this._valueCache[e], r = t.updateFlag;
		return n !== void 0 && n === r ? !1 : (this._valueCache[e] = r, !0);
	}
	_updateMatrix3x3ForUniform(e, t) {
		for (let e = 0; e < 3; e++) n._TempBuffer[e * 4] = t[e * 3], n._TempBuffer[e * 4 + 1] = t[e * 3 + 1], n._TempBuffer[e * 4 + 2] = t[e * 3 + 2], n._TempBuffer[e * 4 + 3] = 0;
		this.updateUniform(e, n._TempBuffer, 12);
	}
	_updateMatrix3x3ForEffect(e, t) {
		this._currentEffect.setMatrix3x3(e, t);
	}
	_updateMatrix2x2ForEffect(e, t) {
		this._currentEffect.setMatrix2x2(e, t);
	}
	_updateMatrix2x2ForUniform(e, t) {
		for (let e = 0; e < 2; e++) n._TempBuffer[e * 4] = t[e * 2], n._TempBuffer[e * 4 + 1] = t[e * 2 + 1], n._TempBuffer[e * 4 + 2] = 0, n._TempBuffer[e * 4 + 3] = 0;
		this.updateUniform(e, n._TempBuffer, 8);
	}
	_updateFloatForEffect(e, t, n = "") {
		this._currentEffect.setFloat(e + n, t);
	}
	_updateFloatForUniform(e, t) {
		n._TempBuffer[0] = t, this.updateUniform(e, n._TempBuffer, 1);
	}
	_updateFloat2ForEffect(e, t, n, r = "") {
		this._currentEffect.setFloat2(e + r, t, n);
	}
	_updateFloat2ForUniform(e, t, r) {
		n._TempBuffer[0] = t, n._TempBuffer[1] = r, this.updateUniform(e, n._TempBuffer, 2);
	}
	_updateFloat3ForEffect(e, t, n, r, i = "") {
		this._currentEffect.setFloat3(e + i, t, n, r);
	}
	_updateFloat3ForUniform(e, t, r, i) {
		n._TempBuffer[0] = t, n._TempBuffer[1] = r, n._TempBuffer[2] = i, this.updateUniform(e, n._TempBuffer, 3);
	}
	_updateFloat4ForEffect(e, t, n, r, i, a = "") {
		this._currentEffect.setFloat4(e + a, t, n, r, i);
	}
	_updateFloat4ForUniform(e, t, r, i, a) {
		n._TempBuffer[0] = t, n._TempBuffer[1] = r, n._TempBuffer[2] = i, n._TempBuffer[3] = a, this.updateUniform(e, n._TempBuffer, 4);
	}
	_updateFloatArrayForEffect(e, t, n = "") {
		switch (this._uniformArraySizes[e]?.strideSize) {
			case 2:
				this._currentEffect.setFloatArray2(e + n, t);
				break;
			case 3:
				this._currentEffect.setFloatArray3(e + n, t);
				break;
			case 4:
				this._currentEffect.setFloatArray4(e + n, t);
				break;
			default: this._currentEffect.setFloatArray(e + n, t);
		}
	}
	_updateFloatArrayForUniform(e, t) {
		this.updateUniformArray(e, t, t.length);
	}
	_updateArrayForEffect(e, t) {
		this._currentEffect.setArray(e, t);
	}
	_updateArrayForUniform(e, t) {
		this.updateUniformArray(e, t, t.length);
	}
	_updateIntArrayForEffect(e, t) {
		this._currentEffect.setIntArray(e, t);
	}
	_updateIntArrayForUniform(e, t) {
		n._TempBufferInt32View.set(t), this.updateUniformArray(e, n._TempBuffer, t.length);
	}
	_updateUIntArrayForEffect(e, t) {
		this._currentEffect.setUIntArray(e, t);
	}
	_updateUIntArrayForUniform(e, t) {
		n._TempBufferUInt32View.set(t), this.updateUniformArray(e, n._TempBuffer, t.length);
	}
	_updateMatrixForEffect(e, t) {
		this._currentEffect.setMatrix(e, t);
	}
	_updateMatrixForUniform(e, t) {
		this._cacheMatrix(e, t) && this.updateUniform(e, t.asArray(), 16);
	}
	_updateMatricesForEffect(e, t) {
		this._currentEffect.setMatrices(e, t);
	}
	_updateMatricesForUniform(e, t) {
		this.updateUniform(e, t, t.length);
	}
	_updateVector3ForEffect(e, t) {
		this._currentEffect.setVector3(e, t);
	}
	_updateVector3ForUniform(e, t) {
		n._TempBuffer[0] = t.x, n._TempBuffer[1] = t.y, n._TempBuffer[2] = t.z, this.updateUniform(e, n._TempBuffer, 3);
	}
	_updateVector4ForEffect(e, t) {
		this._currentEffect.setVector4(e, t);
	}
	_updateVector4ForUniform(e, t) {
		n._TempBuffer[0] = t.x, n._TempBuffer[1] = t.y, n._TempBuffer[2] = t.z, n._TempBuffer[3] = t.w, this.updateUniform(e, n._TempBuffer, 4);
	}
	_updateColor3ForEffect(e, t, n = "") {
		this._currentEffect.setColor3(e + n, t);
	}
	_updateColor3ForUniform(e, t) {
		n._TempBuffer[0] = t.r, n._TempBuffer[1] = t.g, n._TempBuffer[2] = t.b, this.updateUniform(e, n._TempBuffer, 3);
	}
	_updateColor4ForEffect(e, t, n, r = "") {
		this._currentEffect.setColor4(e + r, t, n);
	}
	_updateDirectColor4ForEffect(e, t, n = "") {
		this._currentEffect.setDirectColor4(e + n, t);
	}
	_updateColor4ForUniform(e, t, r) {
		n._TempBuffer[0] = t.r, n._TempBuffer[1] = t.g, n._TempBuffer[2] = t.b, n._TempBuffer[3] = r, this.updateUniform(e, n._TempBuffer, 4);
	}
	_updateDirectColor4ForUniform(e, t) {
		n._TempBuffer[0] = t.r, n._TempBuffer[1] = t.g, n._TempBuffer[2] = t.b, n._TempBuffer[3] = t.a, this.updateUniform(e, n._TempBuffer, 4);
	}
	_updateIntForEffect(e, t, n = "") {
		this._currentEffect.setInt(e + n, t);
	}
	_updateIntForUniform(e, t) {
		n._TempBufferInt32View[0] = t, this.updateUniform(e, n._TempBuffer, 1);
	}
	_updateInt2ForEffect(e, t, n, r = "") {
		this._currentEffect.setInt2(e + r, t, n);
	}
	_updateInt2ForUniform(e, t, r) {
		n._TempBufferInt32View[0] = t, n._TempBufferInt32View[1] = r, this.updateUniform(e, n._TempBuffer, 2);
	}
	_updateInt3ForEffect(e, t, n, r, i = "") {
		this._currentEffect.setInt3(e + i, t, n, r);
	}
	_updateInt3ForUniform(e, t, r, i) {
		n._TempBufferInt32View[0] = t, n._TempBufferInt32View[1] = r, n._TempBufferInt32View[2] = i, this.updateUniform(e, n._TempBuffer, 3);
	}
	_updateInt4ForEffect(e, t, n, r, i, a = "") {
		this._currentEffect.setInt4(e + a, t, n, r, i);
	}
	_updateInt4ForUniform(e, t, r, i, a) {
		n._TempBufferInt32View[0] = t, n._TempBufferInt32View[1] = r, n._TempBufferInt32View[2] = i, n._TempBufferInt32View[3] = a, this.updateUniform(e, n._TempBuffer, 4);
	}
	_updateUIntForEffect(e, t, n = "") {
		this._currentEffect.setUInt(e + n, t);
	}
	_updateUIntForUniform(e, t) {
		n._TempBufferUInt32View[0] = t, this.updateUniform(e, n._TempBuffer, 1);
	}
	_updateUInt2ForEffect(e, t, n, r = "") {
		this._currentEffect.setUInt2(e + r, t, n);
	}
	_updateUInt2ForUniform(e, t, r) {
		n._TempBufferUInt32View[0] = t, n._TempBufferUInt32View[1] = r, this.updateUniform(e, n._TempBuffer, 2);
	}
	_updateUInt3ForEffect(e, t, n, r, i = "") {
		this._currentEffect.setUInt3(e + i, t, n, r);
	}
	_updateUInt3ForUniform(e, t, r, i) {
		n._TempBufferUInt32View[0] = t, n._TempBufferUInt32View[1] = r, n._TempBufferUInt32View[2] = i, this.updateUniform(e, n._TempBuffer, 3);
	}
	_updateUInt4ForEffect(e, t, n, r, i, a = "") {
		this._currentEffect.setUInt4(e + a, t, n, r, i);
	}
	_updateUInt4ForUniform(e, t, r, i, a) {
		n._TempBufferUInt32View[0] = t, n._TempBufferUInt32View[1] = r, n._TempBufferUInt32View[2] = i, n._TempBufferUInt32View[3] = a, this.updateUniform(e, n._TempBuffer, 4);
	}
	setTexture(e, t) {
		this._currentEffect.setTexture(e, t);
	}
	setTextureArray(e, t) {
		this._currentEffect.setTextureArray(e, t);
	}
	bindTexture(e, t) {
		this._currentEffect._bindTexture(e, t);
	}
	updateUniformDirectly(e, t) {
		this.updateUniform(e, t, t.length), this.update();
	}
	bindToEffect(e, t) {
		this._currentEffect = e, this._currentEffectName = t;
	}
	bindUniformBuffer() {
		!this._noUBO && this._buffer && this._currentEffect && this._currentEffect.bindUniformBuffer(this._buffer, this._currentEffectName);
	}
	unbindEffect() {
		this._currentEffect = void 0, this._currentEffectName = void 0;
	}
	setDataBuffer(e) {
		if (!this._buffers) return this._buffer === e;
		for (let t = 0; t < this._buffers.length; ++t) if (this._buffers[t][0] === e) return this._bufferIndex = t, this._buffer = e, this._createBufferOnWrite = !1, this._currentEffect = void 0, this._buffers.length > 1 && this._buffers[t][1] && (this._bufferData.set(this._buffers[t][1]), this._dataGeneration++), this._valueCache = {}, this._currentFrameId = this._engine.frameId, !0;
		return !1;
	}
	has(e) {
		return this._uniformLocations[e] !== void 0;
	}
	dispose() {
		if (this._noUBO) return;
		let e = this._engine._uniformBuffers, t = e.indexOf(this);
		if (t !== -1 && (e[t] = e[e.length - 1], e.pop()), this._trackUBOsInFrame && this._buffers) {
			this._resetOwnerSlots();
			for (let e = 0; e < this._buffers.length; ++e) {
				let t = this._buffers[e][0];
				this._engine._releaseBuffer(t);
			}
			this._buffers = [], this._buffer = null, this._bufferIndex = -1;
		} else this._buffer && this._engine._releaseBuffer(this._buffer) && (this._buffer = null);
	}
};
n._MAX_UNIFORM_SIZE = 256, n._TempBuffer = new Float32Array(n._MAX_UNIFORM_SIZE), n._TempBufferInt32View = new Int32Array(n._TempBuffer.buffer), n._TempBufferUInt32View = new Uint32Array(n._TempBuffer.buffer);
//#endregion
//#region node_modules/@babylonjs/core/Lights/lightConstants.js
var r = class {
	static CompareLightsPriority(e, t) {
		return e.shadowEnabled === t.shadowEnabled ? t.renderPriority - e.renderPriority : +!!t.shadowEnabled - !!e.shadowEnabled;
	}
};
r.FALLOFF_DEFAULT = 0, r.FALLOFF_PHYSICAL = 1, r.FALLOFF_GLTF = 2, r.FALLOFF_STANDARD = 3, r.LIGHTMAP_DEFAULT = 0, r.LIGHTMAP_SPECULAR = 1, r.LIGHTMAP_SHADOWSONLY = 2, r.INTENSITYMODE_AUTOMATIC = 0, r.INTENSITYMODE_LUMINOUSPOWER = 1, r.INTENSITYMODE_LUMINOUSINTENSITY = 2, r.INTENSITYMODE_ILLUMINANCE = 3, r.INTENSITYMODE_LUMINANCE = 4, r.LIGHTTYPEID_POINTLIGHT = 0, r.LIGHTTYPEID_DIRECTIONALLIGHT = 1, r.LIGHTTYPEID_SPOTLIGHT = 2, r.LIGHTTYPEID_HEMISPHERICLIGHT = 3, r.LIGHTTYPEID_RECT_AREALIGHT = 4, r.LIGHTTYPEID_CLUSTERED_CONTAINER = 5;
//#endregion
export { n, r as t };
