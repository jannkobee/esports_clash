import { t as e } from "./internalTexture-QUW4uXxg.js";
import { t } from "./logger-DQIzSR_y.js";
import { r as n } from "./tools.pure-Dy2G52NL.js";
import { t as r } from "./texture.pure-Ce-ILsRv.js";
//#region node_modules/@babylonjs/core/Misc/basisWorker.js
function i() {
	let e = {
		cTFETC1: 0,
		cTFETC2: 1,
		cTFBC1: 2,
		cTFBC3: 3,
		cTFBC4: 4,
		cTFBC5: 5,
		cTFBC7: 6,
		cTFPVRTC1_4_RGB: 8,
		cTFPVRTC1_4_RGBA: 9,
		cTFASTC_4x4: 10,
		cTFATC_RGB: 11,
		cTFATC_RGBA_INTERPOLATED_ALPHA: 12,
		cTFRGBA32: 13,
		cTFRGB565: 14,
		cTFBGR565: 15,
		cTFRGBA4444: 16,
		cTFFXT1_RGB: 17,
		cTFPVRTC2_4_RGB: 18,
		cTFPVRTC2_4_RGBA: 19,
		cTFETC2_EAC_R11: 20,
		cTFETC2_EAC_RG11: 21
	}, t = null;
	onmessage = (a) => {
		if (a.data.action === "init") {
			if (a.data.url) try {
				importScripts(a.data.url);
			} catch (e) {
				postMessage({
					action: "error",
					error: e
				});
			}
			t ||= BASIS({ wasmBinary: a.data.wasmBinary }), t !== null && t.then((e) => {
				BASIS = e, e.initializeBasis(), postMessage({ action: "init" });
			});
		} else if (a.data.action === "transcode") {
			let t = a.data.config, o = a.data.imageData, s = new BASIS.BasisFile(o), c = r(s), l = a.data.ignoreSupportedFormats ? null : n(a.data.config, c), u = !1;
			l === null && (u = !0, l = c.hasAlpha ? e.cTFBC3 : e.cTFBC1);
			let d = !0;
			s.startTranscoding() || (d = !1);
			let f = [];
			for (let e = 0; e < c.images.length && d; e++) {
				let n = c.images[e];
				if (t.loadSingleImage === void 0 || t.loadSingleImage === e) {
					let r = n.levels.length;
					t.loadMipmapLevels === !1 && (r = 1);
					for (let t = 0; t < r; t++) {
						let r = n.levels[t], a = i(s, e, t, l, u);
						if (!a) {
							d = !1;
							break;
						}
						r.transcodedPixels = a, f.push(r.transcodedPixels.buffer);
					}
				}
			}
			s.close(), s.delete(), u && (l = -1), d ? postMessage({
				action: "transcode",
				success: d,
				id: a.data.id,
				fileInfo: c,
				format: l
			}, f) : postMessage({
				action: "transcode",
				success: d,
				id: a.data.id
			});
		}
	};
	function n(t, n) {
		let r = null;
		return t.supportedCompressionFormats && (r = t.supportedCompressionFormats.astc ? e.cTFASTC_4x4 : t.supportedCompressionFormats.bc7 ? e.cTFBC7 : t.supportedCompressionFormats.s3tc ? n.hasAlpha ? e.cTFBC3 : e.cTFBC1 : t.supportedCompressionFormats.pvrtc ? n.hasAlpha ? e.cTFPVRTC1_4_RGBA : e.cTFPVRTC1_4_RGB : t.supportedCompressionFormats.etc2 ? e.cTFETC2 : t.supportedCompressionFormats.etc1 ? e.cTFETC1 : e.cTFRGB565), r;
	}
	function r(e) {
		let t = e.getHasAlpha(), n = e.getNumImages(), r = [];
		for (let t = 0; t < n; t++) {
			let n = { levels: [] }, i = e.getNumLevels(t);
			for (let r = 0; r < i; r++) {
				let i = {
					width: e.getImageWidth(t, r),
					height: e.getImageHeight(t, r)
				};
				n.levels.push(i);
			}
			r.push(n);
		}
		return {
			hasAlpha: t,
			images: r
		};
	}
	function i(e, t, n, r, i) {
		let o = e.getImageTranscodedSizeInBytes(t, n, r), s = new Uint8Array(o);
		if (!e.transcodeImage(s, t, n, r, 1, 0)) return null;
		if (i) {
			let r = e.getImageWidth(t, n) + 3 & -4, i = e.getImageHeight(t, n) + 3 & -4;
			s = a(s, 0, r, i);
		}
		return s;
	}
	function a(e, t, n, r) {
		let i = /* @__PURE__ */ new Uint16Array(4), a = new Uint16Array(n * r), o = n / 4, s = r / 4;
		for (let r = 0; r < s; r++) for (let s = 0; s < o; s++) {
			let c = t + 8 * (r * o + s);
			i[0] = e[c] | e[c + 1] << 8, i[1] = e[c + 2] | e[c + 3] << 8, i[2] = (2 * (i[0] & 31) + 1 * (i[1] & 31)) / 3 | (2 * (i[0] & 2016) + 1 * (i[1] & 2016)) / 3 & 2016 | (2 * (i[0] & 63488) + 1 * (i[1] & 63488)) / 3 & 63488, i[3] = (2 * (i[1] & 31) + 1 * (i[0] & 31)) / 3 | (2 * (i[1] & 2016) + 1 * (i[0] & 2016)) / 3 & 2016 | (2 * (i[1] & 63488) + 1 * (i[0] & 63488)) / 3 & 63488;
			for (let t = 0; t < 4; t++) {
				let o = e[c + 4 + t], l = (r * 4 + t) * n + s * 4;
				a[l++] = i[o & 3], a[l++] = i[o >> 2 & 3], a[l++] = i[o >> 4 & 3], a[l] = i[o >> 6 & 3];
			}
		}
		return a;
	}
}
async function a(e, t, r) {
	return await new Promise((i, a) => {
		let o = (t) => {
			t.data.action === "init" ? (e.removeEventListener("message", o), i(e)) : t.data.action === "error" && a(t.data.error || "error initializing worker");
		};
		e.addEventListener("message", o), e.postMessage({
			action: "init",
			url: r ? n.GetBabylonScriptURL(r) : void 0,
			wasmBinary: t
		}, [t]);
	});
}
//#endregion
//#region node_modules/@babylonjs/core/Misc/basis.pure.js
var o;
(function(e) {
	e[e.cTFETC1 = 0] = "cTFETC1", e[e.cTFETC2 = 1] = "cTFETC2", e[e.cTFBC1 = 2] = "cTFBC1", e[e.cTFBC3 = 3] = "cTFBC3", e[e.cTFBC4 = 4] = "cTFBC4", e[e.cTFBC5 = 5] = "cTFBC5", e[e.cTFBC7 = 6] = "cTFBC7", e[e.cTFPVRTC1_4_RGB = 8] = "cTFPVRTC1_4_RGB", e[e.cTFPVRTC1_4_RGBA = 9] = "cTFPVRTC1_4_RGBA", e[e.cTFASTC_4x4 = 10] = "cTFASTC_4x4", e[e.cTFATC_RGB = 11] = "cTFATC_RGB", e[e.cTFATC_RGBA_INTERPOLATED_ALPHA = 12] = "cTFATC_RGBA_INTERPOLATED_ALPHA", e[e.cTFRGBA32 = 13] = "cTFRGBA32", e[e.cTFRGB565 = 14] = "cTFRGB565", e[e.cTFBGR565 = 15] = "cTFBGR565", e[e.cTFRGBA4444 = 16] = "cTFRGBA4444", e[e.cTFFXT1_RGB = 17] = "cTFFXT1_RGB", e[e.cTFPVRTC2_4_RGB = 18] = "cTFPVRTC2_4_RGB", e[e.cTFPVRTC2_4_RGBA = 19] = "cTFPVRTC2_4_RGBA", e[e.cTFETC2_EAC_R11 = 20] = "cTFETC2_EAC_R11", e[e.cTFETC2_EAC_RG11 = 21] = "cTFETC2_EAC_RG11";
})(o ||= {});
var s = {
	JSModuleURL: `${n._DefaultCdnUrl}/basisTranscoder/1/basis_transcoder.js`,
	WasmModuleURL: `${n._DefaultCdnUrl}/basisTranscoder/1/basis_transcoder.wasm`
}, c = (e, t) => {
	let n;
	switch (e) {
		case o.cTFETC1:
			n = 36196;
			break;
		case o.cTFBC1:
			n = 33776;
			break;
		case o.cTFBC4:
			n = 33779;
			break;
		case o.cTFASTC_4x4:
			n = 37808;
			break;
		case o.cTFETC2:
			n = 37496;
			break;
		case o.cTFBC7: n = 36492;
	}
	if (n === void 0) throw "The chosen Basis transcoder format is not currently supported";
	return n;
}, l = null, u = null, d = 0, f = !1, p = async () => (l ||= new Promise((e, t) => {
	u ? e(u) : n.LoadFileAsync(n.GetBabylonScriptURL(s.WasmModuleURL)).then((n) => {
		if (typeof URL != "function") return t("Basis transcoder requires an environment with a URL constructor");
		let r = URL.createObjectURL(new Blob([`(${i})()`], { type: "application/javascript" }));
		u = new Worker(r), a(u, n, s.JSModuleURL).then(e, t);
	}).catch(t);
}), await l), m = async (e, t) => {
	let n = e instanceof ArrayBuffer ? new Uint8Array(e) : e;
	return await new Promise((e, r) => {
		p().then(() => {
			let i = d++, a = (t) => {
				t.data.action === "transcode" && t.data.id === i && (u.removeEventListener("message", a), t.data.success ? e(t.data) : r("Transcode is not supported on this device"));
			};
			u.addEventListener("message", a);
			let o = new Uint8Array(n.byteLength);
			o.set(new Uint8Array(n.buffer, n.byteOffset, n.byteLength)), u.postMessage({
				action: "transcode",
				id: i,
				imageData: o,
				config: t,
				ignoreSupportedFormats: f
			}, [o.buffer]);
		}, (e) => {
			r(e);
		});
	});
}, h = (e, t) => {
	let n = t._gl?.TEXTURE_2D;
	e.isCube && (n = t._gl?.TEXTURE_CUBE_MAP), t._bindTextureDirectly(n, e, !0);
}, g = (n, i) => {
	let a = n.getEngine();
	for (let s = 0; s < i.fileInfo.images.length; s++) {
		let c = i.fileInfo.images[s].levels[0];
		if (n._invertVScale = n.invertY, i.format === -1 || i.format === o.cTFRGB565) {
			if (n.type = 10, n.format = 4, a._features.basisNeedsPOT && (Math.log2(c.width) % 1 != 0 || Math.log2(c.height) % 1 != 0)) {
				let t = new e(a, 2);
				n._invertVScale = n.invertY, t.type = 10, t.format = 4, t.width = c.width + 3 & -4, t.height = c.height + 3 & -4, h(t, a), a._uploadDataToTextureDirectly(t, new Uint16Array(c.transcodedPixels.buffer), s, 0, 4, !0), a._rescaleTexture(t, n, a.scenes[0], a._getInternalFormat(4), () => {
					a._releaseTexture(t), h(n, a);
				});
			} else n._invertVScale = !n.invertY, n.width = c.width + 3 & -4, n.height = c.height + 3 & -4, n.samplingMode = 2, h(n, a), a._uploadDataToTextureDirectly(n, new Uint16Array(c.transcodedPixels.buffer), s, 0, 4, !0);
		} else {
			n.width = c.width, n.height = c.height, n.generateMipMaps = i.fileInfo.images[s].levels.length > 1;
			let e = _.GetInternalFormatFromBasisFormat(i.format, a);
			n.format = e, h(n, a);
			let o = i.fileInfo.images[s].levels;
			for (let t = 0; t < o.length; t++) {
				let r = o[t];
				a._uploadCompressedDataToTextureDirectly(n, e, r.width, r.height, r.transcodedPixels, s, t);
			}
			a._features.basisNeedsPOT && (Math.log2(n.width) % 1 != 0 || Math.log2(n.height) % 1 != 0) && (t.Warn("Loaded .basis texture width and height are not a power of two. Texture wrapping will be set to Texture.CLAMP_ADDRESSMODE as other modes are not supported with non power of two dimensions in webGL 1."), n._cachedWrapU = r.CLAMP_ADDRESSMODE, n._cachedWrapV = r.CLAMP_ADDRESSMODE);
		}
	}
}, _ = {
	JSModuleURL: s.JSModuleURL,
	WasmModuleURL: s.WasmModuleURL,
	GetInternalFormatFromBasisFormat: c,
	TranscodeAsync: m,
	LoadTextureFromTranscodeResult: g
}, v = class {
	constructor() {
		this.supportCascades = !1;
	}
	loadCubeData(e, t, r, i, a) {
		if (Array.isArray(e)) return;
		let o = t.getEngine().getCaps();
		m(e, { supportedCompressionFormats: {
			etc1: !!o.etc1,
			s3tc: !!o.s3tc,
			pvrtc: !!o.pvrtc,
			etc2: !!o.etc2,
			astc: !!o.astc,
			bc7: !!o.bptc
		} }).then((e) => {
			let n = e.fileInfo.images[0].levels.length > 1 && t.generateMipMaps;
			g(t, e), t.getEngine()._setCubeMapTextureParams(t, n), t.isReady = !0, t.onLoadedObservable.notifyObservers(t), t.onLoadedObservable.clear(), i && i();
		}).catch((e) => {
			n.Warn("Failed to transcode Basis file, transcoding may not be supported on this device"), t.isReady = !0, a && a(e);
		});
	}
	loadData(e, t, r) {
		let i = t.getEngine().getCaps();
		m(e, { supportedCompressionFormats: {
			etc1: !!i.etc1,
			s3tc: !!i.s3tc,
			pvrtc: !!i.pvrtc,
			etc2: !!i.etc2,
			astc: !!i.astc,
			bc7: !!i.bptc
		} }).then((e) => {
			let n = e.fileInfo.images[0].levels[0], i = e.fileInfo.images[0].levels.length > 1 && t.generateMipMaps;
			r(n.width, n.height, i, e.format !== -1, () => {
				g(t, e);
			});
		}).catch((e) => {
			n.Warn("Failed to transcode Basis file, transcoding may not be supported on this device"), n.Warn(`Failed to transcode Basis file: ${e}`), r(0, 0, !1, !1, () => {}, !0);
		});
	}
};
//#endregion
export { v as _BasisTextureLoader };
