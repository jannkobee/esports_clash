import { n as e, t } from "./engineStore-D0BoPdea.js";
import { t as n } from "./logger-DQIzSR_y.js";
import { i as r, r as i, t as a } from "./domManagement-BZa7OPDn.js";
import { S as o, i as s, m as c, o as l, p as u, r as d, s as f } from "./tools.functions-DEecYKlu.js";
import { t as p } from "./typeStore-pENEWnX2.js";
import { t as m } from "./guid-DXeovnrE.js";
import { r as h, t as g } from "./halfFloat-CieD0yV9.js";
//#region node_modules/@babylonjs/core/Misc/webRequest.js
function _() {
	return typeof _native < "u" && _native.XMLHttpRequest ? new _native.XMLHttpRequest() : new XMLHttpRequest();
}
var v = class e {
	constructor() {
		this._xhr = _(), this._requestURL = "";
	}
	static get IsCustomRequestAvailable() {
		return Object.keys(e.CustomRequestHeaders).length > 0 || e.CustomRequestModifiers.length > 0;
	}
	static _CleanUrl(e) {
		return e = e.replace("file:http:", "http:"), e = e.replace("file:https:", "https:"), e;
	}
	static _ShouldSkipRequestModifications(t) {
		return e.SkipRequestModificationForBabylonCDN && (t.includes("preview.babylonjs.com") || t.includes("cdn.babylonjs.com"));
	}
	static _CollectCustomizations(t, n = {}) {
		let r = { ...n };
		if (e._ShouldSkipRequestModifications(t)) return {
			url: t,
			headers: r
		};
		for (let t in e.CustomRequestHeaders) {
			let n = e.CustomRequestHeaders[t];
			n && (r[t] = n);
		}
		let i = { setRequestHeader: (e, t) => {
			r[e] = t;
		} };
		for (let n of e.CustomRequestModifiers) {
			if (e._ShouldSkipRequestModifications(t)) break;
			let r = n(i, t);
			typeof r == "string" && (t = r);
		}
		return {
			url: t,
			headers: r
		};
	}
	static async FetchAsync(t, n = {}) {
		let r = n.method ?? "GET";
		if (typeof fetch < "u") {
			let { url: i, headers: a } = e._CollectCustomizations(e._CleanUrl(t), n.headers ?? {});
			return await fetch(i, {
				method: r,
				headers: a,
				body: n.body ?? void 0
			});
		}
		return await new Promise((i, a) => {
			let o = new e();
			o.responseType = "arraybuffer", o.addEventListener("readystatechange", () => {
				if (o.readyState === 4) {
					if (o.status >= 200 && o.status < 300) {
						let e = typeof Headers < "u" ? new Headers() : void 0, t = o.getResponseHeader("Content-Type");
						t && e && e.set("Content-Type", t), i(typeof Response < "u" ? new Response(o.response, {
							status: o.status,
							statusText: o.statusText,
							headers: e
						}) : {
							ok: !0,
							status: o.status,
							statusText: o.statusText,
							headers: { get: (e) => o.getResponseHeader(e) },
							arrayBuffer: async () => await Promise.resolve(o.response)
						});
					} else a(/* @__PURE__ */ Error(`HTTP ${o.status} loading '${o.requestURL}': ${o.statusText}`));
				}
			}), o.open(r, t, n.headers), o.send(n.body ?? null);
		});
	}
	get requestURL() {
		return this._requestURL;
	}
	get onprogress() {
		return this._xhr.onprogress;
	}
	set onprogress(e) {
		this._xhr.onprogress = e;
	}
	get readyState() {
		return this._xhr.readyState;
	}
	get status() {
		return this._xhr.status;
	}
	get statusText() {
		return this._xhr.statusText;
	}
	get response() {
		return this._xhr.response;
	}
	get responseURL() {
		return this._xhr.responseURL;
	}
	get responseText() {
		return this._xhr.responseText;
	}
	get responseType() {
		return this._xhr.responseType;
	}
	set responseType(e) {
		this._xhr.responseType = e;
	}
	get timeout() {
		return this._xhr.timeout;
	}
	set timeout(e) {
		this._xhr.timeout = e;
	}
	addEventListener(e, t, n) {
		this._xhr.addEventListener(e, t, n);
	}
	removeEventListener(e, t, n) {
		this._xhr.removeEventListener(e, t, n);
	}
	abort() {
		this._xhr.abort();
	}
	send(e) {
		this._xhr.send(e);
	}
	open(t, n, r) {
		let { url: i, headers: a } = e._CollectCustomizations(n, r);
		this._requestURL = e._CleanUrl(i), this._xhr.open(t, this._requestURL, !0);
		for (let e in a) this._xhr.setRequestHeader(e, a[e]);
	}
	setRequestHeader(e, t) {
		this._xhr.setRequestHeader(e, t);
	}
	getResponseHeader(e) {
		return this._xhr.getResponseHeader(e);
	}
};
v.CustomRequestHeaders = {}, v.CustomRequestModifiers = [], v.SkipRequestModificationForBabylonCDN = !0;
//#endregion
//#region node_modules/@babylonjs/core/Misc/filesInputStore.js
var y = class {};
y.FilesToLoad = {};
//#endregion
//#region node_modules/@babylonjs/core/Misc/retryStrategy.js
var b = class {
	static ExponentialBackoff(e = 3, t = 500) {
		return (n, r, i) => r.status !== 0 || i >= e || n.indexOf("file:") !== -1 ? -1 : 2 ** i * t;
	}
}, x = class extends Error {};
x._setPrototypeOf = Object.setPrototypeOf || ((e, t) => (e.__proto__ = t, e));
var S = {
	MeshInvalidPositionsError: 0,
	UnsupportedTextureError: 1e3,
	GLTFLoaderUnexpectedMagicError: 2e3,
	SceneLoaderError: 3e3,
	LoadFileError: 4e3,
	RequestFileError: 4001,
	ReadFileError: 4002
}, C = class e extends x {
	constructor(t, n, r) {
		super(t), this.errorCode = n, this.innerError = r, this.name = "RuntimeError", x._setPrototypeOf(this, e.prototype);
	}
}, ee = (e) => {
	if (typeof TextDecoder < "u") return new TextDecoder().decode(e);
	let t = "";
	for (let n = 0; n < e.byteLength; n++) t += String.fromCharCode(e[n]);
	return t;
};
function te(e) {
	let t = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=", n = "", r, i, a, o, s, c, l, u = 0;
	for (; u < e.length;) r = e[u++], i = u < e.length ? e[u++] : NaN, a = u < e.length ? e[u++] : NaN, o = r >> 2, s = (r & 3) << 4 | i >> 4, c = (i & 15) << 2 | a >> 6, l = a & 63, isNaN(i) ? c = l = 64 : isNaN(a) && (l = 64), n += t.charAt(o) + t.charAt(s) + t.charAt(c) + t.charAt(l);
	return n;
}
function ne(e) {
	let t = T(e), n = t.length, r = new Uint8Array(new ArrayBuffer(n));
	for (let e = 0; e < n; e++) r[e] = t.charCodeAt(e);
	return r.buffer;
}
var w = (e) => {
	let t = ArrayBuffer.isView(e) ? new Uint8Array(e.buffer, e.byteOffset, e.byteLength) : new Uint8Array(e);
	return typeof t.toBase64 == "function" ? t.toBase64() : te(t);
}, T = (e) => atob(e), E = (e) => typeof Uint8Array.fromBase64 == "function" ? Uint8Array.fromBase64(e).buffer : ne(e);
//#endregion
//#region node_modules/@babylonjs/core/Buffers/bufferUtils.js
function re(e, t, n, r) {
	switch (t) {
		case 5120: {
			let t = e.getInt8(n);
			return r && (t = Math.max(t / 127, -1)), t;
		}
		case 5121: {
			let t = e.getUint8(n);
			return r && (t /= 255), t;
		}
		case 5122: {
			let t = e.getInt16(n, !0);
			return r && (t = Math.max(t / 32767, -1)), t;
		}
		case 5123: {
			let t = e.getUint16(n, !0);
			return r && (t /= 65535), t;
		}
		case 5131: return g(e.getUint16(n, !0));
		case 5124: return e.getInt32(n, !0);
		case 5125: return e.getUint32(n, !0);
		case 5126: return e.getFloat32(n, !0);
		default: throw Error(`Invalid component type ${t}`);
	}
}
function ie(e, t, n, r, i) {
	switch (t) {
		case 5120:
			r && (i = Math.round(i * 127)), e.setInt8(n, i);
			break;
		case 5121:
			r && (i = Math.round(i * 255)), e.setUint8(n, i);
			break;
		case 5122:
			r && (i = Math.round(i * 32767)), e.setInt16(n, i, !0);
			break;
		case 5123:
			r && (i = Math.round(i * 65535)), e.setUint16(n, i, !0);
			break;
		case 5131:
			e.setUint16(n, h(i), !0);
			break;
		case 5124:
			e.setInt32(n, i, !0);
			break;
		case 5125:
			e.setUint32(n, i, !0);
			break;
		case 5126:
			e.setFloat32(n, i, !0);
			break;
		default: throw Error(`Invalid component type ${t}`);
	}
}
function D(e) {
	switch (e) {
		case 5120:
		case 5121: return 1;
		case 5122:
		case 5123:
		case 5131: return 2;
		case 5124:
		case 5125:
		case 5126: return 4;
		default: throw Error(`Invalid type '${e}'`);
	}
}
function O(e) {
	switch (e) {
		case 5120: return Int8Array;
		case 5121: return Uint8Array;
		case 5122: return Int16Array;
		case 5123: return Uint16Array;
		case 5131: return Uint16Array;
		case 5124: return Int32Array;
		case 5125: return Uint32Array;
		case 5126: return Float32Array;
		default: throw Error(`Invalid component type '${e}'`);
	}
}
function k(e, t, n, r, i, a, o, s) {
	let c = Array(r), l = Array(r);
	if (e instanceof Array) {
		let i = t / 4, o = n / 4;
		for (let t = 0; t < a; t += r) {
			for (let t = 0; t < r; t++) c[t] = l[t] = e[i + t];
			s(l, t);
			for (let t = 0; t < r; t++) c[t] !== l[t] && (e[i + t] = l[t]);
			i += o;
		}
	} else {
		let u = ArrayBuffer.isView(e) ? new DataView(e.buffer, e.byteOffset, e.byteLength) : new DataView(e), d = D(i);
		for (let e = 0; e < a; e += r) {
			for (let e = 0, n = t; e < r; e++, n += d) c[e] = l[e] = re(u, i, n, o);
			s(l, e);
			for (let e = 0, n = t; e < r; e++, n += d) c[e] !== l[e] && ie(u, i, n, o, l[e]);
			t += n;
		}
	}
}
function ae(e, t, r, i, a, o, s, c) {
	let l = t * D(r), u = s * t;
	if (r !== 5126 || a !== l) {
		let n = new Float32Array(u);
		return k(e, i, a, t, r, u, o, (e, r) => {
			for (let i = 0; i < t; i++) n[r + i] = e[i];
		}), n;
	}
	if (!(e instanceof Array || e instanceof Float32Array) || i !== 0 || e.length !== u) {
		if (e instanceof Array) {
			let t = i / 4;
			return e.slice(t, t + u);
		}
		if (ArrayBuffer.isView(e)) {
			let t = e.byteOffset + i;
			return t & 3 && (n.Warn("Float array must be aligned to 4-bytes border"), c = !0), c ? new Float32Array(e.buffer.slice(t, t + u * Float32Array.BYTES_PER_ELEMENT)) : new Float32Array(e.buffer, t, u);
		}
		return new Float32Array(e, i, u);
	}
	return c ? e.slice() : e;
}
function oe(e, t, r, i, a, o, s) {
	let c = D(r), l = O(r), u = o * t;
	if (Array.isArray(e)) {
		if (i & 3 || a & 3) throw Error("byteOffset and byteStride must be a multiple of 4 for number[] data.");
		let n = i / 4, s = a / 4;
		if (n + (o - 1) * s + t > e.length) throw Error("Last accessed index is out of bounds.");
		if (s < t) throw Error("Data stride cannot be smaller than the component size.");
		if (s !== t) {
			let n = new l(u);
			return k(e, i, a, t, r, u, !1, (e, r) => {
				for (let i = 0; i < t; i++) n[r + i] = e[i];
			}), n;
		}
		return new l(e.slice(n, n + u));
	}
	let d, f = i;
	if (ArrayBuffer.isView(e) ? (d = e.buffer, f += e.byteOffset) : d = e, f + (o - 1) * a + t * c > d.byteLength) throw Error("Last accessed byte is out of bounds.");
	let p = t * c;
	if (a < p) throw Error("Byte stride cannot be smaller than the component's byte size.");
	if (a !== p) {
		let e = new l(u), n = new Uint8Array(d, f), r = new Uint8Array(e.buffer), i = t * c;
		for (let e = 0, t = 0, s = 0; e < o; e++, t += a, s += i) r.set(n.subarray(t, t + i), s);
		return e;
	}
	return c !== 1 && f & c - 1 && (n.Warn("Array must be aligned to border of element size. Data will be copied."), s = !0), s ? new l(d.slice(f, f + u * c)) : new l(d, f, u);
}
function se(e, t, r, i, a, o, s, c) {
	let l = t * D(r), u = s * t;
	if (c.length !== u) throw Error("Output length is not valid");
	if (r !== 5126 || a !== l) k(e, i, a, t, r, u, o, (e, n) => {
		for (let r = 0; r < t; r++) c[n + r] = e[r];
	});
	else if (e instanceof Array) {
		let t = i / 4;
		c.set(e, t);
	} else if (ArrayBuffer.isView(e)) {
		let t = e.byteOffset + i;
		if (t & 3) {
			n.Warn("Float array must be aligned to 4-bytes border"), c.set(new Float32Array(e.buffer.slice(t, t + u * Float32Array.BYTES_PER_ELEMENT)));
			return;
		}
		let r = new Float32Array(e.buffer, t, u);
		c.set(r);
	} else {
		let t = new Float32Array(e, i, u);
		c.set(t);
	}
}
function A(e) {
	let t = e.buffer;
	if (t instanceof ArrayBuffer) return e;
	let n = new ArrayBuffer(e.byteLength);
	return new Uint8Array(n).set(new Uint8Array(t, e.byteOffset, e.byteLength)), n;
}
//#endregion
//#region node_modules/@babylonjs/core/Misc/fileTools.pure.js
var j = /*#__PURE__*/ new RegExp(/^data:([^,]+\/[^,]+)?;base64,/i), M = class e extends C {
	constructor(t, n) {
		super(t, S.LoadFileError), this.name = "LoadFileError", x._setPrototypeOf(this, e.prototype), n instanceof v ? this.request = n : this.file = n;
	}
}, N = class e extends C {
	constructor(t, n) {
		super(t, S.RequestFileError), this.request = n, this.name = "RequestFileError", x._setPrototypeOf(this, e.prototype);
	}
}, ce = class e extends C {
	constructor(t, n) {
		super(t, S.ReadFileError), this.file = n, this.name = "ReadFileError", x._setPrototypeOf(this, e.prototype);
	}
}, P = {
	DefaultRetryStrategy: b.ExponentialBackoff(),
	BaseUrl: "",
	CorsBehavior: "anonymous",
	PreprocessUrl: (e) => e,
	ScriptBaseUrl: "",
	ScriptPreprocessUrl: (e) => e,
	CleanUrl: (e) => (e = e.replace(/#/gm, "%23"), e)
}, F = (e, t) => {
	if (!(e && e.indexOf("data:") === 0) && P.CorsBehavior) {
		if (typeof P.CorsBehavior == "string" || P.CorsBehavior instanceof String) t.crossOrigin = P.CorsBehavior;
		else {
			let n = P.CorsBehavior(e);
			n && (t.crossOrigin = n);
		}
	}
}, I = { getRequiredSize: null }, L = (e, n, r, i, a = "", o, s = t.LastCreatedEngine) => {
	if (typeof HTMLImageElement > "u" && !s?._features.forceBitmapOverHTMLImageElement) return r("LoadImage is only supported in web or BabylonNative environments."), null;
	if (s?._features.forceBitmapOverHTMLImageElement && typeof e != "string" && typeof Blob < "u") {
		let t;
		if (e instanceof Blob) t = e;
		else {
			let n = e instanceof ArrayBuffer ? e : A(e);
			t = new Blob([n], { type: a });
		}
		return s.createImageBitmap(t, {
			premultiplyAlpha: "none",
			colorSpaceConversion: "none",
			...o
		}).then(n).catch((t) => {
			r && r("Error while trying to load image: " + e, t);
		}), null;
	}
	let c, l = !1;
	if (e instanceof ArrayBuffer || ArrayBuffer.isView(e)) {
		if (typeof Blob < "u" && typeof URL < "u") {
			let t;
			t = e instanceof ArrayBuffer ? e : A(e), c = URL.createObjectURL(new Blob([t], { type: a })), l = !0;
		} else c = `data:${a};base64,` + w(e);
	} else e instanceof Blob ? (c = URL.createObjectURL(e), l = !0) : (c = P.CleanUrl(e), c = P.PreprocessUrl(c));
	let u = (t) => {
		if (r) {
			let n = c || e.toString();
			r(`Error while trying to load image: ${n.indexOf("http") === 0 || n.length <= 128 ? n : n.slice(0, 128) + "..."}`, t);
		}
	};
	if (s?._features.forceBitmapOverHTMLImageElement) return z(c, (t) => {
		s.createImageBitmap(new Blob([t], { type: a }), {
			premultiplyAlpha: "none",
			colorSpaceConversion: "none",
			...o
		}).then((e) => {
			n(e), l && URL.revokeObjectURL(c);
		}).catch((t) => {
			r && r("Error while trying to load image: " + e, t);
		});
	}, void 0, i || void 0, !0, (e, t) => {
		u(t);
	}), null;
	let d = new Image();
	if (I.getRequiredSize) {
		let t = I.getRequiredSize(e);
		t.width && (d.width = t.width), t.height && (d.height = t.height);
	}
	F(c, d);
	let f = [], p = () => {
		for (let e of f) e.target.addEventListener(e.name, e.handler);
	}, m = () => {
		for (let e of f) e.target.removeEventListener(e.name, e.handler);
		f.length = 0;
	};
	f.push({
		target: d,
		name: "load",
		handler: () => {
			m(), n(d), l && d.src && URL.revokeObjectURL(d.src);
		}
	}), f.push({
		target: d,
		name: "error",
		handler: (e) => {
			m(), u(e), l && d.src && URL.revokeObjectURL(d.src);
		}
	}), f.push({
		target: document,
		name: "securitypolicyviolation",
		handler: (e) => {
			if (e.blockedURI !== d.src || e.disposition === "report") return;
			m();
			let n = /* @__PURE__ */ Error(`CSP violation of policy ${e.effectiveDirective} ${e.blockedURI}. Current policy is ${e.originalPolicy}`);
			t.UseFallbackTexture = !1, u(n), l && d.src && URL.revokeObjectURL(d.src), d.src = "";
		}
	}), p();
	let h = c.substring(0, 5) === "blob:", g = c.substring(0, 5) === "data:", _ = () => {
		h || g || !v.IsCustomRequestAvailable ? d.src = c : z(c, (e, t, n) => {
			let r = new Blob([e], { type: !a && n ? n : a }), i = URL.createObjectURL(r);
			l = !0, d.src = i;
		}, void 0, i || void 0, !0, (e, t) => {
			u(t);
		});
	}, b = () => {
		i && i.loadImage(c, d);
	};
	if (!h && !g && i && i.enableTexturesOffline) i.open(b, _);
	else {
		if (c.indexOf("file:") !== -1) {
			let e = decodeURIComponent(c.substring(5).toLowerCase());
			if (y.FilesToLoad[e] && typeof URL < "u") {
				try {
					let t;
					try {
						t = URL.createObjectURL(y.FilesToLoad[e]);
					} catch {
						t = URL.createObjectURL(y.FilesToLoad[e]);
					}
					d.src = t, l = !0;
				} catch {
					d.src = "";
				}
				return d;
			}
		}
		_();
	}
	return d;
}, R = (t, n, r, i, a) => {
	let o = new FileReader(), s = {
		onCompleteObservable: new e(),
		abort: () => o.abort()
	};
	return o.onloadend = () => s.onCompleteObservable.notifyObservers(s), a && (o.onerror = () => {
		a(new ce(`Unable to read ${t.name}`, t));
	}), o.onload = (e) => {
		n(e.target.result);
	}, r && (o.onprogress = r), i ? o.readAsArrayBuffer(t) : o.readAsText(t), s;
}, z = (t, r, i, a, o, s, c) => {
	if (t.name) return R(t, r, i, o, s ? (e) => {
		s(void 0, e);
	} : void 0);
	let l = t;
	if (l.indexOf("file:") !== -1) {
		let e = decodeURIComponent(l.substring(5).toLowerCase());
		e.indexOf("./") === 0 && (e = e.substring(2));
		let t = y.FilesToLoad[e];
		if (t) return R(t, r, i, o, s ? (e) => s(void 0, new M(e.message, e.file)) : void 0);
	}
	let { match: u, type: d } = U(l);
	if (u) {
		let t = {
			onCompleteObservable: new e(),
			abort: () => () => {}
		};
		try {
			r(o ? W(l) : G(l), void 0, d);
		} catch (e) {
			s ? s(void 0, e) : n.Error(e.message || "Failed to parse the Data URL");
		}
		return f.SetImmediate(() => {
			t.onCompleteObservable.notifyObservers(t);
		}), t;
	}
	return B(l, (e, t) => {
		r(e, t?.responseURL, t?.getResponseHeader("content-type"));
	}, i, a, o, s ? (e) => {
		s(e.request, new M(e.message, e.request));
	} : void 0, c);
}, B = (i, a, o, s, c, l, u) => {
	s !== null && (s ??= t.LastCreatedScene?.offlineProvider), i = P.CleanUrl(i), i = P.PreprocessUrl(i);
	let d = P.BaseUrl + i, f = !1, p = {
		onCompleteObservable: new e(),
		abort: () => f = !0
	}, m = () => {
		let e = new v(), t = null, i, s = () => {
			e && (o && e.removeEventListener("progress", o), i && e.removeEventListener("readystatechange", i), e.removeEventListener("loadend", m));
		}, m = () => {
			s(), p.onCompleteObservable.notifyObservers(p), p.onCompleteObservable.clear(), o = void 0, i = null, m = null, l = void 0, u = void 0, a = void 0;
		};
		p.abort = () => {
			f = !0, m && m(), e && e.readyState !== (XMLHttpRequest.DONE || 4) && e.abort(), t !== null && (clearTimeout(t), t = null), e = null;
		};
		let h = (t) => {
			let r = t.message || "Unknown error";
			l && e ? l(new N(r, e)) : n.Error(r);
		}, g = (n) => {
			if (e) {
				if (e.open("GET", d), u) try {
					u(e);
				} catch (e) {
					h(e);
					return;
				}
				c && (e.responseType = "arraybuffer"), o && e.addEventListener("progress", o), m && e.addEventListener("loadend", m), i = () => {
					if (!f && e && e.readyState === (XMLHttpRequest.DONE || 4)) {
						if (i && e.removeEventListener("readystatechange", i), e.status >= 200 && e.status < 300 || e.status === 0 && (!r() || V())) {
							let t = c ? e.response : e.responseText;
							if (t !== null) {
								try {
									a && a(t, e);
								} catch (e) {
									h(e);
								}
								return;
							}
						}
						let o = P.DefaultRetryStrategy;
						if (o) {
							let r = o(d, e, n);
							if (r !== -1) {
								s(), e = new v(), t = setTimeout(() => g(n + 1), r);
								return;
							}
						}
						let u = new N("Error status: " + e.status + " " + e.statusText + " - Unable to load " + d, e);
						l && l(u);
					}
				}, e.addEventListener("readystatechange", i), e.send();
			}
		};
		g(0);
	};
	if (s && s.enableSceneOffline && !i.startsWith("blob:")) {
		let e = (e) => {
			e && e.status > 400 ? l && l(e) : m();
		};
		s.open(() => {
			s && s.loadFile(P.BaseUrl + i, (e) => {
				!f && a && a(e), p.onCompleteObservable.notifyObservers(p);
			}, o ? (e) => {
				!f && o && o(e);
			} : void 0, e, c);
		}, e);
	} else m();
	return p;
}, le = (e) => {
	let { match: t, type: n } = U(e);
	if (t) return n || void 0;
	let r = e.lastIndexOf(".");
	switch (e.substring(r + 1).toLowerCase()) {
		case "glb": return "model/gltf-binary";
		case "bin": return "application/octet-stream";
		case "gltf": return "model/gltf+json";
		case "jpg":
		case "jpeg": return "image/jpeg";
		case "png": return "image/png";
		case "webp": return "image/webp";
		case "ktx": return "image/ktx";
		case "ktx2": return "image/ktx2";
		case "avif": return "image/avif";
		default: return;
	}
}, V = () => typeof location < "u" && location.protocol === "file:", H = (e) => j.test(e), U = (e) => {
	let t = j.exec(e);
	return t === null || t.length === 0 ? {
		match: !1,
		type: ""
	} : {
		match: !0,
		type: t[0].replace("data:", "").replace(";base64,", "")
	};
};
function W(e) {
	return E(e.split(",")[1]);
}
var G = (e) => T(e.split(",")[1]), K, ue = (e, t, n, r, i, a, o, s, c, l) => {
	K = {
		DecodeBase64UrlToBinary: e,
		DecodeBase64UrlToString: t,
		DefaultRetryStrategy: n.DefaultRetryStrategy,
		BaseUrl: n.BaseUrl,
		CorsBehavior: n.CorsBehavior,
		PreprocessUrl: n.PreprocessUrl,
		IsBase64DataUrl: r,
		IsFileURL: i,
		LoadFile: a,
		LoadImage: o,
		ReadFile: s,
		RequestFile: c,
		SetCorsBehavior: l
	}, Object.defineProperty(K, "DefaultRetryStrategy", {
		get: function() {
			return n.DefaultRetryStrategy;
		},
		set: function(e) {
			n.DefaultRetryStrategy = e;
		}
	}), Object.defineProperty(K, "BaseUrl", {
		get: function() {
			return n.BaseUrl;
		},
		set: function(e) {
			n.BaseUrl = e;
		}
	}), Object.defineProperty(K, "PreprocessUrl", {
		get: function() {
			return n.PreprocessUrl;
		},
		set: function(e) {
			n.PreprocessUrl = e;
		}
	}), Object.defineProperty(K, "CorsBehavior", {
		get: function() {
			return n.CorsBehavior;
		},
		set: function(e) {
			n.CorsBehavior = e;
		}
	});
}, q = !1;
function de() {
	q || (q = !0, ue(W, G, P, H, V, z, L, R, B, F), c.loadFile = z, c.loadImage = L, u.loadFile = z);
}
//#endregion
//#region node_modules/@babylonjs/core/Misc/deepCopier.js
var J = (e, t, n) => !e || e.getClassName && e.getClassName() === "Mesh" ? null : e.getClassName && (e.getClassName() === "SubMesh" || e.getClassName() === "PhysicsBody") ? e.clone(t) : e.clone ? e.clone() : Array.isArray(e) ? e.slice() : n && typeof e == "object" ? { ...e } : null;
function fe(e) {
	let t = [];
	do {
		let n = Object.getOwnPropertyNames(e);
		for (let e of n) t.indexOf(e) === -1 && t.push(e);
	} while (e = Object.getPrototypeOf(e));
	return t;
}
var Y = class {
	static DeepCopy(e, t, r, i, a = !1) {
		let o = fe(e);
		for (let s of o) {
			if (s[0] === "_" && (!i || i.indexOf(s) === -1) || s.endsWith("Observable") || r && r.indexOf(s) !== -1) continue;
			let o = e[s], c = typeof o;
			if (c !== "function") try {
				if (c === "object") {
					if (o instanceof Uint8Array) t[s] = Uint8Array.from(o);
					else if (o instanceof Array) {
						if (t[s] = [], o.length > 0) {
							if (typeof o[0] == "object") for (let e = 0; e < o.length; e++) {
								let n = J(o[e], t, a);
								t[s].indexOf(n) === -1 && t[s].push(n);
							}
							else t[s] = o.slice(0);
						}
					} else t[s] = J(o, t, a);
				} else t[s] = o;
			} catch (e) {
				n.Warn(e.message);
			}
		}
	}
}, X = class {
	static Instantiate(e) {
		if (this.RegisteredExternalClasses && this.RegisteredExternalClasses[e]) return this.RegisteredExternalClasses[e];
		let t = p(e);
		if (t) return t;
		n.Warn(e + " not found, you may have missed an import.");
		let r = e.split("."), i = typeof window < "u" ? window : typeof globalThis < "u" ? globalThis : this;
		for (let e = 0, t = r.length; e < t; e++) i = i[r[e]];
		return typeof i == "function" ? i : null;
	}
};
X.RegisteredExternalClasses = {};
//#endregion
//#region node_modules/@babylonjs/core/Misc/tools.pure.js
var Z, Q = class {
	static get BaseUrl() {
		return P.BaseUrl;
	}
	static set BaseUrl(e) {
		P.BaseUrl = e;
	}
	static get CleanUrl() {
		return P.CleanUrl;
	}
	static set CleanUrl(e) {
		P.CleanUrl = e;
	}
	static IsAbsoluteUrl(e) {
		return e.indexOf("//") === 0 ? !0 : e.indexOf("://") === -1 || e.indexOf(".") === -1 || e.indexOf("/") === -1 || e.indexOf(":") > e.indexOf("/") ? !1 : e.indexOf("://") < e.indexOf(".") || e.indexOf("data:") === 0 || e.indexOf("blob:") === 0;
	}
	static set ScriptBaseUrl(e) {
		P.ScriptBaseUrl = e;
	}
	static get ScriptBaseUrl() {
		return P.ScriptBaseUrl;
	}
	static set CDNBaseUrl(e) {
		Z.ScriptBaseUrl = e, Z.AssetBaseUrl = e;
	}
	static set ScriptPreprocessUrl(e) {
		P.ScriptPreprocessUrl = e;
	}
	static get ScriptPreprocessUrl() {
		return P.ScriptPreprocessUrl;
	}
	static get DefaultRetryStrategy() {
		return P.DefaultRetryStrategy;
	}
	static set DefaultRetryStrategy(e) {
		P.DefaultRetryStrategy = e;
	}
	static get CorsBehavior() {
		return P.CorsBehavior;
	}
	static set CorsBehavior(e) {
		P.CorsBehavior = e;
	}
	static get UseFallbackTexture() {
		return t.UseFallbackTexture;
	}
	static set UseFallbackTexture(e) {
		t.UseFallbackTexture = e;
	}
	static get RegisteredExternalClasses() {
		return X.RegisteredExternalClasses;
	}
	static set RegisteredExternalClasses(e) {
		X.RegisteredExternalClasses = e;
	}
	static get fallbackTexture() {
		return t.FallbackTexture;
	}
	static set fallbackTexture(e) {
		t.FallbackTexture = e;
	}
	static FetchToRef(e, t, n, r, i, a) {
		let o = ((Math.abs(e) * n % n | 0) + (Math.abs(t) * r % r | 0) * n) * 4;
		a.r = i[o] / 255, a.g = i[o + 1] / 255, a.b = i[o + 2] / 255, a.a = i[o + 3] / 255;
	}
	static Mix(e, t, n) {
		return 0;
	}
	static Instantiate(e) {
		return X.Instantiate(e);
	}
	static SetImmediate(e) {
		f.SetImmediate(e);
	}
	static IsExponentOfTwo(e) {
		return !0;
	}
	static FloatRound(e) {
		return Math.fround(e);
	}
	static GetFilename(e) {
		let t = e.lastIndexOf("/");
		return t < 0 ? e : e.substring(t + 1);
	}
	static GetFolderPath(e, t = !1) {
		let n = e.lastIndexOf("/");
		return n < 0 ? t ? e : "" : e.substring(0, n + 1);
	}
	static ToDegrees(e) {
		return e * 180 / Math.PI;
	}
	static ToRadians(e) {
		return e * Math.PI / 180;
	}
	static SmoothAngleChange(e, t, n = .9) {
		let r = this.ToRadians(e), i = this.ToRadians(t);
		return this.ToDegrees(Math.atan2((1 - n) * Math.sin(i) + n * Math.sin(r), (1 - n) * Math.cos(i) + n * Math.cos(r)));
	}
	static MakeArray(e, t) {
		return t !== !0 && (e === void 0 || e == null) ? null : Array.isArray(e) ? e : [e];
	}
	static GetPointerPrefix(e) {
		return r() && !window.PointerEvent ? "mouse" : "pointer";
	}
	static SetCorsBehavior(e, t) {
		F(e, t);
	}
	static SetReferrerPolicyBehavior(e, t) {
		t.referrerPolicy = e;
	}
	static get PreprocessUrl() {
		return P.PreprocessUrl;
	}
	static set PreprocessUrl(e) {
		P.PreprocessUrl = e;
	}
	static LoadImage(e, t, n, r, i, a) {
		return L(e, t, n, r, i, a);
	}
	static LoadFile(e, t, n, r, i, a) {
		return z(e, t, n, r, i, a);
	}
	static async LoadFileAsync(e, t = !0) {
		return await new Promise((n, r) => {
			z(e, (e) => {
				n(e);
			}, void 0, void 0, t, (e, t) => {
				r(t);
			});
		});
	}
	static GetAssetUrl(e) {
		if (!e) return "";
		if (Z.AssetBaseUrl && e.startsWith(Z._DefaultAssetsUrl)) {
			let t = Z.AssetBaseUrl.endsWith("/") ? Z.AssetBaseUrl.slice(0, -1) : Z.AssetBaseUrl;
			return e.replace(Z._DefaultAssetsUrl, t);
		}
		return e;
	}
	static GetBabylonScriptURL(e, t) {
		if (!e) return "";
		if (e.startsWith(Z._DefaultCdnUrl)) {
			if (Z.ScriptBaseUrl) {
				let t = Z.ScriptBaseUrl.endsWith("/") ? Z.ScriptBaseUrl.slice(0, -1) : Z.ScriptBaseUrl;
				e = e.replace(Z._DefaultCdnUrl, t);
			} else if (Z._CdnVersion) {
				let t = `${Z._DefaultCdnUrl}/v${Z._CdnVersion}`;
				e.startsWith(t) || (e = e.replace(Z._DefaultCdnUrl, t));
			}
		}
		return e = Z.ScriptPreprocessUrl(e), t && !Z.IsAbsoluteUrl(e) && (e = Z.GetAbsoluteUrl(e)), e;
	}
	static LoadBabylonScript(e, t, n, r) {
		e = Z.GetBabylonScriptURL(e), Z.LoadScript(e, t, n);
	}
	static async LoadBabylonScriptAsync(e) {
		return e = Z.GetBabylonScriptURL(e), await Z.LoadScriptAsync(e);
	}
	static _LoadScriptNative(e, t, n, r, i = !1) {
		if (_native) {
			if (i) {
				let e = "Loading a script as an ES module is not supported in Babylon Native";
				n?.(e, /* @__PURE__ */ Error(e));
				return;
			}
			Z.LoadFile(e, (e) => {
				try {
					Function(e).apply(null), t && t();
				} catch (e) {
					n && n("LoadScript Error", e);
				}
			}, void 0, void 0, !1, (e, t) => {
				n && n("LoadScript Error", t);
			});
		}
	}
	static _LoadScriptWeb(e, t, n, i, a = !1) {
		if (typeof importScripts == "function") {
			try {
				importScripts(e), t && t();
			} catch (t) {
				n?.(`Unable to load script '${e}' in worker`, t);
			}
			return;
		}
		if (!r()) {
			n?.(`Cannot load script '${e}' outside of a window or a worker`);
			return;
		}
		let o = document.getElementsByTagName("head")[0], s = document.createElement("script");
		a ? (s.setAttribute("type", "module"), s.innerText = e) : (s.setAttribute("type", "text/javascript"), s.setAttribute("src", e)), i && (s.id = i), s.onload = () => {
			t && t();
		}, s.onerror = (t) => {
			n && n(`Unable to load script '${e}'`, t);
		}, o.appendChild(s);
	}
	static async LoadScriptAsync(e, t) {
		return await new Promise((n, r) => {
			this.LoadScript(e, () => {
				n();
			}, (e, t) => {
				r(t || Error(e));
			}, t);
		});
	}
	static ReadFileAsDataURL(t, n, r) {
		let i = new FileReader(), a = {
			onCompleteObservable: new e(),
			abort: () => i.abort()
		};
		return i.onloadend = () => {
			a.onCompleteObservable.notifyObservers(a);
		}, i.onload = (e) => {
			n(e.target.result);
		}, i.onprogress = r, i.readAsDataURL(t), a;
	}
	static ReadFile(e, t, n, r, i) {
		return R(e, t, n, r, i);
	}
	static FileAsURL(e) {
		let t = new Blob([e]);
		return window.URL.createObjectURL(t);
	}
	static Format(e, t = 2) {
		return e.toFixed(t);
	}
	static DeepCopy(e, t, n, r) {
		Y.DeepCopy(e, t, n, r);
	}
	static IsEmpty(e) {
		for (let t in e) if (Object.prototype.hasOwnProperty.call(e, t)) return !1;
		return !0;
	}
	static RegisterTopRootEvents(e, t) {
		for (let n = 0; n < t.length; n++) {
			let r = t[n];
			e.addEventListener(r.name, r.handler, !1);
			try {
				window.parent && window.parent.addEventListener(r.name, r.handler, !1);
			} catch {}
		}
	}
	static UnregisterTopRootEvents(e, t) {
		for (let n = 0; n < t.length; n++) {
			let r = t[n];
			e.removeEventListener(r.name, r.handler);
			try {
				e.parent && e.parent.removeEventListener(r.name, r.handler);
			} catch {}
		}
	}
	static async DumpFramebuffer(e, t, n, r, i = "image/png", a, s) {
		throw o("DumpTools");
	}
	static DumpData(e, t, n, r, i = "image/png", a, s = !1, c = !1, l) {
		throw o("DumpTools");
	}
	static async DumpDataAsync(e, t, n, r = "image/png", i, a = !1, s = !1, c) {
		throw o("DumpTools");
	}
	static _IsOffScreenCanvas(e) {
		return e.convertToBlob !== void 0;
	}
	static ToBlob(e, t, n = "image/png", r) {
		!Z._IsOffScreenCanvas(e) && !e.toBlob && (e.toBlob = function(e, t, n) {
			setTimeout(() => {
				let r = atob(this.toDataURL(t, n).split(",")[1]), i = r.length, a = new Uint8Array(i);
				for (let e = 0; e < i; e++) a[e] = r.charCodeAt(e);
				e(new Blob([a]));
			});
		}), Z._IsOffScreenCanvas(e) ? e.convertToBlob({
			type: n,
			quality: r
		}).then((e) => t(e)) : e.toBlob(function(e) {
			t(e);
		}, n, r);
	}
	static DownloadBlob(e, t) {
		if ("download" in document.createElement("a")) {
			if (!t) {
				let e = /* @__PURE__ */ new Date();
				t = "screenshot_" + ((e.getFullYear() + "-" + (e.getMonth() + 1)).slice(2) + "-" + e.getDate() + "_" + e.getHours() + "-" + ("0" + e.getMinutes()).slice(-2)) + ".png";
			}
			Z.Download(e, t);
		} else if (e && typeof URL < "u") {
			let t = URL.createObjectURL(e), n = window.open("");
			if (!n) return;
			let r = n.document.createElement("img");
			r.onload = function() {
				URL.revokeObjectURL(t);
			}, r.src = t, n.document.body.appendChild(r);
		}
	}
	static EncodeScreenshotCanvasData(e, t, n = "image/png", r, i) {
		if (typeof r == "string" || !t) this.ToBlob(e, function(e) {
			e && Z.DownloadBlob(e, r), t && t("");
		}, n, i);
		else if (t) {
			if (Z._IsOffScreenCanvas(e)) {
				e.convertToBlob({
					type: n,
					quality: i
				}).then((e) => {
					let n = new FileReader();
					n.readAsDataURL(e), n.onloadend = () => {
						let e = n.result;
						t(e);
					};
				});
				return;
			}
			t(e.toDataURL(n, i));
		}
	}
	static Download(e, t) {
		if (typeof URL > "u") return;
		let n = window.URL.createObjectURL(e), r = document.createElement("a");
		document.body.appendChild(r), r.style.display = "none", r.href = n, r.download = t, r.addEventListener("click", () => {
			r.parentElement && r.parentElement.removeChild(r);
		}), r.click(), window.URL.revokeObjectURL(n);
	}
	static BackCompatCameraNoPreventDefault(e) {
		return typeof e[0] == "boolean" ? e[0] : typeof e[1] == "boolean" && e[1];
	}
	static CreateScreenshot(e, t, n, r, i = "image/png", a = !1, s) {
		throw o("ScreenshotTools");
	}
	static async CreateScreenshotAsync(e, t, n, r = "image/png", i) {
		throw o("ScreenshotTools");
	}
	static CreateScreenshotUsingRenderTarget(e, t, n, r, i = "image/png", a = 1, s = !1, c, l = !1, u = !1, d = !0, f, p) {
		throw o("ScreenshotTools");
	}
	static async CreateScreenshotUsingRenderTargetAsync(e, t, n, r = "image/png", i = 1, a = !1, s, c = !1, l = !1, u = !0, d, f) {
		throw o("ScreenshotTools");
	}
	static RandomId() {
		return m();
	}
	static IsBase64(e) {
		return H(e);
	}
	static DecodeBase64(e) {
		return W(e);
	}
	static get errorsCount() {
		return n.errorsCount;
	}
	static Log(e) {
		n.Log(e);
	}
	static Warn(e) {
		n.Warn(e);
	}
	static Error(e) {
		n.Error(e);
	}
	static get LogCache() {
		return n.LogCache;
	}
	static ClearLogCache() {
		n.ClearLogCache();
	}
	static set LogLevels(e) {
		n.LogLevels = e;
	}
	static set PerformanceLogLevel(e) {
		(e & Z.PerformanceUserMarkLogLevel) === Z.PerformanceUserMarkLogLevel ? _native?.enablePerformanceLogging ? (_native.enablePerformanceLogging(1), Z.StartPerformanceCounter = Z._StartMarkNative, Z.EndPerformanceCounter = Z._EndMarkNative) : (Z.StartPerformanceCounter = Z._StartUserMark, Z.EndPerformanceCounter = Z._EndUserMark) : (e & Z.PerformanceConsoleLogLevel) === Z.PerformanceConsoleLogLevel ? _native?.enablePerformanceLogging ? (_native.enablePerformanceLogging(2), Z.StartPerformanceCounter = Z._StartMarkNative, Z.EndPerformanceCounter = Z._EndMarkNative) : (Z.StartPerformanceCounter = Z._StartPerformanceConsole, Z.EndPerformanceCounter = Z._EndPerformanceConsole) : (Z.StartPerformanceCounter = Z._StartPerformanceCounterDisabled, Z.EndPerformanceCounter = Z._EndPerformanceCounterDisabled, _native?.disablePerformanceLogging?.());
	}
	static _StartPerformanceCounterDisabled(e, t) {}
	static _EndPerformanceCounterDisabled(e, t) {}
	static _StartUserMark(e, t = !0) {
		if (!Z._Performance) {
			if (!r()) return;
			Z._Performance = window.performance;
		}
		t && Z._Performance.mark && Z._Performance.mark(e + "-Begin");
	}
	static _EndUserMark(e, t = !0) {
		t && Z._Performance.mark && (Z._Performance.mark(e + "-End"), Z._Performance.measure(e, e + "-Begin", e + "-End"));
	}
	static _StartPerformanceConsole(e, t = !0) {
		t && (Z._StartUserMark(e, t), console.time && console.time(e));
	}
	static _EndPerformanceConsole(e, t = !0) {
		t && (Z._EndUserMark(e, t), console.timeEnd(e));
	}
	static _StartMarkNative(e, t = !0) {
		if (t && _native?.startPerformanceCounter) {
			if (Z._NativePerformanceCounterHandles.has(e)) Z.Warn(`Performance counter with name ${e} is already started.`);
			else {
				let t = _native.startPerformanceCounter(e);
				Z._NativePerformanceCounterHandles.set(e, t);
			}
		}
	}
	static _EndMarkNative(e, t = !0) {
		if (t && _native?.endPerformanceCounter) {
			let t = Z._NativePerformanceCounterHandles.get(e);
			t ? (_native.endPerformanceCounter(t), Z._NativePerformanceCounterHandles.delete(e)) : Z.Warn(`Performance counter with name ${e} was not started.`);
		}
	}
	static get Now() {
		return l.Now;
	}
	static GetClassName(e, t = !1) {
		let n = null;
		return !t && e.getClassName ? n = e.getClassName() : (e instanceof Object && (n = (t ? e : Object.getPrototypeOf(e)).constructor.__bjsclassName__), n ||= typeof e), n;
	}
	static First(e, t) {
		for (let n of e) if (t(n)) return n;
		return null;
	}
	static getFullClassName(e, t = !1) {
		let n = null, r = null;
		if (!t && e.getClassName) n = e.getClassName();
		else {
			if (e instanceof Object) {
				let i = t ? e : Object.getPrototypeOf(e);
				n = i.constructor.__bjsclassName__, r = i.constructor.__bjsmoduleName__;
			}
			n ||= typeof e;
		}
		return n ? (r == null ? "" : r + ".") + n : null;
	}
	static async DelayAsync(e) {
		await new Promise((t) => {
			setTimeout(() => {
				t();
			}, e);
		});
	}
	static IsSafari() {
		return i() ? /^((?!chrome|android).)*safari/i.test(navigator.userAgent) : !1;
	}
};
Z = Q, Q.AssetBaseUrl = "", Q.UseCustomRequestHeaders = !1, Q.CustomRequestHeaders = v.CustomRequestHeaders, Q.GetDOMTextContent = a, Q._DefaultCdnUrl = "https://cdn.babylonjs.com", Q._CdnVersion = "9.32.0", Q._DefaultAssetsUrl = "https://assets.babylonjs.com/core", Q.LoadScript = typeof _native > "u" ? Z._LoadScriptWeb : Z._LoadScriptNative, Q.GetAbsoluteUrl = typeof document == "object" ? (e) => {
	let t = document.createElement("a");
	return t.href = e, t.href;
} : typeof URL == "function" && typeof location == "object" ? (e) => new URL(e, location.origin).href : () => {
	throw Error("Unable to get absolute URL. Override BABYLON.Tools.GetAbsoluteUrl to a custom implementation for the current context.");
}, Q.NoneLogLevel = n.NoneLogLevel, Q.MessageLogLevel = n.MessageLogLevel, Q.WarningLogLevel = n.WarningLogLevel, Q.ErrorLogLevel = n.ErrorLogLevel, Q.AllLogLevel = n.AllLogLevel, Q.IsWindowObjectExist = r, Q.PerformanceNoneLogLevel = 0, Q.PerformanceUserMarkLogLevel = 1, Q.PerformanceConsoleLogLevel = 2, Q._NativePerformanceCounterHandles = /*#__PURE__*/ new Map(), Q.StartPerformanceCounter = Z._StartPerformanceCounterDisabled, Q.EndPerformanceCounter = Z._EndPerformanceCounterDisabled;
var pe = class e {
	constructor(e, t, n, r = 0) {
		this.iterations = e, this.index = r - 1, this._done = !1, this._fn = t, this._successCallback = n;
	}
	executeNext() {
		this._done || (this.index + 1 < this.iterations ? (++this.index, this._fn(this)) : this.breakLoop());
	}
	breakLoop() {
		this._done = !0, this._successCallback();
	}
	static Run(t, n, r, i = 0) {
		let a = new e(t, n, r, i);
		return a.executeNext(), a;
	}
	static SyncAsyncForLoop(t, n, r, i, a, o = 0) {
		return e.Run(Math.ceil(t / n), (e) => {
			a && a() ? e.breakLoop() : setTimeout(() => {
				for (let i = 0; i < n; ++i) {
					let o = e.index * n + i;
					if (o >= t) break;
					if (r(o), a && a()) {
						e.breakLoop();
						break;
					}
				}
				e.executeNext();
			}, o);
		}, i);
	}
}, $ = !1;
function me() {
	$ || ($ = !0, Q.Mix = s, Q.IsExponentOfTwo = d, t.FallbackTexture = "data:image/jpg;base64,/9j/4AAQSkZJRgABAQEAYABgAAD/4QBmRXhpZgAATU0AKgAAAAgABAEaAAUAAAABAAAAPgEbAAUAAAABAAAARgEoAAMAAAABAAIAAAExAAIAAAAQAAAATgAAAAAAAABgAAAAAQAAAGAAAAABcGFpbnQubmV0IDQuMC41AP/bAEMABAIDAwMCBAMDAwQEBAQFCQYFBQUFCwgIBgkNCw0NDQsMDA4QFBEODxMPDAwSGBITFRYXFxcOERkbGRYaFBYXFv/bAEMBBAQEBQUFCgYGChYPDA8WFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFv/AABEIAQABAAMBIgACEQEDEQH/xAAfAAABBQEBAQEBAQAAAAAAAAAAAQIDBAUGBwgJCgv/xAC1EAACAQMDAgQDBQUEBAAAAX0BAgMABBEFEiExQQYTUWEHInEUMoGRoQgjQrHBFVLR8CQzYnKCCQoWFxgZGiUmJygpKjQ1Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4eLj5OXm5+jp6vHy8/T19vf4+fr/xAAfAQADAQEBAQEBAQEBAAAAAAAAAQIDBAUGBwgJCgv/xAC1EQACAQIEBAMEBwUEBAABAncAAQIDEQQFITEGEkFRB2FxEyIygQgUQpGhscEJIzNS8BVictEKFiQ04SXxFxgZGiYnKCkqNTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqCg4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2dri4+Tl5ufo6ery8/T19vf4+fr/2gAMAwEAAhEDEQA/APH6KKK+FP76Pl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FPqCiiivhT++j5fooor7o/gU+oKKKK+FP76Pl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FPqCiiivhT++j5fooor7o/gU+oKKKK+FP76Pl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FCiiigD6gooor4U/vo+X6KKK+6P4FPqCiiivhT++j5fooor7o/gU+oKKKK+FP76Pl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FPqCiiivhT++j5fooor7o/gU+oKKKK+FP76Pl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FPqCiiivhT++gooooA+X6KKK+6P4FPqCiiivhT++j5fooor7o/gU+oKKKK+FP76Pl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FPqCiiivhT++j5fooor7o/gU+oKKKK+FP76Pl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FPqCiiivhT++j5fooor7o/gUKKKKAPqCiiivhT++j5fooor7o/gU+oKKKK+FP76Pl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FPqCiiivhT++j5fooor7o/gU+oKKKK+FP76Pl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FPqCiiivhT++j5fooor7o/gU+oKKKK+FP76CiiigD5fooor7o/gU+oKKKK+FP76Pl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FPqCiiivhT++j5fooor7o/gU+oKKKK+FP76Pl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FPqCiiivhT++j5fooor7o/gU+oKKKK+FP76Pl+iiivuj+BQooooA+oKKKK+FP76Pl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FPqCiiivhT++j5fooor7o/gU+oKKKK+FP76Pl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FPqCiiivhT++j5fooor7o/gU+oKKKK+FP76Pl+iiivuj+BT6gooor4U/voKKKKAPl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FPqCiiivhT++j5fooor7o/gU+oKKKK+FP76Pl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FPqCiiivhT++j5fooor7o/gU+oKKKK+FP76Pl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FCiiigD6gooor4U/vo+X6KKK+6P4FPqCiiivhT++j5fooor7o/gU+oKKKK+FP76Pl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FPqCiiivhT++j5fooor7o/gU+oKKKK+FP76Pl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FPqCiiivhT++gooooA+X6KKK+6P4FPqCiiivhT++j5fooor7o/gU+oKKKK+FP76Pl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FPqCiiivhT++j5fooor7o/gU+oKKKK+FP76Pl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FPqCiiivhT++j5fooor7o/gUKKKKAPqCiiivhT++j5fooor7o/gU+oKKKK+FP76Pl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FPqCiiivhT++j5fooor7o/gU+oKKKK+FP76Pl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FPqCiiivhT++j5fooor7o/gU+oKKKK+FP76CiiigD5fooor7o/gU+oKKKK+FP76Pl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FPqCiiivhT++j5fooor7o/gU+oKKKK+FP76Pl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FPqCiiivhT++j5fooor7o/gU+oKKKK+FP76Pl+iiivuj+BQooooA+oKKKK+FP76Pl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FPqCiiivhT++j5fooor7o/gU+oKKKK+FP76Pl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FPqCiiivhT++j5fooor7o/gU+oKKKK+FP76Pl+iiivuj+BT6gooor4U/voKKKKAPl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FPqCiiivhT++j5fooor7o/gU+oKKKK+FP76Pl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FPqCiiivhT++j5fooor7o/gU+oKKKK+FP76Pl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FCiiigD6gooor4U/vo+X6KKK+6P4FPqCiiivhT++j5fooor7o/gU+oKKKK+FP76Pl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FPqCiiivhT++j5fooor7o/gU+oKKKK+FP76Pl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FPqCiiivhT++gooooA+X6KKK+6P4FPqCiiivhT++j5fooor7o/gU+oKKKK+FP76Pl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FPqCiiivhT++j5fooor7o/gU+oKKKK+FP76Pl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FPqCiiivhT++j5fooor7o/gUKKKKAPqCiiivhT++j5fooor7o/gU+oKKKK+FP76Pl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FPqCiiivhT++j5fooor7o/gU+oKKKK+FP76Pl+iiivuj+BT6gooor4U/vo+X6KKK+6P4FPqCiiivhT++j5fooor7o/gU+oKKKK+FP76P//Z");
}
//#endregion
export { E as C, v as D, C as E, ee as S, S as T, A as _, Y as a, O as b, H as c, L as d, R as f, k as g, se as h, X as i, z as l, B as m, me as n, W as o, de as p, Q as r, le as s, pe as t, M as u, ae as v, w, oe as x, D as y };
