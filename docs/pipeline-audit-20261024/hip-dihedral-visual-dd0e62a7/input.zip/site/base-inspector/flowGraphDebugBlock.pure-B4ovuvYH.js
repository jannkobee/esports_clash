import { n as e } from "./typeStore-pENEWnX2.js";
import { t } from "./flowGraphBlock-BTSj91tT.js";
import { n } from "./flowGraphRichTypes.pure-BpKU4EZT.js";
//#region node_modules/@babylonjs/core/FlowGraph/Blocks/Data/flowGraphDebugBlock.pure.js
var r = 100, i = class e extends t {
	constructor(e) {
		super(e), this.log = [], this._isDebug = !0, this.input = this.registerDataInput("input", n), this.output = this.registerDataOutput("output", n);
	}
	_updateOutputs(e) {
		let t = this.input.getValue(e);
		this.output.setValue(t, e), this._logValue(t);
	}
	_logValue(t) {
		if (t == null) this.log.push(["null", "null"]);
		else {
			let n = e._FormatValue(t);
			this.log.push([n, String(t)]);
		}
		this.log.length > r && this.log.shift();
	}
	static _FormatValue(e) {
		if (typeof e == "number") return Number.isInteger(e) ? e.toString() : e.toFixed(4);
		if (typeof e == "boolean" || typeof e == "string") return String(e);
		if (e && typeof e == "object") {
			if ("w" in e && "x" in e && "y" in e && "z" in e) return `(${e.x.toFixed(3)}, ${e.y.toFixed(3)}, ${e.z.toFixed(3)}, ${e.w.toFixed(3)})`;
			if ("z" in e && "x" in e && "y" in e) return `(${e.x.toFixed(3)}, ${e.y.toFixed(3)}, ${e.z.toFixed(3)})`;
			if ("x" in e && "y" in e) return `(${e.x.toFixed(3)}, ${e.y.toFixed(3)})`;
			if ("r" in e && "g" in e && "b" in e) {
				let t = "a" in e ? `, ${e.a.toFixed(3)}` : "";
				return `(${e.r.toFixed(3)}, ${e.g.toFixed(3)}, ${e.b.toFixed(3)}${t})`;
			}
			if (typeof e.toString == "function" && e.toString !== Object.prototype.toString) return e.toString();
		}
		try {
			let t = JSON.stringify(e);
			return t.length > 64 ? t.substring(0, 61) + "..." : t;
		} catch {
			return String(e);
		}
	}
	getClassName() {
		return "FlowGraphDebugBlock";
	}
}, a = !1;
function o() {
	a || (a = !0, e("FlowGraphDebugBlock", i));
}
//#endregion
export { i as FlowGraphDebugBlock, o as RegisterFlowGraphDebugBlock };
