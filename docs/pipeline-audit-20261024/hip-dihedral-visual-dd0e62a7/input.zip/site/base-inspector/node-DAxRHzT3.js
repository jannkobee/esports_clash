import { n as e, t } from "./engineStore-D0BoPdea.js";
import { S as n } from "./tools.functions-DEecYKlu.js";
import { a as r, u as i } from "./math.color.pure-CPmbqLkh.js";
import { b as a, i as o, y as s } from "./decorators-BldPRAAT.js";
import { t as c } from "./decorators.serialization-CGAHzP43.js";
//#region node_modules/@babylonjs/core/node.js
var l = class {
	constructor() {
		this._doNotSerialize = !1, this._isDisposed = !1, this._sceneRootNodesIndex = -1, this._isEnabled = !0, this._isParentEnabled = !0, this._isReady = !0, this._onEnabledStateChangedObservable = new e(), this._onEffectiveEnabledStateChangedObservable = null, this._onClonedObservable = new e(), this._inheritVisibility = !1, this._isVisible = !0;
	}
}, u = (() => {
	var u;
	let d, f = [], p = [], m, h = [], g = [], _, v = [], y = [], b, x = [], S = [], C, w = [], T = [];
	return u = class {
		static AddNodeConstructor(e, t) {
			this._NodeConstructors[e] = t;
		}
		static Construct(e, t, n, r) {
			let i = this._NodeConstructors[e];
			return i ? i(t, n, r) : null;
		}
		set accessibilityTag(e) {
			this._accessibilityTag = e, this.onAccessibilityTagChangedObservable.notifyObservers(e);
		}
		get accessibilityTag() {
			return this._accessibilityTag;
		}
		get doNotSerialize() {
			return this._nodeDataStorage._doNotSerialize ? !0 : this._parentNode ? this._parentNode.doNotSerialize : !1;
		}
		set doNotSerialize(e) {
			this._nodeDataStorage._doNotSerialize = e;
		}
		isDisposed() {
			return this._nodeDataStorage._isDisposed;
		}
		set parent(e) {
			if (this._parentNode === e) return;
			let t = this._parentNode;
			if (this._parentNode && this._parentNode._children !== void 0 && this._parentNode._children !== null) {
				let t = this._parentNode._children.indexOf(this);
				t !== -1 && this._parentNode._children.splice(t, 1), !e && !this._nodeDataStorage._isDisposed && this._addToSceneRootNodes();
			}
			this._parentNode = e, this._isDirty = !0, this._parentNode && ((this._parentNode._children === void 0 || this._parentNode._children === null) && (this._parentNode._children = []), this._parentNode._children.push(this), t || this._removeFromSceneRootNodes()), this._syncParentEnabledState();
		}
		get parent() {
			return this._parentNode;
		}
		get inheritVisibility() {
			return this._nodeDataStorage._inheritVisibility;
		}
		set inheritVisibility(e) {
			this._nodeDataStorage._inheritVisibility = e;
		}
		get isVisible() {
			return this.inheritVisibility && this._parentNode && !this._parentNode.isVisible ? !1 : this._nodeDataStorage._isVisible;
		}
		set isVisible(e) {
			this._nodeDataStorage._isVisible = e;
		}
		_serializeAsParent(e) {
			e.parentId = this.uniqueId;
		}
		_addToSceneRootNodes() {
			this._nodeDataStorage._sceneRootNodesIndex === -1 && (this._nodeDataStorage._sceneRootNodesIndex = this._scene.rootNodes.length, this._scene.rootNodes.push(this));
		}
		_removeFromSceneRootNodes() {
			if (this._nodeDataStorage._sceneRootNodesIndex !== -1) {
				let e = this._scene.rootNodes, t = e.length - 1;
				e[this._nodeDataStorage._sceneRootNodesIndex] = e[t], e[this._nodeDataStorage._sceneRootNodesIndex]._nodeDataStorage._sceneRootNodesIndex = this._nodeDataStorage._sceneRootNodesIndex, this._scene.rootNodes.pop(), this._nodeDataStorage._sceneRootNodesIndex = -1;
			}
		}
		get animationPropertiesOverride() {
			return this._animationPropertiesOverride ? this._animationPropertiesOverride : this._scene.animationPropertiesOverride;
		}
		set animationPropertiesOverride(e) {
			this._animationPropertiesOverride = e;
		}
		getClassName() {
			return "Node";
		}
		set onDispose(e) {
			this._onDisposeObserver && this.onDisposeObservable.remove(this._onDisposeObserver), this._onDisposeObserver = this.onDisposeObservable.add(e);
		}
		get onEnabledStateChangedObservable() {
			return this._nodeDataStorage._onEnabledStateChangedObservable;
		}
		get onEffectiveEnabledStateChangedObservable() {
			var t;
			return (t = this._nodeDataStorage)._onEffectiveEnabledStateChangedObservable ?? (t._onEffectiveEnabledStateChangedObservable = new e());
		}
		get onClonedObservable() {
			return this._nodeDataStorage._onClonedObservable;
		}
		constructor(n, i = null, o = !0) {
			this._isDirty = !1, this._nodeDataStorage = new l(), this.name = a(this, f, void 0), this.id = (a(this, p), a(this, h, void 0)), this.uniqueId = (a(this, g), a(this, v, void 0)), this.state = (a(this, y), a(this, x, "")), this.metadata = (a(this, S), a(this, w, null)), this._internalMetadata = a(this, T), this.reservedDataStore = null, this._accessibilityTag = null, this.onAccessibilityTagChangedObservable = new e(), this._parentContainer = null, this.animations = [], this._ranges = {}, this.onReady = null, this._currentRenderId = -1, this._parentUpdateId = -1, this._childUpdateId = -1, this._waitingParentId = null, this._waitingParentInstanceIndex = null, this._waitingParsedUniqueId = null, this._cache = {}, this._parentNode = null, this._children = null, this._worldMatrix = r.Identity(), this._worldMatrixDeterminant = 0, this._worldMatrixDeterminantIsDirty = !0, this._animationPropertiesOverride = null, this._isNode = !0, this.onDisposeObservable = new e(), this._onDisposeObserver = null, this._behaviors = [], this.name = n, this.id = n, this._scene = i || t.LastCreatedScene, this.uniqueId = this._scene.getUniqueId(), this._initCache(), o && this._addToSceneRootNodes();
		}
		getScene() {
			return this._scene;
		}
		getEngine() {
			return this._scene.getEngine();
		}
		addBehavior(e, t = !1) {
			return this._behaviors.indexOf(e) === -1 && (e.init(), this._scene.isLoading && !t ? this._scene.onDataLoadedObservable.addOnce(() => {
				this._behaviors.includes(e) && e.attach(this);
			}) : e.attach(this), this._behaviors.push(e)), this;
		}
		removeBehavior(e) {
			let t = this._behaviors.indexOf(e);
			return t === -1 || (this._behaviors.splice(t, 1), e.detach()), this;
		}
		get behaviors() {
			return this._behaviors;
		}
		getBehaviorByName(e) {
			for (let t of this._behaviors) if (t.name === e) return t;
			return null;
		}
		getWorldMatrix() {
			return this._currentRenderId !== this._scene.getRenderId() && this.computeWorldMatrix(), this._worldMatrix;
		}
		_getWorldMatrixDeterminant() {
			return this._worldMatrixDeterminantIsDirty && (this._worldMatrixDeterminantIsDirty = !1, this._worldMatrixDeterminant = this._worldMatrix.determinant()), this._worldMatrixDeterminant;
		}
		get worldMatrixFromCache() {
			return this._worldMatrix;
		}
		_initCache() {
			this._cache = {};
		}
		updateCache(e) {
			(e || !this.isSynchronized()) && this._updateCache();
		}
		_getActionManagerForTrigger(e, t = !0) {
			return this.parent ? this.parent._getActionManagerForTrigger(e, !1) : null;
		}
		_updateCache(e) {}
		_isSynchronized() {
			return !0;
		}
		_markSyncedWithParent() {
			this._parentNode && (this._parentUpdateId = this._parentNode._childUpdateId);
		}
		isSynchronizedWithParent() {
			return this._parentNode ? this._parentNode._isDirty || this._parentUpdateId !== this._parentNode._childUpdateId ? !1 : this._parentNode.isSynchronized() : !0;
		}
		isSynchronized() {
			return this._parentNode && !this.isSynchronizedWithParent() ? !1 : this._isSynchronized();
		}
		isReady(e = !1) {
			return this._nodeDataStorage._isReady;
		}
		markAsDirty(e) {
			return this._currentRenderId = Number.MAX_VALUE, this._isDirty = !0, this;
		}
		isEnabled(e = !0) {
			return e === !1 ? this._nodeDataStorage._isEnabled : this._nodeDataStorage._isEnabled ? this._nodeDataStorage._isParentEnabled : !1;
		}
		_hasEffectiveEnabledStateObservers() {
			let e = this._nodeDataStorage._onEffectiveEnabledStateChangedObservable;
			return !!e && e.hasObservers();
		}
		_syncParentEnabledState() {
			let e = this._hasEffectiveEnabledStateObservers(), t = e ? this.isEnabled() : null;
			if (this._nodeDataStorage._isParentEnabled = !this._parentNode || this._parentNode.isEnabled(), this._children) for (let e of this._children) e._syncParentEnabledState();
			if (e) {
				let e = this.isEnabled();
				e !== t && this._nodeDataStorage._onEffectiveEnabledStateChangedObservable.notifyObservers(e);
			}
		}
		setEnabled(e) {
			if (this._nodeDataStorage._isEnabled === e) return;
			let t = this._hasEffectiveEnabledStateObservers(), n = t ? this.isEnabled() : null;
			if (this._nodeDataStorage._isEnabled = e, this._syncParentEnabledState(), this._nodeDataStorage._onEnabledStateChangedObservable.notifyObservers(e), t) {
				let e = this.isEnabled();
				e !== n && this._nodeDataStorage._onEffectiveEnabledStateChangedObservable.notifyObservers(e);
			}
		}
		isDescendantOf(e) {
			return this.parent ? this.parent === e || this.parent.isDescendantOf(e) : !1;
		}
		_getDescendants(e, t = !1, n) {
			if (this._children) for (let r = 0; r < this._children.length; r++) {
				let i = this._children[r];
				(!n || n(i)) && e.push(i), t || i._getDescendants(e, !1, n);
			}
		}
		getDescendants(e, t) {
			let n = [];
			return this._getDescendants(n, e, t), n;
		}
		getChildMeshes(e, t) {
			let n = [];
			return this._getDescendants(n, e, (e) => (!t || t(e)) && e.cullingStrategy !== void 0), n;
		}
		getChildren(e, t = !0) {
			return this.getDescendants(t, e);
		}
		_setReady(e) {
			e !== this._nodeDataStorage._isReady && (e ? (this.onReady && this.onReady(this), this._nodeDataStorage._isReady = !0) : this._nodeDataStorage._isReady = !1);
		}
		getAnimationByName(e) {
			for (let t = 0; t < this.animations.length; t++) {
				let n = this.animations[t];
				if (n.name === e) return n;
			}
			return null;
		}
		createAnimationRange(e, t, n) {
			if (!this._ranges[e]) {
				this._ranges[e] = u._AnimationRangeFactory(e, t, n);
				for (let r = 0, i = this.animations.length; r < i; r++) this.animations[r] && this.animations[r].createRange(e, t, n);
			}
		}
		deleteAnimationRange(e, t = !0) {
			for (let n = 0, r = this.animations.length; n < r; n++) this.animations[n] && this.animations[n].deleteRange(e, t);
			this._ranges[e] = null;
		}
		getAnimationRange(e) {
			return this._ranges[e] || null;
		}
		clone(e, t, n) {
			let r = c.Clone(() => new u(e, this.getScene()), this);
			if (t && (r.parent = t), !n) {
				let t = this.getDescendants(!0);
				for (let n = 0; n < t.length; n++) {
					let i = t[n];
					i.clone(e + "." + i.name, r);
				}
			}
			return r;
		}
		getAnimationRanges() {
			let e = [], t;
			for (t in this._ranges) e.push(this._ranges[t]);
			return e;
		}
		beginAnimation(e, t, n, r) {
			let i = this.getAnimationRange(e);
			return i ? this._scene.beginAnimation(this, i.from, i.to, t, n, r) : null;
		}
		serializeAnimationRanges() {
			let e = [];
			for (let t in this._ranges) {
				let n = this._ranges[t];
				if (!n) continue;
				let r = {};
				r.name = t, r.from = n.from, r.to = n.to, e.push(r);
			}
			return e;
		}
		computeWorldMatrix(e) {
			return this._worldMatrix ||= r.Identity(), this._worldMatrix;
		}
		dispose(e, t = !1) {
			if (this._nodeDataStorage._isDisposed = !0, !e) {
				let n = this.getDescendants(!0);
				for (let r of n) r.dispose(e, t);
			}
			this.parent ? this.parent = null : this._removeFromSceneRootNodes(), this.onDisposeObservable.notifyObservers(this), this.onDisposeObservable.clear(), this.onEnabledStateChangedObservable.clear(), this._nodeDataStorage._onEffectiveEnabledStateChangedObservable?.clear(), this.onClonedObservable.clear();
			for (let e of this._behaviors) e.detach();
			this._behaviors.length = 0, this.metadata = null;
		}
		static ParseAnimationRanges(e, t, n) {
			if (t.ranges) for (let n = 0; n < t.ranges.length; n++) {
				let r = t.ranges[n];
				e.createAnimationRange(r.name, r.from, r.to);
			}
		}
		getHierarchyBoundingVectors(e = !0, t = null) {
			this.getScene().incrementRenderId(), this.computeWorldMatrix(!0);
			let n, r, a = this;
			if (a.getBoundingInfo && a.subMeshes) {
				let e = a.getBoundingInfo();
				n = e.boundingBox.minimumWorld.clone(), r = e.boundingBox.maximumWorld.clone();
			} else n = new i(Number.MAX_VALUE, Number.MAX_VALUE, Number.MAX_VALUE), r = new i(-Number.MAX_VALUE, -Number.MAX_VALUE, -Number.MAX_VALUE);
			if (e) {
				let e = this.getDescendants(!1);
				for (let a of e) {
					let e = a;
					if (e.computeWorldMatrix(!0), t && !t(e) || !e.getBoundingInfo || e.getTotalVertices() === 0) continue;
					let o = e.getBoundingInfo().boundingBox, s = o.minimumWorld, c = o.maximumWorld;
					i.CheckExtends(s, n, r), i.CheckExtends(c, n, r);
				}
			}
			return {
				min: n,
				max: r
			};
		}
	}, (() => {
		let e = typeof Symbol == "function" && Symbol.metadata ? Object.create(null) : void 0;
		d = [o()], m = [o()], _ = [o()], b = [o()], C = [o()], s(null, null, d, {
			kind: "field",
			name: "name",
			static: !1,
			private: !1,
			access: {
				has: (e) => "name" in e,
				get: (e) => e.name,
				set: (e, t) => {
					e.name = t;
				}
			},
			metadata: e
		}, f, p), s(null, null, m, {
			kind: "field",
			name: "id",
			static: !1,
			private: !1,
			access: {
				has: (e) => "id" in e,
				get: (e) => e.id,
				set: (e, t) => {
					e.id = t;
				}
			},
			metadata: e
		}, h, g), s(null, null, _, {
			kind: "field",
			name: "uniqueId",
			static: !1,
			private: !1,
			access: {
				has: (e) => "uniqueId" in e,
				get: (e) => e.uniqueId,
				set: (e, t) => {
					e.uniqueId = t;
				}
			},
			metadata: e
		}, v, y), s(null, null, b, {
			kind: "field",
			name: "state",
			static: !1,
			private: !1,
			access: {
				has: (e) => "state" in e,
				get: (e) => e.state,
				set: (e, t) => {
					e.state = t;
				}
			},
			metadata: e
		}, x, S), s(null, null, C, {
			kind: "field",
			name: "metadata",
			static: !1,
			private: !1,
			access: {
				has: (e) => "metadata" in e,
				get: (e) => e.metadata,
				set: (e, t) => {
					e.metadata = t;
				}
			},
			metadata: e
		}, w, T), e && Object.defineProperty(u, Symbol.metadata, {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: e
		});
	})(), u._AnimationRangeFactory = (e, t, r) => {
		throw n("AnimationRange");
	}, u._NodeConstructors = {}, u;
})();
//#endregion
export { u as t };
