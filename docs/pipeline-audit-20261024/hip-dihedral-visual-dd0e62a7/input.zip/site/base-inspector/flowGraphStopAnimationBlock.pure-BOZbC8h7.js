import { t as e } from "./logger-DQIzSR_y.js";
import { n as t } from "./typeStore-pENEWnX2.js";
import { t as n } from "./flowGraphAsyncExecutionBlock-y06fnRVP.js";
import { c as r, n as i } from "./flowGraphRichTypes.pure-BpKU4EZT.js";
import { t as a } from "./flowGraphAnimationHelpers-Cw0WGn23.js";
//#region node_modules/@babylonjs/core/FlowGraph/Blocks/Execution/Animation/flowGraphStopAnimationBlock.pure.js
var o = class extends n {
	constructor(e) {
		super(e), this.animationGroup = this.registerDataInput("animationGroup", i), this.stopAtFrame = this.registerDataInput("stopAtFrame", r, -1);
	}
	_preparePendingTasks(e) {
		let t = this.animationGroup.getValue(e), n = this.stopAtFrame.getValue(e) ?? -1, r = e._getGlobalContextVariable("pendingStopAnimations", []);
		if (this.config?.useVirtualStopAt) {
			let i = r.find((e) => e.uniqueId === t.uniqueId && e.useVirtualStopAt);
			i ? (i.block !== this && e._removePendingBlock(i.block), i.stopAtFrame = n, i.block = this) : r.push({
				uniqueId: t.uniqueId,
				stopAtFrame: n,
				block: this,
				useVirtualStopAt: !0
			});
		} else r.push({
			uniqueId: t.uniqueId,
			stopAtFrame: n,
			block: this,
			useVirtualStopAt: !1
		});
		e._setGlobalContextVariable("pendingStopAnimations", r);
	}
	_cancelPendingTasks(e) {
		let t = this.animationGroup.getValue(e), n = e._getGlobalContextVariable("pendingStopAnimations", []);
		for (let r = 0; r < n.length; r++) if (n[r].uniqueId === t.uniqueId && n[r].block === this) {
			n.splice(r, 1), e._setGlobalContextVariable("pendingStopAnimations", n);
			break;
		}
	}
	_execute(t) {
		let n = this.animationGroup.getValue(t), r = this.stopAtFrame.getValue(t) ?? -1;
		if (!n) return e.Warn("No animation group provided to stop."), this._reportError(t, "No animation group provided to stop.");
		if (isNaN(r)) return this._reportError(t, "Invalid stop time.");
		let i = !!this.config?.useVirtualStopAt, a = i ? this.stopAtFrame.isConnected() || t._hasConnectionValue(this.stopAtFrame) : r > 0, o = !1;
		a ? i && n.isValidVirtualStopFrame(r) && n.isVirtualFrameReached(r) ? (this._stopAnimation(n, t, r), o = !0) : this._startPendingTasks(t) : this._stopAnimation(n, t), this.out._activateSignal(t), o && this.done._activateSignal(t);
	}
	_executeOnTick(e) {
		let t = this.animationGroup.getValue(e), n = e._getGlobalContextVariable("pendingStopAnimations", []);
		for (let r = 0; r < n.length; r++) if (n[r].uniqueId === t.uniqueId && n[r].block === this) {
			let i = n[r].useVirtualStopAt;
			if (i ? t.isValidVirtualStopFrame(n[r].stopAtFrame) && t.isVirtualFrameReached(n[r].stopAtFrame) : t.getCurrentFrame() >= n[r].stopAtFrame) {
				this._stopAnimation(t, e, i ? n[r].stopAtFrame : void 0), n.splice(r, 1), e._setGlobalContextVariable("pendingStopAnimations", n), this.done._activateSignal(e), e._removePendingBlock(this);
				break;
			}
			if (!t.isPlaying) {
				n.splice(r, 1), e._setGlobalContextVariable("pendingStopAnimations", n), e._removePendingBlock(this);
				break;
			}
		}
	}
	getClassName() {
		return "FlowGraphStopAnimationBlock";
	}
	_stopAnimation(e, t, n) {
		let r = t._getGlobalContextVariable("currentlyRunningAnimationGroups", []);
		if (r.indexOf(e.uniqueId) !== -1) {
			let i = this.config?.skipOnAnimationEnd !== !1;
			(i ? a(t, e) : void 0)?._cleanupAfterExternalStop(t, e), n !== void 0 && e.setVirtualCurrentFrame(n), i ? e.stop(!0) : e.stop();
			let o = r.indexOf(e.uniqueId);
			o !== -1 && (r.splice(o, 1), t._setGlobalContextVariable("currentlyRunningAnimationGroups", r));
		}
	}
}, s = !1;
function c() {
	s || (s = !0, t("FlowGraphStopAnimationBlock", o));
}
//#endregion
export { o as FlowGraphStopAnimationBlock, c as RegisterFlowGraphStopAnimationBlock };
