import { n as e } from "./engineStore-D0BoPdea.js";
import { S as t, s as n } from "./tools.functions-DEecYKlu.js";
import { a as r, c as i, u as a } from "./math.color.pure-CPmbqLkh.js";
import { t as o } from "./typeStore-pENEWnX2.js";
import { t as s } from "./math.plane-wePi4N1d.js";
import { b as c, i as l, y as u } from "./decorators-BldPRAAT.js";
import { t as d } from "./baseTexture.pure-CQS3PJ87.js";
import { t as f } from "./decorators.serialization-CGAHzP43.js";
import { i as p, w as m } from "./tools.pure-Dy2G52NL.js";
//#region node_modules/@babylonjs/core/Compat/compatibilityOptions.js
var h = !1;
//#endregion
//#region node_modules/@babylonjs/core/Misc/copyTools.js
function g(e, t, n = !1) {
	let r = t.width, i = t.height;
	if (e instanceof Float32Array) {
		let t = e.byteLength / e.BYTES_PER_ELEMENT, n = new Uint8Array(t);
		for (; --t >= 0;) {
			let r = e[t];
			r < 0 ? r = 0 : r > 1 && (r = 1), n[t] = r * 255;
		}
		e = n;
	}
	let a = document.createElement("canvas");
	a.width = r, a.height = i;
	let o = a.getContext("2d");
	if (!o) return null;
	let s = o.createImageData(r, i);
	if (s.data.set(e), o.putImageData(s, 0, 0), n) {
		let e = document.createElement("canvas");
		e.width = r, e.height = i;
		let t = e.getContext("2d");
		return t ? (t.translate(0, i), t.scale(1, -1), t.drawImage(a, 0, 0), e.toDataURL("image/png")) : null;
	}
	return a.toDataURL("image/png");
}
function _(e, t = 0, n = 0) {
	let r = e.getInternalTexture();
	if (!r) return null;
	let i = e._readPixelsSync(t, n);
	return i ? g(i, e.getSize(), r.invertY) : null;
}
async function v(e, t = 0, n = 0) {
	let r = e.getInternalTexture();
	if (!r) return null;
	let i = await e.readPixels(t, n);
	return i ? g(i, e.getSize(), r.invertY) : null;
}
//#endregion
//#region node_modules/@babylonjs/core/Materials/Textures/texture.pure.js
var y = (() => {
	var h;
	let g = d, y = [], b, x = [], S = [], C, w = [], T = [], E, D = [], O = [], k, A = [], j = [], M, N = [], P = [], F, I = [], L = [], R, z = [], B = [], V, H = [], U = [], W, G = [], K = [], q, J = [], Y = [], X, Z = [], Q = [], $, ee = [], te = [], ne;
	return h = class extends g {
		static _CreateVideoTexture(e, n, r, i = !1, a = !1, o = h.TRILINEAR_SAMPLINGMODE, s = {}, c, l = 5) {
			throw t("VideoTexture");
		}
		get noMipmap() {
			return this._noMipmap;
		}
		get mimeType() {
			return this._mimeType;
		}
		set isBlocking(e) {
			this._isBlocking = e;
		}
		get isBlocking() {
			return this._isBlocking;
		}
		get invertY() {
			return this._invertY;
		}
		constructor(t, r, i, a, o = h.TRILINEAR_SAMPLINGMODE, s = null, l = null, u = null, d = !1, f, p, m, g, _) {
			super(r), this.url = (c(this, y), c(this, x, null)), this.uOffset = (c(this, S), c(this, w, 0)), this.vOffset = (c(this, T), c(this, D, 0)), this.uScale = (c(this, O), c(this, A, 1)), this.vScale = (c(this, j), c(this, N, 1)), this.uAng = (c(this, P), c(this, I, 0)), this.vAng = (c(this, L), c(this, z, 0)), this.wAng = (c(this, B), c(this, H, 0)), this.uRotationCenter = (c(this, U), c(this, G, .5)), this.vRotationCenter = (c(this, K), c(this, J, .5)), this.wRotationCenter = (c(this, Y), c(this, Z, .5)), this.homogeneousRotationInUVTransform = (c(this, Q), c(this, ee, !1)), this.inspectableCustomProperties = (c(this, te), null), this._noMipmap = !1, this._invertY = !1, this._rowGenerationMatrix = null, this._cachedTextureMatrix = null, this._projectionModeMatrix = null, this._t0 = null, this._t1 = null, this._t2 = null, this._cachedUOffset = -1, this._cachedVOffset = -1, this._cachedUScale = 0, this._cachedVScale = 0, this._cachedUAng = -1, this._cachedVAng = -1, this._cachedWAng = -1, this._cachedReflectionProjectionMatrixId = -1, this._cachedURotationCenter = -1, this._cachedVRotationCenter = -1, this._cachedWRotationCenter = -1, this._cachedHomogeneousRotationInUVTransform = !1, this._cachedIdentity3x2 = !0, this._cachedReflectionTextureMatrix = null, this._cachedReflectionUOffset = -1, this._cachedReflectionVOffset = -1, this._cachedReflectionUScale = 0, this._cachedReflectionVScale = 0, this._cachedReflectionCoordinatesMode = -1, this._buffer = null, this._deleteBuffer = !1, this._format = null, this._delayedOnLoad = null, this._delayedOnError = null, this.onLoadObservable = new e(), this._isBlocking = !0, this.name = t || "", this.url = t;
			let v, b = !1, C = null, E = !0;
			typeof i == "object" && i ? (v = i.noMipmap ?? !1, a = i.invertY ?? !0, o = i.samplingMode ?? h.TRILINEAR_SAMPLINGMODE, s = i.onLoad ?? null, l = i.onError ?? null, u = i.buffer ?? null, d = i.deleteBuffer ?? !1, f = i.format, p = i.mimeType, m = i.loaderOptions, g = i.creationFlags, b = i.useSRGBBuffer ?? !1, C = i.internalTexture ?? null, E = i.gammaSpace ?? E, _ = i.forcedExtension ?? _) : v = !!i, this._gammaSpace = E, this._noMipmap = v, this._invertY = a === void 0 || a, this._initialSamplingMode = o, this._buffer = u, this._deleteBuffer = d, this._mimeType = p, this._loaderOptions = m, this._creationFlags = g, this._useSRGBBuffer = b, this._forcedExtension = _, f !== void 0 && (this._format = f);
			let k = this.getScene(), M = this._getEngine();
			if (!M) return;
			M.onBeforeTextureInitObservable.notifyObservers(this);
			let F = () => {
				this._texture && (this._texture._invertVScale && (this.vScale *= -1, this.vOffset += 1), this._texture._cachedWrapU !== null && (this.wrapU = this._texture._cachedWrapU, this._texture._cachedWrapU = null), this._texture._cachedWrapV !== null && (this.wrapV = this._texture._cachedWrapV, this._texture._cachedWrapV = null), this._texture._cachedWrapR !== null && (this.wrapR = this._texture._cachedWrapR, this._texture._cachedWrapR = null)), this.onLoadObservable.hasObservers() && this.onLoadObservable.notifyObservers(this), s && s(), !this.isBlocking && k && k.resetCachedMaterial();
			}, R = (e, t) => {
				this._loadingError = !0, this._errorObject = {
					message: e,
					exception: t
				}, l && l(e, t), h.OnTextureLoadErrorObservable.notifyObservers(this);
			};
			if (!this.url && !C) this._delayedOnLoad = F, this._delayedOnError = R;
			else if (this._texture = C ?? this._getFromCache(this.url, v, o, this._invertY, b, this.isCube), !this._texture) {
				if (!k || !k.useDelayedTextureLoading) {
					try {
						this._texture = M.createTexture(this.url, v, this._invertY, k, o, F, R, this._buffer, void 0, this._format, this._forcedExtension, p, m, g, b);
					} catch (e) {
						throw R("error loading", e), e;
					}
					d && (this._buffer = null);
				} else this.delayLoadState = 4, this._delayedOnLoad = F, this._delayedOnError = R;
			} else if (this._texture.isReady) n.SetImmediate(() => F());
			else {
				let e = this._texture.onLoadedObservable.add(F);
				this._texture.onErrorObservable.add((t) => {
					R(t.message, t.exception), this._texture?.onLoadedObservable.remove(e);
				});
			}
		}
		updateURL(e, t = null, n, r) {
			this.url && (this.releaseInternalTexture(), this.getScene().markAllMaterialsAsDirty(1, (e) => e.hasTexture(this))), (!this.name || this.name.startsWith("data:")) && (this.name = e), this.url = e, this._buffer = t, this._forcedExtension = r, this.delayLoadState = 4;
			let i = this._delayedOnLoad, a = () => {
				i ? i() : this.onLoadObservable.hasObservers() && this.onLoadObservable.notifyObservers(this), n && n();
			};
			this._delayedOnLoad = a, this.delayLoad();
		}
		delayLoad() {
			if (this.delayLoadState !== 4) return;
			let e = this.getScene();
			if (!e) return;
			let t = this.url;
			!t && (this.name.indexOf("://") > 0 || this.name.startsWith("data:")) && (t = this.name), this.delayLoadState = 1, this._texture = this._getFromCache(t, this._noMipmap, this.samplingMode, this._invertY, this._useSRGBBuffer, this.isCube), this._texture ? this._delayedOnLoad && (this._texture.isReady ? n.SetImmediate(this._delayedOnLoad) : this._texture.onLoadedObservable.add(this._delayedOnLoad)) : (this._texture = e.getEngine().createTexture(t, this._noMipmap, this._invertY, e, this.samplingMode, this._delayedOnLoad, this._delayedOnError, this._buffer, null, this._format, this._forcedExtension, this._mimeType, this._loaderOptions, this._creationFlags, this._useSRGBBuffer), this._deleteBuffer && (this._buffer = null)), this._delayedOnLoad = null, this._delayedOnError = null;
		}
		_prepareRowForTextureGeneration(e, t, n, r) {
			e *= this._cachedUScale, t *= this._cachedVScale, e -= this.uRotationCenter * this._cachedUScale, t -= this.vRotationCenter * this._cachedVScale, n -= this.wRotationCenter, a.TransformCoordinatesFromFloatsToRef(e, t, n, this._rowGenerationMatrix, r), r.x += this.uRotationCenter * this._cachedUScale + this._cachedUOffset, r.y += this.vRotationCenter * this._cachedVScale + this._cachedVOffset, r.z += this.wRotationCenter;
		}
		getTextureMatrix(e = 1) {
			if (this.uOffset === this._cachedUOffset && this.vOffset === this._cachedVOffset && this.uScale * e === this._cachedUScale && this.vScale === this._cachedVScale && this.uAng === this._cachedUAng && this.vAng === this._cachedVAng && this.wAng === this._cachedWAng && this.uRotationCenter === this._cachedURotationCenter && this.vRotationCenter === this._cachedVRotationCenter && this.wRotationCenter === this._cachedWRotationCenter && this.homogeneousRotationInUVTransform === this._cachedHomogeneousRotationInUVTransform) return this._cachedTextureMatrix;
			this._cachedUOffset = this.uOffset, this._cachedVOffset = this.vOffset, this._cachedUScale = this.uScale * e, this._cachedVScale = this.vScale, this._cachedUAng = this.uAng, this._cachedVAng = this.vAng, this._cachedWAng = this.wAng, this._cachedURotationCenter = this.uRotationCenter, this._cachedVRotationCenter = this.vRotationCenter, this._cachedWRotationCenter = this.wRotationCenter, this._cachedHomogeneousRotationInUVTransform = this.homogeneousRotationInUVTransform, (!this._cachedTextureMatrix || !this._rowGenerationMatrix) && (this._cachedTextureMatrix = r.Zero(), this._rowGenerationMatrix = new r(), this._t0 = a.Zero(), this._t1 = a.Zero(), this._t2 = a.Zero()), r.RotationYawPitchRollToRef(this.vAng, this.uAng, this.wAng, this._rowGenerationMatrix), this.homogeneousRotationInUVTransform ? (r.TranslationToRef(-this._cachedURotationCenter, -this._cachedVRotationCenter, -this._cachedWRotationCenter, i.Matrix[0]), r.TranslationToRef(this._cachedURotationCenter, this._cachedVRotationCenter, this._cachedWRotationCenter, i.Matrix[1]), r.ScalingToRef(this._cachedUScale, this._cachedVScale, 0, i.Matrix[2]), r.TranslationToRef(this._cachedUOffset, this._cachedVOffset, 0, i.Matrix[3]), i.Matrix[0].multiplyToRef(this._rowGenerationMatrix, this._cachedTextureMatrix), this._cachedTextureMatrix.multiplyToRef(i.Matrix[1], this._cachedTextureMatrix), this._cachedTextureMatrix.multiplyToRef(i.Matrix[2], this._cachedTextureMatrix), this._cachedTextureMatrix.multiplyToRef(i.Matrix[3], this._cachedTextureMatrix), this._cachedTextureMatrix.setRowFromFloats(2, this._cachedTextureMatrix.m[12], this._cachedTextureMatrix.m[13], this._cachedTextureMatrix.m[14], 1)) : (this._prepareRowForTextureGeneration(0, 0, 0, this._t0), this._prepareRowForTextureGeneration(1, 0, 0, this._t1), this._prepareRowForTextureGeneration(0, 1, 0, this._t2), this._t1.subtractInPlace(this._t0), this._t2.subtractInPlace(this._t0), r.FromValuesToRef(this._t1.x, this._t1.y, this._t1.z, 0, this._t2.x, this._t2.y, this._t2.z, 0, this._t0.x, this._t0.y, this._t0.z, 0, 0, 0, 0, 1, this._cachedTextureMatrix));
			let t = this.getScene();
			if (!t) return this._cachedTextureMatrix;
			let n = this._cachedIdentity3x2;
			return this._cachedIdentity3x2 = this._cachedTextureMatrix.isIdentityAs3x2(), this.optimizeUVAllocation && n !== this._cachedIdentity3x2 && t.markAllMaterialsAsDirty(1, (e) => e.hasTexture(this)), this._cachedTextureMatrix;
		}
		getReflectionTextureMatrix() {
			let e = this.getScene();
			if (!e) return this._cachedReflectionTextureMatrix;
			if (this.uOffset === this._cachedReflectionUOffset && this.vOffset === this._cachedReflectionVOffset && this.uScale === this._cachedReflectionUScale && this.vScale === this._cachedReflectionVScale && this.coordinatesMode === this._cachedReflectionCoordinatesMode) {
				if (this.coordinatesMode === h.PROJECTION_MODE) {
					if (this._cachedReflectionProjectionMatrixId === e.getProjectionMatrix().updateFlag) return this._cachedReflectionTextureMatrix;
				} else return this._cachedReflectionTextureMatrix;
			}
			this._cachedReflectionTextureMatrix ||= r.Zero(), this._projectionModeMatrix ||= r.Zero();
			let t = this._cachedReflectionCoordinatesMode !== this.coordinatesMode;
			switch (this._cachedReflectionUOffset = this.uOffset, this._cachedReflectionVOffset = this.vOffset, this._cachedReflectionUScale = this.uScale, this._cachedReflectionVScale = this.vScale, this._cachedReflectionCoordinatesMode = this.coordinatesMode, this.coordinatesMode) {
				case h.PLANAR_MODE:
					r.IdentityToRef(this._cachedReflectionTextureMatrix), this._cachedReflectionTextureMatrix[0] = this.uScale, this._cachedReflectionTextureMatrix[5] = this.vScale, this._cachedReflectionTextureMatrix[12] = this.uOffset, this._cachedReflectionTextureMatrix[13] = this.vOffset;
					break;
				case h.PROJECTION_MODE: {
					r.FromValuesToRef(.5, 0, 0, 0, 0, -.5, 0, 0, 0, 0, 0, 0, .5, .5, 1, 1, this._projectionModeMatrix);
					let t = e.getProjectionMatrix();
					this._cachedReflectionProjectionMatrixId = t.updateFlag, t.multiplyToRef(this._projectionModeMatrix, this._cachedReflectionTextureMatrix);
					break;
				}
				default: r.IdentityToRef(this._cachedReflectionTextureMatrix);
			}
			return t && e.markAllMaterialsAsDirty(1, (e) => e.hasTexture(this)), this._cachedReflectionTextureMatrix;
		}
		clone() {
			let e = {
				noMipmap: this._noMipmap,
				invertY: this._invertY,
				samplingMode: this.samplingMode,
				onLoad: void 0,
				onError: void 0,
				buffer: this._texture ? this._texture._buffer : void 0,
				deleteBuffer: this._deleteBuffer,
				format: this.textureFormat,
				mimeType: this.mimeType,
				loaderOptions: this._loaderOptions,
				creationFlags: this._creationFlags,
				useSRGBBuffer: this._useSRGBBuffer
			};
			return f.Clone(() => new h(this._texture ? this._texture.url : null, this.getScene(), e), this);
		}
		serialize() {
			let e = this.name;
			h.SerializeBuffers || this.name.startsWith("data:") && (this.name = ""), this.name.startsWith("data:") && this.url === this.name && (this.url = "");
			let t = super.serialize(h._SerializeInternalTextureUniqueId);
			return t ? ((h.SerializeBuffers || h.ForceSerializeBuffers) && (typeof this._buffer == "string" && this._buffer.startsWith("data:") ? (t.base64String = this._buffer, t.name = t.name.replace("data:", "")) : this.url && this.url.startsWith("data:") && this._buffer instanceof Uint8Array ? t.base64String = `data:${this.mimeType || "image/png"};base64,${m(this._buffer)}` : (h.ForceSerializeBuffers || this.url && this.url.startsWith("blob:") || this._forceSerialize) && (t.base64String = !this._engine || this._engine._features.supportSyncTextureRead ? _(this) : v(this))), t.invertY = this._invertY, t.samplingMode = this.samplingMode, t._creationFlags = this._creationFlags, t._useSRGBBuffer = this._useSRGBBuffer, h._SerializeInternalTextureUniqueId && (t.internalTextureUniqueId = this._texture?.uniqueId), t.internalTextureLabel = this._texture?.label, t.noMipmap = this._noMipmap, this.name = e, t) : null;
		}
		getClassName() {
			return "Texture";
		}
		dispose() {
			super.dispose(), this.onLoadObservable.clear(), this._delayedOnLoad = null, this._delayedOnError = null, this._buffer = null;
		}
		static Parse(e, t, n) {
			if (e.customType) {
				let r = p.Instantiate(e.customType).Parse(e, t, n);
				return e.samplingMode && r.updateSamplingMode && r._samplingMode && r._samplingMode !== e.samplingMode && r.updateSamplingMode(e.samplingMode), r;
			}
			if (e.isCube && !e.isRenderTarget) return h._CubeTextureParser(e, t, n);
			let r = e.internalTextureUniqueId !== void 0;
			if (!e.name && !e.isRenderTarget && !r) return null;
			let i;
			if (r) {
				let n = t.getEngine().getLoadedTexturesCache();
				for (let t of n) if (t.uniqueId === e.internalTextureUniqueId) {
					i = t;
					break;
				}
			}
			let a = (t) => {
				if (t && t._texture && (t._texture._cachedWrapU = null, t._texture._cachedWrapV = null, t._texture._cachedWrapR = null), e.samplingMode) {
					let n = e.samplingMode;
					t && t.samplingMode !== n && t.updateSamplingMode(n);
				}
				if (t && e.animations) for (let n = 0; n < e.animations.length; n++) {
					let r = e.animations[n], i = o("BABYLON.Animation");
					i && t.animations.push(i.Parse(r));
				}
				t && t._texture && (r && !i && t._texture._setUniqueId(e.internalTextureUniqueId), t._texture.label = e.internalTextureLabel);
			};
			return f.Parse(() => {
				let r = !0;
				if (e.noMipmap && (r = !1), e.mirrorPlane) {
					let n = h._CreateMirror(e.name, e.renderTargetSize, t, r);
					return n._waitingRenderList = e.renderList, n.mirrorPlane = s.FromArray(e.mirrorPlane), a(n), n;
				}
				if (e.isRenderTarget && !e.base64String) {
					let n = null;
					if (e.isCube) {
						if (t.reflectionProbes) for (let n = 0; n < t.reflectionProbes.length; n++) {
							let r = t.reflectionProbes[n];
							if (r.name === e.name) return r.cubeTexture;
						}
					} else n = h._CreateRenderTargetTexture(e.name, e.renderTargetSize, t, r, e._creationFlags ?? 0), n._waitingRenderList = e.renderList;
					return a(n), n;
				}
				if (e.isVideo) {
					let i = h._CreateVideoTexture(n + (e.url || e.name), n + (e.src || e.url), t, r, e.invertY, e.samplingMode, e.settings || {});
					return a(i), i;
				}
				{
					let o;
					if (typeof e.base64String == "string" && e.base64String && !i) {
						let n = {
							buffer: e.base64String,
							noMipmap: !r,
							invertY: e.invertY,
							samplingMode: e.samplingMode,
							useSRGBBuffer: e._useSRGBBuffer ?? !1,
							creationFlags: e._creationFlags ?? 0,
							onLoad: () => {
								a(o);
							}
						}, i = e.base64String, s = i.startsWith("data:") ? i.substring(5) : i;
						o = h.CreateFromBase64String("", s, t, n), o.name = e.name;
					} else {
						let s;
						s = e.name && (e.name.indexOf("://") > 0 || e.name.startsWith("data:")) ? e.name : n + e.name, e.url && (e.url.startsWith("data:") || h.UseSerializedUrlIfAny) && (s = e.url);
						let c = {
							noMipmap: !r,
							invertY: e.invertY,
							samplingMode: e.samplingMode,
							useSRGBBuffer: e._useSRGBBuffer ?? !1,
							creationFlags: e._creationFlags ?? 0,
							onLoad: () => {
								a(o);
							},
							internalTexture: i
						};
						o = new h(s, t, c);
					}
					return o;
				}
			}, e, t);
		}
		static CreateFromBase64String(e, t, n, r, i, a = h.TRILINEAR_SAMPLINGMODE, o = null, s = null, c = 5, l, u) {
			return new h("data:" + t, n, r, i, a, o, s, e, !1, c, void 0, void 0, l, u);
		}
		static LoadFromDataString(e, t, n, r = !1, i, a = !0, o = h.TRILINEAR_SAMPLINGMODE, s = null, c = null, l = 5, u, d) {
			return e.substring(0, 5) !== "data:" && (e = "data:" + e), new h(e, n, i, a, o, s, c, t, r, l, void 0, void 0, u, d);
		}
	}, (() => {
		let e = typeof Symbol == "function" && Symbol.metadata ? Object.create(g[Symbol.metadata] ?? null) : void 0;
		b = [l()], C = [l()], E = [l()], k = [l()], M = [l()], F = [l()], R = [l()], V = [l()], W = [l()], q = [l()], X = [l()], $ = [l()], ne = [l()], u(h, null, ne, {
			kind: "getter",
			name: "isBlocking",
			static: !1,
			private: !1,
			access: {
				has: (e) => "isBlocking" in e,
				get: (e) => e.isBlocking
			},
			metadata: e
		}, null, y), u(null, null, b, {
			kind: "field",
			name: "url",
			static: !1,
			private: !1,
			access: {
				has: (e) => "url" in e,
				get: (e) => e.url,
				set: (e, t) => {
					e.url = t;
				}
			},
			metadata: e
		}, x, S), u(null, null, C, {
			kind: "field",
			name: "uOffset",
			static: !1,
			private: !1,
			access: {
				has: (e) => "uOffset" in e,
				get: (e) => e.uOffset,
				set: (e, t) => {
					e.uOffset = t;
				}
			},
			metadata: e
		}, w, T), u(null, null, E, {
			kind: "field",
			name: "vOffset",
			static: !1,
			private: !1,
			access: {
				has: (e) => "vOffset" in e,
				get: (e) => e.vOffset,
				set: (e, t) => {
					e.vOffset = t;
				}
			},
			metadata: e
		}, D, O), u(null, null, k, {
			kind: "field",
			name: "uScale",
			static: !1,
			private: !1,
			access: {
				has: (e) => "uScale" in e,
				get: (e) => e.uScale,
				set: (e, t) => {
					e.uScale = t;
				}
			},
			metadata: e
		}, A, j), u(null, null, M, {
			kind: "field",
			name: "vScale",
			static: !1,
			private: !1,
			access: {
				has: (e) => "vScale" in e,
				get: (e) => e.vScale,
				set: (e, t) => {
					e.vScale = t;
				}
			},
			metadata: e
		}, N, P), u(null, null, F, {
			kind: "field",
			name: "uAng",
			static: !1,
			private: !1,
			access: {
				has: (e) => "uAng" in e,
				get: (e) => e.uAng,
				set: (e, t) => {
					e.uAng = t;
				}
			},
			metadata: e
		}, I, L), u(null, null, R, {
			kind: "field",
			name: "vAng",
			static: !1,
			private: !1,
			access: {
				has: (e) => "vAng" in e,
				get: (e) => e.vAng,
				set: (e, t) => {
					e.vAng = t;
				}
			},
			metadata: e
		}, z, B), u(null, null, V, {
			kind: "field",
			name: "wAng",
			static: !1,
			private: !1,
			access: {
				has: (e) => "wAng" in e,
				get: (e) => e.wAng,
				set: (e, t) => {
					e.wAng = t;
				}
			},
			metadata: e
		}, H, U), u(null, null, W, {
			kind: "field",
			name: "uRotationCenter",
			static: !1,
			private: !1,
			access: {
				has: (e) => "uRotationCenter" in e,
				get: (e) => e.uRotationCenter,
				set: (e, t) => {
					e.uRotationCenter = t;
				}
			},
			metadata: e
		}, G, K), u(null, null, q, {
			kind: "field",
			name: "vRotationCenter",
			static: !1,
			private: !1,
			access: {
				has: (e) => "vRotationCenter" in e,
				get: (e) => e.vRotationCenter,
				set: (e, t) => {
					e.vRotationCenter = t;
				}
			},
			metadata: e
		}, J, Y), u(null, null, X, {
			kind: "field",
			name: "wRotationCenter",
			static: !1,
			private: !1,
			access: {
				has: (e) => "wRotationCenter" in e,
				get: (e) => e.wRotationCenter,
				set: (e, t) => {
					e.wRotationCenter = t;
				}
			},
			metadata: e
		}, Z, Q), u(null, null, $, {
			kind: "field",
			name: "homogeneousRotationInUVTransform",
			static: !1,
			private: !1,
			access: {
				has: (e) => "homogeneousRotationInUVTransform" in e,
				get: (e) => e.homogeneousRotationInUVTransform,
				set: (e, t) => {
					e.homogeneousRotationInUVTransform = t;
				}
			},
			metadata: e
		}, ee, te), e && Object.defineProperty(h, Symbol.metadata, {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: e
		});
	})(), h.SerializeBuffers = !0, h.ForceSerializeBuffers = !1, h.OnTextureLoadErrorObservable = new e(), h._SerializeInternalTextureUniqueId = !1, h._CubeTextureParser = (e, n, r) => {
		throw t("CubeTexture");
	}, h._CreateMirror = (e, n, r, i) => {
		throw t("MirrorTexture");
	}, h._CreateRenderTargetTexture = (e, n, r, i, a) => {
		throw t("RenderTargetTexture");
	}, h.NEAREST_SAMPLINGMODE = 1, h.NEAREST_NEAREST_MIPLINEAR = 8, h.BILINEAR_SAMPLINGMODE = 2, h.LINEAR_LINEAR_MIPNEAREST = 11, h.TRILINEAR_SAMPLINGMODE = 3, h.LINEAR_LINEAR_MIPLINEAR = 3, h.NEAREST_NEAREST_MIPNEAREST = 4, h.NEAREST_LINEAR_MIPNEAREST = 5, h.NEAREST_LINEAR_MIPLINEAR = 6, h.NEAREST_LINEAR = 7, h.NEAREST_NEAREST = 1, h.LINEAR_NEAREST_MIPNEAREST = 9, h.LINEAR_NEAREST_MIPLINEAR = 10, h.LINEAR_LINEAR = 2, h.LINEAR_NEAREST = 12, h.EXPLICIT_MODE = 0, h.SPHERICAL_MODE = 1, h.PLANAR_MODE = 2, h.CUBIC_MODE = 3, h.PROJECTION_MODE = 4, h.SKYBOX_MODE = 5, h.INVCUBIC_MODE = 6, h.EQUIRECTANGULAR_MODE = 7, h.FIXED_EQUIRECTANGULAR_MODE = 8, h.FIXED_EQUIRECTANGULAR_MIRRORED_MODE = 9, h.CLAMP_ADDRESSMODE = 0, h.WRAP_ADDRESSMODE = 1, h.MIRROR_ADDRESSMODE = 2, h.UseSerializedUrlIfAny = !1, h;
})();
//#endregion
export { h as i, _ as n, v as r, y as t };
