import { n as e, t } from "./flowGraphBlock-BTSj91tT.js";
//#region node_modules/@babylonjs/core/FlowGraph/flowGraphSignalConnection.pure.js
var n = class extends e {
	constructor() {
		super(...arguments), this.priority = 0, this._lastActivationTime = -1;
	}
	_isSingularConnection() {
		return !1;
	}
	connectTo(e) {
		super.connectTo(e), this._connectedPoint.sort((e, t) => t.priority - e.priority);
	}
	_activateSignal(e) {
		if (this._lastActivationTime = performance.now(), e.logger?.addLogItem({
			action: "ActivateSignal",
			className: this._ownerBlock.getClassName(),
			uniqueId: this._ownerBlock.uniqueId,
			payload: {
				connectionType: this.connectionType,
				name: this.name
			}
		}), this.connectionType === 0) {
			if (e._shouldBreak(this._ownerBlock, this)) return;
			e._increaseExecutionId(), e._notifyExecuteNode(this._ownerBlock);
			let t = performance.now();
			this._ownerBlock._execute(e, this), this._ownerBlock._lastExecutionTime = performance.now() - t;
		} else for (let t of this._connectedPoint) t._activateSignal(e);
	}
}, r = class extends t {
	constructor(e) {
		super(e), this.priority = 0, this._lastExecutionTime = -1, this.signalInputs = [], this.signalOutputs = [], this.in = this._registerSignalInput("in"), this.error = this._registerSignalOutput("error");
	}
	_registerSignalInput(e) {
		let t = new n(e, 0, this);
		return this.signalInputs.push(t), t;
	}
	_registerSignalOutput(e) {
		let t = new n(e, 1, this);
		return this.signalOutputs.push(t), t;
	}
	_unregisterSignalInput(e) {
		let t = this.signalInputs.findIndex((t) => t.name === e);
		t !== -1 && (this.signalInputs[t].dispose(), this.signalInputs.splice(t, 1));
	}
	_unregisterSignalOutput(e) {
		let t = this.signalOutputs.findIndex((t) => t.name === e);
		t !== -1 && (this.signalOutputs[t].dispose(), this.signalOutputs.splice(t, 1));
	}
	_reportError(e, t) {
		this.error.payload = typeof t == "string" ? Error(t) : t, this.error._activateSignal(e);
	}
	getSignalInput(e) {
		return this.signalInputs.find((t) => t.name === e);
	}
	getSignalOutput(e) {
		return this.signalOutputs.find((t) => t.name === e);
	}
	serialize(e = {}) {
		super.serialize(e), e.signalInputs = [], e.signalOutputs = [];
		for (let t of this.signalInputs) {
			let n = {};
			t.serialize(n), e.signalInputs.push(n);
		}
		for (let t of this.signalOutputs) {
			let n = {};
			t.serialize(n), e.signalOutputs.push(n);
		}
	}
	deserialize(e) {
		for (let t = 0; t < e.signalInputs.length; t++) {
			let n = this.getSignalInput(e.signalInputs[t].name);
			if (n) n.deserialize(e.signalInputs[t]);
			else throw Error("Could not find signal input with name " + e.signalInputs[t].name + " in block " + e.className);
		}
		for (let t = 0; t < e.signalOutputs.length; t++) {
			let n = this.getSignalOutput(e.signalOutputs[t].name);
			if (n) n.deserialize(e.signalOutputs[t]);
			else throw Error("Could not find signal output with name " + e.signalOutputs[t].name + " in block " + e.className);
		}
	}
	getClassName() {
		return "FlowGraphExecutionBlock";
	}
};
//#endregion
export { r as t };
