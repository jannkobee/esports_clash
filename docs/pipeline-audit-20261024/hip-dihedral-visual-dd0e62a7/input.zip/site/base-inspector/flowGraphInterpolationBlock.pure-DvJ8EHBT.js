import { n as e } from "./typeStore-pENEWnX2.js";
import { n as t } from "./animation.pure-D6aX6Q8L.js";
import { t as n } from "./flowGraphBlock-BTSj91tT.js";
import { c as r, g as i, h as a, n as o, u as s } from "./flowGraphRichTypes.pure-BpKU4EZT.js";
//#region node_modules/@babylonjs/core/FlowGraph/Blocks/Execution/Animation/flowGraphInterpolationBlock.pure.js
var c = class extends n {
	constructor(e = {}) {
		super(e), this.keyFrames = [];
		let t = typeof e?.animationType == "string" ? i(e.animationType) : a(e?.animationType ?? 0), n = e?.keyFramesCount ?? 1, c = this.registerDataInput("duration_0", r, 0), l = this.registerDataInput("value_0", t);
		this.keyFrames.push({
			duration: c,
			value: l
		});
		for (let i = 1; i < n + 1; i++) {
			let a = this.registerDataInput(`duration_${i}`, r, i === n ? e.duration : void 0), o = this.registerDataInput(`value_${i}`, t);
			this.keyFrames.push({
				duration: a,
				value: o
			});
		}
		this.initialValue = this.keyFrames[0].value, this.endValue = this.keyFrames[n].value, this.easingFunction = this.registerDataInput("easingFunction", o), this.animation = this.registerDataOutput("animation", o), this.propertyName = this.registerDataInput("propertyName", s, e?.propertyName), this.customBuildAnimation = this.registerDataInput("customBuildAnimation", o);
	}
	_updateOutputs(e) {
		let t = e._getGlobalContextVariable("interpolationAnimations", []), n = this.propertyName.getValue(e), r = this.easingFunction.getValue(e), i = this._createAnimation(e, n, r);
		if (this.animation.setValue(i, e), Array.isArray(i)) for (let e of i) t.push(e.uniqueId);
		else t.push(i.uniqueId);
		e._setGlobalContextVariable("interpolationAnimations", t);
	}
	_createAnimation(e, n, r) {
		let i = this.initialValue.richType, a = [], o = this.initialValue.getValue(e) ?? i.defaultValue;
		a.push({
			frame: 0,
			value: o
		});
		let s = this.config?.numberOfKeyFrames ?? 1;
		for (let t = 1; t < s + 1; t++) {
			let n = this.keyFrames[t].duration?.getValue(e), r = this.keyFrames[t].value?.getValue(e);
			t === s - 1 && (r ??= i.defaultValue), n !== void 0 && r != null && a.push({
				frame: n * 60,
				value: r
			});
		}
		let c = this.customBuildAnimation.getValue(e);
		if (c) return c(null, null, e)(a, 60, i.animationType, r);
		if (typeof n == "string") {
			let e = t(n, i.animationType, 60, r);
			return e.setKeys(a), [e];
		}
		return n.map((e) => {
			let n = t(e, i.animationType, 60, r);
			return n.setKeys(a), n;
		});
	}
	getClassName() {
		return "FlowGraphInterpolationBlock";
	}
}, l = !1;
function u() {
	l || (l = !0, e("FlowGraphInterpolationBlock", c));
}
//#endregion
export { c as FlowGraphInterpolationBlock, u as RegisterFlowGraphInterpolationBlock };
