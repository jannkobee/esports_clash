//#region node_modules/@babylonjs/core/Maths/math.size.js
var e = class e {
	constructor(e, t) {
		this.width = e, this.height = t;
	}
	toString() {
		return `{W: ${this.width}, H: ${this.height}}`;
	}
	getClassName() {
		return "Size";
	}
	getHashCode() {
		let e = this.width | 0;
		return e = e * 397 ^ (this.height | 0), e;
	}
	copyFrom(e) {
		this.width = e.width, this.height = e.height;
	}
	copyFromFloats(e, t) {
		return this.width = e, this.height = t, this;
	}
	set(e, t) {
		return this.copyFromFloats(e, t);
	}
	multiplyByFloats(t, n) {
		return new e(this.width * t, this.height * n);
	}
	clone() {
		return new e(this.width, this.height);
	}
	equals(e) {
		return e ? this.width === e.width && this.height === e.height : !1;
	}
	get surface() {
		return this.width * this.height;
	}
	static Zero() {
		return new e(0, 0);
	}
	add(t) {
		return new e(this.width + t.width, this.height + t.height);
	}
	subtract(t) {
		return new e(this.width - t.width, this.height - t.height);
	}
	scale(t) {
		return new e(this.width * t, this.height * t);
	}
	static Lerp(t, n, r) {
		let i = t.width + (n.width - t.width) * r, a = t.height + (n.height - t.height) * r;
		return new e(i, a);
	}
};
//#endregion
export { e as t };
