import { t as e } from "./flowGraphExecutionBlockWithOutSignal-XngQvXka.js";
//#region node_modules/@babylonjs/core/FlowGraph/flowGraphAsyncExecutionBlock.js
var t = class extends e {
	constructor(e, t) {
		if (super(e), this._eventsSignalOutputs = {}, this.done = this._registerSignalOutput("done"), t) for (let e of t) this._eventsSignalOutputs[e] = this._registerSignalOutput(e + "Event");
	}
	_executeOnTick(e) {}
	_startPendingTasks(e) {
		e._getExecutionVariable(this, "_initialized", !1) && (this._cancelPendingTasks(e), this._resetAfterCanceled(e)), this._preparePendingTasks(e), e._addPendingBlock(this), this.out._activateSignal(e), e._setExecutionVariable(this, "_initialized", !0);
	}
	_resetAfterCanceled(e) {
		e._deleteExecutionVariable(this, "_initialized"), e._removePendingBlock(this);
	}
};
//#endregion
export { t };
