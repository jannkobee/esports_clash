import { n as e } from "./typeStore-pENEWnX2.js";
import { t } from "./flowGraphInteger.pure-DqL1vt3x.js";
import { t as n } from "./flowGraphExecutionBlockWithOutSignal-XngQvXka.js";
import { i as r } from "./flowGraphRichTypes.pure-BpKU4EZT.js";
//#region node_modules/@babylonjs/core/FlowGraph/Blocks/Execution/ControlFlow/flowGraphWaitAllBlock.pure.js
var i = class extends n {
	constructor(e) {
		super(e), this.config = e, this.inFlows = [], this._cachedActivationState = [], this.reset = this._registerSignalInput("reset"), this.completed = this._registerSignalOutput("completed"), this.remainingInputs = this.registerDataOutput("remainingInputs", r, new t(this.config.inputSignalCount || 0));
		for (let e = 0; e < this.config.inputSignalCount; e++) this.inFlows.push(this._registerSignalInput(`in_${e}`));
		this._unregisterSignalInput("in");
	}
	_getCurrentActivationState(e) {
		let t = this._cachedActivationState;
		if (t.length = 0, e._hasExecutionVariable(this, "activationState")) {
			let n = e._getExecutionVariable(this, "activationState", []);
			for (let e = 0; e < n.length; e++) t.push(n[e]);
		} else for (let e = 0; e < this.config.inputSignalCount; e++) t.push(!1);
		return t;
	}
	_execute(e, n) {
		let r = this._getCurrentActivationState(e);
		if (n === this.reset) for (let e = 0; e < this.config.inputSignalCount; e++) r[e] = !1;
		else {
			let e = this.inFlows.indexOf(n);
			e >= 0 && (r[e] = !0);
		}
		if (this.remainingInputs.setValue(new t(r.filter((e) => !e).length), e), e._setExecutionVariable(this, "activationState", r.slice()), r.includes(!1)) n !== this.reset && this.out._activateSignal(e);
		else {
			this.completed._activateSignal(e);
			for (let e = 0; e < this.config.inputSignalCount; e++) r[e] = !1;
		}
	}
	getClassName() {
		return "FlowGraphWaitAllBlock";
	}
	serialize(e) {
		super.serialize(e), e.config.inputFlows = this.config.inputSignalCount;
	}
}, a = !1;
function o() {
	a || (a = !0, e("FlowGraphWaitAllBlock", i));
}
//#endregion
export { i as FlowGraphWaitAllBlock, o as RegisterFlowGraphWaitAllBlock };
