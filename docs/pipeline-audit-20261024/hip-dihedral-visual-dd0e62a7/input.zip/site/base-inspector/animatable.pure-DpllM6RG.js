import { n as e } from "./engineStore-D0BoPdea.js";
import { b as t, o as n } from "./tools.functions-DEecYKlu.js";
import { n as r } from "./scene.pure-B0rulfRT.js";
import { a as i, c as a, m as o, o as s, u as c } from "./math.color.pure-CPmbqLkh.js";
import { t as l } from "./node-DAxRHzT3.js";
import { a as u, c as d, l as f, o as p, s as m, t as h, u as g } from "./animation.pure-D6aX6Q8L.js";
//#region node_modules/@babylonjs/core/Animations/runtimeAnimation.js
var _ = class {
	get currentFrame() {
		return this._currentFrame;
	}
	get _evaluatedFrom() {
		return this._playbackFrom;
	}
	get _evaluatedTo() {
		return this._playbackTo;
	}
	get _evaluatedProgress() {
		return this._playbackProgress;
	}
	get _evaluatedSyncRoot() {
		return this._playbackSyncRoot;
	}
	get _evaluatedJump() {
		return this._playbackJumped;
	}
	get weight() {
		return this._weight;
	}
	get currentValue() {
		return this._currentValue;
	}
	get targetPath() {
		return this._targetPath;
	}
	get target() {
		return this._currentActiveTarget;
	}
	get isAdditive() {
		return this._host && this._host.isAdditive;
	}
	constructor(e, t, n, r) {
		if (this._events = [], this._currentFrame = 0, this._originalValue = [], this._originalBlendValue = null, this._offsetsCache = {}, this._highLimitsCache = {}, this._stopped = !1, this._blendingFactor = 0, this._currentValue = null, this._currentActiveTarget = null, this._directTarget = null, this._targetPath = "", this._weight = 1, this._absoluteFrameOffset = 0, this._previousElapsedTime = 0, this._yoyoDirection = 1, this._previousAbsoluteFrame = 0, this._playbackFrom = 0, this._playbackTo = 0, this._playbackFrames = 0, this._playbackProgress = 0, this._playbackSyncRoot = null, this._playbackJumped = !1, this._playbackSyncMasterPlayed = 0, this._playbackSyncMasterFrame = 0, this._targetIsArray = !1, this._coreRuntimeAnimation = null, this._animation = t, this._target = e, this._scene = n, this._host = r, this._activeTargets = [], t._runtimeAnimations.push(this), this._animationState = {
			key: 0,
			repeatCount: 0,
			loopMode: this._getCorrectLoopMode()
		}, this._animation.dataType === h.ANIMATIONTYPE_MATRIX && (this._animationState.workValue = i.Zero()), this._keys = this._animation.getKeys(), this._minFrame = this._keys[0].frame, this._maxFrame = this._keys[this._keys.length - 1].frame, this._minFrame !== 0) {
			let e = {
				frame: 0,
				value: this._keys[0].value
			};
			this._keys.splice(0, 0, e);
		}
		if (this._target instanceof Array) {
			let e = 0;
			for (let t of this._target) this._preparePath(t, e), this._getOriginalValues(e), e++;
			this._targetIsArray = !0;
		} else this._preparePath(this._target), this._getOriginalValues(), this._targetIsArray = !1, this._directTarget = this._activeTargets[0];
		let a = t.getEvents();
		if (a && a.length > 0) for (let e of a) this._events.push(e._clone());
		this._enableBlending = e && e.animationPropertiesOverride ? e.animationPropertiesOverride.enableBlending : this._animation.enableBlending;
	}
	_preparePath(e, t = 0) {
		let n = this._animation.targetPropertyPath;
		if (n.length > 1) {
			let r = e;
			for (let e = 0; e < n.length - 1; e++) {
				let t = n[e];
				if (r = r[t], r === void 0) throw Error(`Invalid property (${t}) in property path (${n.join(".")})`);
			}
			this._targetPath = n[n.length - 1], this._activeTargets[t] = r;
		} else this._targetPath = n[0], this._activeTargets[t] = e;
		if (this._activeTargets[t][this._targetPath] === void 0) throw Error(`Invalid property (${this._targetPath}) in property path (${n.join(".")})`);
	}
	get animation() {
		return this._animation;
	}
	reset(e = !1) {
		if (e) {
			if (this._target instanceof Array) {
				let e = 0;
				for (let t of this._target) this._originalValue[e] !== void 0 && this._setValue(t, this._activeTargets[e], this._originalValue[e], -1, e), e++;
			} else this._originalValue[0] !== void 0 && this._setValue(this._target, this._directTarget, this._originalValue[0], -1, 0);
		}
		this._offsetsCache = {}, this._highLimitsCache = {}, this._currentFrame = 0, this._blendingFactor = 0;
		for (let e = 0; e < this._events.length; e++) this._events[e].isDone = !1;
	}
	isStopped() {
		return this._stopped;
	}
	dispose() {
		let e = this._animation.runtimeAnimations.indexOf(this);
		e > -1 && this._animation.runtimeAnimations.splice(e, 1);
	}
	setValue(e, t) {
		if (this._targetIsArray) for (let n = 0; n < this._target.length; n++) {
			let r = this._target[n];
			this._setValue(r, this._activeTargets[n], e, t, n);
		}
		else this._setValue(this._target, this._directTarget, e, t, 0);
	}
	_getOriginalValues(e = 0) {
		let t, n = this._activeTargets[e];
		if (h.InheritOriginalValueFromActiveAnimations) {
			let t = this._scene._activeAnimatables;
			for (let r = 0; r < t.length; r++) {
				let i = t[r]._runtimeAnimations;
				for (let t = 0; t < i.length; t++) {
					let r = i[t];
					if (r !== this && r._targetPath === this._targetPath) {
						for (let t = 0; t < r._activeTargets.length; t++) if (r._activeTargets[t] === n && r._originalValue[t] !== void 0) {
							r._originalValue[t] && r._originalValue[t].clone ? this._originalValue[e] = r._originalValue[t].clone() : this._originalValue[e] = r._originalValue[t];
							return;
						}
					}
				}
			}
		}
		t = n.getLocalMatrix && this._targetPath === "_matrix" ? n.getLocalMatrix() : n[this._targetPath], t && t.clone ? this._originalValue[e] = t.clone() : this._originalValue[e] = t;
	}
	_registerTargetForLateAnimationBinding(e, t) {
		let n = e.target;
		this._scene._registeredForLateAnimationBindings.pushNoDuplicate(n), n._lateAnimationHolders ||= {}, n._lateAnimationHolders[e.targetPath] || (n._lateAnimationHolders[e.targetPath] = {
			totalWeight: 0,
			totalAdditiveWeight: 0,
			animations: [],
			additiveAnimations: [],
			originalValue: t
		}), e.isAdditive ? (n._lateAnimationHolders[e.targetPath].additiveAnimations.push(e), n._lateAnimationHolders[e.targetPath].totalAdditiveWeight += e.weight) : (n._lateAnimationHolders[e.targetPath].animations.push(e), n._lateAnimationHolders[e.targetPath].totalWeight += e.weight);
	}
	_setValue(e, t, n, r, a) {
		let o = this._scene._animationWrites, s = this._scene._animationWriteCount++, c = o[s];
		if (c ||= o[s] = {
			runtimeAnimation: this,
			target: e,
			weight: r,
			additive: !1,
			blendingFactor: 1,
			carried: !1
		}, c.runtimeAnimation = this, c.target = e, c.weight = r, c.additive = this.isAdditive, c.carried = !1, this._currentActiveTarget = t, this._weight = r, this._enableBlending && this._blendingFactor <= 1) {
			if (!this._originalBlendValue) {
				let e = t[this._targetPath];
				this._originalBlendValue = e.clone ? e.clone() : e;
			}
			this._originalBlendValue.m ? h.AllowMatrixDecomposeForInterpolation ? this._currentValue ? i.DecomposeLerpToRef(this._originalBlendValue, n, this._blendingFactor, this._currentValue) : this._currentValue = i.DecomposeLerp(this._originalBlendValue, n, this._blendingFactor) : this._currentValue ? i.LerpToRef(this._originalBlendValue, n, this._blendingFactor, this._currentValue) : this._currentValue = i.Lerp(this._originalBlendValue, n, this._blendingFactor) : this._currentValue = h._UniversalLerp(this._originalBlendValue, n, this._blendingFactor);
			let r = e && e.animationPropertiesOverride ? e.animationPropertiesOverride.blendingSpeed : this._animation.blendingSpeed;
			c.blendingFactor = this._blendingFactor, this._blendingFactor += r;
		} else c.blendingFactor = 1, this._currentValue ? this._currentValue.copyFrom ? this._currentValue.copyFrom(n) : this._currentValue = n : this._currentValue = n?.clone ? n.clone() : n;
		r === -1 ? this._animationState.loopMode === h.ANIMATIONLOOPMODE_RELATIVE_FROM_CURRENT ? this._currentValue.addToRef ? this._currentValue.addToRef(this._originalValue[a], t[this._targetPath]) : t[this._targetPath] = this._originalValue[a] + this._currentValue : t[this._targetPath] = this._currentValue : this._registerTargetForLateAnimationBinding(this, this._originalValue[a]), e.markAsDirty && e.markAsDirty(this._animation.targetProperty);
	}
	_getCorrectLoopMode() {
		return this._target && this._target.animationPropertiesOverride ? this._target.getClassName?.() === "MorphTarget" && this._target._animationPropertiesOverride == null ? this._animation.loopMode : this._target.animationPropertiesOverride.loopMode : this._animation.loopMode;
	}
	goToFrame(e, t = -1) {
		let n = this._animation.getKeys();
		e < n[0].frame ? e = n[0].frame : e > n[n.length - 1].frame && (e = n[n.length - 1].frame);
		let r = this._events;
		if (r.length) for (let t = 0; t < r.length; t++) r[t].onlyOnce || (r[t].isDone = r[t].frame < e);
		this._currentFrame = e;
		let i = this._animation._interpolate(e, this._animationState);
		this.setValue(i, t);
	}
	_prepareForSpeedRatioChange(e) {
		let t = this._previousElapsedTime * (this._animation.framePerSecond * e) / 1e3;
		this._absoluteFrameOffset = this._previousAbsoluteFrame - t;
	}
	animate(e, t, n, r, i, a = -1) {
		let o = this._animation, s = o.targetPropertyPath;
		if (!s || s.length < 1) return this._stopped = !0, !1;
		let c = !0, l, _ = this._events, v;
		if (this._coreRuntimeAnimation) v = n - t, l = this._coreRuntimeAnimation.currentFrame, this._currentFrame = l, this._animationState.repeatCount = this._coreRuntimeAnimation._animationState.repeatCount, this._animationState.highLimitValue = this._coreRuntimeAnimation._animationState.highLimitValue, this._animationState.offsetValue = this._coreRuntimeAnimation._animationState.offsetValue, this._playbackFrom = this._coreRuntimeAnimation._playbackFrom, this._playbackTo = this._coreRuntimeAnimation._playbackTo, this._playbackFrames = this._coreRuntimeAnimation._playbackFrames, this._playbackProgress = this._coreRuntimeAnimation._playbackProgress, this._playbackJumped = this._coreRuntimeAnimation._playbackJumped, this._playbackSyncRoot = this._coreRuntimeAnimation._playbackSyncRoot;
		else {
			(t < this._minFrame || t > this._maxFrame) && (t = this._minFrame), (n < this._minFrame || n > this._maxFrame) && (n = this._maxFrame), v = n - t;
			let a, s = e * (o.framePerSecond * i) / 1e3 + this._absoluteFrameOffset, y = 0, b = !1, x = r && this._animationState.loopMode === h.ANIMATIONLOOPMODE_YOYO;
			if (x) {
				let e = (s - t) / v, n = Math.sin(e * Math.PI);
				s = Math.abs(n) * v + t;
				let r = n >= 0 ? 1 : -1;
				this._yoyoDirection !== r && (b = !0), this._yoyoDirection = r;
			}
			if (this._previousElapsedTime = e, this._previousAbsoluteFrame = s, !r && n >= t && (s >= v && i > 0 || s <= 0 && i < 0)) c = !1, y = o.evaluate(n);
			else if (!r && t >= n && (s <= v && i < 0 || s >= 0 && i > 0)) c = !1, y = o.evaluate(t);
			else if (this._animationState.loopMode !== h.ANIMATIONLOOPMODE_CYCLE) {
				let e = n.toString() + t.toString();
				if (!this._offsetsCache[e]) {
					this._animationState.repeatCount = 0, this._animationState.loopMode = h.ANIMATIONLOOPMODE_CYCLE;
					let r = o._interpolate(t, this._animationState), i = o._interpolate(n, this._animationState);
					switch (this._animationState.loopMode = this._getCorrectLoopMode(), o.dataType) {
						case h.ANIMATIONTYPE_FLOAT:
							this._offsetsCache[e] = i - r;
							break;
						case h.ANIMATIONTYPE_QUATERNION:
							this._offsetsCache[e] = i.subtract(r);
							break;
						case h.ANIMATIONTYPE_VECTOR3:
							this._offsetsCache[e] = i.subtract(r);
							break;
						case h.ANIMATIONTYPE_VECTOR2:
							this._offsetsCache[e] = i.subtract(r);
							break;
						case h.ANIMATIONTYPE_SIZE:
							this._offsetsCache[e] = i.subtract(r);
							break;
						case h.ANIMATIONTYPE_COLOR3:
							this._offsetsCache[e] = i.subtract(r);
							break;
						case h.ANIMATIONTYPE_COLOR4: this._offsetsCache[e] = i.subtract(r);
					}
					this._highLimitsCache[e] = i;
				}
				y = this._highLimitsCache[e], a = this._offsetsCache[e];
			}
			if (a === void 0) switch (o.dataType) {
				case h.ANIMATIONTYPE_FLOAT:
					a = 0;
					break;
				case h.ANIMATIONTYPE_QUATERNION:
					a = m;
					break;
				case h.ANIMATIONTYPE_VECTOR3:
					a = g;
					break;
				case h.ANIMATIONTYPE_VECTOR2:
					a = f;
					break;
				case h.ANIMATIONTYPE_SIZE:
					a = d;
					break;
				case h.ANIMATIONTYPE_COLOR3:
					a = u;
					break;
				case h.ANIMATIONTYPE_COLOR4: a = p;
			}
			let S = this._host ? this._host.syncRoot : null, C = this._playbackFrames, w = !1;
			if (S) {
				let e = S.toFrame - S.fromFrame, n = S.masterFrame, r = (n - S.fromFrame) / e;
				l = t + v * r;
				let i = S.getAnimations()[0];
				if (i && e !== 0) {
					let e = v * r, t = i._playbackTo - i._playbackFrom;
					if (t !== 0 && i._playbackFrom <= S.fromFrame && i._playbackTo >= S.toFrame) {
						let n = Math.round((i._playbackFrames - (i._currentFrame - i._playbackFrom)) / t);
						C = v * n + e;
					} else w = (n - this._playbackSyncMasterFrame) * (i._playbackFrames - this._playbackSyncMasterPlayed) < 0, C = e;
					w ||= i._playbackJumped, this._playbackSyncMasterPlayed = i._playbackFrames, this._playbackSyncMasterFrame = n;
				}
			} else l = s > 0 && t > n || s < 0 && t < n ? c && v !== 0 ? n + s % v : t : c && v !== 0 ? t + s % v : n;
			if (!x && (i > 0 && this.currentFrame > l || i < 0 && this.currentFrame < l) || x && b) {
				this._onLoop();
				for (let e = 0; e < _.length; e++) _[e].onlyOnce || (_[e].isDone = !1);
				this._animationState.key = i > 0 ? 0 : o.getKeys().length - 1;
			}
			this._currentFrame = l, this._animationState.repeatCount = v === 0 ? 0 : s / v | 0, this._animationState.highLimitValue = y, this._animationState.offsetValue = a, this._playbackFrom = t, this._playbackTo = n, this._playbackJumped = w, this._playbackSyncRoot = S;
			let T;
			if (S) T = C;
			else if (c) T = x ? l === t && s === n ? v : l - t : s;
			else {
				let e = v === 0 ? 0 : Math.floor(this._playbackFrames / v);
				T = (l === n ? e + 1 : e) * v;
			}
			this._playbackFrames = T, this._playbackProgress = this._animationState.loopMode === h.ANIMATIONLOOPMODE_CONSTANT && this._animationState.repeatCount > 0 ? v : T;
		}
		let y = o._interpolate(l, this._animationState);
		if (this.setValue(y, a), _.length) {
			for (let e = 0; e < _.length; e++) if (v >= 0 && l >= _[e].frame && _[e].frame >= t || v < 0 && l <= _[e].frame && _[e].frame <= t) {
				let t = _[e];
				t.isDone || (t.onlyOnce && (_.splice(e, 1), e--), t.isDone = !0, t.action(l));
			}
		}
		return c || (this._stopped = !0), c;
	}
}, v = class t {
	get syncRoot() {
		return this._syncRoot;
	}
	get masterFrame() {
		return this._runtimeAnimations.length === 0 ? 0 : this._runtimeAnimations[0].currentFrame;
	}
	get weight() {
		return this._weight;
	}
	set weight(e) {
		this._weight = e === -1 ? -1 : Math.min(Math.max(e, 0), 1);
	}
	get speedRatio() {
		return this._speedRatio;
	}
	set speedRatio(e) {
		for (let t = 0; t < this._runtimeAnimations.length; t++) this._runtimeAnimations[t]._prepareForSpeedRatioChange(e);
		this._speedRatio = e, this._goToFrame !== null && this.goToFrame(this._goToFrame);
	}
	get elapsedTime() {
		return this._localDelayOffset === null ? 0 : this._scene._animationTime - this._localDelayOffset;
	}
	constructor(t, n, r = 0, i = 100, a = !1, o = 1, s, c, l, u = !1, d = 0) {
		this.target = n, this.fromFrame = r, this.toFrame = i, this.loopAnimation = a, this.onAnimationEnd = s, this.onAnimationLoop = l, this.isAdditive = u, this.playOrder = d, this._localDelayOffset = null, this._pausedDelay = null, this._manualJumpDelay = null, this._runtimeAnimations = [], this._paused = !1, this._speedRatio = 1, this._weight = -1, this._previousWeight = -1, this._syncRoot = null, this._frameToSyncFromJump = null, this._goToFrame = null, this.disposeOnEnd = !0, this.animationStarted = !1, this.onAnimationEndObservable = new e(), this.onAnimationLoopObservable = new e(), this._scene = t, c && this.appendAnimations(n, c), this._speedRatio = o, t._activeAnimatables.push(this);
	}
	syncWith(e) {
		if (this._syncRoot = e, e) {
			let e = this._scene._activeAnimatables.indexOf(this);
			e > -1 && (this._scene._activeAnimatables.splice(e, 1), this._scene._activeAnimatables.push(this));
		}
		return this;
	}
	getAnimations() {
		return this._runtimeAnimations;
	}
	appendAnimations(e, t) {
		for (let n = 0; n < t.length; n++) {
			let r = t[n], i = new _(e, r, this._scene, this);
			i._onLoop = () => {
				this.onAnimationLoopObservable.notifyObservers(this), this.onAnimationLoop && this.onAnimationLoop();
			}, this._runtimeAnimations.push(i);
		}
	}
	getAnimationByTargetProperty(e) {
		let t = this._runtimeAnimations;
		for (let n = 0; n < t.length; n++) if (t[n].animation.targetProperty === e) return t[n].animation;
		return null;
	}
	getRuntimeAnimationByTargetProperty(e) {
		let t = this._runtimeAnimations;
		for (let n = 0; n < t.length; n++) if (t[n].animation.targetProperty === e) return t[n];
		return null;
	}
	reset() {
		let e = this._runtimeAnimations;
		for (let t = 0; t < e.length; t++) e[t].reset(!0);
		this._localDelayOffset = null, this._pausedDelay = null;
	}
	enableBlending(e) {
		let t = this._runtimeAnimations;
		for (let n = 0; n < t.length; n++) t[n].animation.enableBlending = !0, t[n].animation.blendingSpeed = e;
	}
	disableBlending() {
		let e = this._runtimeAnimations;
		for (let t = 0; t < e.length; t++) e[t].animation.enableBlending = !1;
	}
	goToFrame(e, t = !1) {
		let n = this._runtimeAnimations;
		if (n[0]) {
			let t = n[0].animation.framePerSecond;
			this._frameToSyncFromJump = this._frameToSyncFromJump ?? n[0].currentFrame;
			let r = this.speedRatio === 0 ? 0 : (e - this._frameToSyncFromJump) / t * 1e3 / this.speedRatio;
			this._manualJumpDelay = -r;
		}
		for (let r = 0; r < n.length; r++) n[r].goToFrame(e, t ? this._weight : -1);
		this._goToFrame = e;
	}
	get paused() {
		return this._paused;
	}
	pause() {
		this._paused ||= !0;
	}
	restart() {
		this._paused = !1;
	}
	_raiseOnAnimationEnd() {
		this.onAnimationEnd && this.onAnimationEnd(), this.onAnimationEndObservable.notifyObservers(this);
	}
	stop(e, t, n = !1, r = !1) {
		if (e || t) {
			let i = this._scene._activeAnimatables.indexOf(this);
			if (i > -1) {
				let a = this._runtimeAnimations;
				for (let n = a.length - 1; n >= 0; n--) {
					let r = a[n];
					e && r.animation.name != e || (!t || t(r.target)) && (r.dispose(), a.splice(n, 1));
				}
				a.length == 0 && (n || this._scene._activeAnimatables.splice(i, 1), r || this._raiseOnAnimationEnd());
			}
		} else {
			let e = this._scene._activeAnimatables.indexOf(this);
			if (e > -1) {
				n || this._scene._activeAnimatables.splice(e, 1);
				let t = this._runtimeAnimations;
				for (let e = 0; e < t.length; e++) t[e].dispose();
				this._runtimeAnimations.length = 0, r || this._raiseOnAnimationEnd();
			}
		}
	}
	async waitAsync() {
		return await new Promise((e) => {
			this.onAnimationEndObservable.add(() => {
				e(this);
			}, void 0, void 0, this, !0);
		});
	}
	_animate(e) {
		if (this._paused) return this.animationStarted = !1, this._pausedDelay === null && (this._pausedDelay = e), !0;
		if (this._localDelayOffset === null ? (this._localDelayOffset = e, this._pausedDelay = null) : this._pausedDelay !== null && (this._localDelayOffset += e - this._pausedDelay, this._pausedDelay = null), this._manualJumpDelay !== null && (this._localDelayOffset += this.speedRatio < 0 ? -this._manualJumpDelay : this._manualJumpDelay, this._manualJumpDelay = null, this._frameToSyncFromJump = null), this._goToFrame = null, !t.ProcessPausedAnimatables && this._weight === 0 && this._previousWeight === 0) return !0;
		this._previousWeight = this._weight;
		let n = !1, r = this._runtimeAnimations, i = 0;
		for (; i < r.length; i++) {
			let t = r[i].animate(e - this._localDelayOffset, this.fromFrame, this.toFrame, this.loopAnimation, this._speedRatio, this._weight);
			n ||= t;
		}
		if (this.animationStarted = n, !n) {
			if (this.disposeOnEnd) for (i = this._scene._activeAnimatables.indexOf(this), this._scene._activeAnimatables.splice(i, 1), i = 0; i < r.length; i++) r[i].dispose();
			this._raiseOnAnimationEnd(), this.disposeOnEnd && (this.onAnimationEnd = null, this.onAnimationLoop = null, this.onAnimationLoopObservable.clear(), this.onAnimationEndObservable.clear());
		}
		return n;
	}
};
v.ProcessPausedAnimatables = !1;
function y(e) {
	if (e.totalWeight === 0 && e.totalAdditiveWeight === 0) return e.originalValue;
	let t = 1, n = a.Vector3[0], r = a.Vector3[1], o = a.Quaternion[0], l = 0, u = e.animations[0], d = e.originalValue, f, p = !1;
	if (e.totalWeight < 1) f = 1 - e.totalWeight, d.decompose(r, o, n);
	else {
		if (l = 1, t = e.totalWeight, f = u.weight / t, f == 1) {
			if (e.totalAdditiveWeight) p = !0;
			else return u.currentValue;
		}
		u.currentValue.decompose(r, o, n);
	}
	if (!p) {
		r.scaleInPlace(f), n.scaleInPlace(f), o.scaleInPlace(f);
		for (let i = l; i < e.animations.length; i++) {
			let c = e.animations[i];
			if (c.weight === 0) continue;
			f = c.weight / t;
			let l = a.Vector3[2], u = a.Vector3[3], d = a.Quaternion[1];
			c.currentValue.decompose(u, d, l), u.scaleAndAddToRef(f, r), d.scaleAndAddToRef(s.Dot(o, d) > 0 ? f : -f, o), l.scaleAndAddToRef(f, n);
		}
		o.normalize();
	}
	for (let t = 0; t < e.additiveAnimations.length; t++) {
		let i = e.additiveAnimations[t];
		if (i.weight === 0) continue;
		let l = a.Vector3[2], u = a.Vector3[3], d = a.Quaternion[1];
		i.currentValue.decompose(u, d, l), u.multiplyToRef(r, u), c.LerpToRef(r, u, i.weight, r), o.multiplyToRef(d, d), s.SlerpToRef(o, d, i.weight, o), l.scaleAndAddToRef(i.weight, n);
	}
	let m = u ? u._animationState.workValue : a.Matrix[0].clone();
	return i.ComposeToRef(r, o, n, m), m;
}
function b(e, t) {
	if (e.totalWeight === 0 && e.totalAdditiveWeight === 0) return t;
	let n = e.animations[0], r = e.originalValue, i = t;
	if (e.totalWeight === 0 && e.totalAdditiveWeight > 0) i.copyFrom(r);
	else if (e.animations.length === 1) {
		if (s.SlerpToRef(r, n.currentValue, Math.min(1, e.totalWeight), i), e.totalAdditiveWeight === 0) return i;
	} else if (e.animations.length > 1) {
		let n = 1, a, o;
		if (e.totalWeight < 1) {
			let t = 1 - e.totalWeight;
			a = [], o = [], a.push(r), o.push(t);
		} else {
			if (e.animations.length === 2 && (s.SlerpToRef(e.animations[0].currentValue, e.animations[1].currentValue, e.animations[1].weight / e.totalWeight, t), e.totalAdditiveWeight === 0)) return t;
			a = [], o = [], n = e.totalWeight;
		}
		for (let t = 0; t < e.animations.length; t++) {
			let r = e.animations[t];
			a.push(r.currentValue), o.push(r.weight / n);
		}
		let c = 0;
		for (let e = 0; e < a.length;) e ? (c += o[e], s.SlerpToRef(i, a[e], o[e] / c, i), e++) : (s.SlerpToRef(a[e], a[e + 1], o[e + 1] / (o[e] + o[e + 1]), t), i = t, c = o[e] + o[e + 1], e += 2);
	}
	for (let t = 0; t < e.additiveAnimations.length; t++) {
		let n = e.additiveAnimations[t];
		n.weight !== 0 && (i.multiplyToRef(n.currentValue, a.Quaternion[0]), s.SlerpToRef(i, a.Quaternion[0], n.weight, i));
	}
	return i;
}
function x(e) {
	if (e._registeredForLateAnimationBindings.length) {
		for (let t = 0; t < e._registeredForLateAnimationBindings.length; t++) {
			let n = e._registeredForLateAnimationBindings.data[t];
			for (let e in n._lateAnimationHolders) {
				let t = n._lateAnimationHolders[e], r = t.animations[0], i = t.originalValue;
				if (i == null) continue;
				let a = h.AllowMatrixDecomposeForInterpolation && i.m, o = n[e];
				if (a) o = y(t);
				else if (i.w !== void 0) o = b(t, o || s.Identity());
				else {
					let e = 0, n = 1, a = r && r._animationState.loopMode === h.ANIMATIONLOOPMODE_RELATIVE_FROM_CURRENT;
					if (t.totalWeight < 1) o = a ? i.clone ? i.clone() : i : r && i.scale ? i.scale(1 - t.totalWeight) : r ? i * (1 - t.totalWeight) : i.clone ? i.clone() : i;
					else if (r) {
						n = t.totalWeight;
						let s = r.weight / n;
						o = s === 1 ? (t.animations.length > 1 || t.additiveAnimations.length > 0) && r.currentValue.clone ? r.currentValue.clone() : r.currentValue : r.currentValue.scale ? r.currentValue.scale(s) : r.currentValue * s, a && (o.addToRef ? o.addToRef(i, o) : o += i), e = 1;
					}
					for (let r = e; r < t.animations.length; r++) {
						let e = t.animations[r], i = e.weight / n;
						if (i) e.currentValue.scaleAndAddToRef ? e.currentValue.scaleAndAddToRef(i, o) : o += e.currentValue * i;
						else continue;
					}
					for (let e = 0; e < t.additiveAnimations.length; e++) {
						let n = t.additiveAnimations[e], r = n.weight;
						if (r) n.currentValue.scaleAndAddToRef ? n.currentValue.scaleAndAddToRef(r, o) : o += n.currentValue * r;
						else continue;
					}
				}
				n[e] = o;
			}
			n._lateAnimationHolders = {};
		}
		e._registeredForLateAnimationBindings.reset();
	}
}
function S(e, t) {
	t && (t.prototype.copyAnimationRange = function(e, t, n, r = !1, i = null) {
		this.animations.length === 0 && (this.animations.push(new h(this.name, "_matrix", e.animations[0].framePerSecond, h.ANIMATIONTYPE_MATRIX, 0)), this.animations[0].setKeys([]));
		let a = e.animations[0].getRange(t);
		if (!a) return !1;
		let o = a.from, s = a.to, c = e.animations[0].getKeys(), l = e.length, u = e.getParent(), d = this.getParent(), f = r && u && l && this.length && l !== this.length, p = f && d && u ? d.length / u.length : 1, m = r && !d && i && (i.x !== 1 || i.y !== 1 || i.z !== 1), g = this.animations[0].getKeys(), _, v, y;
		for (let e = 0, t = c.length; e < t; e++) _ = c[e], _.frame >= o && _.frame <= s && (r ? (y = _.value.clone(), f ? (v = y.getTranslation(), y.setTranslation(v.scaleInPlace(p))) : m && i ? (v = y.getTranslation(), y.setTranslation(v.multiplyInPlace(i))) : y = _.value) : y = _.value, g.push({
			frame: _.frame + n,
			value: y
		}));
		return this.animations[0].createRange(t, o + n, s + n), !0;
	}), e && (e.prototype._animate = function(e) {
		let t = this._animationWrites, r = this._animationWriteCount, i = 0;
		for (let e = this._animationStepWriteCount; e < r; e++) {
			let n = t[e];
			n.carried && n.weight === -1 || (n.carried = !0, t[e] = t[i], t[i] = n, i++);
		}
		for (let e = i; e < r; e++) {
			let n = t[e];
			n.runtimeAnimation = null, n.target = null;
		}
		if (this._animationWriteCount = i, this._animationStepWriteCount = 0, this._animationStepEvaluated = !1, !this.animationsEnabled) return;
		let a = n.Now;
		if (!this._animationTimeLast) {
			if (this._pendingData.length > 0) return;
			this._animationTimeLast = a;
		}
		this.deltaTime = e === void 0 ? this.useConstantAnimationDeltaTime ? 16 : (a - this._animationTimeLast) * this.animationTimeScale : e, this._animationTimeLast = a;
		let o = this._activeAnimatables;
		if (o.length === 0) return;
		this._animationTime += this.deltaTime;
		let s = this._animationTime;
		this._animationStepEvaluated = !0;
		for (let e = 0; e < o.length; e++) {
			let t = o[e];
			!t._animate(s) && t.disposeOnEnd && e--;
		}
		x(this), this._animationStepWriteCount = this._animationWriteCount;
	}, e.prototype.sortActiveAnimatables = function() {
		this._activeAnimatables.sort((e, t) => e.playOrder - t.playOrder);
	}, e.prototype.beginWeightedAnimation = function(e, t, n, r = 1, i, a = 1, o, s, c, l, u = !1) {
		let d = this.beginAnimation(e, t, n, i, a, o, s, !1, c, l, u);
		return d.weight = r, d;
	}, e.prototype.beginAnimation = function(e, t, n, r, i = 1, a, o, s = !0, c, l, u = !1) {
		if (i < 0) {
			let e = t;
			t = n, n = e, i = -i;
		}
		t > n && (i = -i), s && this.stopAnimation(e, void 0, c), o ||= new v(this, e, t, n, r, i, a, void 0, l, u);
		let d = !c || c(e);
		if (e.animations && d && o.appendAnimations(e, e.animations), e.getAnimatables) {
			let u = e.getAnimatables();
			for (let e = 0; e < u.length; e++) this.beginAnimation(u[e], t, n, r, i, a, o, s, c, l);
		}
		return o.reset(), o;
	}, e.prototype.beginHierarchyAnimation = function(e, t, n, r, i, a = 1, o, s, c = !0, l, u, d = !1) {
		let f = e.getDescendants(t), p = [];
		p.push(this.beginAnimation(e, n, r, i, a, o, s, c, l, void 0, d));
		for (let e of f) p.push(this.beginAnimation(e, n, r, i, a, o, s, c, l, void 0, d));
		return p;
	}, e.prototype.beginDirectAnimation = function(e, t, n, r, i, a = 1, o, s, c = !1) {
		if (a < 0) {
			let e = n;
			n = r, r = e, a = -a;
		}
		return n > r && (a = -a), new v(this, e, n, r, i, a, o, t, s, c);
	}, e.prototype.beginDirectHierarchyAnimation = function(e, t, n, r, i, a, o, s, c, l = !1) {
		let u = e.getDescendants(t), d = [];
		d.push(this.beginDirectAnimation(e, n, r, i, a, o, s, c, l));
		for (let e of u) d.push(this.beginDirectAnimation(e, n, r, i, a, o, s, c, l));
		return d;
	}, e.prototype.getAnimatableByTarget = function(e) {
		for (let t = 0; t < this._activeAnimatables.length; t++) if (this._activeAnimatables[t].target === e) return this._activeAnimatables[t];
		return null;
	}, e.prototype.getAllAnimatablesByTarget = function(e) {
		let t = [];
		for (let n = 0; n < this._activeAnimatables.length; n++) this._activeAnimatables[n].target === e && t.push(this._activeAnimatables[n]);
		return t;
	}, e.prototype.stopAnimation = function(e, t, n) {
		let r = this.getAllAnimatablesByTarget(e);
		for (let e of r) e.stop(t, n);
	}, e.prototype.stopAllAnimations = function() {
		if (this._activeAnimatables) {
			for (let e = 0; e < this._activeAnimatables.length; e++) this._activeAnimatables[e].stop(void 0, void 0, !0);
			this._activeAnimatables.length = 0;
		}
		for (let e of this.animationGroups) e.stop();
	});
}
//#endregion
//#region node_modules/@babylonjs/core/Bones/bone.pure.js
var C, w = class e extends l {
	get _matrix() {
		return this._compose(), this._localMatrix;
	}
	set _matrix(e) {
		(e.updateFlag !== this._localMatrix.updateFlag || this._needToCompose) && (this._needToCompose = !1, this._localMatrix.copyFrom(e), this._markAsDirtyAndDecompose());
	}
	constructor(e, t, n = null, r = null, a = null, o = null, s = null) {
		super(e, t.getScene(), !1), this.name = e, this.children = [], this.animations = [], this._index = null, this._scalingDeterminant = 1, this._needToDecompose = !0, this._needToCompose = !1, this._linkedTransformNode = null, this._waitingTransformNodeId = null, this._waitingTransformNodeUniqueId = null, this._skeleton = t, this._localMatrix = r?.clone() ?? i.Identity(), this._restMatrix = a ?? this._localMatrix.clone(), this._bindMatrix = o ?? this._localMatrix.clone(), this._index = s, this._absoluteMatrix = new i(), this._absoluteBindMatrix = new i(), this._absoluteInverseBindMatrix = new i(), this._finalMatrix = new i(), t.bones.push(this), this.setParent(n, !1), this._updateAbsoluteBindMatrices();
	}
	getClassName() {
		return "Bone";
	}
	getSkeleton() {
		return this._skeleton;
	}
	get parent() {
		return this._parentNode;
	}
	getParent() {
		return this.parent;
	}
	getChildren() {
		return this.children;
	}
	getIndex() {
		return this._index === null ? this.getSkeleton().bones.indexOf(this) : this._index;
	}
	set parent(e) {
		this.setParent(e);
	}
	setParent(e, t = !0) {
		if (this.parent !== e) {
			if (this.parent) {
				let e = this.parent.children.indexOf(this);
				e !== -1 && this.parent.children.splice(e, 1);
			}
			this._parentNode = e, this.parent && this.parent.children.push(this), t && this._updateAbsoluteBindMatrices(), this.markAsDirty();
		}
	}
	getLocalMatrix() {
		return this._compose(), this._localMatrix;
	}
	getBindMatrix() {
		return this._bindMatrix;
	}
	getBaseMatrix() {
		return this.getBindMatrix();
	}
	getRestMatrix() {
		return this._restMatrix;
	}
	getRestPose() {
		return this.getRestMatrix();
	}
	setRestMatrix(e) {
		this._restMatrix.copyFrom(e);
	}
	setRestPose(e) {
		this.setRestMatrix(e);
	}
	getBindPose() {
		return this.getBindMatrix();
	}
	setBindMatrix(e) {
		this.updateMatrix(e);
	}
	setBindPose(e) {
		this.setBindMatrix(e);
	}
	getFinalMatrix() {
		return this._finalMatrix;
	}
	getWorldMatrix() {
		return this.getFinalMatrix();
	}
	returnToRest() {
		if (this._linkedTransformNode) {
			let e = a.Vector3[0], t = a.Quaternion[0], n = a.Vector3[1];
			this.getRestMatrix().decompose(e, t, n), this._linkedTransformNode.position.copyFrom(n), this._linkedTransformNode.rotationQuaternion = this._linkedTransformNode.rotationQuaternion ?? s.Identity(), this._linkedTransformNode.rotationQuaternion.copyFrom(t), this._linkedTransformNode.scaling.copyFrom(e);
		} else this._matrix = this._restMatrix;
	}
	getAbsoluteInverseBindMatrix() {
		return this._absoluteInverseBindMatrix;
	}
	getInvertedAbsoluteTransform() {
		return this.getAbsoluteInverseBindMatrix();
	}
	getAbsoluteMatrix() {
		return this._skeleton.computeAbsoluteMatrices(), this._absoluteMatrix;
	}
	getAbsoluteTransform() {
		return this.getAbsoluteMatrix();
	}
	linkTransformNode(e) {
		this._linkedTransformNode && this._skeleton._numBonesWithLinkedTransformNode--, this._linkedTransformNode = e, this._linkedTransformNode && this._skeleton._numBonesWithLinkedTransformNode++;
	}
	getTransformNode() {
		return this._linkedTransformNode;
	}
	get position() {
		return this._decompose(), this._localPosition;
	}
	set position(e) {
		this._decompose(), this._localPosition.copyFrom(e), this._markAsDirtyAndCompose();
	}
	get rotation() {
		return this.getRotation();
	}
	set rotation(e) {
		this.setRotation(e);
	}
	get rotationQuaternion() {
		return this._decompose(), this._localRotation;
	}
	set rotationQuaternion(e) {
		this.setRotationQuaternion(e);
	}
	get scaling() {
		return this.getScale();
	}
	set scaling(e) {
		this.setScale(e);
	}
	get animationPropertiesOverride() {
		return this._skeleton.animationPropertiesOverride;
	}
	_decompose() {
		this._needToDecompose && (this._needToDecompose = !1, this._localScaling || (this._localScaling = c.Zero(), this._localRotation = s.Zero(), this._localPosition = c.Zero()), this._localMatrix.decompose(this._localScaling, this._localRotation, this._localPosition));
	}
	_compose() {
		this._needToCompose && (this._localScaling ? (this._needToCompose = !1, i.ComposeToRef(this._localScaling, this._localRotation, this._localPosition, this._localMatrix)) : this._needToCompose = !1);
	}
	updateMatrix(e, t = !0, n = !0) {
		this._bindMatrix.copyFrom(e), t && this._updateAbsoluteBindMatrices(), n ? this._matrix = e : this.markAsDirty();
	}
	_updateAbsoluteBindMatrices(e, t = !0) {
		if (e ||= this._bindMatrix, this.parent ? e.multiplyToRef(this.parent._absoluteBindMatrix, this._absoluteBindMatrix) : this._absoluteBindMatrix.copyFrom(e), this._absoluteBindMatrix.invertToRef(this._absoluteInverseBindMatrix), t) for (let e = 0; e < this.children.length; e++) this.children[e]._updateAbsoluteBindMatrices();
		this._scalingDeterminant = this._absoluteBindMatrix.determinant() < 0 ? -1 : 1;
	}
	markAsDirty() {
		return this._currentRenderId++, this._childUpdateId++, this._skeleton._markAsDirty(), this;
	}
	_markAsDirtyAndCompose() {
		this.markAsDirty(), this._needToCompose = !0;
	}
	_markAsDirtyAndDecompose() {
		this.markAsDirty(), this._needToDecompose = !0;
	}
	_updatePosition(t, n = 0, r, a = !0) {
		let o = this.getLocalMatrix();
		if (n == 0) a ? (o.addAtIndex(12, t.x), o.addAtIndex(13, t.y), o.addAtIndex(14, t.z)) : o.setTranslationFromFloats(t.x, t.y, t.z);
		else {
			let n = e._TmpMats[0], s = e._TmpVecs[0];
			this.parent ? (n.copyFrom(this.parent.getAbsoluteMatrix()), r && n.multiplyToRef(r.getWorldMatrix(), n)) : i.IdentityToRef(n), a && n.setTranslationFromFloats(0, 0, 0), n.invert(), c.TransformCoordinatesToRef(t, n, s), a ? (o.addAtIndex(12, s.x), o.addAtIndex(13, s.y), o.addAtIndex(14, s.z)) : o.setTranslationFromFloats(s.x, s.y, s.z);
		}
		this._markAsDirtyAndDecompose();
	}
	translate(e, t = 0, n) {
		this._updatePosition(e, t, n, !0);
	}
	setPosition(e, t = 0, n) {
		this._updatePosition(e, t, n, !1);
	}
	setAbsolutePosition(e, t) {
		this.setPosition(e, 1, t);
	}
	scale(t, n, r, a = !1) {
		let o = this.getLocalMatrix(), s = e._TmpMats[0];
		i.ScalingToRef(t, n, r, s), s.multiplyToRef(o, o), s.invert();
		for (let e of this.children) {
			let i = e.getLocalMatrix();
			i.multiplyToRef(s, i), i.multiplyAtIndex(12, t), i.multiplyAtIndex(13, n), i.multiplyAtIndex(14, r), e._markAsDirtyAndDecompose();
		}
		if (this._markAsDirtyAndDecompose(), a) for (let e of this.children) e.scale(t, n, r, a);
	}
	setScale(e) {
		this._decompose(), this._localScaling.copyFrom(e), this._markAsDirtyAndCompose();
	}
	getScale() {
		return this._decompose(), this._localScaling;
	}
	getScaleToRef(e) {
		this._decompose(), e.copyFrom(this._localScaling);
	}
	setYawPitchRoll(t, n, r, a = 0, o) {
		if (a === 0) {
			let i = e._TmpQuat;
			s.RotationYawPitchRollToRef(t, n, r, i), this.setRotationQuaternion(i, a, o);
			return;
		}
		let c = e._TmpMats[0];
		if (!this._getAbsoluteInverseMatrixUnscaledToRef(c, o)) return;
		let l = e._TmpMats[1];
		i.RotationYawPitchRollToRef(t, n, r, l), c.multiplyToRef(l, l), this._rotateWithMatrix(l, a, o);
	}
	rotate(t, n, r = 0, a) {
		let o = e._TmpMats[0];
		o.setTranslationFromFloats(0, 0, 0), i.RotationAxisToRef(t, n, o), this._rotateWithMatrix(o, r, a);
	}
	setAxisAngle(t, n, r = 0, a) {
		if (r === 0) {
			let i = e._TmpQuat;
			s.RotationAxisToRef(t, n, i), this.setRotationQuaternion(i, r, a);
			return;
		}
		let o = e._TmpMats[0];
		if (!this._getAbsoluteInverseMatrixUnscaledToRef(o, a)) return;
		let c = e._TmpMats[1];
		i.RotationAxisToRef(t, n, c), o.multiplyToRef(c, c), this._rotateWithMatrix(c, r, a);
	}
	setRotation(e, t = 0, n) {
		this.setYawPitchRoll(e.y, e.x, e.z, t, n);
	}
	setRotationQuaternion(t, n = 0, r) {
		if (n === 0) {
			this._decompose(), this._localRotation.copyFrom(t), this._markAsDirtyAndCompose();
			return;
		}
		let a = e._TmpMats[0];
		if (!this._getAbsoluteInverseMatrixUnscaledToRef(a, r)) return;
		let o = e._TmpMats[1];
		i.FromQuaternionToRef(t, o), a.multiplyToRef(o, o), this._rotateWithMatrix(o, n, r);
	}
	setRotationMatrix(t, n = 0, r) {
		if (n === 0) {
			let i = e._TmpQuat;
			s.FromRotationMatrixToRef(t, i), this.setRotationQuaternion(i, n, r);
			return;
		}
		let i = e._TmpMats[0];
		if (!this._getAbsoluteInverseMatrixUnscaledToRef(i, r)) return;
		let a = e._TmpMats[1];
		a.copyFrom(t), i.multiplyToRef(t, a), this._rotateWithMatrix(a, n, r);
	}
	_rotateWithMatrix(t, n = 0, r) {
		let i = this.getLocalMatrix(), a = i.m[12], o = i.m[13], s = i.m[14], c = this.getParent(), l = e._TmpMats[3], u = e._TmpMats[4];
		c && n == 1 ? (r ? (l.copyFrom(r.getWorldMatrix()), c.getAbsoluteMatrix().multiplyToRef(l, l)) : l.copyFrom(c.getAbsoluteMatrix()), u.copyFrom(l), u.invert(), i.multiplyToRef(l, i), i.multiplyToRef(t, i), i.multiplyToRef(u, i)) : n == 1 && r ? (l.copyFrom(r.getWorldMatrix()), u.copyFrom(l), u.invert(), i.multiplyToRef(l, i), i.multiplyToRef(t, i), i.multiplyToRef(u, i)) : i.multiplyToRef(t, i), i.setTranslationFromFloats(a, o, s), this._markAsDirtyAndDecompose();
	}
	_getAbsoluteInverseMatrixUnscaledToRef(t, n) {
		let r = e._TmpMats[2];
		return t.copyFrom(this.getAbsoluteMatrix()), n ? (t.multiplyToRef(n.getWorldMatrix(), t), i.ScalingToRef(n.scaling.x, n.scaling.y, n.scaling.z, r)) : i.IdentityToRef(r), t.invert(), !isNaN(t.m[0]) && (r.multiplyAtIndex(0, this._scalingDeterminant), t.multiplyToRef(r, t), !0);
	}
	getPosition(e = 0, t = null) {
		let n = c.Zero();
		return this.getPositionToRef(e, t, n), n;
	}
	getPositionToRef(t = 0, n, r) {
		if (t == 0) {
			let e = this.getLocalMatrix();
			r.x = e.m[12], r.y = e.m[13], r.z = e.m[14];
		} else {
			let t = e._TmpMats[0].copyFrom(this.getAbsoluteMatrix());
			n && t.multiplyToRef(n.getWorldMatrix(), t), r.x = t.m[12], r.y = t.m[13], r.z = t.m[14];
		}
	}
	getAbsolutePosition(e = null) {
		let t = c.Zero();
		return this.getPositionToRef(1, e, t), t;
	}
	getAbsolutePositionToRef(e, t) {
		this.getPositionToRef(1, e, t);
	}
	computeAbsoluteMatrices() {
		if (this._compose(), this.parent) this._localMatrix.multiplyToRef(this.parent._absoluteMatrix, this._absoluteMatrix);
		else {
			this._absoluteMatrix.copyFrom(this._localMatrix);
			let e = this._skeleton.getPoseMatrix();
			e && this._absoluteMatrix.multiplyToRef(e, this._absoluteMatrix);
		}
		let e = this.children, t = e.length;
		for (let n = 0; n < t; n++) e[n].computeAbsoluteMatrices();
	}
	computeAbsoluteTransforms() {
		this.computeAbsoluteMatrices();
	}
	getDirection(e, t = null) {
		let n = c.Zero();
		return this.getDirectionToRef(e, t, n), n;
	}
	getDirectionToRef(t, n = null, r) {
		let i = e._TmpMats[0].copyFrom(this.getAbsoluteMatrix());
		n && i.multiplyToRef(n.getWorldMatrix(), i), c.TransformNormalToRef(t, i, r), r.normalize();
	}
	getRotation(e = 0, t = null) {
		let n = c.Zero();
		return this.getRotationToRef(e, t, n), n;
	}
	getRotationToRef(t = 0, n = null, r) {
		let i = e._TmpQuat;
		this.getRotationQuaternionToRef(t, n, i), i.toEulerAnglesToRef(r);
	}
	getRotationQuaternion(e = 0, t = null) {
		let n = s.Identity();
		return this.getRotationQuaternionToRef(e, t, n), n;
	}
	getRotationQuaternionToRef(t = 0, n = null, r) {
		if (t == 0) this._decompose(), r.copyFrom(this._localRotation);
		else {
			let t = e._TmpMats[0], i = this.getAbsoluteMatrix();
			n ? i.multiplyToRef(n.getWorldMatrix(), t) : t.copyFrom(i), t.multiplyAtIndex(0, this._scalingDeterminant), t.multiplyAtIndex(1, this._scalingDeterminant), t.multiplyAtIndex(2, this._scalingDeterminant), t.decompose(void 0, r, void 0);
		}
	}
	getRotationMatrix(e = 0, t) {
		let n = i.Identity();
		return this.getRotationMatrixToRef(e, t, n), n;
	}
	getRotationMatrixToRef(t = 0, n, r) {
		if (t == 0) this.getLocalMatrix().getRotationMatrixToRef(r);
		else {
			let t = e._TmpMats[0], i = this.getAbsoluteMatrix();
			n ? i.multiplyToRef(n.getWorldMatrix(), t) : t.copyFrom(i), t.multiplyAtIndex(0, this._scalingDeterminant), t.multiplyAtIndex(1, this._scalingDeterminant), t.multiplyAtIndex(2, this._scalingDeterminant), t.getRotationMatrixToRef(r);
		}
	}
	getAbsolutePositionFromLocal(e, t = null) {
		let n = c.Zero();
		return this.getAbsolutePositionFromLocalToRef(e, t, n), n;
	}
	getAbsolutePositionFromLocalToRef(t, n = null, r) {
		let i = e._TmpMats[0].copyFrom(this.getAbsoluteMatrix());
		n && i.multiplyToRef(n.getWorldMatrix(), i), c.TransformCoordinatesToRef(t, i, r);
	}
	getLocalPositionFromAbsolute(e, t = null) {
		let n = c.Zero();
		return this.getLocalPositionFromAbsoluteToRef(e, t, n), n;
	}
	getLocalPositionFromAbsoluteToRef(t, n = null, r) {
		let i = e._TmpMats[0].copyFrom(this.getAbsoluteMatrix());
		n && i.multiplyToRef(n.getWorldMatrix(), i), i.invert(), c.TransformCoordinatesToRef(t, i, r);
	}
	setCurrentPoseAsRest() {
		this.setRestMatrix(this.getLocalMatrix());
	}
	dispose() {
		this._linkedTransformNode = null;
		let e = this._skeleton.bones.indexOf(this);
		if (e !== -1 && this._skeleton.bones.splice(e, 1), this._parentNode && this._parentNode.children) {
			let e = this._parentNode.children, t = e.indexOf(this);
			t !== -1 && e.splice(t, 1);
		}
		super.dispose();
	}
};
w._TmpVecs = /*#__PURE__*/ o(2, c.Zero), w._TmpQuat = /*#__PURE__*/ s.Identity(), w._TmpMats = /*#__PURE__*/ o(5, i.Identity), (C = w.prototype).copyAnimationRange ?? (C.copyAnimationRange = t("Bone", "copyAnimationRange"));
//#endregion
//#region node_modules/@babylonjs/core/Animations/animatable.pure.js
var T = !1;
function E() {
	T || (T = !0, S(r, w));
}
//#endregion
export { w as n, E as t };
