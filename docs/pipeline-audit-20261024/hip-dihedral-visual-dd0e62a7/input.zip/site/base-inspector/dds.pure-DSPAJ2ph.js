import { t as e } from "./math.scalar.functions-D7lyzZPV.js";
import { t } from "./logger-DQIzSR_y.js";
import { r as n, t as r } from "./halfFloat-CieD0yV9.js";
import { t as i } from "./cubemapToSphericalPolynomial-Df-crXSp.js";
//#region node_modules/@babylonjs/core/Misc/dds.pure.js
var a = 542327876, o = 131072, s = 512, c = 4, l = 64, u = 131072;
function d(e) {
	return e.charCodeAt(0) + (e.charCodeAt(1) << 8) + (e.charCodeAt(2) << 16) + (e.charCodeAt(3) << 24);
}
function f(e) {
	return String.fromCharCode(e & 255, e >> 8 & 255, e >> 16 & 255, e >> 24 & 255);
}
var p = /*#__PURE__*/ d("DXT1"), m = /*#__PURE__*/ d("DXT3"), h = /*#__PURE__*/ d("DXT5"), g = /*#__PURE__*/ d("DX10"), _ = 113, v = 116, y = 2, b = 10, x = 88, S = 31, ee = 0, te = 1, C = 2, w = 3, T = 4, E = 7, D = 20, O = 21, k = 22, A = 23, j = 24, M = 25, N = 26, P = 28, F = 32, I = class d {
	static GetDDSInfo(e) {
		let t = new Int32Array(e.buffer, e.byteOffset, S), n = new Int32Array(e.buffer, e.byteOffset, 35), r = 1;
		t[C] & o && (r = Math.max(1, t[E]));
		let i = t[O], a = i === g ? n[F] : 0, d = 0;
		switch (i) {
			case _:
				d = 2;
				break;
			case v:
				d = 1;
				break;
			case g:
				if (a === b) {
					d = 2;
					break;
				}
				if (a === y) {
					d = 1;
					break;
				}
		}
		return {
			width: t[T],
			height: t[w],
			mipmapCount: r,
			isFourCC: (t[D] & c) === c,
			isRGB: (t[D] & l) === l,
			isLuminance: (t[D] & u) === u,
			isCube: (t[P] & s) === s,
			isCompressed: i === p || i === m || i === h,
			dxgiFormat: a,
			textureType: d
		};
	}
	static _GetHalfFloatAsFloatRGBAArrayBuffer(e, t, n, i, a, o) {
		let s = new Float32Array(i), c = new Uint16Array(a, n), l = 0;
		for (let n = 0; n < t; n++) for (let t = 0; t < e; t++) {
			let i = (t + n * e) * 4;
			s[l] = r(c[i]), s[l + 1] = r(c[i + 1]), s[l + 2] = r(c[i + 2]), d.StoreLODInAlphaChannel ? s[l + 3] = o : s[l + 3] = r(c[i + 3]), l += 4;
		}
		return s;
	}
	static _GetHalfFloatRGBAArrayBuffer(e, t, r, i, a, o) {
		if (d.StoreLODInAlphaChannel) {
			let s = new Uint16Array(i), c = new Uint16Array(a, r), l = 0;
			for (let r = 0; r < t; r++) for (let t = 0; t < e; t++) {
				let i = (t + r * e) * 4;
				s[l] = c[i], s[l + 1] = c[i + 1], s[l + 2] = c[i + 2], s[l + 3] = n(o), l += 4;
			}
			return s;
		}
		return new Uint16Array(a, r, i);
	}
	static _GetFloatRGBAArrayBuffer(e, t, n, r, i, a) {
		if (d.StoreLODInAlphaChannel) {
			let o = new Float32Array(r), s = new Float32Array(i, n), c = 0;
			for (let n = 0; n < t; n++) for (let t = 0; t < e; t++) {
				let r = (t + n * e) * 4;
				o[c] = s[r], o[c + 1] = s[r + 1], o[c + 2] = s[r + 2], o[c + 3] = a, c += 4;
			}
			return o;
		}
		return new Float32Array(i, n, r);
	}
	static _GetFloatAsHalfFloatRGBAArrayBuffer(e, t, r, i, a, o) {
		let s = new Uint16Array(i), c = new Float32Array(a, r), l = 0;
		for (let r = 0; r < t; r++) for (let t = 0; t < e; t++) s[l] = n(c[l]), s[l + 1] = n(c[l + 1]), s[l + 2] = n(c[l + 2]), d.StoreLODInAlphaChannel ? s[l + 3] = n(o) : s[l + 3] = n(c[l + 3]), l += 4;
		return s;
	}
	static _GetFloatAsUIntRGBAArrayBuffer(t, n, r, i, a, o) {
		let s = new Uint8Array(i), c = new Float32Array(a, r), l = 0;
		for (let r = 0; r < n; r++) for (let n = 0; n < t; n++) {
			let i = (n + r * t) * 4;
			s[l] = e(c[i]) * 255, s[l + 1] = e(c[i + 1]) * 255, s[l + 2] = e(c[i + 2]) * 255, d.StoreLODInAlphaChannel ? s[l + 3] = o : s[l + 3] = e(c[i + 3]) * 255, l += 4;
		}
		return s;
	}
	static _GetHalfFloatAsUIntRGBAArrayBuffer(t, n, i, a, o, s) {
		let c = new Uint8Array(a), l = new Uint16Array(o, i), u = 0;
		for (let i = 0; i < n; i++) for (let n = 0; n < t; n++) {
			let a = (n + i * t) * 4;
			c[u] = e(r(l[a])) * 255, c[u + 1] = e(r(l[a + 1])) * 255, c[u + 2] = e(r(l[a + 2])) * 255, d.StoreLODInAlphaChannel ? c[u + 3] = s : c[u + 3] = e(r(l[a + 3])) * 255, u += 4;
		}
		return c;
	}
	static _GetRGBAArrayBuffer(e, t, n, r, i, a, o, s, c) {
		let l = new Uint8Array(r), u = new Uint8Array(i, n), d = 0;
		for (let n = 0; n < t; n++) for (let t = 0; t < e; t++) {
			let r = (t + n * e) * 4;
			l[d] = u[r + a], l[d + 1] = u[r + o], l[d + 2] = u[r + s], l[d + 3] = u[r + c], d += 4;
		}
		return l;
	}
	static _ExtractLongWordOrder(e) {
		return e === 0 || e === 255 || e === -16777216 ? 0 : 1 + d._ExtractLongWordOrder(e >> 8);
	}
	static _GetRGBArrayBuffer(e, t, n, r, i, a, o, s) {
		let c = new Uint8Array(r), l = new Uint8Array(i, n), u = 0;
		for (let n = 0; n < t; n++) for (let t = 0; t < e; t++) {
			let r = (t + n * e) * 3;
			c[u] = l[r + a], c[u + 1] = l[r + o], c[u + 2] = l[r + s], u += 3;
		}
		return c;
	}
	static _GetLuminanceArrayBuffer(e, t, n, r, i) {
		let a = new Uint8Array(r), o = new Uint8Array(i, n), s = 0;
		for (let n = 0; n < t; n++) for (let t = 0; t < e; t++) {
			let r = t + n * e;
			a[s] = o[r], s++;
		}
		return a;
	}
	static UploadDDSLevels(e, n, r, s, c, l, u = -1, D, P = !0) {
		let F = null;
		s.sphericalPolynomial && (F = []);
		let I = !!e.getCaps().s3tc;
		n.generateMipMaps = c;
		let L = new Int32Array(r.buffer, r.byteOffset, S), R, z, B, V = 0, H, U, W, G, K = 0, q = 1;
		if (L[ee] !== a) {
			t.Error("Invalid magic number in DDS header");
			return;
		}
		if (!s.isFourCC && !s.isRGB && !s.isLuminance) {
			t.Error("Unsupported format, must contain a FourCC, RGB or LUMINANCE code");
			return;
		}
		if (s.isCompressed && !I) {
			t.Error("Compressed textures are not supported on this platform.");
			return;
		}
		let J = L[k];
		H = L[te] + 4;
		let Y = !1;
		if (s.isFourCC) switch (R = L[O], R) {
			case p:
				q = 8, K = 33777;
				break;
			case m:
				q = 16, K = 33778;
				break;
			case h:
				q = 16, K = 33779;
				break;
			case _:
				Y = !0, J = 64;
				break;
			case v:
				Y = !0, J = 128;
				break;
			case g: {
				H += 20;
				let e = !1;
				switch (s.dxgiFormat) {
					case b:
						Y = !0, J = 64, e = !0;
						break;
					case y:
						Y = !0, J = 128, e = !0;
						break;
					case x: s.isRGB = !0, s.isFourCC = !1, J = 32, e = !0;
				}
				if (e) break;
			}
			default:
				t.Error(["Unsupported FourCC code:", f(R)]);
				return;
		}
		let X = d._ExtractLongWordOrder(L[A]), Z = d._ExtractLongWordOrder(L[j]), Q = d._ExtractLongWordOrder(L[M]), ne = d._ExtractLongWordOrder(L[N]);
		Y && (K = e._getRGBABufferInternalSizedFormat(s.textureType)), W = 1, L[C] & o && c !== !1 && (W = Math.max(1, L[E]));
		let re = D || 0, $ = e.getCaps();
		for (let t = re; t < l; t++) {
			for (z = L[T], B = L[w], G = 0; G < W; ++G) {
				if (u === -1 || u === G) {
					let i = u === -1 ? G : 0;
					if (!s.isCompressed && s.isFourCC) {
						n.format = 5, V = z * B * 4;
						let a = null;
						if (e._badOS || e._badDesktopOS || !$.textureHalfFloat && !$.textureFloat) J === 128 ? (a = d._GetFloatAsUIntRGBAArrayBuffer(z, B, r.byteOffset + H, V, r.buffer, i), F && i == 0 && F.push(d._GetFloatRGBAArrayBuffer(z, B, r.byteOffset + H, V, r.buffer, i))) : J === 64 && (a = d._GetHalfFloatAsUIntRGBAArrayBuffer(z, B, r.byteOffset + H, V, r.buffer, i), F && i == 0 && F.push(d._GetHalfFloatAsFloatRGBAArrayBuffer(z, B, r.byteOffset + H, V, r.buffer, i))), n.type = 0;
						else {
							let e = $.textureFloat && (P && $.textureFloatLinearFiltering || !P), t = $.textureHalfFloat && (P && $.textureHalfFloatLinearFiltering || !P), o = (J === 128 || J === 64 && !t) && e ? 1 : (J === 64 || J === 128 && !e) && t ? 2 : 0, s, c = null;
							switch (J) {
								case 128:
									switch (o) {
										case 1:
											s = d._GetFloatRGBAArrayBuffer, c = null;
											break;
										case 2:
											s = d._GetFloatAsHalfFloatRGBAArrayBuffer, c = d._GetFloatRGBAArrayBuffer;
											break;
										case 0: s = d._GetFloatAsUIntRGBAArrayBuffer, c = d._GetFloatRGBAArrayBuffer;
									}
									break;
								default: switch (o) {
									case 1:
										s = d._GetHalfFloatAsFloatRGBAArrayBuffer, c = null;
										break;
									case 2:
										s = d._GetHalfFloatRGBAArrayBuffer, c = d._GetHalfFloatAsFloatRGBAArrayBuffer;
										break;
									case 0: s = d._GetHalfFloatAsUIntRGBAArrayBuffer, c = d._GetHalfFloatAsFloatRGBAArrayBuffer;
								}
							}
							n.type = o, a = s(z, B, r.byteOffset + H, V, r.buffer, i), F && i == 0 && F.push(c ? c(z, B, r.byteOffset + H, V, r.buffer, i) : a);
						}
						a && e._uploadDataToTextureDirectly(n, a, t, i);
					} else if (s.isRGB) n.type = 0, J === 24 ? (n.format = 4, V = z * B * 3, U = d._GetRGBArrayBuffer(z, B, r.byteOffset + H, V, r.buffer, X, Z, Q), e._uploadDataToTextureDirectly(n, U, t, i)) : (n.format = 5, V = z * B * 4, U = d._GetRGBAArrayBuffer(z, B, r.byteOffset + H, V, r.buffer, X, Z, Q, ne), e._uploadDataToTextureDirectly(n, U, t, i));
					else if (s.isLuminance) {
						let a = e._getUnpackAlignement(), o = z;
						V = Math.floor((z + a - 1) / a) * a * (B - 1) + o, U = d._GetLuminanceArrayBuffer(z, B, r.byteOffset + H, V, r.buffer), n.format = 1, n.type = 0, e._uploadDataToTextureDirectly(n, U, t, i);
					} else V = Math.max(4, z) / 4 * Math.max(4, B) / 4 * q, U = new Uint8Array(r.buffer, r.byteOffset + H, V), n.type = 0, e._uploadCompressedDataToTextureDirectly(n, K, z, B, U, t, i);
				}
				H += J ? z * B * (J / 8) : V, z *= .5, B *= .5, z = Math.max(1, z), B = Math.max(1, B);
			}
			if (D !== void 0) break;
		}
		s.sphericalPolynomial = F && F.length > 0 ? i.ConvertCubeMapToSphericalPolynomial({
			size: L[T],
			right: F[0],
			left: F[1],
			up: F[2],
			down: F[3],
			front: F[4],
			back: F[5],
			format: 5,
			type: 1,
			gammaSpace: !1
		}) : void 0;
	}
};
I.StoreLODInAlphaChannel = !1;
//#endregion
export { I as DDSTools };
