import { a as e, u as t } from "./math.color.pure-CPmbqLkh.js";
//#region node_modules/@babylonjs/core/Maths/math.plane.js
var n = class e {
	constructor(e, n, r, i) {
		this.normal = new t(e, n, r), this.d = i;
	}
	asArray() {
		return [
			this.normal.x,
			this.normal.y,
			this.normal.z,
			this.d
		];
	}
	clone() {
		return new e(this.normal.x, this.normal.y, this.normal.z, this.d);
	}
	getClassName() {
		return "Plane";
	}
	getHashCode() {
		let e = this.normal.getHashCode();
		return e = e * 397 ^ (this.d | 0), e;
	}
	normalize() {
		let e = Math.sqrt(this.normal.x * this.normal.x + this.normal.y * this.normal.y + this.normal.z * this.normal.z), t = 0;
		return e !== 0 && (t = 1 / e), this.normal.x *= t, this.normal.y *= t, this.normal.z *= t, this.d *= t, this;
	}
	transform(t) {
		let n = e._TmpMatrix;
		t.invertToRef(n);
		let r = n.m, i = this.normal.x, a = this.normal.y, o = this.normal.z, s = this.d, c = i * r[0] + a * r[1] + o * r[2] + s * r[3], l = i * r[4] + a * r[5] + o * r[6] + s * r[7], u = i * r[8] + a * r[9] + o * r[10] + s * r[11], d = i * r[12] + a * r[13] + o * r[14] + s * r[15];
		return new e(c, l, u, d);
	}
	dotCoordinate(e) {
		return this.normal.x * e.x + this.normal.y * e.y + this.normal.z * e.z + this.d;
	}
	copyFromPoints(e, t, n) {
		let r = t.x - e.x, i = t.y - e.y, a = t.z - e.z, o = n.x - e.x, s = n.y - e.y, c = n.z - e.z, l = i * c - a * s, u = a * o - r * c, d = r * s - i * o, f = Math.sqrt(l * l + u * u + d * d), p;
		return p = f === 0 ? 0 : 1 / f, this.normal.x = l * p, this.normal.y = u * p, this.normal.z = d * p, this.d = -(this.normal.x * e.x + this.normal.y * e.y + this.normal.z * e.z), this;
	}
	isFrontFacingTo(e, n) {
		return t.Dot(this.normal, e) <= n;
	}
	signedDistanceTo(e) {
		return t.Dot(e, this.normal) + this.d;
	}
	static FromArray(t) {
		return new e(t[0], t[1], t[2], t[3]);
	}
	static FromPoints(t, n, r) {
		let i = new e(0, 0, 0, 0);
		return i.copyFromPoints(t, n, r), i;
	}
	static FromPositionAndNormal(t, n) {
		let r = new e(0, 0, 0, 0);
		return this.FromPositionAndNormalToRef(t, n, r);
	}
	static FromPositionAndNormalToRef(e, t, n) {
		return n.normal.copyFrom(t), n.normal.normalize(), n.d = -e.dot(n.normal), n;
	}
	static SignedDistanceToPlaneFromPositionAndNormal(e, n, r) {
		let i = -(n.x * e.x + n.y * e.y + n.z * e.z);
		return t.Dot(r, n) + i;
	}
};
n._TmpMatrix = e.Identity();
//#endregion
export { n as t };
