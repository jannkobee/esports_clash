import { n as e } from "./typeStore-pENEWnX2.js";
import { t } from "./flowGraphInteger.pure-DqL1vt3x.js";
import { t as n } from "./flowGraphExecutionBlockWithOutSignal-XngQvXka.js";
import { i as r } from "./flowGraphRichTypes.pure-BpKU4EZT.js";
//#region node_modules/@babylonjs/core/FlowGraph/Blocks/Execution/ControlFlow/flowGraphDoNBlock.pure.js
var i = class extends n {
	constructor(e = {}) {
		super(e), this.config = e, this.config.startIndex = e.startIndex ?? new t(0), this.reset = this._registerSignalInput("reset"), this.maxExecutions = this.registerDataInput("maxExecutions", r), this.executionCount = this.registerDataOutput("executionCount", r, new t(0));
	}
	_execute(e, n) {
		if (n === this.reset) this.executionCount.setValue(this.config.startIndex, e);
		else {
			let n = this.executionCount.getValue(e);
			n.value < this.maxExecutions.getValue(e).value && (this.executionCount.setValue(new t(n.value + 1), e), this.out._activateSignal(e));
		}
	}
	getClassName() {
		return "FlowGraphDoNBlock";
	}
}, a = !1;
function o() {
	a || (a = !0, e("FlowGraphDoNBlock", i));
}
//#endregion
export { i as FlowGraphDoNBlock, o as RegisterFlowGraphDoNBlock };
