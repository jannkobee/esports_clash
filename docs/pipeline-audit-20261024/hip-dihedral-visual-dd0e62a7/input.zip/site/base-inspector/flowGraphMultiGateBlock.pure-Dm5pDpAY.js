import { n as e } from "./typeStore-pENEWnX2.js";
import { t } from "./flowGraphInteger.pure-DqL1vt3x.js";
import { t as n } from "./flowGraphExecutionBlock-CX4ysaWA.js";
import { i as r } from "./flowGraphRichTypes.pure-BpKU4EZT.js";
//#region node_modules/@babylonjs/core/FlowGraph/Blocks/Execution/ControlFlow/flowGraphMultiGateBlock.pure.js
var i = class extends n {
	constructor(e) {
		super(e), this.config = e, this.outputSignals = [], this.reset = this._registerSignalInput("reset"), this.lastIndex = this.registerDataOutput("lastIndex", r, new t(-1)), this.setNumberOfOutputSignals(e?.outputSignalCount);
	}
	_getNextIndex(e) {
		if (e.includes(!1) || this.config.isLoop && e.fill(!1), this.config.isRandom) {
			let t = e.map((e, t) => e ? -1 : t).filter((e) => e !== -1);
			return t.length ? t[Math.floor(Math.random() * t.length)] : -1;
		}
		return e.indexOf(!1);
	}
	setNumberOfOutputSignals(e = 1) {
		for (; this.outputSignals.length > e;) {
			let e = this.outputSignals.pop();
			e && (e.disconnectFromAll(), this._unregisterSignalOutput(e.name));
		}
		for (; this.outputSignals.length < e;) this.outputSignals.push(this._registerSignalOutput(`out_${this.outputSignals.length}`));
	}
	_execute(e, n) {
		if (e._hasExecutionVariable(this, "indexesUsed") || e._setExecutionVariable(this, "indexesUsed", this.outputSignals.map(() => !1)), n === this.reset) {
			e._deleteExecutionVariable(this, "indexesUsed"), this.lastIndex.setValue(new t(-1), e);
			return;
		}
		let r = e._getExecutionVariable(this, "indexesUsed", []), i = this._getNextIndex(r);
		i > -1 && (this.lastIndex.setValue(new t(i), e), r[i] = !0, e._setExecutionVariable(this, "indexesUsed", r), this.outputSignals[i]._activateSignal(e));
	}
	getClassName() {
		return "FlowGraphMultiGateBlock";
	}
	serialize(e) {
		super.serialize(e), e.config.outputSignalCount = this.config.outputSignalCount, e.config.isRandom = this.config.isRandom, e.config.loop = this.config.isLoop, e.config.startIndex = this.config.startIndex;
	}
}, a = !1;
function o() {
	a || (a = !0, e("FlowGraphMultiGateBlock", i));
}
//#endregion
export { i as FlowGraphMultiGateBlock, o as RegisterFlowGraphMultiGateBlock };
