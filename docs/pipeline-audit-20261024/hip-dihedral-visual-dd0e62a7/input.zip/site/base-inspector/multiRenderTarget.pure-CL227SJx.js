import { t as e } from "./internalTexture-QUW4uXxg.js";
import { t } from "./logger-DQIzSR_y.js";
import { a as n, i as r, t as i } from "./thinEngine.pure-CFnvxmRZ.js";
import { n as a } from "./math.color.pure-CPmbqLkh.js";
import { n as o } from "./renderTargetTexture.pure-SdlS3qU7.js";
import { t as s } from "./texture.pure-Ce-ILsRv.js";
//#region node_modules/@babylonjs/core/Engines/Extensions/engine.multiRender.pure.js
var c = !1, l = /*#__PURE__*/ new a(), u = /*#__PURE__*/ new a();
function d() {
	c || (c = !0, i.prototype.restoreSingleAttachment = function() {
		let e = this._gl;
		this.bindAttachments([e.BACK]);
	}, i.prototype.restoreSingleAttachmentForRenderTarget = function() {
		let e = this._gl;
		this.bindAttachments([e.COLOR_ATTACHMENT0]);
	}, i.prototype.buildTextureLayout = function(e, t = !1) {
		let n = this._gl, r = [];
		if (t) r.push(n.BACK);
		else for (let t = 0; t < e.length; t++) e[t] ? r.push(n["COLOR_ATTACHMENT" + t]) : r.push(n.NONE);
		return r;
	}, i.prototype.bindAttachments = function(e) {
		let t = this._gl, n = this._currentRenderTarget?.textures;
		if (this._integerMRTAttachmentsMask = 0, n) for (let i = 0; i < e.length; i++) e[i] !== t.NONE && n[i] && r(n[i].format) && (this._integerMRTAttachmentsMask |= 1 << i);
		t.drawBuffers(e);
	}, i.prototype.clearAttachments = function(e, t, i, a, o = !1, s = 0) {
		let c = this._currentRenderTarget?.textures, d = !1;
		if (i && e && c) for (let e = 0; e < t.length; e++) {
			let n = c[e];
			if (t[e] !== this._gl.NONE && n && r(n.format)) {
				if (this._webGLVersion < 2) throw Error("ThinEngine.clearAttachments: integer MRT attachments require WebGL2");
				d = !0;
				break;
			}
		}
		if (!d || !e || !c) this.bindAttachments(t), this.clear(e, i, a, o, s);
		else {
			this.bindAttachments(t), this._applyColorWriteState();
			for (let i = 0; i < t.length; i++) {
				let a = c[i];
				if (t[i] !== this._gl.NONE && a) {
					let t = e;
					if (r(a.format)) {
						let r = n(a.type);
						t = r ? l : u;
						let i = r ? 255 : 1;
						t.r = Math.round(e.r * i), t.g = Math.round(e.g * i), t.b = Math.round(e.b * i), t.a = Math.round(e.a * i);
					}
					this._clearColorAttachment(i, t, a.format, a.type);
				}
			}
			if (a || o) {
				let e = this._integerMRTAttachmentsMask;
				this._integerMRTAttachmentsMask = 0;
				try {
					this.clear(null, !1, a, o, s);
				} finally {
					this._integerMRTAttachmentsMask = e;
				}
			}
		}
	}, i.prototype.unBindMultiColorAttachmentFramebuffer = function(e, t = !1, n) {
		this._currentRenderTarget = null, this._integerMRTAttachmentsMask = 0, e.disableAutomaticMSAAResolve || this.resolveMultiFramebuffer(e), t || this.generateMipMapsMultiFramebuffer(e), n && (e._MSAAFramebuffer && this._bindUnboundFramebuffer(e._framebuffer), n()), this._bindUnboundFramebuffer(null);
	}, i.prototype.createMultipleRenderTarget = function(n, r, i = !0) {
		let a = !1, o = !0, s = !1, c = !1, l, u = 1, d = 1, f = [], p = [], m = [], h = [], g = [], _ = [], v = [], y = [], b = [], x = !1, S = this._createHardwareRenderTargetWrapper(!0, !1, n);
		r !== void 0 && (a = r.generateMipMaps !== void 0 && r.generateMipMaps, o = r.generateDepthBuffer === void 0 || r.generateDepthBuffer, s = r.generateStencilBuffer !== void 0 && r.generateStencilBuffer, c = r.generateDepthTexture !== void 0 && r.generateDepthTexture, u = r.textureCount ?? 1, d = r.samples ?? d, f = r.types || f, p = r.samplingModes || p, m = r.useSRGBBuffers || m, h = r.formats || h, g = r.targetTypes || g, _ = r.faceIndex || _, v = r.layerIndex || v, y = r.layerCounts || y, b = r.labels || b, x = r.dontCreateTextures ?? !1, this.webGLVersion > 1 && (r.depthTextureFormat === 13 || r.depthTextureFormat === 17 || r.depthTextureFormat === 16 || r.depthTextureFormat === 14 || r.depthTextureFormat === 18) && (l = r.depthTextureFormat)), l === void 0 && (l = s ? 13 : 14);
		let C = this._gl, w = this._currentFramebuffer, T = C.createFramebuffer();
		this._bindUnboundFramebuffer(T);
		let E = n.width ?? n, D = n.height ?? n, O = [], k = [], A = this.webGLVersion > 1 && (l === 13 || l === 17 || l === 18);
		S.label = r?.label ?? "MultiRenderTargetWrapper", S._framebuffer = T, S._generateDepthBuffer = c || o, S._generateStencilBuffer = c ? A : s, S._depthStencilBuffer = this._setupFramebufferDepthAttachments(S._generateStencilBuffer, S._generateDepthBuffer, E, D, 1, l), S._attachments = k;
		for (let n = 0; n < u; n++) {
			let r = p[n] || 3, i = f[n] || 0, o = m[n] || !1, s = h[n] || 5, c = g[n] || 3553, l = y[n] ?? 1;
			(i === 1 && !this._caps.textureFloatLinearFiltering || i === 2 && !this._caps.textureHalfFloatLinearFiltering) && (r = 1);
			let u = this._getSamplingParameters(r, a);
			i === 1 && !this._caps.textureFloat && (i = 0, t.Warn("Float textures are not supported. Render target forced to TEXTURETYPE_UNSIGNED_BYTE type")), o = o && this._caps.supportSRGBBuffers && (this.webGLVersion > 1 || this.isWebGPU);
			let d = this.webGLVersion > 1, _ = C[d ? "COLOR_ATTACHMENT" + n : "COLOR_ATTACHMENT" + n + "_WEBGL"];
			if (k.push(_), c === -1 || x) continue;
			let v = new e(this, 6);
			O[n] = v, C.activeTexture(C["TEXTURE" + n]), C.bindTexture(c, v._hardwareTexture.underlyingResource), C.texParameteri(c, C.TEXTURE_MAG_FILTER, u.mag), C.texParameteri(c, C.TEXTURE_MIN_FILTER, u.min), C.texParameteri(c, C.TEXTURE_WRAP_S, C.CLAMP_TO_EDGE), C.texParameteri(c, C.TEXTURE_WRAP_T, C.CLAMP_TO_EDGE);
			let w = this._getRGBABufferInternalSizedFormat(i, s, o), T = this._getInternalFormat(s), A = this._getWebGLTextureType(i);
			if (d && (c === 35866 || c === 32879)) c === 35866 ? v.is2DArray = !0 : v.is3D = !0, v.baseDepth = v.depth = l, C.texImage3D(c, 0, w, E, D, l, 0, T, A, null);
			else if (c === 34067) {
				for (let e = 0; e < 6; e++) C.texImage2D(C.TEXTURE_CUBE_MAP_POSITIVE_X + e, 0, w, E, D, 0, T, A, null);
				v.isCube = !0;
			} else C.texImage2D(C.TEXTURE_2D, 0, w, E, D, 0, T, A, null);
			a && C.generateMipmap(c), this._bindTextureDirectly(c, null), v.baseWidth = E, v.baseHeight = D, v.width = E, v.height = D, v.isReady = !0, v.samples = 1, v.generateMipMaps = a, v.samplingMode = r, v.type = i, v._useSRGBBuffer = o, v.format = s, v.label = b[n] ?? S.label + "-Texture" + n, this._internalTexturesCache.push(v);
		}
		if (c && this._caps.depthTextureExtension && !x) {
			let t = new e(this, 14), n = 5, r = C.DEPTH_COMPONENT16, i = C.DEPTH_COMPONENT, o = C.UNSIGNED_SHORT, s = C.DEPTH_ATTACHMENT;
			this.webGLVersion < 2 ? r = C.DEPTH_COMPONENT : l === 14 ? (n = 1, o = C.FLOAT, r = C.DEPTH_COMPONENT32F) : l === 18 ? (n = 0, o = C.FLOAT_32_UNSIGNED_INT_24_8_REV, r = C.DEPTH32F_STENCIL8, i = C.DEPTH_STENCIL, s = C.DEPTH_STENCIL_ATTACHMENT) : l === 16 ? (n = 0, o = C.UNSIGNED_INT, r = C.DEPTH_COMPONENT24, s = C.DEPTH_ATTACHMENT) : (l === 13 || l === 17) && (n = 12, o = C.UNSIGNED_INT_24_8, r = C.DEPTH24_STENCIL8, i = C.DEPTH_STENCIL, s = C.DEPTH_STENCIL_ATTACHMENT), this._bindTextureDirectly(C.TEXTURE_2D, t, !0), C.texParameteri(C.TEXTURE_2D, C.TEXTURE_MAG_FILTER, C.NEAREST), C.texParameteri(C.TEXTURE_2D, C.TEXTURE_MIN_FILTER, C.NEAREST), C.texParameteri(C.TEXTURE_2D, C.TEXTURE_WRAP_S, C.CLAMP_TO_EDGE), C.texParameteri(C.TEXTURE_2D, C.TEXTURE_WRAP_T, C.CLAMP_TO_EDGE), C.texImage2D(C.TEXTURE_2D, 0, r, E, D, 0, i, o, null), C.framebufferTexture2D(C.FRAMEBUFFER, s, C.TEXTURE_2D, t._hardwareTexture.underlyingResource, 0), this._bindTextureDirectly(C.TEXTURE_2D, null), S._depthStencilTexture = t, S._depthStencilTextureWithStencil = A, t.baseWidth = E, t.baseHeight = D, t.width = E, t.height = D, t.isReady = !0, t.samples = 1, t.generateMipMaps = a, t.samplingMode = 1, t.format = l, t.type = n, t.label = S.label + "-DepthStencil", O[u] = t, this._internalTexturesCache.push(t);
		}
		if (S.setTextures(O), i && C.drawBuffers(k), this._bindUnboundFramebuffer(w), S.setLayerAndFaceIndices(v, _), this.resetTextureCache(), !x) this.updateMultipleRenderTargetTextureSampleCount(S, d, i);
		else if (d > 1) {
			let e = C.createFramebuffer();
			if (!e) throw Error("Unable to create multi sampled framebuffer");
			S._samples = d, S._MSAAFramebuffer = e, u > 0 && i && (this._bindUnboundFramebuffer(e), C.drawBuffers(k), this._bindUnboundFramebuffer(w));
		}
		return S;
	}, i.prototype.updateMultipleRenderTargetTextureSampleCount = function(e, t, n = !0) {
		if (this.webGLVersion < 2 || !e) return 1;
		if (e.samples === t) return t;
		let r = this._gl;
		t = Math.min(t, this.getCaps().maxMSAASamples), e._depthStencilBuffer &&= (r.deleteRenderbuffer(e._depthStencilBuffer), null), e._MSAAFramebuffer &&= (r.deleteFramebuffer(e._MSAAFramebuffer), null);
		let i = e._attachments.length;
		for (let t = 0; t < i; t++) e.textures[t]._hardwareTexture?.releaseMSAARenderBuffers();
		if (t > 1 && typeof r.renderbufferStorageMultisample == "function") {
			let a = r.createFramebuffer();
			if (!a) throw Error("Unable to create multi sampled framebuffer");
			e._MSAAFramebuffer = a, this._bindUnboundFramebuffer(a);
			let o = [];
			for (let n = 0; n < i; n++) {
				let i = e.textures[n], a = i._hardwareTexture, s = r[this.webGLVersion > 1 ? "COLOR_ATTACHMENT" + n : "COLOR_ATTACHMENT" + n + "_WEBGL"], c = this._createRenderBuffer(i.width, i.height, t, -1, this._getRGBABufferInternalSizedFormat(i.type, i.format, i._useSRGBBuffer), s);
				if (!c) throw Error("Unable to create multi sampled framebuffer");
				a.addMSAARenderBuffer(c), i.samples = t, o.push(s);
			}
			n && r.drawBuffers(o);
		} else this._bindUnboundFramebuffer(e._framebuffer);
		let a = e._depthStencilTexture ? e._depthStencilTexture.format : void 0;
		return e._depthStencilBuffer = this._setupFramebufferDepthAttachments(e._generateStencilBuffer, e._generateDepthBuffer, e.width, e.height, t, a), this._bindUnboundFramebuffer(null), e._samples = t, t;
	}, i.prototype.generateMipMapsMultiFramebuffer = function(e) {
		let t = e, n = this._gl;
		if (t.isMulti) for (let e = 0; e < t._attachments.length; e++) {
			let r = t.textures[e];
			r?.generateMipMaps && !r?.isCube && !r?.is3D && (this._bindTextureDirectly(n.TEXTURE_2D, r, !0), n.generateMipmap(n.TEXTURE_2D), this._bindTextureDirectly(n.TEXTURE_2D, null));
		}
	}, i.prototype.resolveMultiFramebuffer = function(e) {
		let t = e, n = this._gl;
		if (!t._MSAAFramebuffer || !t.isMulti) return;
		let r = t.resolveMSAAColors ? n.COLOR_BUFFER_BIT : 0;
		r |= t._generateDepthBuffer && t.resolveMSAADepth ? n.DEPTH_BUFFER_BIT : 0, r |= t._generateStencilBuffer && t.resolveMSAAStencil ? n.STENCIL_BUFFER_BIT : 0;
		let i = t._attachments, a = i.length;
		n.bindFramebuffer(n.READ_FRAMEBUFFER, t._MSAAFramebuffer), n.bindFramebuffer(n.DRAW_FRAMEBUFFER, t._framebuffer);
		for (let e = 0; e < a; e++) {
			let o = t.textures[e];
			for (let e = 0; e < a; e++) i[e] = n.NONE;
			i[e] = n[this.webGLVersion > 1 ? "COLOR_ATTACHMENT" + e : "COLOR_ATTACHMENT" + e + "_WEBGL"], n.readBuffer(i[e]), n.drawBuffers(i), n.blitFramebuffer(0, 0, o.width, o.height, 0, 0, o.width, o.height, r, n.NEAREST);
		}
		for (let e = 0; e < a; e++) i[e] = n[this.webGLVersion > 1 ? "COLOR_ATTACHMENT" + e : "COLOR_ATTACHMENT" + e + "_WEBGL"];
		n.drawBuffers(i), n.bindFramebuffer(this._gl.FRAMEBUFFER, t._MSAAFramebuffer);
	});
}
//#endregion
//#region node_modules/@babylonjs/core/Materials/Textures/multiRenderTarget.pure.js
var f = class extends o {
	get isSupported() {
		return this._engine?.getCaps().drawBuffersExtension ?? !1;
	}
	get textures() {
		return this._textures;
	}
	get count() {
		return this._count;
	}
	get depthTexture() {
		return this._textures[this._textures.length - 1];
	}
	set wrapU(e) {
		if (this._textures) for (let t = 0; t < this._textures.length; t++) this._textures[t].wrapU = e;
	}
	set wrapV(e) {
		if (this._textures) for (let t = 0; t < this._textures.length; t++) this._textures[t].wrapV = e;
	}
	constructor(e, t, n, r, i, a) {
		let o = i && i.generateMipMaps ? i.generateMipMaps : !1, s = i && i.generateDepthTexture ? i.generateDepthTexture : !1, c = i && i.depthTextureFormat ? i.depthTextureFormat : 15, l = !i || i.doNotChangeAspectRatio === void 0 || i.doNotChangeAspectRatio, u = i && i.drawOnlyOnFirstAttachmentByDefault ? i.drawOnlyOnFirstAttachmentByDefault : !1;
		if (super(e, t, r, o, l, void 0, void 0, void 0, void 0, void 0, void 0, void 0, !0), d(), !this.isSupported) {
			this.dispose();
			return;
		}
		this._textureNames = a;
		let f = [], p = [], m = [], h = [], g = [], _ = [], v = [], y = [];
		this._initTypes(n, f, p, m, h, g, _, v, y, i);
		let b = !i || i.generateDepthBuffer === void 0 || i.generateDepthBuffer, x = !i || i.generateStencilBuffer === void 0 ? !1 : i.generateStencilBuffer, S = i && i.samples ? i.samples : 1;
		this._multiRenderTargetOptions = {
			samplingModes: p,
			generateMipMaps: o,
			generateDepthBuffer: b,
			generateStencilBuffer: x,
			generateDepthTexture: s,
			depthTextureFormat: c,
			types: f,
			textureCount: n,
			useSRGBBuffers: m,
			samples: S,
			formats: h,
			targetTypes: g,
			faceIndex: _,
			layerIndex: v,
			layerCounts: y,
			labels: a,
			label: e
		}, this._count = n, this._drawOnlyOnFirstAttachmentByDefault = u, n > 0 && (this._createInternalTextures(), this._createTextures(a));
	}
	_initTypes(e, t, n, r, i, a, o, c, l, u) {
		for (let d = 0; d < e; d++) u && u.types && u.types[d] !== void 0 ? t.push(u.types[d]) : t.push(u && u.defaultType ? u.defaultType : 0), u && u.samplingModes && u.samplingModes[d] !== void 0 ? n.push(u.samplingModes[d]) : n.push(s.BILINEAR_SAMPLINGMODE), u && u.useSRGBBuffers && u.useSRGBBuffers[d] !== void 0 ? r.push(u.useSRGBBuffers[d]) : r.push(!1), u && u.formats && u.formats[d] !== void 0 ? i.push(u.formats[d]) : i.push(5), u && u.targetTypes && u.targetTypes[d] !== void 0 ? a.push(u.targetTypes[d]) : a.push(3553), u && u.faceIndex && u.faceIndex[d] !== void 0 ? o.push(u.faceIndex[d]) : o.push(0), u && u.layerIndex && u.layerIndex[d] !== void 0 ? c.push(u.layerIndex[d]) : c.push(0), u && u.layerCounts && u.layerCounts[d] !== void 0 ? l.push(u.layerCounts[d]) : l.push(1);
	}
	_createInternaTextureIndexMapping() {
		let e = {}, t = [];
		if (!this._renderTarget) return t;
		let n = this._renderTarget.textures;
		for (let r = 0; r < n.length; r++) {
			let i = n[r];
			if (!i) continue;
			let a = e[i.uniqueId];
			a === void 0 ? e[i.uniqueId] = r : t[r] = a;
		}
		return t;
	}
	_rebuild(e = !1, t = !1, n) {
		if (this._count < 1 || e) return;
		let r = this._createInternaTextureIndexMapping();
		this.releaseInternalTextures(), this._createInternalTextures(), t && (this._releaseTextures(), this._createTextures(n));
		let i = this._renderTarget.textures;
		for (let e = 0; e < i.length; e++) {
			let t = this._textures[e];
			r[e] !== void 0 && this._renderTarget.setTexture(i[r[e]], e), t._texture = i[e], t._texture && (t._noMipmap = !t._texture.useMipMaps, t._useSRGBBuffer = t._texture._useSRGBBuffer);
		}
		this.samples !== 1 && this._renderTarget.setSamples(this.samples, !this._drawOnlyOnFirstAttachmentByDefault, !0);
	}
	_createInternalTextures() {
		this._renderTarget = this._getEngine().createMultipleRenderTarget(this._size, this._multiRenderTargetOptions, !this._drawOnlyOnFirstAttachmentByDefault), this._texture = this._renderTarget.texture;
	}
	_releaseTextures() {
		if (this._textures) for (let e = 0; e < this._textures.length; e++) this._textures[e]._texture = null, this._textures[e].dispose();
	}
	_createTextures(e) {
		let t = this._renderTarget.textures;
		this._textures = [];
		for (let n = 0; n < t.length; n++) {
			let r = new s(null, this.getScene());
			e?.[n] && (r.name = e[n]), r._texture = t[n], r._texture && (r._noMipmap = !r._texture.useMipMaps, r._useSRGBBuffer = r._texture._useSRGBBuffer), this._textures.push(r);
		}
	}
	setInternalTexture(e, t, n = !0) {
		if (this.renderTarget && (t === 0 && (this._texture = e), this.renderTarget.setTexture(e, t, n), this.textures[t] || (this.textures[t] = new s(null, this.getScene()), this.textures[t].name = this._textureNames?.[t] ?? this.textures[t].name), this.textures[t]._texture = e, this.textures[t]._noMipmap = !e.useMipMaps, this.textures[t]._useSRGBBuffer = e._useSRGBBuffer, this._count = this.renderTarget.textures ? this.renderTarget.textures.length : 0, this._multiRenderTargetOptions.types && (this._multiRenderTargetOptions.types[t] = e.type), this._multiRenderTargetOptions.samplingModes && (this._multiRenderTargetOptions.samplingModes[t] = e.samplingMode), this._multiRenderTargetOptions.useSRGBBuffers && (this._multiRenderTargetOptions.useSRGBBuffers[t] = e._useSRGBBuffer), this._multiRenderTargetOptions.targetTypes && this._multiRenderTargetOptions.targetTypes[t] !== -1)) {
			let n;
			n = e.is2DArray ? 35866 : e.isCube ? 34067 : e.is3D ? 32879 : 3553, this._multiRenderTargetOptions.targetTypes[t] = n;
		}
	}
	setLayerAndFaceIndex(e, t = -1, n = -1) {
		this.textures[e] && this.renderTarget && (this._multiRenderTargetOptions.layerIndex && (this._multiRenderTargetOptions.layerIndex[e] = t), this._multiRenderTargetOptions.faceIndex && (this._multiRenderTargetOptions.faceIndex[e] = n), this.renderTarget.setLayerAndFaceIndex(e, t, n));
	}
	setLayerAndFaceIndices(e, t) {
		this.renderTarget && (this._multiRenderTargetOptions.layerIndex = e, this._multiRenderTargetOptions.faceIndex = t, this.renderTarget.setLayerAndFaceIndices(e, t));
	}
	get samples() {
		return this._samples;
	}
	set samples(e) {
		this._samples = this._renderTarget ? this._renderTarget.setSamples(e) : e;
	}
	resize(e) {
		this._processSizeParameter(e), this._rebuild(!1, void 0, this._textureNames);
	}
	updateCount(e, t, n) {
		this._multiRenderTargetOptions.textureCount = e, this._count = e;
		let r = [], i = [], a = [], o = [], s = [], c = [], l = [], u = [];
		this._textureNames = n, this._initTypes(e, r, i, a, o, s, c, l, u, t), this._multiRenderTargetOptions.types = r, this._multiRenderTargetOptions.samplingModes = i, this._multiRenderTargetOptions.useSRGBBuffers = a, this._multiRenderTargetOptions.formats = o, this._multiRenderTargetOptions.targetTypes = s, this._multiRenderTargetOptions.faceIndex = c, this._multiRenderTargetOptions.layerIndex = l, this._multiRenderTargetOptions.layerCounts = u, this._multiRenderTargetOptions.labels = n, this._rebuild(!1, !0, n);
	}
	_unbindFrameBuffer(e, t) {
		this._renderTarget && e.unBindMultiColorAttachmentFramebuffer(this._renderTarget, this.isCube, () => {
			this.onAfterRenderObservable.notifyObservers(t);
		});
	}
	dispose(e = !1) {
		this._releaseTextures(), e ? this._texture = null : this.releaseInternalTextures(), super.dispose();
	}
	releaseInternalTextures() {
		let e = this._renderTarget?.textures;
		if (e) {
			for (let t = e.length - 1; t >= 0; t--) this._textures[t]._texture = null;
			this._renderTarget?.dispose(), this._renderTarget = null;
		}
	}
};
//#endregion
export { f as t };
