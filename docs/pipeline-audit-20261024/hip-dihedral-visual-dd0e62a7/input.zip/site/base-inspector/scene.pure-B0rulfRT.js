import { t as e } from "./math.scalar.functions-D7lyzZPV.js";
import { n as t, t as n } from "./engineStore-D0BoPdea.js";
import { t as r } from "./logger-DQIzSR_y.js";
import { i, r as a } from "./domManagement-BZa7OPDn.js";
import { S as o, b as s, c, i as l, o as u, s as d, x as f, y as p } from "./tools.functions-DEecYKlu.js";
import { n as m } from "./buffer.pure-CgsgX1aa.js";
import { a as h, c as g, d as _, h as v, l as y, n as b, t as x, u as S } from "./math.color.pure-CPmbqLkh.js";
import { n as C } from "./typeStore-pENEWnX2.js";
import { t as w } from "./math.plane-wePi4N1d.js";
import { b as T, f as ee, i as E, o as te, s as ne, y as D } from "./decorators-BldPRAAT.js";
import { n as O, t as k } from "./decorators.serialization-CGAHzP43.js";
import { f as re, l as ie, m as ae, r as A } from "./tools.pure-Dy2G52NL.js";
import { n as j, t as M } from "./smartArray-BmGU7Yab.js";
import { n as N, t as P } from "./lightConstants-Dqs8OH2d.js";
import { a as oe, i as se, n as F, o as ce, r as le, s as ue } from "./sceneComponent-C2CdEKig.js";
import { n as I, r as de, t as L } from "./pointerEvents-BQVevekB.js";
import { n as fe, r as pe, t as me } from "./keyboardEvents-BnzTAWpo.js";
//#region node_modules/@babylonjs/core/Misc/perfCounter.js
var R = class e {
	get min() {
		return this._min;
	}
	get max() {
		return this._max;
	}
	get average() {
		return this._average;
	}
	get lastSecAverage() {
		return this._lastSecAverage;
	}
	get current() {
		return this._current;
	}
	get total() {
		return this._totalAccumulated;
	}
	get count() {
		return this._totalValueCount;
	}
	constructor() {
		this._startMonitoringTime = 0, this._min = 0, this._max = 0, this._hasResult = !1, this._hasCurrentValue = !1, this._average = 0, this._lastSecAverage = 0, this._current = 0, this._totalValueCount = 0, this._totalAccumulated = 0, this._lastSecAccumulated = 0, this._lastSecTime = 0, this._lastSecValueCount = 0;
	}
	fetchNewFrame() {
		this._totalValueCount++, this._current = 0, this._hasCurrentValue = e.Enabled, this._lastSecValueCount++;
	}
	addCount(t, n) {
		e.Enabled && (this._current += t, this._hasCurrentValue = !0, n && this._fetchResult());
	}
	beginMonitoring() {
		e.Enabled && (this._startMonitoringTime = u.Now);
	}
	endMonitoring(t = !0) {
		if (!e.Enabled) return;
		t && this.fetchNewFrame();
		let n = u.Now;
		this._current = n - this._startMonitoringTime, this._hasCurrentValue = !0, t && this._fetchResult();
	}
	endFrame() {
		this._fetchResult();
	}
	_fetchResult() {
		if (!this._hasCurrentValue) return;
		this._totalAccumulated += this._current, this._lastSecAccumulated += this._current, this._hasResult ? (this._min = Math.min(this._min, this._current), this._max = Math.max(this._max, this._current)) : (this._min = this._current, this._max = this._current, this._hasResult = !0), this._average = this._totalAccumulated / this._totalValueCount;
		let e = u.Now;
		e - this._lastSecTime > 1e3 && (this._lastSecAverage = this._lastSecAccumulated / this._lastSecValueCount, this._lastSecTime = e, this._lastSecAccumulated = 0, this._lastSecValueCount = 0);
	}
};
R.Enabled = !0;
//#endregion
//#region node_modules/@babylonjs/core/Maths/math.frustum.js
var z = class e {
	static GetPlanes(t) {
		let n = [];
		for (let e = 0; e < 6; e++) n.push(new w(0, 0, 0, 0));
		return e.GetPlanesToRef(t, n), n;
	}
	static GetNearPlaneToRef(e, t) {
		let n = e.m;
		t.normal.x = n[3] + n[2], t.normal.y = n[7] + n[6], t.normal.z = n[11] + n[10], t.d = n[15] + n[14], t.normalize();
	}
	static GetFarPlaneToRef(e, t) {
		let n = e.m;
		t.normal.x = n[3] - n[2], t.normal.y = n[7] - n[6], t.normal.z = n[11] - n[10], t.d = n[15] - n[14], t.normalize();
	}
	static GetLeftPlaneToRef(e, t) {
		let n = e.m;
		t.normal.x = n[3] + n[0], t.normal.y = n[7] + n[4], t.normal.z = n[11] + n[8], t.d = n[15] + n[12], t.normalize();
	}
	static GetRightPlaneToRef(e, t) {
		let n = e.m;
		t.normal.x = n[3] - n[0], t.normal.y = n[7] - n[4], t.normal.z = n[11] - n[8], t.d = n[15] - n[12], t.normalize();
	}
	static GetTopPlaneToRef(e, t) {
		let n = e.m;
		t.normal.x = n[3] - n[1], t.normal.y = n[7] - n[5], t.normal.z = n[11] - n[9], t.d = n[15] - n[13], t.normalize();
	}
	static GetBottomPlaneToRef(e, t) {
		let n = e.m;
		t.normal.x = n[3] + n[1], t.normal.y = n[7] + n[5], t.normal.z = n[11] + n[9], t.d = n[15] + n[13], t.normalize();
	}
	static GetPlanesToRef(t, n) {
		e.GetNearPlaneToRef(t, n[0]), e.GetFarPlaneToRef(t, n[1]), e.GetLeftPlaneToRef(t, n[2]), e.GetRightPlaneToRef(t, n[3]), e.GetTopPlaneToRef(t, n[4]), e.GetBottomPlaneToRef(t, n[5]);
	}
	static IsPointInFrustum(e, t) {
		for (let n = 0; n < 6; n++) if (t[n].dotCoordinate(e) < 0) return !1;
		return !0;
	}
}, he = class {
	constructor() {
		this._count = 0, this._data = {};
	}
	copyFrom(e) {
		this.clear(), e.forEach((e, t) => this.add(e, t));
	}
	get(e) {
		let t = this._data[e];
		if (t !== void 0) return t;
	}
	getOrAddWithFactory(e, t) {
		let n = this.get(e);
		return n === void 0 && (n = t(e), n && this.add(e, n)), n;
	}
	getOrAdd(e, t) {
		let n = this.get(e);
		return n === void 0 ? (this.add(e, t), t) : n;
	}
	contains(e) {
		return this._data[e] !== void 0;
	}
	add(e, t) {
		return this._data[e] === void 0 && (this._data[e] = t, ++this._count, !0);
	}
	set(e, t) {
		return this._data[e] !== void 0 && (this._data[e] = t, !0);
	}
	getAndRemove(e) {
		let t = this.get(e);
		return t === void 0 ? null : (delete this._data[e], --this._count, t);
	}
	remove(e) {
		return this.contains(e) ? (delete this._data[e], --this._count, !0) : !1;
	}
	clear() {
		this._data = {}, this._count = 0;
	}
	get count() {
		return this._count;
	}
	forEach(e) {
		for (let t in this._data) {
			let n = this._data[t];
			e(t, n);
		}
	}
	first(e) {
		for (let t in this._data) {
			let n = this._data[t], r = e(t, n);
			if (r) return r;
		}
		return null;
	}
}, B = [
	[
		0,
		.18006,
		.26352,
		-.24341
	],
	[
		10,
		.18066,
		.26589,
		-.25479
	],
	[
		20,
		.18133,
		.26846,
		-.26876
	],
	[
		30,
		.18208,
		.27119,
		-.28539
	],
	[
		40,
		.18293,
		.27407,
		-.3047
	],
	[
		50,
		.18388,
		.27709,
		-.32675
	],
	[
		60,
		.18494,
		.28021,
		-.35156
	],
	[
		70,
		.18611,
		.28342,
		-.37915
	],
	[
		80,
		.1874,
		.28668,
		-.40955
	],
	[
		90,
		.1888,
		.28997,
		-.44278
	],
	[
		100,
		.19032,
		.29326,
		-.47888
	],
	[
		125,
		.19462,
		.30141,
		-.58204
	],
	[
		150,
		.19962,
		.30921,
		-.70471
	],
	[
		175,
		.20525,
		.31647,
		-.84901
	],
	[
		200,
		.21142,
		.32312,
		-1.0182
	],
	[
		225,
		.21807,
		.32909,
		-1.2168
	],
	[
		250,
		.22511,
		.33439,
		-1.4512
	],
	[
		275,
		.23247,
		.33904,
		-1.7298
	],
	[
		300,
		.2401,
		.34308,
		-2.0637
	],
	[
		325,
		.24792,
		.34655,
		-2.4681
	],
	[
		350,
		.25591,
		.34951,
		-2.9641
	],
	[
		375,
		.264,
		.352,
		-3.5814
	],
	[
		400,
		.27218,
		.35407,
		-4.3633
	],
	[
		425,
		.28039,
		.35577,
		-5.3762
	],
	[
		450,
		.28863,
		.35714,
		-6.7262
	],
	[
		475,
		.29685,
		.35823,
		-8.5955
	],
	[
		500,
		.30505,
		.35907,
		-11.324
	],
	[
		525,
		.3132,
		.35968,
		-15.628
	],
	[
		550,
		.32129,
		.36011,
		-23.325
	],
	[
		575,
		.32931,
		.36038,
		-40.77
	],
	[
		600,
		.33724,
		.36051,
		-116.45
	]
], ge = 1e6 / B[B.length - 1][0];
function _e(t, n) {
	let r = e(1e6 / (Number.isNaN(t) ? ge : Math.max(t, ge)), B[0][0], B[B.length - 1][0]), i = 0, a = B.length - 1;
	for (; a - i > 1;) {
		let e = i + a >> 1;
		B[e][0] <= r ? i = e : a = e;
	}
	let o = i, [s, c, l, u] = B[o], [d, f, p, m] = B[o + 1], h = (r - s) / (d - s), g = y.Lerp(new y(c, l), new y(f, p), h), _ = y.Normalize(new y(1, u)), v = y.Normalize(new y(1, m)), b = y.Normalize(y.Lerp(_, v, h)), x = e(n, -150, 150);
	g.subtractInPlace(b.scale(x / 3e3));
	let C = 2 * g.x - 8 * g.y + 4, w = 3 * g.x / C, T = 2 * g.y / C;
	return new S(w / T, 1, (1 - w - T) / T);
}
var V = h.FromArray([
	.8951,
	-.7502,
	.0389,
	0,
	.2664,
	1.7135,
	-.0685,
	0,
	-.1614,
	.0367,
	1.0296,
	0,
	0,
	0,
	0,
	1
]), ve = h.Invert(V);
function H(t, n) {
	let r = n > 0 ? t / n : 10;
	return e(r, .1, 10);
}
function ye(e, t) {
	let n = S.TransformNormal(e, V), r = S.TransformNormal(t, V), i = h.FromArray([
		H(r.x, n.x),
		0,
		0,
		0,
		0,
		H(r.y, n.y),
		0,
		0,
		0,
		0,
		H(r.z, n.z),
		0,
		0,
		0,
		0,
		1
	]);
	return V.multiply(i).multiply(ve);
}
var be = new S(.95047, 1, 1.08883), U = h.FromArray([
	.4124564,
	.2126729,
	.0193339,
	0,
	.3575761,
	.7151522,
	.119192,
	0,
	.1804375,
	.072175,
	.9503041,
	0,
	0,
	0,
	0,
	1
]).multiply(ye(be, _e(6500, 0))), xe = h.Invert(U), Se = S.TransformNormal(new S(1, 1, 1), U);
function Ce(e, t) {
	let n = ye(_e(e, t), Se), r = U.multiply(n).multiply(xe);
	return h.GetAsMatrix3x3(r);
}
//#endregion
//#region node_modules/@babylonjs/core/Materials/colorCurves.functions.js
function we(e) {
	e.push("vCameraColorCurveNeutral", "vCameraColorCurvePositive", "vCameraColorCurveNegative");
}
//#endregion
//#region node_modules/@babylonjs/core/Materials/colorCurves.pure.js
var Te = (() => {
	var e;
	let t, n = [], r = [], i, a = [], o = [], s, c = [], l = [], u, d = [], f = [], p, m = [], h = [], g, _ = [], v = [], y, x = [], S = [], C, w = [], ee = [], te, ne = [], O = [], re, ie = [], ae = [], A, j = [], M = [], N, P = [], oe = [];
	return e = class {
		constructor() {
			this._dirty = !0, this._tempColor = new b(0, 0, 0, 0), this._globalCurve = new b(0, 0, 0, 0), this._highlightsCurve = new b(0, 0, 0, 0), this._midtonesCurve = new b(0, 0, 0, 0), this._shadowsCurve = new b(0, 0, 0, 0), this._positiveCurve = new b(0, 0, 0, 0), this._negativeCurve = new b(0, 0, 0, 0), this._globalHue = T(this, n, 30), this._globalDensity = (T(this, r), T(this, a, 0)), this._globalSaturation = (T(this, o), T(this, c, 0)), this._globalExposure = (T(this, l), T(this, d, 0)), this._highlightsHue = (T(this, f), T(this, m, 30)), this._highlightsDensity = (T(this, h), T(this, _, 0)), this._highlightsSaturation = (T(this, v), T(this, x, 0)), this._highlightsExposure = (T(this, S), T(this, w, 0)), this._midtonesHue = (T(this, ee), T(this, ne, 30)), this._midtonesDensity = (T(this, O), T(this, ie, 0)), this._midtonesSaturation = (T(this, ae), T(this, j, 0)), this._midtonesExposure = (T(this, M), T(this, P, 0)), this._shadowsHue = (T(this, oe), 30), this._shadowsDensity = 0, this._shadowsSaturation = 0, this._shadowsExposure = 0;
		}
		get globalHue() {
			return this._globalHue;
		}
		set globalHue(e) {
			this._globalHue = e, this._dirty = !0;
		}
		get globalDensity() {
			return this._globalDensity;
		}
		set globalDensity(e) {
			this._globalDensity = e, this._dirty = !0;
		}
		get globalSaturation() {
			return this._globalSaturation;
		}
		set globalSaturation(e) {
			this._globalSaturation = e, this._dirty = !0;
		}
		get globalExposure() {
			return this._globalExposure;
		}
		set globalExposure(e) {
			this._globalExposure = e, this._dirty = !0;
		}
		get highlightsHue() {
			return this._highlightsHue;
		}
		set highlightsHue(e) {
			this._highlightsHue = e, this._dirty = !0;
		}
		get highlightsDensity() {
			return this._highlightsDensity;
		}
		set highlightsDensity(e) {
			this._highlightsDensity = e, this._dirty = !0;
		}
		get highlightsSaturation() {
			return this._highlightsSaturation;
		}
		set highlightsSaturation(e) {
			this._highlightsSaturation = e, this._dirty = !0;
		}
		get highlightsExposure() {
			return this._highlightsExposure;
		}
		set highlightsExposure(e) {
			this._highlightsExposure = e, this._dirty = !0;
		}
		get midtonesHue() {
			return this._midtonesHue;
		}
		set midtonesHue(e) {
			this._midtonesHue = e, this._dirty = !0;
		}
		get midtonesDensity() {
			return this._midtonesDensity;
		}
		set midtonesDensity(e) {
			this._midtonesDensity = e, this._dirty = !0;
		}
		get midtonesSaturation() {
			return this._midtonesSaturation;
		}
		set midtonesSaturation(e) {
			this._midtonesSaturation = e, this._dirty = !0;
		}
		get midtonesExposure() {
			return this._midtonesExposure;
		}
		set midtonesExposure(e) {
			this._midtonesExposure = e, this._dirty = !0;
		}
		get shadowsHue() {
			return this._shadowsHue;
		}
		set shadowsHue(e) {
			this._shadowsHue = e, this._dirty = !0;
		}
		get shadowsDensity() {
			return this._shadowsDensity;
		}
		set shadowsDensity(e) {
			this._shadowsDensity = e, this._dirty = !0;
		}
		get shadowsSaturation() {
			return this._shadowsSaturation;
		}
		set shadowsSaturation(e) {
			this._shadowsSaturation = e, this._dirty = !0;
		}
		get shadowsExposure() {
			return this._shadowsExposure;
		}
		set shadowsExposure(e) {
			this._shadowsExposure = e, this._dirty = !0;
		}
		getClassName() {
			return "ColorCurves";
		}
		_getColorGradingDataToRef(t, n, r, i, a) {
			t != null && (t = e._Clamp(t, 0, 360), n = e._Clamp(n, -100, 100), r = e._Clamp(r, -100, 100), i = e._Clamp(i, -100, 100), n = e._ApplyColorGradingSliderNonlinear(n), n *= .5, i = e._ApplyColorGradingSliderNonlinear(i), n < 0 && (n *= -1, t = (t + 180) % 360), e._FromHSBToRef(t, n, 50 + .25 * i, a), a.scaleToRef(2, a), a.a = 1 + .01 * r);
		}
		static _ApplyColorGradingSliderNonlinear(e) {
			e /= 100;
			let t = Math.abs(e);
			return t **= 2, e < 0 && (t *= -1), t *= 100, t;
		}
		static _FromHSBToRef(t, n, r, i) {
			let a = e._Clamp(t, 0, 360), o = e._Clamp(n / 100, 0, 1), s = e._Clamp(r / 100, 0, 1);
			if (o === 0) i.r = s, i.g = s, i.b = s;
			else {
				a /= 60;
				let e = Math.floor(a), t = a - e, n = s * (1 - o), r = s * (1 - o * t), c = s * (1 - o * (1 - t));
				switch (e) {
					case 0:
						i.r = s, i.g = c, i.b = n;
						break;
					case 1:
						i.r = r, i.g = s, i.b = n;
						break;
					case 2:
						i.r = n, i.g = s, i.b = c;
						break;
					case 3:
						i.r = n, i.g = r, i.b = s;
						break;
					case 4:
						i.r = c, i.g = n, i.b = s;
						break;
					default: i.r = s, i.g = n, i.b = r;
				}
			}
			i.a = 1;
		}
		static _Clamp(e, t, n) {
			return Math.min(Math.max(e, t), n);
		}
		clone() {
			return k.Clone(() => new e(), this);
		}
		serialize() {
			return k.Serialize(this);
		}
		_bind(e, t = "vCameraColorCurvePositive", n = "vCameraColorCurveNeutral", r = "vCameraColorCurveNegative") {
			this._dirty && (this._dirty = !1, this._getColorGradingDataToRef(this._globalHue, this._globalDensity, this._globalSaturation, this._globalExposure, this._globalCurve), this._getColorGradingDataToRef(this._highlightsHue, this._highlightsDensity, this._highlightsSaturation, this._highlightsExposure, this._tempColor), this._tempColor.multiplyToRef(this._globalCurve, this._highlightsCurve), this._getColorGradingDataToRef(this._midtonesHue, this._midtonesDensity, this._midtonesSaturation, this._midtonesExposure, this._tempColor), this._tempColor.multiplyToRef(this._globalCurve, this._midtonesCurve), this._getColorGradingDataToRef(this._shadowsHue, this._shadowsDensity, this._shadowsSaturation, this._shadowsExposure, this._tempColor), this._tempColor.multiplyToRef(this._globalCurve, this._shadowsCurve), this._highlightsCurve.subtractToRef(this._midtonesCurve, this._positiveCurve), this._midtonesCurve.subtractToRef(this._shadowsCurve, this._negativeCurve)), e && (e.setFloat4(t, this._positiveCurve.r, this._positiveCurve.g, this._positiveCurve.b, this._positiveCurve.a), e.setFloat4(n, this._midtonesCurve.r, this._midtonesCurve.g, this._midtonesCurve.b, this._midtonesCurve.a), e.setFloat4(r, this._negativeCurve.r, this._negativeCurve.g, this._negativeCurve.b, this._negativeCurve.a));
		}
	}, (() => {
		let b = typeof Symbol == "function" && Symbol.metadata ? Object.create(null) : void 0;
		t = [E()], i = [E()], s = [E()], u = [E()], p = [E()], g = [E()], y = [E()], C = [E()], te = [E()], re = [E()], A = [E()], N = [E()], D(null, null, t, {
			kind: "field",
			name: "_globalHue",
			static: !1,
			private: !1,
			access: {
				has: (e) => "_globalHue" in e,
				get: (e) => e._globalHue,
				set: (e, t) => {
					e._globalHue = t;
				}
			},
			metadata: b
		}, n, r), D(null, null, i, {
			kind: "field",
			name: "_globalDensity",
			static: !1,
			private: !1,
			access: {
				has: (e) => "_globalDensity" in e,
				get: (e) => e._globalDensity,
				set: (e, t) => {
					e._globalDensity = t;
				}
			},
			metadata: b
		}, a, o), D(null, null, s, {
			kind: "field",
			name: "_globalSaturation",
			static: !1,
			private: !1,
			access: {
				has: (e) => "_globalSaturation" in e,
				get: (e) => e._globalSaturation,
				set: (e, t) => {
					e._globalSaturation = t;
				}
			},
			metadata: b
		}, c, l), D(null, null, u, {
			kind: "field",
			name: "_globalExposure",
			static: !1,
			private: !1,
			access: {
				has: (e) => "_globalExposure" in e,
				get: (e) => e._globalExposure,
				set: (e, t) => {
					e._globalExposure = t;
				}
			},
			metadata: b
		}, d, f), D(null, null, p, {
			kind: "field",
			name: "_highlightsHue",
			static: !1,
			private: !1,
			access: {
				has: (e) => "_highlightsHue" in e,
				get: (e) => e._highlightsHue,
				set: (e, t) => {
					e._highlightsHue = t;
				}
			},
			metadata: b
		}, m, h), D(null, null, g, {
			kind: "field",
			name: "_highlightsDensity",
			static: !1,
			private: !1,
			access: {
				has: (e) => "_highlightsDensity" in e,
				get: (e) => e._highlightsDensity,
				set: (e, t) => {
					e._highlightsDensity = t;
				}
			},
			metadata: b
		}, _, v), D(null, null, y, {
			kind: "field",
			name: "_highlightsSaturation",
			static: !1,
			private: !1,
			access: {
				has: (e) => "_highlightsSaturation" in e,
				get: (e) => e._highlightsSaturation,
				set: (e, t) => {
					e._highlightsSaturation = t;
				}
			},
			metadata: b
		}, x, S), D(null, null, C, {
			kind: "field",
			name: "_highlightsExposure",
			static: !1,
			private: !1,
			access: {
				has: (e) => "_highlightsExposure" in e,
				get: (e) => e._highlightsExposure,
				set: (e, t) => {
					e._highlightsExposure = t;
				}
			},
			metadata: b
		}, w, ee), D(null, null, te, {
			kind: "field",
			name: "_midtonesHue",
			static: !1,
			private: !1,
			access: {
				has: (e) => "_midtonesHue" in e,
				get: (e) => e._midtonesHue,
				set: (e, t) => {
					e._midtonesHue = t;
				}
			},
			metadata: b
		}, ne, O), D(null, null, re, {
			kind: "field",
			name: "_midtonesDensity",
			static: !1,
			private: !1,
			access: {
				has: (e) => "_midtonesDensity" in e,
				get: (e) => e._midtonesDensity,
				set: (e, t) => {
					e._midtonesDensity = t;
				}
			},
			metadata: b
		}, ie, ae), D(null, null, A, {
			kind: "field",
			name: "_midtonesSaturation",
			static: !1,
			private: !1,
			access: {
				has: (e) => "_midtonesSaturation" in e,
				get: (e) => e._midtonesSaturation,
				set: (e, t) => {
					e._midtonesSaturation = t;
				}
			},
			metadata: b
		}, j, M), D(null, null, N, {
			kind: "field",
			name: "_midtonesExposure",
			static: !1,
			private: !1,
			access: {
				has: (e) => "_midtonesExposure" in e,
				get: (e) => e._midtonesExposure,
				set: (e, t) => {
					e._midtonesExposure = t;
				}
			},
			metadata: b
		}, P, oe), b && Object.defineProperty(e, Symbol.metadata, {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: b
		});
	})(), e.PrepareUniforms = we, e;
})();
function Ee(e, t, n = "vCameraColorCurvePositive", r = "vCameraColorCurveNeutral", i = "vCameraColorCurveNegative") {
	e._bind(t, n, r, i);
}
//#endregion
//#region node_modules/@babylonjs/core/Materials/imageProcessingConfiguration.functions.js
function De(e, t) {
	t.WHITEBALANCE && e.push("whiteBalanceMatrix"), t.EXPOSURE && e.push("exposureLinear"), t.CONTRAST && e.push("contrast"), t.COLORGRADING && e.push("colorTransformSettings"), (t.VIGNETTE || t.DITHER) && e.push("vInverseScreenSize"), t.VIGNETTE && (e.push("vignetteSettings1"), e.push("vignetteSettings2")), t.COLORCURVES && we(e), t.DITHER && e.push("ditherIntensity");
}
function Oe(e, t) {
	t.COLORGRADING && e.push("txColorTransform");
}
//#endregion
//#region node_modules/@babylonjs/core/Materials/imageProcessingConfiguration.pure.js
var W = (() => {
	var n;
	let r, i = [], a = [], o, s = [], c = [], u, d = [], f = [], p, m = [], h = [], g, _ = [], v = [], y, x = [], S = [], C, w = [], O = [], re, ie = [], ae = [], A, j = [], M = [], N, P = [], oe = [], se, F = [], ce = [], le, ue = [], I = [], de, L = [], fe = [], pe, me = [], R = [], z, he = [], B = [], _e, V = [], ve = [], H, ye = [], be = [], U, xe = [], Se = [], we, W = [], ke = [], Ae, je = [], G = [], K, q = [], J = [], Y, Me = [], Ne = [], Pe, Fe = [], Ie = [], Le, X = [], Z = [], Re, ze = [], Be = [], Ve, He = [], Ue = [], We, Ge = [], Ke = [], Q, qe = [], Je = [];
	return n = class {
		constructor() {
			this.colorCurves = T(this, i, new Te()), this._colorCurvesEnabled = (T(this, a), T(this, s, !1)), this._colorGradingTexture = (T(this, c), T(this, d, void 0)), this._colorGradingEnabled = (T(this, f), T(this, m, !1)), this._colorGradingWithGreenDepth = (T(this, h), T(this, _, !0)), this._colorGradingBGR = (T(this, v), T(this, x, !0)), this._exposure = (T(this, S), T(this, w, 1)), this._toneMappingEnabled = (T(this, O), T(this, ie, !1)), this._toneMappingType = (T(this, ae), T(this, j, n.TONEMAPPING_STANDARD)), this._contrast = (T(this, M), T(this, P, 1)), this._whiteBalanceEnabled = (T(this, oe), T(this, F, !1)), this._temperature = (T(this, ce), T(this, ue, 6500)), this._tint = (T(this, I), T(this, L, 0)), this._whiteBalanceMatrix = (T(this, fe), null), this._whiteBalanceMatrixTemperature = null, this._whiteBalanceMatrixTint = null, this.vignetteStretch = T(this, me, 0), this.vignetteCenterX = (T(this, R), T(this, he, 0)), this.vignetteCenterY = (T(this, B), T(this, V, 0)), this.vignetteWeight = (T(this, ve), T(this, ye, 1.5)), this.vignetteColor = (T(this, be), T(this, xe, new b(0, 0, 0, 0))), this.vignetteCameraFov = (T(this, Se), T(this, W, .5)), this._vignetteBlendMode = (T(this, ke), T(this, je, n.VIGNETTEMODE_MULTIPLY)), this._vignetteEnabled = (T(this, G), T(this, q, !1)), this._ditheringEnabled = (T(this, J), T(this, Me, !1)), this._ditheringIntensity = (T(this, Ne), T(this, Fe, 1 / 255)), this._skipFinalColorClamp = (T(this, Ie), T(this, X, !1)), this._applyByPostProcess = (T(this, Z), T(this, ze, !1)), this._isEnabled = (T(this, Be), T(this, He, !0)), this.outputTextureWidth = (T(this, Ue), T(this, Ge, 0)), this.outputTextureHeight = (T(this, Ke), T(this, qe, 0)), this.onUpdateParameters = (T(this, Je), new t());
		}
		get colorCurvesEnabled() {
			return this._colorCurvesEnabled;
		}
		set colorCurvesEnabled(e) {
			this._colorCurvesEnabled !== e && (this._colorCurvesEnabled = e, this._updateParameters());
		}
		get colorGradingTexture() {
			return this._colorGradingTexture;
		}
		set colorGradingTexture(e) {
			this._colorGradingTexture !== e && (this._colorGradingTexture = e, this._updateParameters());
		}
		get colorGradingEnabled() {
			return this._colorGradingEnabled;
		}
		set colorGradingEnabled(e) {
			this._colorGradingEnabled !== e && (this._colorGradingEnabled = e, this._updateParameters());
		}
		get colorGradingWithGreenDepth() {
			return this._colorGradingWithGreenDepth;
		}
		set colorGradingWithGreenDepth(e) {
			this._colorGradingWithGreenDepth !== e && (this._colorGradingWithGreenDepth = e, this._updateParameters());
		}
		get colorGradingBGR() {
			return this._colorGradingBGR;
		}
		set colorGradingBGR(e) {
			this._colorGradingBGR !== e && (this._colorGradingBGR = e, this._updateParameters());
		}
		get exposure() {
			return this._exposure;
		}
		set exposure(e) {
			this._exposure !== e && (this._exposure = e, this._updateParameters());
		}
		get toneMappingEnabled() {
			return this._toneMappingEnabled;
		}
		set toneMappingEnabled(e) {
			this._toneMappingEnabled !== e && (this._toneMappingEnabled = e, this._updateParameters());
		}
		get toneMappingType() {
			return this._toneMappingType;
		}
		set toneMappingType(e) {
			this._toneMappingType !== e && (this._toneMappingType = e, this._updateParameters());
		}
		get contrast() {
			return this._contrast;
		}
		set contrast(e) {
			this._contrast !== e && (this._contrast = e, this._updateParameters());
		}
		get whiteBalanceEnabled() {
			return this._whiteBalanceEnabled;
		}
		set whiteBalanceEnabled(e) {
			this._whiteBalanceEnabled !== e && (this._whiteBalanceEnabled = e, this._updateParameters());
		}
		get temperature() {
			return this._temperature;
		}
		set temperature(e) {
			e = Number.isNaN(e) ? ge : Math.max(e, ge), this._temperature !== e && (this._temperature = e, this._updateParameters());
		}
		get tint() {
			return this._tint;
		}
		set tint(t) {
			t = e(t, -150, 150), this._tint !== t && (this._tint = t, this._updateParameters());
		}
		_getWhiteBalanceMatrix() {
			return (this._whiteBalanceMatrix === null || this._whiteBalanceMatrixTemperature !== this._temperature || this._whiteBalanceMatrixTint !== this._tint) && (this._whiteBalanceMatrixTemperature = this._temperature, this._whiteBalanceMatrixTint = this._tint, this._whiteBalanceMatrix = Ce(this._temperature, this._tint)), this._whiteBalanceMatrix;
		}
		get vignetteCentreY() {
			return this.vignetteCenterY;
		}
		set vignetteCentreY(e) {
			this.vignetteCenterY = e;
		}
		get vignetteCentreX() {
			return this.vignetteCenterX;
		}
		set vignetteCentreX(e) {
			this.vignetteCenterX = e;
		}
		get vignetteBlendMode() {
			return this._vignetteBlendMode;
		}
		set vignetteBlendMode(e) {
			this._vignetteBlendMode !== e && (this._vignetteBlendMode = e, this._updateParameters());
		}
		get vignetteEnabled() {
			return this._vignetteEnabled;
		}
		set vignetteEnabled(e) {
			this._vignetteEnabled !== e && (this._vignetteEnabled = e, this._updateParameters());
		}
		get ditheringEnabled() {
			return this._ditheringEnabled;
		}
		set ditheringEnabled(e) {
			this._ditheringEnabled !== e && (this._ditheringEnabled = e, this._updateParameters());
		}
		get ditheringIntensity() {
			return this._ditheringIntensity;
		}
		set ditheringIntensity(e) {
			this._ditheringIntensity !== e && (this._ditheringIntensity = e, this._updateParameters());
		}
		get skipFinalColorClamp() {
			return this._skipFinalColorClamp;
		}
		set skipFinalColorClamp(e) {
			this._skipFinalColorClamp !== e && (this._skipFinalColorClamp = e, this._updateParameters());
		}
		get applyByPostProcess() {
			return this._applyByPostProcess;
		}
		set applyByPostProcess(e) {
			this._applyByPostProcess !== e && (this._applyByPostProcess = e, this._updateParameters());
		}
		get isEnabled() {
			return this._isEnabled;
		}
		set isEnabled(e) {
			this._isEnabled !== e && (this._isEnabled = e, this._updateParameters());
		}
		_updateParameters() {
			this.onUpdateParameters.notifyObservers(this);
		}
		getClassName() {
			return "ImageProcessingConfiguration";
		}
		prepareDefines(e, t = !1) {
			if (t !== this.applyByPostProcess || !this._isEnabled) e.WHITEBALANCE = !1, e.VIGNETTE = !1, e.TONEMAPPING = 0, e.CONTRAST = !1, e.EXPOSURE = !1, e.COLORCURVES = !1, e.COLORGRADING = !1, e.COLORGRADING3D = !1, e.DITHER = !1, e.IMAGEPROCESSING = !1, e.SKIPFINALCOLORCLAMP = this.skipFinalColorClamp, e.IMAGEPROCESSINGPOSTPROCESS = this.applyByPostProcess && this._isEnabled;
			else {
				if (e.WHITEBALANCE = this._whiteBalanceEnabled, e.VIGNETTE = this.vignetteEnabled, e.VIGNETTEBLENDMODEMULTIPLY = this.vignetteBlendMode === n._VIGNETTEMODE_MULTIPLY, e.VIGNETTEBLENDMODEOPAQUE = !e.VIGNETTEBLENDMODEMULTIPLY, !this._toneMappingEnabled) e.TONEMAPPING = 0;
				else switch (this._toneMappingType) {
					case n.TONEMAPPING_KHR_PBR_NEUTRAL:
						e.TONEMAPPING = 3;
						break;
					case n.TONEMAPPING_ACES:
						e.TONEMAPPING = 2;
						break;
					default: e.TONEMAPPING = 1;
				}
				e.CONTRAST = this.contrast !== 1, e.EXPOSURE = this.exposure !== 1, e.COLORCURVES = this.colorCurvesEnabled && !!this.colorCurves, e.COLORGRADING = this.colorGradingEnabled && !!this.colorGradingTexture, e.COLORGRADING3D = e.COLORGRADING ? this.colorGradingTexture.is3D : !1, e.SAMPLER3DGREENDEPTH = this.colorGradingWithGreenDepth, e.SAMPLER3DBGRMAP = this.colorGradingBGR, e.DITHER = this._ditheringEnabled, e.IMAGEPROCESSINGPOSTPROCESS = this.applyByPostProcess, e.SKIPFINALCOLORCLAMP = this.skipFinalColorClamp, e.IMAGEPROCESSING = e.WHITEBALANCE || e.VIGNETTE || !!e.TONEMAPPING || e.CONTRAST || e.EXPOSURE || e.COLORCURVES || e.COLORGRADING || e.DITHER;
			}
		}
		isReady() {
			return !this.colorGradingEnabled || !this.colorGradingTexture || this.colorGradingTexture.isReady();
		}
		bind(e, t) {
			if (this._whiteBalanceEnabled && e.setMatrix3x3("whiteBalanceMatrix", this._getWhiteBalanceMatrix()), this._colorCurvesEnabled && this.colorCurves && Ee(this.colorCurves, e), this._vignetteEnabled || this._ditheringEnabled) {
				let n = 1 / (this.outputTextureWidth || e.getEngine().getRenderWidth()), r = 1 / (this.outputTextureHeight || e.getEngine().getRenderHeight());
				if (e.setFloat2("vInverseScreenSize", n, r), this._ditheringEnabled && e.setFloat("ditherIntensity", .5 * this._ditheringIntensity), this._vignetteEnabled) {
					let i = t ?? r / n, a = Math.tan(this.vignetteCameraFov * .5), o = a * i, s = Math.sqrt(o * a);
					o = l(o, s, this.vignetteStretch), a = l(a, s, this.vignetteStretch), e.setFloat4("vignetteSettings1", o, a, -o * this.vignetteCenterX, -a * this.vignetteCenterY);
					let c = -2 * this.vignetteWeight;
					e.setFloat4("vignetteSettings2", this.vignetteColor.r, this.vignetteColor.g, this.vignetteColor.b, c);
				}
			}
			if (e.setFloat("exposureLinear", this.exposure), e.setFloat("contrast", this.contrast), this.colorGradingTexture) {
				e.setTexture("txColorTransform", this.colorGradingTexture);
				let t = this.colorGradingTexture.getSize().height;
				e.setFloat4("colorTransformSettings", (t - 1) / t, .5 / t, t, this.colorGradingTexture.level);
			}
		}
		clone() {
			return k.Clone(() => new n(), this);
		}
		serialize() {
			return k.Serialize(this);
		}
		static get VIGNETTEMODE_MULTIPLY() {
			return this._VIGNETTEMODE_MULTIPLY;
		}
		static get VIGNETTEMODE_OPAQUE() {
			return this._VIGNETTEMODE_OPAQUE;
		}
	}, (() => {
		let e = typeof Symbol == "function" && Symbol.metadata ? Object.create(null) : void 0;
		r = [ne()], o = [E()], u = [ee("colorGradingTexture")], p = [E()], g = [E()], y = [E()], C = [E()], re = [E()], A = [E()], N = [E()], se = [E()], le = [E()], de = [E()], pe = [E()], z = [E()], _e = [E()], H = [E()], U = [te()], we = [E()], Ae = [E()], K = [E()], Y = [E()], Pe = [E()], Le = [E()], Re = [E()], Ve = [E()], We = [E()], Q = [E()], D(null, null, r, {
			kind: "field",
			name: "colorCurves",
			static: !1,
			private: !1,
			access: {
				has: (e) => "colorCurves" in e,
				get: (e) => e.colorCurves,
				set: (e, t) => {
					e.colorCurves = t;
				}
			},
			metadata: e
		}, i, a), D(null, null, o, {
			kind: "field",
			name: "_colorCurvesEnabled",
			static: !1,
			private: !1,
			access: {
				has: (e) => "_colorCurvesEnabled" in e,
				get: (e) => e._colorCurvesEnabled,
				set: (e, t) => {
					e._colorCurvesEnabled = t;
				}
			},
			metadata: e
		}, s, c), D(null, null, u, {
			kind: "field",
			name: "_colorGradingTexture",
			static: !1,
			private: !1,
			access: {
				has: (e) => "_colorGradingTexture" in e,
				get: (e) => e._colorGradingTexture,
				set: (e, t) => {
					e._colorGradingTexture = t;
				}
			},
			metadata: e
		}, d, f), D(null, null, p, {
			kind: "field",
			name: "_colorGradingEnabled",
			static: !1,
			private: !1,
			access: {
				has: (e) => "_colorGradingEnabled" in e,
				get: (e) => e._colorGradingEnabled,
				set: (e, t) => {
					e._colorGradingEnabled = t;
				}
			},
			metadata: e
		}, m, h), D(null, null, g, {
			kind: "field",
			name: "_colorGradingWithGreenDepth",
			static: !1,
			private: !1,
			access: {
				has: (e) => "_colorGradingWithGreenDepth" in e,
				get: (e) => e._colorGradingWithGreenDepth,
				set: (e, t) => {
					e._colorGradingWithGreenDepth = t;
				}
			},
			metadata: e
		}, _, v), D(null, null, y, {
			kind: "field",
			name: "_colorGradingBGR",
			static: !1,
			private: !1,
			access: {
				has: (e) => "_colorGradingBGR" in e,
				get: (e) => e._colorGradingBGR,
				set: (e, t) => {
					e._colorGradingBGR = t;
				}
			},
			metadata: e
		}, x, S), D(null, null, C, {
			kind: "field",
			name: "_exposure",
			static: !1,
			private: !1,
			access: {
				has: (e) => "_exposure" in e,
				get: (e) => e._exposure,
				set: (e, t) => {
					e._exposure = t;
				}
			},
			metadata: e
		}, w, O), D(null, null, re, {
			kind: "field",
			name: "_toneMappingEnabled",
			static: !1,
			private: !1,
			access: {
				has: (e) => "_toneMappingEnabled" in e,
				get: (e) => e._toneMappingEnabled,
				set: (e, t) => {
					e._toneMappingEnabled = t;
				}
			},
			metadata: e
		}, ie, ae), D(null, null, A, {
			kind: "field",
			name: "_toneMappingType",
			static: !1,
			private: !1,
			access: {
				has: (e) => "_toneMappingType" in e,
				get: (e) => e._toneMappingType,
				set: (e, t) => {
					e._toneMappingType = t;
				}
			},
			metadata: e
		}, j, M), D(null, null, N, {
			kind: "field",
			name: "_contrast",
			static: !1,
			private: !1,
			access: {
				has: (e) => "_contrast" in e,
				get: (e) => e._contrast,
				set: (e, t) => {
					e._contrast = t;
				}
			},
			metadata: e
		}, P, oe), D(null, null, se, {
			kind: "field",
			name: "_whiteBalanceEnabled",
			static: !1,
			private: !1,
			access: {
				has: (e) => "_whiteBalanceEnabled" in e,
				get: (e) => e._whiteBalanceEnabled,
				set: (e, t) => {
					e._whiteBalanceEnabled = t;
				}
			},
			metadata: e
		}, F, ce), D(null, null, le, {
			kind: "field",
			name: "_temperature",
			static: !1,
			private: !1,
			access: {
				has: (e) => "_temperature" in e,
				get: (e) => e._temperature,
				set: (e, t) => {
					e._temperature = t;
				}
			},
			metadata: e
		}, ue, I), D(null, null, de, {
			kind: "field",
			name: "_tint",
			static: !1,
			private: !1,
			access: {
				has: (e) => "_tint" in e,
				get: (e) => e._tint,
				set: (e, t) => {
					e._tint = t;
				}
			},
			metadata: e
		}, L, fe), D(null, null, pe, {
			kind: "field",
			name: "vignetteStretch",
			static: !1,
			private: !1,
			access: {
				has: (e) => "vignetteStretch" in e,
				get: (e) => e.vignetteStretch,
				set: (e, t) => {
					e.vignetteStretch = t;
				}
			},
			metadata: e
		}, me, R), D(null, null, z, {
			kind: "field",
			name: "vignetteCenterX",
			static: !1,
			private: !1,
			access: {
				has: (e) => "vignetteCenterX" in e,
				get: (e) => e.vignetteCenterX,
				set: (e, t) => {
					e.vignetteCenterX = t;
				}
			},
			metadata: e
		}, he, B), D(null, null, _e, {
			kind: "field",
			name: "vignetteCenterY",
			static: !1,
			private: !1,
			access: {
				has: (e) => "vignetteCenterY" in e,
				get: (e) => e.vignetteCenterY,
				set: (e, t) => {
					e.vignetteCenterY = t;
				}
			},
			metadata: e
		}, V, ve), D(null, null, H, {
			kind: "field",
			name: "vignetteWeight",
			static: !1,
			private: !1,
			access: {
				has: (e) => "vignetteWeight" in e,
				get: (e) => e.vignetteWeight,
				set: (e, t) => {
					e.vignetteWeight = t;
				}
			},
			metadata: e
		}, ye, be), D(null, null, U, {
			kind: "field",
			name: "vignetteColor",
			static: !1,
			private: !1,
			access: {
				has: (e) => "vignetteColor" in e,
				get: (e) => e.vignetteColor,
				set: (e, t) => {
					e.vignetteColor = t;
				}
			},
			metadata: e
		}, xe, Se), D(null, null, we, {
			kind: "field",
			name: "vignetteCameraFov",
			static: !1,
			private: !1,
			access: {
				has: (e) => "vignetteCameraFov" in e,
				get: (e) => e.vignetteCameraFov,
				set: (e, t) => {
					e.vignetteCameraFov = t;
				}
			},
			metadata: e
		}, W, ke), D(null, null, Ae, {
			kind: "field",
			name: "_vignetteBlendMode",
			static: !1,
			private: !1,
			access: {
				has: (e) => "_vignetteBlendMode" in e,
				get: (e) => e._vignetteBlendMode,
				set: (e, t) => {
					e._vignetteBlendMode = t;
				}
			},
			metadata: e
		}, je, G), D(null, null, K, {
			kind: "field",
			name: "_vignetteEnabled",
			static: !1,
			private: !1,
			access: {
				has: (e) => "_vignetteEnabled" in e,
				get: (e) => e._vignetteEnabled,
				set: (e, t) => {
					e._vignetteEnabled = t;
				}
			},
			metadata: e
		}, q, J), D(null, null, Y, {
			kind: "field",
			name: "_ditheringEnabled",
			static: !1,
			private: !1,
			access: {
				has: (e) => "_ditheringEnabled" in e,
				get: (e) => e._ditheringEnabled,
				set: (e, t) => {
					e._ditheringEnabled = t;
				}
			},
			metadata: e
		}, Me, Ne), D(null, null, Pe, {
			kind: "field",
			name: "_ditheringIntensity",
			static: !1,
			private: !1,
			access: {
				has: (e) => "_ditheringIntensity" in e,
				get: (e) => e._ditheringIntensity,
				set: (e, t) => {
					e._ditheringIntensity = t;
				}
			},
			metadata: e
		}, Fe, Ie), D(null, null, Le, {
			kind: "field",
			name: "_skipFinalColorClamp",
			static: !1,
			private: !1,
			access: {
				has: (e) => "_skipFinalColorClamp" in e,
				get: (e) => e._skipFinalColorClamp,
				set: (e, t) => {
					e._skipFinalColorClamp = t;
				}
			},
			metadata: e
		}, X, Z), D(null, null, Re, {
			kind: "field",
			name: "_applyByPostProcess",
			static: !1,
			private: !1,
			access: {
				has: (e) => "_applyByPostProcess" in e,
				get: (e) => e._applyByPostProcess,
				set: (e, t) => {
					e._applyByPostProcess = t;
				}
			},
			metadata: e
		}, ze, Be), D(null, null, Ve, {
			kind: "field",
			name: "_isEnabled",
			static: !1,
			private: !1,
			access: {
				has: (e) => "_isEnabled" in e,
				get: (e) => e._isEnabled,
				set: (e, t) => {
					e._isEnabled = t;
				}
			},
			metadata: e
		}, He, Ue), D(null, null, We, {
			kind: "field",
			name: "outputTextureWidth",
			static: !1,
			private: !1,
			access: {
				has: (e) => "outputTextureWidth" in e,
				get: (e) => e.outputTextureWidth,
				set: (e, t) => {
					e.outputTextureWidth = t;
				}
			},
			metadata: e
		}, Ge, Ke), D(null, null, Q, {
			kind: "field",
			name: "outputTextureHeight",
			static: !1,
			private: !1,
			access: {
				has: (e) => "outputTextureHeight" in e,
				get: (e) => e.outputTextureHeight,
				set: (e, t) => {
					e.outputTextureHeight = t;
				}
			},
			metadata: e
		}, qe, Je), e && Object.defineProperty(n, Symbol.metadata, {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: e
		});
	})(), n.TONEMAPPING_STANDARD = 0, n.TONEMAPPING_ACES = 1, n.TONEMAPPING_KHR_PBR_NEUTRAL = 2, n.PrepareUniforms = De, n.PrepareSamplers = Oe, n._VIGNETTEMODE_MULTIPLY = 0, n._VIGNETTEMODE_OPAQUE = 1, n;
})(), ke = !1;
function Ae(e) {
	let t = k.Parse(() => new W(), e, null, null);
	return e.vignetteCentreX !== void 0 && (t.vignetteCenterX = e.vignetteCentreX), e.vignetteCentreY !== void 0 && (t.vignetteCenterY = e.vignetteCentreY), t;
}
function je() {
	ke || (ke = !0, W.Parse = Ae, k._ImageProcessingConfigurationParser = Ae, C("BABYLON.ImageProcessingConfiguration", W));
}
//#endregion
//#region node_modules/@babylonjs/core/Collisions/pickingInfo.js
var G = class {
	constructor() {
		this.hit = !1, this.distance = 0, this.pickedPoint = null, this.pickedMesh = null, this.bu = 0, this.bv = 0, this.faceId = -1, this.subMeshFaceId = -1, this.subMeshId = 0, this.pickedSprite = null, this.thinInstanceIndex = -1, this.ray = null, this.originMesh = null, this.aimTransform = null, this.gripTransform = null;
	}
	getNormal(e = !1, t = !0) {
		if (!this.pickedMesh || t && !this.pickedMesh.isVerticesDataPresent(m.NormalKind)) return null;
		let n = this.pickedMesh.getIndices();
		n?.length === 0 && (n = null);
		let r, i = g.Vector3[0], a = g.Vector3[1], o = g.Vector3[2];
		if (t) {
			let e = this.pickedMesh.getVerticesData(m.NormalKind), t = n ? S.FromArrayToRef(e, n[this.faceId * 3] * 3, i) : i.copyFromFloats(e[this.faceId * 3 * 3], e[this.faceId * 3 * 3 + 1], e[this.faceId * 3 * 3 + 2]), s = n ? S.FromArrayToRef(e, n[this.faceId * 3 + 1] * 3, a) : a.copyFromFloats(e[(this.faceId * 3 + 1) * 3], e[(this.faceId * 3 + 1) * 3 + 1], e[(this.faceId * 3 + 1) * 3 + 2]), c = n ? S.FromArrayToRef(e, n[this.faceId * 3 + 2] * 3, o) : o.copyFromFloats(e[(this.faceId * 3 + 2) * 3], e[(this.faceId * 3 + 2) * 3 + 1], e[(this.faceId * 3 + 2) * 3 + 2]);
			t = t.scale(this.bu), s = s.scale(this.bv), c = c.scale(1 - this.bu - this.bv), r = new S(t.x + s.x + c.x, t.y + s.y + c.y, t.z + s.z + c.z);
		} else {
			let e = this.pickedMesh.getVerticesData(m.PositionKind), t = n ? S.FromArrayToRef(e, n[this.faceId * 3] * 3, i) : i.copyFromFloats(e[this.faceId * 3 * 3], e[this.faceId * 3 * 3 + 1], e[this.faceId * 3 * 3 + 2]), s = n ? S.FromArrayToRef(e, n[this.faceId * 3 + 1] * 3, a) : a.copyFromFloats(e[(this.faceId * 3 + 1) * 3], e[(this.faceId * 3 + 1) * 3 + 1], e[(this.faceId * 3 + 1) * 3 + 2]), c = n ? S.FromArrayToRef(e, n[this.faceId * 3 + 2] * 3, o) : o.copyFromFloats(e[(this.faceId * 3 + 2) * 3], e[(this.faceId * 3 + 2) * 3 + 1], e[(this.faceId * 3 + 2) * 3 + 2]), l = t.subtract(s), u = c.subtract(s);
			r = S.Cross(l, u);
		}
		let s = (e, t) => {
			if (this.thinInstanceIndex !== -1) {
				let n = e._thinInstanceDataStorage.matrixData, r = this.thinInstanceIndex << 4;
				if (n && n.length > r) {
					let e = g.Matrix[0];
					h.FromArrayToRef(n, r, e), S.TransformNormalToRef(t, e, t);
				}
			}
			let n = e.getWorldMatrix();
			e.nonUniformScaling && (g.Matrix[0].copyFrom(n), n = g.Matrix[0], n.setTranslationFromFloats(0, 0, 0), n.invert(), n.transposeToRef(g.Matrix[1]), n = g.Matrix[1]), S.TransformNormalToRef(t, n, t);
		};
		if (e && s(this.pickedMesh, r), this.ray) {
			let t = g.Vector3[0].copyFrom(r);
			e || s(this.pickedMesh, t), S.Dot(t, this.ray.direction) > 0 && r.negateInPlace();
		}
		return r.normalize(), r;
	}
	getTextureCoordinates(e = m.UVKind) {
		if (!this.pickedMesh || !this.pickedMesh.isVerticesDataPresent(e)) return null;
		let t = this.pickedMesh.getIndices();
		if (!t) return null;
		let n = this.pickedMesh.getVerticesData(e);
		if (!n) return null;
		let r = y.FromArray(n, t[this.faceId * 3] * 2), i = y.FromArray(n, t[this.faceId * 3 + 1] * 2), a = y.FromArray(n, t[this.faceId * 3 + 2] * 2);
		return r = r.scale(this.bu), i = i.scale(this.bv), a = a.scale(1 - this.bu - this.bv), new y(r.x + i.x + a.x, r.y + i.y + a.y);
	}
}, K = class e {
	constructor(e, t, n, r, i, a) {
		this.source = e, this.pointerX = t, this.pointerY = n, this.meshUnderPointer = r, this.sourceEvent = i, this.additionalData = a;
	}
	static CreateNew(t, n, r) {
		let i = t.getScene();
		return new e(t, i.pointerX, i.pointerY, i.meshUnderPointer || t, n, r);
	}
	static CreateNewFromSprite(t, n, r, i) {
		return new e(t, n.pointerX, n.pointerY, n.meshUnderPointer, r, i);
	}
	static CreateNewFromScene(t, n) {
		return new e(null, t.pointerX, t.pointerY, t.meshUnderPointer, n);
	}
	static CreateNewFromPrimitive(t, n, r, i) {
		return new e(t, n.x, n.y, null, r, i);
	}
}, q = class e {
	constructor() {
		this.hoverCursor = "", this.actions = [], this.isRecursive = !1, this.disposeWhenUnowned = !0;
	}
	static get HasTriggers() {
		for (let t in e.Triggers) if (Object.prototype.hasOwnProperty.call(e.Triggers, t)) return !0;
		return !1;
	}
	static get HasPickTriggers() {
		for (let t in e.Triggers) if (Object.prototype.hasOwnProperty.call(e.Triggers, t)) {
			let e = parseInt(t);
			if (e >= 1 && e <= 7) return !0;
		}
		return !1;
	}
	static HasSpecificTrigger(t) {
		for (let n in e.Triggers) if (Object.prototype.hasOwnProperty.call(e.Triggers, n) && parseInt(n) === t) return !0;
		return !1;
	}
};
q.Triggers = {};
//#endregion
//#region node_modules/@babylonjs/core/DeviceInput/InputDevices/deviceEnums.js
var J;
(function(e) {
	e[e.Generic = 0] = "Generic", e[e.Keyboard = 1] = "Keyboard", e[e.Mouse = 2] = "Mouse", e[e.Touch = 3] = "Touch", e[e.DualShock = 4] = "DualShock", e[e.Xbox = 5] = "Xbox", e[e.Switch = 6] = "Switch", e[e.DualSense = 7] = "DualSense";
})(J ||= {});
var Y;
(function(e) {
	e[e.Horizontal = 0] = "Horizontal", e[e.Vertical = 1] = "Vertical", e[e.LeftClick = 2] = "LeftClick", e[e.MiddleClick = 3] = "MiddleClick", e[e.RightClick = 4] = "RightClick", e[e.BrowserBack = 5] = "BrowserBack", e[e.BrowserForward = 6] = "BrowserForward", e[e.MouseWheelX = 7] = "MouseWheelX", e[e.MouseWheelY = 8] = "MouseWheelY", e[e.MouseWheelZ = 9] = "MouseWheelZ", e[e.Move = 12] = "Move";
})(Y ||= {});
var Me;
(function(e) {
	e[e.Horizontal = 0] = "Horizontal", e[e.Vertical = 1] = "Vertical", e[e.LeftClick = 2] = "LeftClick", e[e.MiddleClick = 3] = "MiddleClick", e[e.RightClick = 4] = "RightClick", e[e.BrowserBack = 5] = "BrowserBack", e[e.BrowserForward = 6] = "BrowserForward", e[e.MouseWheelX = 7] = "MouseWheelX", e[e.MouseWheelY = 8] = "MouseWheelY", e[e.MouseWheelZ = 9] = "MouseWheelZ", e[e.DeltaHorizontal = 10] = "DeltaHorizontal", e[e.DeltaVertical = 11] = "DeltaVertical";
})(Me ||= {});
var Ne;
(function(e) {
	e[e.Cross = 0] = "Cross", e[e.Circle = 1] = "Circle", e[e.Square = 2] = "Square", e[e.Triangle = 3] = "Triangle", e[e.L1 = 4] = "L1", e[e.R1 = 5] = "R1", e[e.L2 = 6] = "L2", e[e.R2 = 7] = "R2", e[e.Share = 8] = "Share", e[e.Options = 9] = "Options", e[e.L3 = 10] = "L3", e[e.R3 = 11] = "R3", e[e.DPadUp = 12] = "DPadUp", e[e.DPadDown = 13] = "DPadDown", e[e.DPadLeft = 14] = "DPadLeft", e[e.DPadRight = 15] = "DPadRight", e[e.Home = 16] = "Home", e[e.TouchPad = 17] = "TouchPad", e[e.LStickXAxis = 18] = "LStickXAxis", e[e.LStickYAxis = 19] = "LStickYAxis", e[e.RStickXAxis = 20] = "RStickXAxis", e[e.RStickYAxis = 21] = "RStickYAxis";
})(Ne ||= {});
var Pe;
(function(e) {
	e[e.Cross = 0] = "Cross", e[e.Circle = 1] = "Circle", e[e.Square = 2] = "Square", e[e.Triangle = 3] = "Triangle", e[e.L1 = 4] = "L1", e[e.R1 = 5] = "R1", e[e.L2 = 6] = "L2", e[e.R2 = 7] = "R2", e[e.Create = 8] = "Create", e[e.Options = 9] = "Options", e[e.L3 = 10] = "L3", e[e.R3 = 11] = "R3", e[e.DPadUp = 12] = "DPadUp", e[e.DPadDown = 13] = "DPadDown", e[e.DPadLeft = 14] = "DPadLeft", e[e.DPadRight = 15] = "DPadRight", e[e.Home = 16] = "Home", e[e.TouchPad = 17] = "TouchPad", e[e.LStickXAxis = 18] = "LStickXAxis", e[e.LStickYAxis = 19] = "LStickYAxis", e[e.RStickXAxis = 20] = "RStickXAxis", e[e.RStickYAxis = 21] = "RStickYAxis";
})(Pe ||= {});
var Fe;
(function(e) {
	e[e.A = 0] = "A", e[e.B = 1] = "B", e[e.X = 2] = "X", e[e.Y = 3] = "Y", e[e.LB = 4] = "LB", e[e.RB = 5] = "RB", e[e.LT = 6] = "LT", e[e.RT = 7] = "RT", e[e.Back = 8] = "Back", e[e.Start = 9] = "Start", e[e.LS = 10] = "LS", e[e.RS = 11] = "RS", e[e.DPadUp = 12] = "DPadUp", e[e.DPadDown = 13] = "DPadDown", e[e.DPadLeft = 14] = "DPadLeft", e[e.DPadRight = 15] = "DPadRight", e[e.Home = 16] = "Home", e[e.LStickXAxis = 17] = "LStickXAxis", e[e.LStickYAxis = 18] = "LStickYAxis", e[e.RStickXAxis = 19] = "RStickXAxis", e[e.RStickYAxis = 20] = "RStickYAxis";
})(Fe ||= {});
var Ie;
(function(e) {
	e[e.B = 0] = "B", e[e.A = 1] = "A", e[e.Y = 2] = "Y", e[e.X = 3] = "X", e[e.L = 4] = "L", e[e.R = 5] = "R", e[e.ZL = 6] = "ZL", e[e.ZR = 7] = "ZR", e[e.Minus = 8] = "Minus", e[e.Plus = 9] = "Plus", e[e.LS = 10] = "LS", e[e.RS = 11] = "RS", e[e.DPadUp = 12] = "DPadUp", e[e.DPadDown = 13] = "DPadDown", e[e.DPadLeft = 14] = "DPadLeft", e[e.DPadRight = 15] = "DPadRight", e[e.Home = 16] = "Home", e[e.Capture = 17] = "Capture", e[e.LStickXAxis = 18] = "LStickXAxis", e[e.LStickYAxis = 19] = "LStickYAxis", e[e.RStickXAxis = 20] = "RStickXAxis", e[e.RStickYAxis = 21] = "RStickYAxis";
})(Ie ||= {});
//#endregion
//#region node_modules/@babylonjs/core/Events/deviceInputEvents.js
var Le;
(function(e) {
	e[e.PointerMove = 0] = "PointerMove", e[e.PointerDown = 1] = "PointerDown", e[e.PointerUp = 2] = "PointerUp";
})(Le ||= {});
var X = class {};
X.DOM_DELTA_PIXEL = 0, X.DOM_DELTA_LINE = 1, X.DOM_DELTA_PAGE = 2;
//#endregion
//#region node_modules/@babylonjs/core/DeviceInput/eventFactory.js
var Z = class {
	static CreateDeviceEvent(e, t, n, r, i, a, o) {
		switch (e) {
			case J.Keyboard: return this._CreateKeyboardEvent(n, r, i, a);
			case J.Mouse: if (n === Y.MouseWheelX || n === Y.MouseWheelY || n === Y.MouseWheelZ) return this._CreateWheelEvent(e, t, n, r, i, a);
			case J.Touch: return this._CreatePointerEvent(e, t, n, r, i, a, o);
			default: throw `Unable to generate event for device ${J[e]}`;
		}
	}
	static _CreatePointerEvent(e, t, n, r, i, a, o) {
		let s = this._CreateMouseEvent(e, t, n, r, i, a);
		e === J.Mouse ? (s.deviceType = J.Mouse, s.pointerId = 1, s.pointerType = "mouse") : (s.deviceType = J.Touch, s.pointerId = o ?? t, s.pointerType = "touch");
		let c = 0;
		return c += i.pollInput(e, t, Y.LeftClick), c += i.pollInput(e, t, Y.RightClick) * 2, c += i.pollInput(e, t, Y.MiddleClick) * 4, s.buttons = c, n === Y.Move ? s.type = "pointermove" : n >= Y.LeftClick && n <= Y.RightClick && (s.type = r === 1 ? "pointerdown" : "pointerup", s.button = n - 2), s;
	}
	static _CreateWheelEvent(e, t, n, r, i, a) {
		let o = this._CreateMouseEvent(e, t, n, r, i, a);
		switch (o.pointerId = 1, o.type = "wheel", o.deltaMode = X.DOM_DELTA_PIXEL, o.deltaX = 0, o.deltaY = 0, o.deltaZ = 0, n) {
			case Y.MouseWheelX:
				o.deltaX = r;
				break;
			case Y.MouseWheelY:
				o.deltaY = r;
				break;
			case Y.MouseWheelZ: o.deltaZ = r;
		}
		return o;
	}
	static _CreateMouseEvent(e, t, n, r, i, a) {
		let o = this._CreateEvent(a), s = i.pollInput(e, t, Y.Horizontal), c = i.pollInput(e, t, Y.Vertical);
		return a ? (o.movementX = 0, o.movementY = 0, o.offsetX = o.movementX - a.getBoundingClientRect().x, o.offsetY = o.movementY - a.getBoundingClientRect().y) : (o.movementX = i.pollInput(e, t, 10), o.movementY = i.pollInput(e, t, 11), o.offsetX = 0, o.offsetY = 0), this._CheckNonCharacterKeys(o, i), o.clientX = s, o.clientY = c, o.x = s, o.y = c, o.deviceType = e, o.deviceSlot = t, o.inputIndex = n, o;
	}
	static _CreateKeyboardEvent(e, t, n, r) {
		let i = this._CreateEvent(r);
		return this._CheckNonCharacterKeys(i, n), i.deviceType = J.Keyboard, i.deviceSlot = 0, i.inputIndex = e, i.type = t === 1 ? "keydown" : "keyup", i.key = String.fromCharCode(e), i.keyCode = e, i;
	}
	static _CheckNonCharacterKeys(e, t) {
		let n = t.isDeviceAvailable(J.Keyboard), r = n && t.pollInput(J.Keyboard, 0, 18) === 1, i = n && t.pollInput(J.Keyboard, 0, 17) === 1, a = n && (t.pollInput(J.Keyboard, 0, 91) === 1 || t.pollInput(J.Keyboard, 0, 92) === 1 || t.pollInput(J.Keyboard, 0, 93) === 1), o = n && t.pollInput(J.Keyboard, 0, 16) === 1;
		e.altKey = r, e.ctrlKey = i, e.metaKey = a, e.shiftKey = o;
	}
	static _CreateEvent(e) {
		let t = {};
		return t.preventDefault = () => {}, t.target = e, t;
	}
}, Re = class {
	constructor(e, t, n) {
		this._nativeInput = _native.DeviceInputSystem ? new _native.DeviceInputSystem(e, t, (e, t, r, i) => {
			n(e, t, Z.CreateDeviceEvent(e, t, r, i, this));
		}) : this._createDummyNativeInput();
	}
	pollInput(e, t, n) {
		return this._nativeInput.pollInput(e, t, n);
	}
	isDeviceAvailable(e) {
		return e === J.Mouse || e === J.Touch;
	}
	dispose() {
		this._nativeInput.dispose();
	}
	_createDummyNativeInput() {
		return {
			pollInput: () => 0,
			isDeviceAvailable: () => !1,
			dispose: () => {}
		};
	}
}, ze = 255, Be = Object.keys(Y).length / 2, Ve = class {
	constructor(e, t, n, r) {
		this._inputs = [], this._keyboardActive = !1, this._pointerActive = !1, this._usingSafari = A.IsSafari(), this._usingMacOs = a() && /(Mac|iPhone|iPod|iPad)/i.test(navigator.platform), this._keyboardDownEvent = (e) => {}, this._keyboardUpEvent = (e) => {}, this._keyboardBlurEvent = (e) => {}, this._pointerMoveEvent = (e) => {}, this._pointerDownEvent = (e) => {}, this._pointerUpEvent = (e) => {}, this._pointerCancelEvent = (e) => {}, this._pointerCancelTouch = (e) => {}, this._pointerLeaveEvent = (e) => {}, this._pointerWheelEvent = (e) => {}, this._pointerBlurEvent = (e) => {}, this._pointerMacOsChromeOutEvent = (e) => {}, this._eventsAttached = !1, this._mouseId = -1, this._isUsingFirefox = a() && navigator.userAgent && navigator.userAgent.indexOf("Firefox") !== -1, this._isUsingChromium = a() && navigator.userAgent && navigator.userAgent.indexOf("Chrome") !== -1, this._maxTouchPoints = 0, this._pointerInputClearObserver = null, this._gamepadConnectedEvent = (e) => {}, this._gamepadDisconnectedEvent = (e) => {}, this._eventPrefix = A.GetPointerPrefix(e), this._engine = e, this._onDeviceConnected = t, this._onDeviceDisconnected = n, this._onInputChanged = r, this._mouseId = +!this._isUsingFirefox, this._enableEvents(), this._usingMacOs && (this._metaKeys = []), this._engine._onEngineViewChanged || (this._engine._onEngineViewChanged = () => {
			this._enableEvents();
		});
	}
	pollInput(e, t, n) {
		let r = this._inputs[e][t];
		if (!r) throw `Unable to find device ${J[e]}`;
		e >= J.DualShock && e <= J.DualSense && this._updateDevice(e, t, n);
		let i = r[n];
		if (i === void 0) throw `Unable to find input ${n} for device ${J[e]} in slot ${t}`;
		return n === Y.Move && A.Warn("Unable to provide information for PointerInput.Move.  Try using PointerInput.Horizontal or PointerInput.Vertical for move data."), i;
	}
	isDeviceAvailable(e) {
		return this._inputs[e] !== void 0;
	}
	dispose() {
		this._onDeviceConnected = () => {}, this._onDeviceDisconnected = () => {}, this._onInputChanged = () => {}, delete this._engine._onEngineViewChanged, this._elementToAttachTo && this._disableEvents();
	}
	_enableEvents() {
		let e = this?._engine.getInputElement();
		if (e && (!this._eventsAttached || this._elementToAttachTo !== e)) {
			if (this._disableEvents(), this._inputs) {
				for (let e of this._inputs) if (e) for (let t in e) {
					let n = e[+t];
					if (n) for (let e = 0; e < n.length; e++) n[e] = 0;
				}
			}
			this._elementToAttachTo = e, this._elementToAttachTo.tabIndex = this._elementToAttachTo.tabIndex === -1 ? this._engine.canvasTabIndex : this._elementToAttachTo.tabIndex, this._handleKeyActions(), this._handlePointerActions(), this._handleGamepadActions(), this._eventsAttached = !0, this._checkForConnectedDevices();
		}
	}
	_disableEvents() {
		this._elementToAttachTo && (this._elementToAttachTo.removeEventListener("blur", this._keyboardBlurEvent), this._elementToAttachTo.removeEventListener("blur", this._pointerBlurEvent), this._elementToAttachTo.removeEventListener("keydown", this._keyboardDownEvent), this._elementToAttachTo.removeEventListener("keyup", this._keyboardUpEvent), this._elementToAttachTo.removeEventListener(this._eventPrefix + "move", this._pointerMoveEvent), this._elementToAttachTo.removeEventListener(this._eventPrefix + "down", this._pointerDownEvent), this._elementToAttachTo.removeEventListener(this._eventPrefix + "up", this._pointerUpEvent), this._elementToAttachTo.removeEventListener(this._eventPrefix + "cancel", this._pointerCancelEvent), this._elementToAttachTo.removeEventListener(this._eventPrefix + "leave", this._pointerLeaveEvent), this._elementToAttachTo.removeEventListener(this._wheelEventName, this._pointerWheelEvent), this._usingMacOs && this._isUsingChromium && this._elementToAttachTo.removeEventListener("lostpointercapture", this._pointerMacOsChromeOutEvent), window.removeEventListener("gamepadconnected", this._gamepadConnectedEvent), window.removeEventListener("gamepaddisconnected", this._gamepadDisconnectedEvent)), this._pointerInputClearObserver && this._engine.onEndFrameObservable.remove(this._pointerInputClearObserver), this._eventsAttached = !1;
	}
	_checkForConnectedDevices() {
		if (navigator.getGamepads) {
			let e = navigator.getGamepads();
			for (let t of e) t && this._addGamePad(t);
		}
		typeof matchMedia == "function" && matchMedia("(pointer:fine)").matches && this._addPointerDevice(J.Mouse, 0, 0, 0);
	}
	_addGamePad(e) {
		let t = this._getGamepadDeviceType(e.id), n = e.index;
		this._gamepads = this._gamepads || Array(e.index + 1), this._registerDevice(t, n, e.buttons.length + e.axes.length), this._gamepads[n] = t;
	}
	_addPointerDevice(e, t, n, r) {
		this._pointerActive ||= !0, this._registerDevice(e, t, Be);
		let i = this._inputs[e][t];
		i[0] = n, i[1] = r;
	}
	_registerDevice(e, t, n) {
		if (t === void 0) throw `Unable to register device ${J[e]} to undefined slot.`;
		if (this._inputs[e] || (this._inputs[e] = {}), !this._inputs[e][t]) {
			let r = Array(n);
			r.fill(0), this._inputs[e][t] = r, this._onDeviceConnected(e, t);
		}
	}
	_unregisterDevice(e, t) {
		this._inputs[e][t] && (delete this._inputs[e][t], this._onDeviceDisconnected(e, t));
	}
	_handleKeyActions() {
		this._keyboardDownEvent = (e) => {
			this._keyboardActive || (this._keyboardActive = !0, this._registerDevice(J.Keyboard, 0, ze));
			let t = this._inputs[J.Keyboard][0];
			if (t) {
				t[e.keyCode] = 1;
				let n = e;
				n.inputIndex = e.keyCode, this._usingMacOs && e.metaKey && e.key !== "Meta" && (this._metaKeys.includes(e.keyCode) || this._metaKeys.push(e.keyCode)), this._onInputChanged(J.Keyboard, 0, n);
			}
		}, this._keyboardUpEvent = (e) => {
			this._keyboardActive || (this._keyboardActive = !0, this._registerDevice(J.Keyboard, 0, ze));
			let t = this._inputs[J.Keyboard][0];
			if (t) {
				t[e.keyCode] = 0;
				let n = e;
				if (n.inputIndex = e.keyCode, this._usingMacOs && e.key === "Meta" && this._metaKeys.length > 0) {
					for (let e of this._metaKeys) {
						let n = Z.CreateDeviceEvent(J.Keyboard, 0, e, 0, this, this._elementToAttachTo);
						t[e] = 0, this._onInputChanged(J.Keyboard, 0, n);
					}
					this._metaKeys.splice(0, this._metaKeys.length);
				}
				this._onInputChanged(J.Keyboard, 0, n);
			}
		}, this._keyboardBlurEvent = () => {
			if (this._keyboardActive) {
				let e = this._inputs[J.Keyboard][0];
				for (let t = 0; t < e.length; t++) if (e[t] !== 0) {
					e[t] = 0;
					let n = Z.CreateDeviceEvent(J.Keyboard, 0, t, 0, this, this._elementToAttachTo);
					this._onInputChanged(J.Keyboard, 0, n);
				}
				this._usingMacOs && this._metaKeys.splice(0, this._metaKeys.length);
			}
		}, this._elementToAttachTo.addEventListener("keydown", this._keyboardDownEvent), this._elementToAttachTo.addEventListener("keyup", this._keyboardUpEvent), this._elementToAttachTo.addEventListener("blur", this._keyboardBlurEvent);
	}
	_handlePointerActions() {
		this._maxTouchPoints = a() && navigator.maxTouchPoints || 2, this._activeTouchIds ||= Array(this._maxTouchPoints);
		for (let e = 0; e < this._maxTouchPoints; e++) this._activeTouchIds[e] = -1;
		this._pointerMoveEvent = (e) => {
			let t = this._getPointerType(e), n = t === J.Mouse ? 0 : this._activeTouchIds.indexOf(e.pointerId);
			if (t === J.Touch && n === -1) {
				if (e.buttons === 0) return;
				let r = this._activeTouchIds.indexOf(-1);
				if (r >= 0) n = r, this._activeTouchIds[r] = e.pointerId, this._onDeviceConnected(t, n);
				else {
					A.Warn(`Max number of touches exceeded.  Ignoring touches in excess of ${this._maxTouchPoints}`);
					return;
				}
			}
			this._inputs[t] || (this._inputs[t] = {}), this._inputs[t][n] || this._addPointerDevice(t, n, e.clientX, e.clientY);
			let r = this._inputs[t][n];
			if (r) {
				let i = e;
				i.inputIndex = Y.Move, r[Y.Horizontal] = e.clientX, r[Y.Vertical] = e.clientY, t === J.Touch && r[Y.LeftClick] === 0 && (r[Y.LeftClick] = 1), e.pointerId === void 0 && (e.pointerId = this._mouseId), this._onInputChanged(t, n, i), !this._usingSafari && e.button !== -1 && (i.inputIndex = e.button + 2, r[e.button + 2] = +!r[e.button + 2], this._onInputChanged(t, n, i));
			}
		}, this._pointerDownEvent = (e) => {
			let t = this._getPointerType(e), n = t === J.Mouse ? 0 : e.pointerId;
			if (t === J.Touch) {
				let t = this._activeTouchIds.indexOf(e.pointerId);
				if (t === -1 && (t = this._activeTouchIds.indexOf(-1)), t >= 0) n = t, this._activeTouchIds[t] = e.pointerId;
				else {
					A.Warn(`Max number of touches exceeded.  Ignoring touches in excess of ${this._maxTouchPoints}`);
					return;
				}
			}
			this._inputs[t] || (this._inputs[t] = {}), this._inputs[t][n] ? t === J.Touch && this._onDeviceConnected(t, n) : this._addPointerDevice(t, n, e.clientX, e.clientY);
			let r = this._inputs[t][n];
			if (r) {
				let i = r[Y.Horizontal], a = r[Y.Vertical];
				if (t === J.Mouse) {
					if (e.pointerId === void 0 && (e.pointerId = this._mouseId), !document.pointerLockElement) try {
						this._elementToAttachTo.setPointerCapture(this._mouseId);
					} catch {}
				} else if (e.pointerId && !document.pointerLockElement) try {
					this._elementToAttachTo.setPointerCapture(e.pointerId);
				} catch {}
				r[Y.Horizontal] = e.clientX, r[Y.Vertical] = e.clientY, r[e.button + 2] = 1;
				let o = e;
				o.inputIndex = e.button + 2, this._onInputChanged(t, n, o), (i !== e.clientX || a !== e.clientY) && (o.inputIndex = Y.Move, this._onInputChanged(t, n, o));
			}
		}, this._pointerUpEvent = (e) => {
			let t = this._getPointerType(e), n = t === J.Mouse ? 0 : this._activeTouchIds.indexOf(e.pointerId);
			if (t === J.Touch) {
				if (n === -1) return;
				this._activeTouchIds[n] = -1;
			}
			let r = this._inputs[t]?.[n], i = e.button, a = r && r[i + 2] !== 0;
			if (!a && this._isUsingFirefox && this._usingMacOs && r && (i = i === 2 ? 0 : 2, a = r[i + 2] !== 0), a) {
				let a = r[Y.Horizontal], o = r[Y.Vertical];
				r[Y.Horizontal] = e.clientX, r[Y.Vertical] = e.clientY, r[i + 2] = 0;
				let s = e;
				e.pointerId === void 0 && (e.pointerId = this._mouseId), (a !== e.clientX || o !== e.clientY) && (s.inputIndex = Y.Move, this._onInputChanged(t, n, s)), s.inputIndex = i + 2, t === J.Mouse && this._mouseId >= 0 && this._elementToAttachTo.hasPointerCapture?.(this._mouseId) ? this._elementToAttachTo.releasePointerCapture(this._mouseId) : e.pointerId && this._elementToAttachTo.hasPointerCapture?.(e.pointerId) && this._elementToAttachTo.releasePointerCapture(e.pointerId), this._onInputChanged(t, n, s), t === J.Touch && this._onDeviceDisconnected(t, n);
			}
		}, this._pointerCancelTouch = (e) => {
			let t = this._activeTouchIds.indexOf(e);
			if (t === -1) return;
			this._elementToAttachTo.hasPointerCapture?.(e) && this._elementToAttachTo.releasePointerCapture(e), this._inputs[J.Touch][t][Y.LeftClick] = 0;
			let n = Z.CreateDeviceEvent(J.Touch, t, Y.LeftClick, 0, this, this._elementToAttachTo, e);
			this._onInputChanged(J.Touch, t, n), this._activeTouchIds[t] = -1, this._onDeviceDisconnected(J.Touch, t);
		}, this._pointerCancelEvent = (e) => {
			if (e.pointerType === "mouse") {
				let e = this._inputs[J.Mouse][0];
				this._mouseId >= 0 && this._elementToAttachTo.hasPointerCapture?.(this._mouseId) && this._elementToAttachTo.releasePointerCapture(this._mouseId);
				for (let t = Y.LeftClick; t <= Y.BrowserForward; t++) if (e[t] === 1) {
					e[t] = 0;
					let n = Z.CreateDeviceEvent(J.Mouse, 0, t, 0, this, this._elementToAttachTo);
					this._onInputChanged(J.Mouse, 0, n);
				}
			} else this._pointerCancelTouch(e.pointerId);
		}, this._pointerLeaveEvent = (e) => {
			e.pointerType === "pen" && this._pointerCancelTouch(e.pointerId);
		}, this._wheelEventName = "onwheel" in document.createElement("div") ? "wheel" : document.onmousewheel === void 0 ? "DOMMouseScroll" : "mousewheel";
		let e = !1, t = function() {};
		try {
			let n = Object.defineProperty({}, "passive", { get: function() {
				e = !0;
			} });
			this._elementToAttachTo.addEventListener("test", t, n), this._elementToAttachTo.removeEventListener("test", t, n);
		} catch {}
		this._pointerBlurEvent = () => {
			if (this.isDeviceAvailable(J.Mouse)) {
				let e = this._inputs[J.Mouse][0];
				this._mouseId >= 0 && this._elementToAttachTo.hasPointerCapture?.(this._mouseId) && this._elementToAttachTo.releasePointerCapture(this._mouseId);
				for (let t = Y.LeftClick; t <= Y.BrowserForward; t++) if (e[t] === 1) {
					e[t] = 0;
					let n = Z.CreateDeviceEvent(J.Mouse, 0, t, 0, this, this._elementToAttachTo);
					this._onInputChanged(J.Mouse, 0, n);
				}
			}
			if (this.isDeviceAvailable(J.Touch)) {
				let e = this._inputs[J.Touch];
				for (let t = 0; t < this._activeTouchIds.length; t++) {
					let n = this._activeTouchIds[t];
					if (this._elementToAttachTo.hasPointerCapture?.(n) && this._elementToAttachTo.releasePointerCapture(n), n !== -1 && e[t]?.[Y.LeftClick] === 1) {
						e[t][Y.LeftClick] = 0;
						let r = Z.CreateDeviceEvent(J.Touch, t, Y.LeftClick, 0, this, this._elementToAttachTo, n);
						this._onInputChanged(J.Touch, t, r), this._activeTouchIds[t] = -1, this._onDeviceDisconnected(J.Touch, t);
					}
				}
			}
		}, this._pointerWheelEvent = (e) => {
			let t = J.Mouse;
			this._inputs[t] || (this._inputs[t] = []), this._inputs[t][0] || (this._pointerActive = !0, this._registerDevice(t, 0, Be));
			let n = this._inputs[t][0];
			if (n) {
				n[Y.MouseWheelX] = e.deltaX || 0, n[Y.MouseWheelY] = e.deltaY || e.wheelDelta || 0, n[Y.MouseWheelZ] = e.deltaZ || 0;
				let r = e;
				e.pointerId === void 0 && (e.pointerId = this._mouseId), n[Y.MouseWheelX] !== 0 && (r.inputIndex = Y.MouseWheelX, this._onInputChanged(t, 0, r)), n[Y.MouseWheelY] !== 0 && (r.inputIndex = Y.MouseWheelY, this._onInputChanged(t, 0, r)), n[Y.MouseWheelZ] !== 0 && (r.inputIndex = Y.MouseWheelZ, this._onInputChanged(t, 0, r));
			}
		}, this._usingMacOs && this._isUsingChromium && (this._pointerMacOsChromeOutEvent = (e) => {
			e.buttons > 1 && this._pointerCancelEvent(e);
		}, this._elementToAttachTo.addEventListener("lostpointercapture", this._pointerMacOsChromeOutEvent)), this._elementToAttachTo.addEventListener(this._eventPrefix + "move", this._pointerMoveEvent), this._elementToAttachTo.addEventListener(this._eventPrefix + "down", this._pointerDownEvent), this._elementToAttachTo.addEventListener(this._eventPrefix + "up", this._pointerUpEvent), this._elementToAttachTo.addEventListener(this._eventPrefix + "cancel", this._pointerCancelEvent), this._elementToAttachTo.addEventListener(this._eventPrefix + "leave", this._pointerLeaveEvent), this._elementToAttachTo.addEventListener("blur", this._pointerBlurEvent), this._elementToAttachTo.addEventListener(this._wheelEventName, this._pointerWheelEvent, e ? { passive: !1 } : !1), this._pointerInputClearObserver = this._engine.onEndFrameObservable.add(() => {
			if (this.isDeviceAvailable(J.Mouse)) {
				let e = this._inputs[J.Mouse][0];
				e[Y.MouseWheelX] = 0, e[Y.MouseWheelY] = 0, e[Y.MouseWheelZ] = 0;
			}
		});
	}
	_handleGamepadActions() {
		this._gamepadConnectedEvent = (e) => {
			this._addGamePad(e.gamepad);
		}, this._gamepadDisconnectedEvent = (e) => {
			if (this._gamepads) {
				let t = this._getGamepadDeviceType(e.gamepad.id), n = e.gamepad.index;
				this._unregisterDevice(t, n), delete this._gamepads[n];
			}
		}, window.addEventListener("gamepadconnected", this._gamepadConnectedEvent), window.addEventListener("gamepaddisconnected", this._gamepadDisconnectedEvent);
	}
	_updateDevice(e, t, n) {
		let r = navigator.getGamepads()[t];
		if (r && e === this._gamepads[t]) {
			let i = this._inputs[e][t];
			i[n] = n >= r.buttons.length ? r.axes[n - r.buttons.length].valueOf() : r.buttons[n].value;
		}
	}
	_getGamepadDeviceType(e) {
		return e.indexOf("054c") === -1 ? e.indexOf("Xbox One") !== -1 || e.search("Xbox 360") !== -1 || e.search("xinput") !== -1 || e.indexOf("045e") !== -1 && e.indexOf("Surface Dock") === -1 ? J.Xbox : e.indexOf("057e") === -1 ? J.Generic : J.Switch : e.indexOf("0ce6") === -1 ? J.DualShock : J.DualSense;
	}
	_getPointerType(e) {
		let t = J.Mouse;
		return (e.pointerType === "touch" || e.pointerType === "pen" || e.touches) && (t = J.Touch), t;
	}
}, He = class {
	constructor(e, n, r = 0) {
		this.deviceType = n, this.deviceSlot = r, this.onInputChangedObservable = new t(), this._deviceInputSystem = e;
	}
	getInput(e) {
		return this._deviceInputSystem.pollInput(this.deviceType, this.deviceSlot, e);
	}
}, Ue = class {
	constructor(e) {
		this._registeredManagers = [], this._refCount = 0, this.registerManager = (e) => {
			for (let t = 0; t < this._devices.length; t++) {
				let n = this._devices[t];
				for (let r in n) {
					let n = +r;
					e._addDevice(new He(this._deviceInputSystem, t, n));
				}
			}
			this._registeredManagers.push(e);
		}, this.unregisterManager = (e) => {
			let t = this._registeredManagers.indexOf(e);
			t > -1 && this._registeredManagers.splice(t, 1);
		};
		let t = Object.keys(J).length / 2;
		this._devices = Array(t);
		let n = (e, t) => {
			this._devices[e] || (this._devices[e] = []), this._devices[e][t] || (this._devices[e][t] = t);
			for (let n of this._registeredManagers) {
				let r = new He(this._deviceInputSystem, e, t);
				n._addDevice(r);
			}
		}, r = (e, t) => {
			this._devices[e]?.[t] && delete this._devices[e][t];
			for (let n of this._registeredManagers) n._removeDevice(e, t);
		}, i = (e, t, n) => {
			if (n) for (let r of this._registeredManagers) r._onInputChanged(e, t, n);
		};
		this._deviceInputSystem = typeof _native < "u" ? new Re(n, r, i) : new Ve(e, n, r, i);
	}
	dispose() {
		this._deviceInputSystem.dispose();
	}
}, We = class {
	getDeviceSource(e, t) {
		if (t === void 0) {
			if (this._firstDevice[e] === void 0) return null;
			t = this._firstDevice[e];
		}
		return !this._devices[e] || this._devices[e][t] === void 0 ? null : this._devices[e][t];
	}
	getDeviceSources(e) {
		return this._devices[e] ? this._devices[e].filter((e) => !!e) : [];
	}
	constructor(e) {
		let n = Object.keys(J).length / 2;
		this._devices = Array(n), this._firstDevice = Array(n), this._engine = e, this._engine._deviceSourceManager || (this._engine._deviceSourceManager = new Ue(e)), this._engine._deviceSourceManager._refCount++, this.onDeviceConnectedObservable = new t((e) => {
			for (let t of this._devices) if (t) for (let n of t) n && this.onDeviceConnectedObservable.notifyObserver(e, n);
		}), this.onDeviceDisconnectedObservable = new t(), this._engine._deviceSourceManager.registerManager(this), this._onDisposeObserver = e.onDisposeObservable.add(() => {
			this.dispose();
		});
	}
	dispose() {
		this.onDeviceConnectedObservable.clear(), this.onDeviceDisconnectedObservable.clear(), this._engine._deviceSourceManager && (this._engine._deviceSourceManager.unregisterManager(this), --this._engine._deviceSourceManager._refCount < 1 && (this._engine._deviceSourceManager.dispose(), delete this._engine._deviceSourceManager)), this._engine.onDisposeObservable.remove(this._onDisposeObserver);
	}
	_addDevice(e) {
		this._devices[e.deviceType] || (this._devices[e.deviceType] = []), this._devices[e.deviceType][e.deviceSlot] || (this._devices[e.deviceType][e.deviceSlot] = e, this._updateFirstDevices(e.deviceType)), this.onDeviceConnectedObservable.notifyObservers(e);
	}
	_removeDevice(e, t) {
		let n = this._devices[e]?.[t];
		this.onDeviceDisconnectedObservable.notifyObservers(n), this._devices[e]?.[t] && delete this._devices[e][t], this._updateFirstDevices(e);
	}
	_onInputChanged(e, t, n) {
		this._devices[e]?.[t]?.onInputChangedObservable.notifyObservers(n);
	}
	_updateFirstDevices(e) {
		switch (e) {
			case J.Keyboard:
			case J.Mouse:
				this._firstDevice[e] = 0;
				break;
			case J.Touch:
			case J.DualSense:
			case J.DualShock:
			case J.Xbox:
			case J.Switch:
			case J.Generic: {
				delete this._firstDevice[e];
				let t = this._devices[e];
				if (t) {
					for (let n = 0; n < t.length; n++) if (t[n]) {
						this._firstDevice[e] = n;
						break;
					}
				}
				break;
			}
		}
	}
}, Ge = class {};
Ge._IsPickingAvailable = !1;
//#endregion
//#region node_modules/@babylonjs/core/Inputs/scene.inputManager.js
var Ke = class {
	constructor() {
		this._singleClick = !1, this._doubleClick = !1, this._hasSwiped = !1, this._ignore = !1;
	}
	get singleClick() {
		return this._singleClick;
	}
	get doubleClick() {
		return this._doubleClick;
	}
	get hasSwiped() {
		return this._hasSwiped;
	}
	get ignore() {
		return this._ignore;
	}
	set singleClick(e) {
		this._singleClick = e;
	}
	set doubleClick(e) {
		this._doubleClick = e;
	}
	set hasSwiped(e) {
		this._hasSwiped = e;
	}
	set ignore(e) {
		this._ignore = e;
	}
}, Q = class e {
	constructor(e) {
		this._alreadyAttached = !1, this._meshPickProceed = !1, this._currentPickResult = null, this._previousPickResult = null, this._activePointerIds = [], this._activePointerIdsCount = 0, this._doubleClickOccured = !1, this._isSwiping = !1, this._swipeButtonPressed = -1, this._skipPointerTap = !1, this._isMultiTouchGesture = !1, this._pointerX = 0, this._pointerY = 0, this._startingPointerPosition = new y(0, 0), this._previousStartingPointerPosition = new y(0, 0), this._startingPointerTime = 0, this._previousStartingPointerTime = 0, this._pointerCaptures = {}, this._meshUnderPointerId = {}, this._movePointerInfo = null, this._latestPointerMoveEvents = /* @__PURE__ */ new Map(), this._cameraObserverCount = 0, this._delayedClicks = [
			null,
			null,
			null,
			null,
			null
		], this._deviceSourceManager = null, this._scene = e || n.LastCreatedScene, this._scene;
	}
	get meshUnderPointer() {
		return this._movePointerInfo &&= (this._movePointerInfo._generatePickInfo(), null), this._pointerOverMesh;
	}
	getMeshUnderPointerByPointerId(e) {
		return this._meshUnderPointerId[e] || null;
	}
	get unTranslatedPointer() {
		return new y(this._unTranslatedPointerX, this._unTranslatedPointerY);
	}
	get pointerX() {
		return this._pointerX;
	}
	set pointerX(e) {
		this._pointerX = e;
	}
	get pointerY() {
		return this._pointerY;
	}
	set pointerY(e) {
		this._pointerY = e;
	}
	_updatePointerPosition(e) {
		let t = this._scene.getEngine().getInputElementClientRect();
		t && (this._pointerX = e.clientX - t.left, this._pointerY = e.clientY - t.top, this._unTranslatedPointerX = this._pointerX, this._unTranslatedPointerY = this._pointerY);
	}
	_processPointerMove(e, t) {
		let n = this._scene, r = n.getEngine(), i = r.getInputElement();
		i && (i.tabIndex = r.canvasTabIndex, n.doNotHandleCursors || (i.style.cursor = n.defaultCursor)), this._setCursorAndPointerOverMesh(e, t, n);
		for (let r of n._pointerMoveStage) {
			e ||= this._pickMove(t);
			let n = !!e?.pickedMesh;
			e = r.action(this._unTranslatedPointerX, this._unTranslatedPointerY, e, n, i);
		}
		let a = t.inputIndex >= Y.MouseWheelX && t.inputIndex <= Y.MouseWheelZ ? L.POINTERWHEEL : L.POINTERMOVE;
		n.onPointerMove && (e ||= this._pickMove(t), n.onPointerMove(t, e, a));
		let o;
		e ? (o = new I(a, t, e), this._setRayOnPointerInfo(e, t)) : (o = new I(a, t, null, this), this._movePointerInfo = o), n.onPointerObservable.hasObservers() && n.onPointerObservable.notifyObservers(o, a);
	}
	_setRayOnPointerInfo(e, t) {
		let n = this._scene;
		e && Ge._IsPickingAvailable && (e.ray ||= n.createPickingRay(t.offsetX, t.offsetY, h.Identity(), n.activeCamera));
	}
	_addCameraPointerObserver(e, t) {
		return this._cameraObserverCount++, this._scene.onPointerObservable.add(e, t);
	}
	_removeCameraPointerObserver(e) {
		return this._cameraObserverCount--, this._scene.onPointerObservable.remove(e);
	}
	_checkForPicking() {
		return !!(this._scene.onPointerObservable.observers.length > this._cameraObserverCount || this._scene.onPointerPick);
	}
	_checkPrePointerObservable(e, t, n) {
		let r = this._scene, i = new de(n, t, this._unTranslatedPointerX, this._unTranslatedPointerY);
		return e && (i.originalPickingInfo = e, i.ray = e.ray, t.pointerType === "xr-near" && e.originMesh && (i.nearInteractionPickingInfo = e)), r.onPrePointerObservable.notifyObservers(i, n), !!i.skipOnPointerObservable;
	}
	_pickMove(e) {
		let t = this._scene, n = t.pick(this._unTranslatedPointerX, this._unTranslatedPointerY, t.pointerMovePredicate, t.pointerMoveFastCheck, t.cameraToUseForPointers, t.pointerMoveTrianglePredicate);
		return this._setCursorAndPointerOverMesh(n, e, t), n;
	}
	_updateMeshUnderPointer() {
		let e = this._scene;
		if (!e.constantlyUpdateMeshUnderPointer || this._latestPointerMoveEvents.size === 0 || e.skipPointerMovePicking || !e.cameraToUseForPointers && !e.activeCamera) return;
		this._ensurePointerMovePredicate();
		let t = this._pointerX, n = this._pointerY, r = this._unTranslatedPointerX, i = this._unTranslatedPointerY;
		for (let e of this._latestPointerMoveEvents.values()) this._pointerX = e.pointerX, this._pointerY = e.pointerY, this._unTranslatedPointerX = e.unTranslatedPointerX, this._unTranslatedPointerY = e.unTranslatedPointerY, this._pickMove(e.event);
		this._pointerX = t, this._pointerY = n, this._unTranslatedPointerX = r, this._unTranslatedPointerY = i;
	}
	_ensurePointerMovePredicate() {
		let e = this._scene;
		e.pointerMovePredicate ||= (t) => (t._isPointerMovePickable ?? t.isPickable) && t.isVisible && t.isReady() && t.isEnabled() && (t.enablePointerMoveEvents || e.constantlyUpdateMeshUnderPointer || t._getActionManagerForTrigger() !== null) && (!e.cameraToUseForPointers || (e.cameraToUseForPointers.layerMask & t.layerMask) !== 0);
	}
	_setCursorAndPointerOverMesh(e, t, n) {
		let r = n.getEngine().getInputElement();
		if (e?.pickedMesh) {
			if (this.setPointerOverMesh(e.pickedMesh, t.pointerId, e, t), !n.doNotHandleCursors && r && this._pointerOverMesh) {
				let e = this._pointerOverMesh._getActionManagerForTrigger();
				e && e.hasPointerTriggers && (r.style.cursor = e.hoverCursor || n.hoverCursor);
			}
		} else this.setPointerOverMesh(null, t.pointerId, e, t);
	}
	simulatePointerMove(e, t) {
		let n = new PointerEvent("pointermove", t);
		n.inputIndex = Y.Move, !this._checkPrePointerObservable(e, n, L.POINTERMOVE) && this._processPointerMove(e, n);
	}
	simulatePointerDown(e, t) {
		let n = new PointerEvent("pointerdown", t);
		n.inputIndex = n.button + 2, !this._checkPrePointerObservable(e, n, L.POINTERDOWN) && this._processPointerDown(e, n);
	}
	_processPointerDown(t, n) {
		let r = this._scene;
		if (t?.pickedMesh) {
			this._pickedDownMesh = t.pickedMesh;
			let i = t.pickedMesh._getActionManagerForTrigger();
			if (i) {
				if (i.hasPickTriggers) switch (i.processTrigger(5, new K(t.pickedMesh, r.pointerX, r.pointerY, t.pickedMesh, n, t)), n.button) {
					case 0:
						i.processTrigger(2, new K(t.pickedMesh, r.pointerX, r.pointerY, t.pickedMesh, n, t));
						break;
					case 1:
						i.processTrigger(4, new K(t.pickedMesh, r.pointerX, r.pointerY, t.pickedMesh, n, t));
						break;
					case 2: i.processTrigger(3, new K(t.pickedMesh, r.pointerX, r.pointerY, t.pickedMesh, n, t));
				}
				i.hasSpecificTrigger(8) && window.setTimeout(() => {
					let t = r.pick(this._unTranslatedPointerX, this._unTranslatedPointerY, (e) => e.isPickable && e.isVisible && e.isReady() && e.actionManager && e.actionManager.hasSpecificTrigger(8) && e === this._pickedDownMesh, !1, r.cameraToUseForPointers);
					t?.pickedMesh && i && this._activePointerIdsCount !== 0 && Date.now() - this._startingPointerTime > e.LongPressDelay && !this._isPointerSwiping() && (this._startingPointerTime = 0, i.processTrigger(8, K.CreateNew(t.pickedMesh, n)));
				}, e.LongPressDelay);
			}
		} else for (let e of r._pointerDownStage) t = e.action(this._unTranslatedPointerX, this._unTranslatedPointerY, t, n, !1);
		let i, a = L.POINTERDOWN;
		t ? (r.onPointerDown && r.onPointerDown(n, t, a), i = new I(a, n, t), this._setRayOnPointerInfo(t, n)) : i = new I(a, n, null, this), r.onPointerObservable.hasObservers() && r.onPointerObservable.notifyObservers(i, a);
	}
	_isPointerSwiping() {
		return this._isSwiping;
	}
	simulatePointerUp(e, t, n) {
		let r = new PointerEvent("pointerup", t);
		r.inputIndex = Y.Move;
		let i = new Ke();
		n ? i.doubleClick = !0 : i.singleClick = !0, !this._checkPrePointerObservable(e, r, L.POINTERUP) && this._processPointerUp(e, r, i);
	}
	_processPointerUp(e, t, n) {
		let r = this._scene;
		if (e?.pickedMesh) {
			if (this._pickedUpMesh = e.pickedMesh, this._pickedDownMesh === this._pickedUpMesh && (r.onPointerPick && r.onPointerPick(t, e), n.singleClick && !n.ignore && r.onPointerObservable.observers.length > this._cameraObserverCount)) {
				let n = L.POINTERPICK, i = new I(n, t, e);
				this._setRayOnPointerInfo(e, t), r.onPointerObservable.notifyObservers(i, n);
			}
			let i = e.pickedMesh._getActionManagerForTrigger();
			if (i && !n.ignore) {
				i.processTrigger(7, K.CreateNew(e.pickedMesh, t, e)), !n.hasSwiped && n.singleClick && i.processTrigger(1, K.CreateNew(e.pickedMesh, t, e));
				let r = e.pickedMesh._getActionManagerForTrigger(6);
				n.doubleClick && r && r.processTrigger(6, K.CreateNew(e.pickedMesh, t, e));
			}
		} else if (!n.ignore) for (let i of r._pointerUpStage) e = i.action(this._unTranslatedPointerX, this._unTranslatedPointerY, e, t, n.doubleClick);
		if (this._pickedDownMesh && this._pickedDownMesh !== this._pickedUpMesh) {
			let e = this._pickedDownMesh._getActionManagerForTrigger(16);
			e && e.processTrigger(16, K.CreateNew(this._pickedDownMesh, t));
		}
		if (!n.ignore) {
			let i = new I(L.POINTERUP, t, e);
			if (this._setRayOnPointerInfo(e, t), r.onPointerObservable.notifyObservers(i, L.POINTERUP), r.onPointerUp && r.onPointerUp(t, e, L.POINTERUP), !n.hasSwiped && !this._skipPointerTap && !this._isMultiTouchGesture) {
				let i = 0;
				if (n.singleClick ? i = L.POINTERTAP : n.doubleClick && (i = L.POINTERDOUBLETAP), i) {
					let n = new I(i, t, e);
					r.onPointerObservable.hasObservers() && r.onPointerObservable.hasSpecificMask(i) && r.onPointerObservable.notifyObservers(n, i);
				}
			}
		}
	}
	isPointerCaptured(e = 0) {
		return this._pointerCaptures[e];
	}
	attachControl(t = !0, n = !0, r = !0, i = null) {
		let a = this._scene, o = a.getEngine();
		i ||= o.getInputElement(), this._alreadyAttached && this.detachControl(), i && (this._alreadyAttachedTo = i), this._deviceSourceManager = new We(o), this._initActionManager = (e) => {
			if (!this._meshPickProceed) {
				let t = a.skipPointerUpPicking || a._registeredActions === 0 && !this._checkForPicking() && !a.onPointerUp ? null : a.pick(this._unTranslatedPointerX, this._unTranslatedPointerY, a.pointerUpPredicate, a.pointerUpFastCheck, a.cameraToUseForPointers, a.pointerUpTrianglePredicate);
				this._currentPickResult = t, t && (e = t.hit && t.pickedMesh ? t.pickedMesh._getActionManagerForTrigger() : null), this._meshPickProceed = !0;
			}
			return e;
		}, this._delayedSimpleClick = (t, n, r) => {
			if ((Date.now() - this._previousStartingPointerTime > e.DoubleClickDelay && !this._doubleClickOccured || t !== this._previousButtonPressed) && (this._doubleClickOccured = !1, n.singleClick = !0, n.ignore = !1, this._delayedClicks[t])) {
				let e = this._delayedClicks[t].evt, n = L.POINTERTAP, r = new I(n, e, this._currentPickResult);
				a.onPointerObservable.hasObservers() && a.onPointerObservable.hasSpecificMask(n) && a.onPointerObservable.notifyObservers(r, n), this._delayedClicks[t] = null;
			}
		}, this._initClickEvent = (t, n, r, i) => {
			let a = new Ke();
			this._currentPickResult = null;
			let o = null, s = t.hasSpecificMask(L.POINTERPICK) || n.hasSpecificMask(L.POINTERPICK) || t.hasSpecificMask(L.POINTERTAP) || n.hasSpecificMask(L.POINTERTAP) || t.hasSpecificMask(L.POINTERDOUBLETAP) || n.hasSpecificMask(L.POINTERDOUBLETAP);
			!s && q && (o = this._initActionManager(o, a), o && (s = o.hasPickTriggers));
			let c = !1;
			if (s &&= !this._isMultiTouchGesture, s) {
				let s = r.button;
				if (a.hasSwiped = this._isPointerSwiping(), !a.hasSwiped) {
					let l = !e.ExclusiveDoubleClickMode;
					if (l || (l = !t.hasSpecificMask(L.POINTERDOUBLETAP) && !n.hasSpecificMask(L.POINTERDOUBLETAP), l && !q.HasSpecificTrigger(6) && (o = this._initActionManager(o, a), o && (l = !o.hasSpecificTrigger(6)))), l) (Date.now() - this._previousStartingPointerTime > e.DoubleClickDelay || s !== this._previousButtonPressed) && (a.singleClick = !0, i(a, this._currentPickResult), c = !0);
					else {
						let t = {
							evt: r,
							clickInfo: a,
							timeoutId: window.setTimeout(this._delayedSimpleClick.bind(this, s, a, i), e.DoubleClickDelay)
						};
						this._delayedClicks[s] = t;
					}
					let u = t.hasSpecificMask(L.POINTERDOUBLETAP) || n.hasSpecificMask(L.POINTERDOUBLETAP);
					!u && q.HasSpecificTrigger(6) && (o = this._initActionManager(o, a), o && (u = o.hasSpecificTrigger(6))), u && (s === this._previousButtonPressed && Date.now() - this._previousStartingPointerTime < e.DoubleClickDelay && !this._doubleClickOccured ? (!a.hasSwiped && !this._isPointerSwiping() ? (this._previousStartingPointerTime = 0, this._doubleClickOccured = !0, a.doubleClick = !0, a.ignore = !1, e.ExclusiveDoubleClickMode && this._delayedClicks[s] && (clearTimeout(this._delayedClicks[s]?.timeoutId), this._delayedClicks[s] = null), i(a, this._currentPickResult)) : (this._doubleClickOccured = !1, this._previousStartingPointerTime = this._startingPointerTime, this._previousStartingPointerPosition.x = this._startingPointerPosition.x, this._previousStartingPointerPosition.y = this._startingPointerPosition.y, this._previousButtonPressed = s, e.ExclusiveDoubleClickMode ? (this._delayedClicks[s] && (clearTimeout(this._delayedClicks[s]?.timeoutId), this._delayedClicks[s] = null), i(a, this._previousPickResult)) : i(a, this._currentPickResult)), c = !0) : (this._doubleClickOccured = !1, this._previousStartingPointerTime = this._startingPointerTime, this._previousStartingPointerPosition.x = this._startingPointerPosition.x, this._previousStartingPointerPosition.y = this._startingPointerPosition.y, this._previousButtonPressed = s));
				}
			}
			c || i(a, this._currentPickResult);
		}, this._onPointerMove = (t) => {
			if (this._updatePointerPosition(t), this._latestPointerMoveEvents.set(t.pointerId, {
				event: t,
				pointerX: this._pointerX,
				pointerY: this._pointerY,
				unTranslatedPointerX: this._unTranslatedPointerX,
				unTranslatedPointerY: this._unTranslatedPointerY
			}), !this._isSwiping && this._swipeButtonPressed !== -1 && (this._isSwiping = Math.abs(this._startingPointerPosition.x - this._pointerX) > e.DragMovementThreshold || Math.abs(this._startingPointerPosition.y - this._pointerY) > e.DragMovementThreshold), o.isPointerLock && o._verifyPointerLock(), this._checkPrePointerObservable(null, t, t.inputIndex >= Y.MouseWheelX && t.inputIndex <= Y.MouseWheelZ ? L.POINTERWHEEL : L.POINTERMOVE) || !a.cameraToUseForPointers && !a.activeCamera) return;
			if (a.skipPointerMovePicking) {
				this._processPointerMove(new G(), t);
				return;
			}
			this._ensurePointerMovePredicate();
			let n = a._registeredActions > 0 || a.constantlyUpdateMeshUnderPointer ? this._pickMove(t) : null;
			this._processPointerMove(n, t);
		}, this._onPointerDown = (t) => {
			let n = this._activePointerIds.indexOf(-1);
			if (n === -1 ? this._activePointerIds.push(t.pointerId) : this._activePointerIds[n] = t.pointerId, this._activePointerIdsCount++, this._pickedDownMesh = null, this._meshPickProceed = !1, e.ExclusiveDoubleClickMode) {
				for (let e = 0; e < this._delayedClicks.length; e++) if (this._delayedClicks[e]) {
					if (t.button === e) clearTimeout(this._delayedClicks[e]?.timeoutId);
					else {
						let t = this._delayedClicks[e].clickInfo;
						this._doubleClickOccured = !1, t.singleClick = !0, t.ignore = !1;
						let n = this._delayedClicks[e].evt, r = L.POINTERTAP, i = new I(r, n, this._currentPickResult);
						a.onPointerObservable.hasObservers() && a.onPointerObservable.hasSpecificMask(r) && a.onPointerObservable.notifyObservers(i, r), this._delayedClicks[e] = null;
					}
				}
			}
			if (this._updatePointerPosition(t), this._swipeButtonPressed === -1 && (this._swipeButtonPressed = t.button), a.preventDefaultOnPointerDown && i && (t.preventDefault(), i.focus()), this._startingPointerPosition.x = this._pointerX, this._startingPointerPosition.y = this._pointerY, this._startingPointerTime = Date.now(), this._checkPrePointerObservable(null, t, L.POINTERDOWN) || !a.cameraToUseForPointers && !a.activeCamera) return;
			this._pointerCaptures[t.pointerId] = !0, a.pointerDownPredicate ||= (e) => e.isPickable && e.isVisible && e.isReady() && e.isEnabled() && (!a.cameraToUseForPointers || (a.cameraToUseForPointers.layerMask & e.layerMask) !== 0), this._pickedDownMesh = null;
			let r;
			r = a.skipPointerDownPicking || a._registeredActions === 0 && !this._checkForPicking() && !a.onPointerDown ? new G() : a.pick(this._unTranslatedPointerX, this._unTranslatedPointerY, a.pointerDownPredicate, a.pointerDownFastCheck, a.cameraToUseForPointers, a.pointerDownTrianglePredicate), this._processPointerDown(r, t);
		}, this._onPointerUp = (e) => {
			let t = this._activePointerIds.indexOf(e.pointerId);
			t !== -1 && (this._activePointerIds[t] = -1, this._activePointerIdsCount--, e.pointerType === "touch" && this._latestPointerMoveEvents.delete(e.pointerId), this._pickedUpMesh = null, this._meshPickProceed = !1, this._updatePointerPosition(e), a.preventDefaultOnPointerUp && i && (e.preventDefault(), i.focus()), this._initClickEvent(a.onPrePointerObservable, a.onPointerObservable, e, (t, n) => {
				if (a.onPrePointerObservable.hasObservers() && (this._skipPointerTap = !1, !t.ignore)) {
					if (this._checkPrePointerObservable(null, e, L.POINTERUP)) {
						this._swipeButtonPressed === e.button && (this._isSwiping = !1, this._swipeButtonPressed = -1), e.buttons === 0 && (this._pointerCaptures[e.pointerId] = !1);
						return;
					}
					t.hasSwiped || (t.singleClick && a.onPrePointerObservable.hasSpecificMask(L.POINTERTAP) && this._checkPrePointerObservable(null, e, L.POINTERTAP) && (this._skipPointerTap = !0), t.doubleClick && a.onPrePointerObservable.hasSpecificMask(L.POINTERDOUBLETAP) && this._checkPrePointerObservable(null, e, L.POINTERDOUBLETAP) && (this._skipPointerTap = !0));
				}
				this._pointerCaptures[e.pointerId] ? (e.buttons === 0 && (this._pointerCaptures[e.pointerId] = !1), (a.cameraToUseForPointers || a.activeCamera) && (a.pointerUpPredicate ||= (e) => e.isPickable && e.isVisible && e.isReady() && e.isEnabled() && (!a.cameraToUseForPointers || (a.cameraToUseForPointers.layerMask & e.layerMask) !== 0), !this._meshPickProceed && (q && q.HasTriggers || this._checkForPicking() || a.onPointerUp) && this._initActionManager(null, t), n ||= this._currentPickResult, this._processPointerUp(n, e, t), this._previousPickResult = this._currentPickResult, this._swipeButtonPressed === e.button && (this._isSwiping = !1, this._swipeButtonPressed = -1))) : this._swipeButtonPressed === e.button && (this._isSwiping = !1, this._swipeButtonPressed = -1);
			}));
		}, this._onKeyDown = (e) => {
			let t = me.KEYDOWN;
			if (a.onPreKeyboardObservable.hasObservers()) {
				let n = new pe(t, e);
				if (a.onPreKeyboardObservable.notifyObservers(n, t), n.skipOnKeyboardObservable) return;
			}
			if (a.onKeyboardObservable.hasObservers()) {
				let n = new fe(t, e);
				a.onKeyboardObservable.notifyObservers(n, t);
			}
			a.actionManager && a.actionManager.processTrigger(14, K.CreateNewFromScene(a, e));
		}, this._onKeyUp = (e) => {
			let t = me.KEYUP;
			if (a.onPreKeyboardObservable.hasObservers()) {
				let n = new pe(t, e);
				if (a.onPreKeyboardObservable.notifyObservers(n, t), n.skipOnKeyboardObservable) return;
			}
			if (a.onKeyboardObservable.hasObservers()) {
				let n = new fe(t, e);
				a.onKeyboardObservable.notifyObservers(n, t);
			}
			a.actionManager && a.actionManager.processTrigger(15, K.CreateNewFromScene(a, e));
		}, this._deviceSourceManager.onDeviceConnectedObservable.add((e) => {
			e.deviceType === J.Mouse ? e.onInputChangedObservable.add((i) => {
				this._originMouseEvent = i, i.inputIndex === Y.LeftClick || i.inputIndex === Y.MiddleClick || i.inputIndex === Y.RightClick || i.inputIndex === Y.BrowserBack || i.inputIndex === Y.BrowserForward ? n && e.getInput(i.inputIndex) === 1 ? this._onPointerDown(i) : t && e.getInput(i.inputIndex) === 0 && this._onPointerUp(i) : r && (i.inputIndex === Y.Move || i.inputIndex === Y.MouseWheelX || i.inputIndex === Y.MouseWheelY || i.inputIndex === Y.MouseWheelZ) && this._onPointerMove(i);
			}) : e.deviceType === J.Touch ? e.onInputChangedObservable.add((i) => {
				i.inputIndex === Y.LeftClick && (n && e.getInput(i.inputIndex) === 1 ? (this._onPointerDown(i), this._activePointerIdsCount > 1 && (this._isMultiTouchGesture = !0)) : t && e.getInput(i.inputIndex) === 0 && (this._onPointerUp(i), this._activePointerIdsCount === 0 && (this._isMultiTouchGesture = !1))), r && i.inputIndex === Y.Move && this._onPointerMove(i);
			}) : e.deviceType === J.Keyboard && e.onInputChangedObservable.add((e) => {
				e.type === "keydown" ? this._onKeyDown(e) : e.type === "keyup" && this._onKeyUp(e);
			});
		}), this._alreadyAttached = !0;
	}
	detachControl() {
		this._alreadyAttached && (this._deviceSourceManager.dispose(), this._deviceSourceManager = null, this._alreadyAttachedTo && !this._scene.doNotHandleCursors && (this._alreadyAttachedTo.style.cursor = this._scene.defaultCursor), this._alreadyAttached = !1, this._alreadyAttachedTo = null, this._latestPointerMoveEvents.clear());
	}
	setPointerOverMesh(e, t = 0, n, r) {
		if (this._meshUnderPointerId[t] === e && (!e || !e._internalAbstractMeshDataInfo._pointerOverDisableMeshTesting)) return;
		let i = this._meshUnderPointerId[t], a;
		i && (a = i._getActionManagerForTrigger(10), a && a.processTrigger(10, new K(i, this._pointerX, this._pointerY, e, r, { pointerId: t }))), e ? (this._meshUnderPointerId[t] = e, this._pointerOverMesh = e, a = e._getActionManagerForTrigger(9), a && a.processTrigger(9, new K(e, this._pointerX, this._pointerY, e, r, {
			pointerId: t,
			pickResult: n
		}))) : (delete this._meshUnderPointerId[t], this._pointerOverMesh = null), this._scene.onMeshUnderPointerUpdatedObservable.hasObservers() && this._scene.onMeshUnderPointerUpdatedObservable.notifyObservers({
			mesh: e,
			pointerId: t
		});
	}
	getPointerOverMesh() {
		return this.meshUnderPointer;
	}
	_invalidateMesh(e) {
		this._pointerOverMesh === e && (this._pointerOverMesh = null), this._pickedDownMesh === e && (this._pickedDownMesh = null), this._pickedUpMesh === e && (this._pickedUpMesh = null);
		for (let t in this._meshUnderPointerId) this._meshUnderPointerId[t] === e && delete this._meshUnderPointerId[t];
	}
};
Q.DragMovementThreshold = 10, Q.LongPressDelay = 500, Q.DoubleClickDelay = 300, Q.ExclusiveDoubleClickMode = !1;
//#endregion
//#region node_modules/@babylonjs/core/Misc/uniqueIdGenerator.js
var qe = class {
	static get UniqueId() {
		let e = this._UniqueIdCounter;
		return this._UniqueIdCounter++, e;
	}
};
qe._UniqueIdCounter = 1;
//#endregion
//#region node_modules/@babylonjs/core/Inputs/pointerPickingConfiguration.js
var Je = class {
	constructor() {
		this.pointerDownFastCheck = !1, this.pointerUpFastCheck = !1, this.pointerMoveFastCheck = !1, this.skipPointerMovePicking = !1, this.skipPointerDownPicking = !1, this.skipPointerUpPicking = !1;
	}
}, Ye, Xe, Ze, Qe, $e, et, tt, nt, rt, it, at, ot, st, ct, lt, ut, dt, ft, pt, mt, ht, gt, _t, vt, yt, bt, xt, St, Ct, wt, Tt, Et, Dt, Ot, kt, At, jt, Mt, Nt, Pt, Ft, It, Lt, Rt, zt, Bt, Vt, Ht, Ut, Wt, Gt, Kt, qt, Jt = /*#__PURE__*/ new _(), Yt = /*#__PURE__*/ new _(), Xt;
(function(e) {
	e[e.BackwardCompatible = 0] = "BackwardCompatible", e[e.Intermediate = 1] = "Intermediate", e[e.Aggressive = 2] = "Aggressive";
})(Xt ||= {});
var $ = class e {
	static DefaultMaterialFactory(e) {
		throw o("StandardMaterial");
	}
	static CollisionCoordinatorFactory() {
		throw o("DefaultCollisionCoordinator");
	}
	_executeWithBlockedEntityCollection(e, t) {
		let n = this._blockEntityCollection;
		this._blockEntityCollection = n || e;
		try {
			return t();
		} finally {
			this._blockEntityCollection = n;
		}
	}
	get clearColor() {
		return this._clearColor;
	}
	set clearColor(e) {
		e !== this._clearColor && (this._clearColor = e, this.onClearColorChangedObservable.notifyObservers(this._clearColor));
	}
	get imageProcessingConfiguration() {
		return this._imageProcessingConfiguration;
	}
	get performancePriority() {
		return this._performancePriority;
	}
	set performancePriority(e) {
		if (e !== this._performancePriority) {
			switch (this._performancePriority = e, e) {
				case 0:
					this.skipFrustumClipping = !1, this._renderingManager.maintainStateBetweenFrames = !1, this.skipPointerMovePicking = !1, this.autoClear = !0;
					break;
				case 1:
					this.skipFrustumClipping = !1, this._renderingManager.maintainStateBetweenFrames = !1, this.skipPointerMovePicking = !0, this.autoClear = !1;
					break;
				case 2: this.skipFrustumClipping = !0, this._renderingManager.maintainStateBetweenFrames = !0, this.skipPointerMovePicking = !0, this.autoClear = !1;
			}
			this.onScenePerformancePriorityChangedObservable.notifyObservers(e);
		}
	}
	set forceWireframe(e) {
		this._forceWireframe !== e && (this._forceWireframe = e, this.markAllMaterialsAsDirty(16));
	}
	get forceWireframe() {
		return this._forceWireframe;
	}
	set skipFrustumClipping(e) {
		this._skipFrustumClipping !== e && (this._skipFrustumClipping = e);
	}
	get skipFrustumClipping() {
		return this._skipFrustumClipping;
	}
	set forcePointsCloud(e) {
		this._forcePointsCloud !== e && (this._forcePointsCloud = e, this.markAllMaterialsAsDirty(16));
	}
	get forcePointsCloud() {
		return this._forcePointsCloud;
	}
	get environmentTexture() {
		return this._environmentTexture;
	}
	set environmentTexture(e) {
		this._environmentTexture !== e && (this._environmentTexture = e, this.onEnvironmentTextureChangedObservable.notifyObservers(e), this.markAllMaterialsAsDirty(1));
	}
	getNodes() {
		let e = [];
		e = e.concat(this.meshes), e = e.concat(this.lights), e = e.concat(this.cameras), e = e.concat(this.transformNodes);
		for (let t of this.skeletons) e = e.concat(t.bones);
		return e;
	}
	get animationPropertiesOverride() {
		return this._animationPropertiesOverride;
	}
	set animationPropertiesOverride(e) {
		this._animationPropertiesOverride = e;
	}
	set onDispose(e) {
		this._onDisposeObserver && this.onDisposeObservable.remove(this._onDisposeObserver), this._onDisposeObserver = this.onDisposeObservable.add(e);
	}
	set beforeRender(e) {
		this._onBeforeRenderObserver && this.onBeforeRenderObservable.remove(this._onBeforeRenderObserver), e && (this._onBeforeRenderObserver = this.onBeforeRenderObservable.add(e));
	}
	set afterRender(e) {
		this._onAfterRenderObserver && this.onAfterRenderObservable.remove(this._onAfterRenderObserver), e && (this._onAfterRenderObserver = this.onAfterRenderObservable.add(e));
	}
	set beforeCameraRender(e) {
		this._onBeforeCameraRenderObserver && this.onBeforeCameraRenderObservable.remove(this._onBeforeCameraRenderObserver), this._onBeforeCameraRenderObserver = this.onBeforeCameraRenderObservable.add(e);
	}
	set afterCameraRender(e) {
		this._onAfterCameraRenderObserver && this.onAfterCameraRenderObservable.remove(this._onAfterCameraRenderObserver), this._onAfterCameraRenderObserver = this.onAfterCameraRenderObservable.add(e);
	}
	get pointerDownPredicate() {
		return this._pointerPickingConfiguration.pointerDownPredicate;
	}
	set pointerDownPredicate(e) {
		this._pointerPickingConfiguration.pointerDownPredicate = e;
	}
	get pointerUpPredicate() {
		return this._pointerPickingConfiguration.pointerUpPredicate;
	}
	set pointerUpPredicate(e) {
		this._pointerPickingConfiguration.pointerUpPredicate = e;
	}
	get pointerMovePredicate() {
		return this._pointerPickingConfiguration.pointerMovePredicate;
	}
	set pointerMovePredicate(e) {
		this._pointerPickingConfiguration.pointerMovePredicate = e;
	}
	get pointerDownFastCheck() {
		return this._pointerPickingConfiguration.pointerDownFastCheck;
	}
	set pointerDownFastCheck(e) {
		this._pointerPickingConfiguration.pointerDownFastCheck = e;
	}
	get pointerUpFastCheck() {
		return this._pointerPickingConfiguration.pointerUpFastCheck;
	}
	set pointerUpFastCheck(e) {
		this._pointerPickingConfiguration.pointerUpFastCheck = e;
	}
	get pointerMoveFastCheck() {
		return this._pointerPickingConfiguration.pointerMoveFastCheck;
	}
	set pointerMoveFastCheck(e) {
		this._pointerPickingConfiguration.pointerMoveFastCheck = e;
	}
	get skipPointerMovePicking() {
		return this._pointerPickingConfiguration.skipPointerMovePicking;
	}
	set skipPointerMovePicking(e) {
		this._pointerPickingConfiguration.skipPointerMovePicking = e;
	}
	get skipPointerDownPicking() {
		return this._pointerPickingConfiguration.skipPointerDownPicking;
	}
	set skipPointerDownPicking(e) {
		this._pointerPickingConfiguration.skipPointerDownPicking = e;
	}
	get skipPointerUpPicking() {
		return this._pointerPickingConfiguration.skipPointerUpPicking;
	}
	set skipPointerUpPicking(e) {
		this._pointerPickingConfiguration.skipPointerUpPicking = e;
	}
	get unTranslatedPointer() {
		return this._inputManager.unTranslatedPointer;
	}
	static get DragMovementThreshold() {
		return Q.DragMovementThreshold;
	}
	static set DragMovementThreshold(e) {
		Q.DragMovementThreshold = e;
	}
	static get LongPressDelay() {
		return Q.LongPressDelay;
	}
	static set LongPressDelay(e) {
		Q.LongPressDelay = e;
	}
	static get DoubleClickDelay() {
		return Q.DoubleClickDelay;
	}
	static set DoubleClickDelay(e) {
		Q.DoubleClickDelay = e;
	}
	static get ExclusiveDoubleClickMode() {
		return Q.ExclusiveDoubleClickMode;
	}
	static set ExclusiveDoubleClickMode(e) {
		Q.ExclusiveDoubleClickMode = e;
	}
	get _eyePosition() {
		return this._forcedViewPosition ?? this.activeCamera?.globalPosition ?? S.ZeroReadOnly;
	}
	bindEyePosition(e, t = "vEyePosition", n = !1) {
		let r = this._eyePosition, i = this.useRightHandedSystem === (this._mirroredCameraPosition != null), a = this.floatingOriginOffset, o = Jt.set(r.x, r.y, r.z, i ? -1 : 1), s = o.subtractFromFloatsToRef(a.x, a.y, a.z, 0, Yt);
		return e && (n ? e.setFloat3(t, s.x, s.y, s.z) : e.setVector4(t, s)), o;
	}
	finalizeSceneUbo() {
		let e = this.getSceneUniformBuffer(), t = this.bindEyePosition(null), n = this.floatingOriginOffset;
		return e.updateFloat4("vEyePosition", t.x - n.x, t.y - n.y, t.z - n.z, t.w), e.update(), e;
	}
	set useRightHandedSystem(e) {
		this._useRightHandedSystem !== e && (this._useRightHandedSystem = e, this.markAllMaterialsAsDirty(16));
	}
	get useRightHandedSystem() {
		return this._useRightHandedSystem;
	}
	setStepId(e) {
		this._currentStepId = e;
	}
	getStepId() {
		return this._currentStepId;
	}
	getInternalStep() {
		return this._currentInternalStep;
	}
	set fogEnabled(e) {
		this._fogEnabled !== e && (this._fogEnabled = e, this.markAllMaterialsAsDirty(16));
	}
	get fogEnabled() {
		return this._fogEnabled;
	}
	set fogMode(e) {
		this._fogMode !== e && (this._fogMode = e, this.markAllMaterialsAsDirty(16));
	}
	get fogMode() {
		return this._fogMode;
	}
	get prePass() {
		return !!this.prePassRenderer && this.prePassRenderer.defaultRT.enabled;
	}
	get needsPreviousWorldMatrices() {
		return this._needsPreviousWorldMatrices;
	}
	set needsPreviousWorldMatrices(e) {
		this._manualPreviousWorldMatrices = e, this._needsPreviousWorldMatrices = e || this._previousWorldMatricesOwners.size > 0;
	}
	_setPreviousWorldMatricesRequired(e, t) {
		t ? this._previousWorldMatricesOwners.add(e) : this._previousWorldMatricesOwners.delete(e), this._needsPreviousWorldMatrices = this._manualPreviousWorldMatrices || this._previousWorldMatricesOwners.size > 0;
	}
	set shadowsEnabled(e) {
		this._shadowsEnabled !== e && (this._shadowsEnabled = e, this.markAllMaterialsAsDirty(2));
	}
	get shadowsEnabled() {
		return this._shadowsEnabled;
	}
	set lightsEnabled(e) {
		this._lightsEnabled !== e && (this._lightsEnabled = e, this.markAllMaterialsAsDirty(2));
	}
	get lightsEnabled() {
		return this._lightsEnabled;
	}
	get activeCameras() {
		return this._activeCameras;
	}
	set activeCameras(e) {
		this._unObserveActiveCameras &&= (this._unObserveActiveCameras(), null), e && (this._unObserveActiveCameras = v(e, () => {
			this.onActiveCamerasChanged.notifyObservers(this);
		})), this._activeCameras = e;
	}
	get activeCamera() {
		return this._activeCamera;
	}
	set activeCamera(e) {
		e !== this._activeCamera && (this._activeCamera = e, this.onActiveCameraChanged.notifyObservers(this));
	}
	get _hasDefaultMaterial() {
		return e.DefaultMaterialFactory !== e._OriginalDefaultMaterialFactory;
	}
	get defaultMaterial() {
		return this._defaultMaterial ||= e.DefaultMaterialFactory(this), this._defaultMaterial;
	}
	set defaultMaterial(e) {
		this._defaultMaterial = e;
	}
	set texturesEnabled(e) {
		this._texturesEnabled !== e && (this._texturesEnabled = e, this.markAllMaterialsAsDirty(1));
	}
	get texturesEnabled() {
		return this._texturesEnabled;
	}
	get frameGraph() {
		return this._frameGraph;
	}
	set frameGraph(e) {
		this._frameGraph ? (this._frameGraph = e, e || (this.customRenderFunction = this._currentCustomRenderFunction)) : (this._frameGraph = e, e && (this._currentCustomRenderFunction = this.customRenderFunction, this.customRenderFunction = this._renderWithFrameGraph, this.activeCamera = null));
	}
	set skeletonsEnabled(e) {
		this._skeletonsEnabled !== e && (this._skeletonsEnabled = e, this.markAllMaterialsAsDirty(8));
	}
	get skeletonsEnabled() {
		return this._skeletonsEnabled;
	}
	get collisionCoordinator() {
		return this._collisionCoordinator || (this._collisionCoordinator = e.CollisionCoordinatorFactory(), this._collisionCoordinator.init(this)), this._collisionCoordinator;
	}
	get renderingManager() {
		return this._renderingManager;
	}
	get frustumPlanes() {
		return this._frustumPlanes;
	}
	_registerTransientComponents() {
		if (this._transientComponents.length > 0) {
			for (let e of this._transientComponents) e.register();
			this._transientComponents.length = 0;
		}
	}
	_addComponent(e) {
		this._components.push(e), this._transientComponents.push(e);
		let t = e;
		t.addFromContainer && t.serialize && this._serializableComponents.push(t);
	}
	_getComponent(e) {
		for (let t of this._components) if (t.name === e) return t;
		return null;
	}
	get uniqueId() {
		return this._uniqueId;
	}
	constructor(r, a) {
		this._inputManager = new Q(this), this.cameraToUseForPointers = null, this._isScene = !0, this._blockEntityCollection = !1, this.autoClear = !0, this.autoClearDepthAndStencil = !0, this._clearColor = new b(.2, .2, .3, 1), this.onClearColorChangedObservable = new t(), this.ambientColor = new x(0, 0, 0), this.environmentIntensity = 1, this.iblIntensity = 1, this._performancePriority = 0, this.onScenePerformancePriorityChangedObservable = new t(), this._forceWireframe = !1, this._skipFrustumClipping = !1, this._forcePointsCloud = !1, this.rootNodes = [], this.cameras = [], this.lights = [], this.meshes = [], this.skeletons = [], this.particleSystems = [], this.animations = [], this.animationGroups = [], this.multiMaterials = [], this.materials = [], this.morphTargetManagers = [], this.geometries = [], this.transformNodes = [], this.actionManagers = [], this.objectRenderers = [], this.textures = [], this._environmentTexture = null, this.postProcesses = [], this.effectLayers = [], this.sounds = null, this.layers = [], this.lensFlareSystems = [], this.proceduralTextures = [], this.animationsEnabled = !0, this._animationPropertiesOverride = null, this.useConstantAnimationDeltaTime = !1, this.constantlyUpdateMeshUnderPointer = !1, this.hoverCursor = "pointer", this.defaultCursor = "", this.doNotHandleCursors = !1, this.preventDefaultOnPointerDown = !0, this.preventDefaultOnPointerUp = !0, this.metadata = null, this.reservedDataStore = null, this.disableOfflineSupportExceptionRules = [], this.onDisposeObservable = new t(), this._onDisposeObserver = null, this.onBeforeRenderObservable = new t(), this._onBeforeRenderObserver = null, this.onAfterRenderObservable = new t(), this.onAfterRenderCameraObservable = new t(), this._onAfterRenderObserver = null, this.onBeforeAnimationsObservable = new t(), this.onAfterAnimationsObservable = new t(), this.onBeforeDrawPhaseObservable = new t(), this.onAfterDrawPhaseObservable = new t(), this.onReadyObservable = new t(), this.onBeforeCameraRenderObservable = new t(), this._onBeforeCameraRenderObserver = null, this.onAfterCameraRenderObservable = new t(), this._onAfterCameraRenderObserver = null, this.onBeforeActiveMeshesEvaluationObservable = new t(), this.onAfterActiveMeshesEvaluationObservable = new t(), this.onBeforeParticlesRenderingObservable = new t(), this.onAfterParticlesRenderingObservable = new t(), this.onDataLoadedObservable = new t(), this.onNewCameraAddedObservable = new t(), this.onCameraRemovedObservable = new t(), this.onNewLightAddedObservable = new t(), this.onLightRemovedObservable = new t(), this.onNewGeometryAddedObservable = new t(), this.onGeometryRemovedObservable = new t(), this.onNewTransformNodeAddedObservable = new t(), this.onTransformNodeRemovedObservable = new t(), this.onNewMeshAddedObservable = new t(), this.onMeshRemovedObservable = new t(), this.onNewSkeletonAddedObservable = new t(), this.onSkeletonRemovedObservable = new t(), this.onNewParticleSystemAddedObservable = new t(), this.onParticleSystemRemovedObservable = new t(), this.onNewAnimationGroupAddedObservable = new t(), this.onAnimationGroupRemovedObservable = new t(), this.onNewMaterialAddedObservable = new t(), this.onNewMultiMaterialAddedObservable = new t(), this.onMaterialRemovedObservable = new t(), this.onMultiMaterialRemovedObservable = new t(), this.onNewTextureAddedObservable = new t(), this.onTextureRemovedObservable = new t(), this.onNewFrameGraphAddedObservable = new t(), this.onFrameGraphRemovedObservable = new t(), this.onNewObjectRendererAddedObservable = new t(), this.onObjectRendererRemovedObservable = new t(), this.onNewPostProcessAddedObservable = new t(), this.onPostProcessRemovedObservable = new t(), this.onNewEffectLayerAddedObservable = new t(), this.onEffectLayerRemovedObservable = new t(), this.onBeforeRenderTargetsRenderObservable = new t(), this.onAfterRenderTargetsRenderObservable = new t(), this.onBeforeStepObservable = new t(), this.onAfterStepObservable = new t(), this.onActiveCameraChanged = new t(), this.onActiveCamerasChanged = new t(), this.onBeforeRenderingGroupObservable = new t(), this.onAfterRenderingGroupObservable = new t(), this.onMeshImportedObservable = new t(), this.onAnimationFileImportedObservable = new t(), this.onEnvironmentTextureChangedObservable = new t(), this.onMeshUnderPointerUpdatedObservable = new t(), this._registeredForLateAnimationBindings = new j(256), this._pointerPickingConfiguration = new Je(), this.onPrePointerObservable = new t(), this.onPointerObservable = new t(), this.onPreKeyboardObservable = new t(), this.onKeyboardObservable = new t(), this._useRightHandedSystem = !1, this._timeAccumulator = 0, this._currentStepId = 0, this._currentInternalStep = 0, this._fogEnabled = !0, this._fogMode = e.FOGMODE_NONE, this.fogColor = new x(.2, .2, .3), this.fogDensity = .1, this.fogStart = 0, this.fogEnd = 1e3, this._needsPreviousWorldMatrices = !1, this._manualPreviousWorldMatrices = !1, this._previousWorldMatricesOwners = /* @__PURE__ */ new Set(), this._shadowsEnabled = !0, this._lightsEnabled = !0, this._unObserveActiveCameras = null, this._texturesEnabled = !0, this._frameGraph = null, this.frameGraphs = [], this.physicsEnabled = !0, this.particlesEnabled = !0, this.spritesEnabled = !0, this._skeletonsEnabled = !0, this.lensFlaresEnabled = !0, this.collisionsEnabled = !0, this.gravity = new S(0, -9.807, 0), this.postProcessesEnabled = !0, this.renderTargetsEnabled = !0, this.dumpNextRenderTargets = !1, this.customRenderTargets = [], this.importedMeshesFiles = [], this.probesEnabled = !0, this._meshesForIntersections = new j(256), this.proceduralTexturesEnabled = !0, this._totalVertices = new R(), this._activeIndices = new R(), this._activeParticles = new R(), this._activeBones = new R(), this._animationTime = 0, this.animationTimeScale = 1, this._renderId = 0, this._frameId = 0, this._renderingMeshEvaluationDepth = 0, this._executeWhenReadyTimeoutId = null, this._intermediateRendering = !1, this._defaultFrameBufferCleared = !1, this._viewUpdateFlag = -1, this._projectionUpdateFlag = -1, this._toBeDisposed = Array(256), this._activeRequests = [], this._delayedFileRequests = null, this._pendingData = [], this._isDisposed = !1, this._isDisposing = !1, this._isReadyChecks = [], this.dispatchAllSubMeshesOfActiveMeshes = !1, this._activeMeshes = new M(256), this._processedMaterials = new M(256), this._renderTargets = new j(256), this._materialsRenderTargets = new j(256), this._activeParticleSystems = new M(256), this._activeSkeletons = new j(32), this._softwareSkinnedMeshes = new j(32), this._activeAnimatables = [], this._animationWrites = [], this._animationWriteCount = 0, this._animationStepWriteCount = 0, this._animationStepEvaluated = !1, this._transformMatrix = h.Zero(), this.requireLightSorting = !1, this._components = [], this._serializableComponents = [], this._transientComponents = [], this._beforeCameraUpdateStage = F.Create(), this._beforeClearStage = F.Create(), this._beforeRenderTargetClearStage = F.Create(), this._gatherRenderTargetsStage = F.Create(), this._gatherActiveCameraRenderTargetsStage = F.Create(), this._isReadyForMeshStage = F.Create(), this._beforeEvaluateActiveMeshStage = F.Create(), this._evaluateSubMeshStage = F.Create(), this._preActiveMeshStage = F.Create(), this._cameraDrawRenderTargetStage = F.Create(), this._beforeCameraDrawStage = F.Create(), this._beforeRenderTargetDrawStage = F.Create(), this._beforeRenderingGroupDrawStage = F.Create(), this._beforeRenderingMeshStage = F.Create(), this._afterRenderingMeshStage = F.Create(), this._afterRenderingGroupDrawStage = F.Create(), this._afterCameraDrawStage = F.Create(), this._afterCameraPostProcessStage = F.Create(), this._afterRenderTargetDrawStage = F.Create(), this._afterRenderTargetPostProcessStage = F.Create(), this._afterRenderStage = F.Create(), this._pointerMoveStage = F.Create(), this._pointerDownStage = F.Create(), this._pointerUpStage = F.Create(), this._geometriesByUniqueId = null, this._uniqueId = 0, this._defaultMeshCandidates = {
			data: [],
			length: 0
		}, this._defaultSubMeshCandidates = {
			data: [],
			length: 0
		}, this.onReadyTimeoutObservable = new t(), this.onReadyTimeoutDuration = 12e4, this._timeoutChecksStartTime = 0, this._floatingOriginScene = void 0, this._preventFreeActiveMeshesAndRenderingGroups = !1, this._activeMeshesFrozen = !1, this._activeMeshesFrozenButKeepClipping = !1, this._skipEvaluateActiveMeshesCompletely = !1, this._freezeActiveMeshesCancel = null, this._useCurrentFrameBuffer = !1, this._allowPostProcessClearColor = !0, this.getDeterministicFrameTime = () => this._engine.getTimeStep(), this._getFloatingOriginScene = () => this._floatingOriginScene, this._registeredActions = 0, this._blockMaterialDirtyMechanism = !1, this._perfCollector = null, this.activeCameras = [], this._uniqueId = this.getUniqueId();
		let o = {
			useGeometryUniqueIdsMap: !0,
			useMaterialMeshMap: !0,
			useClonedMeshMap: !0,
			virtual: !1,
			defaultCameraLayerMask: 268435455,
			defaultRenderableLayerMask: 268435455,
			...a
		};
		this.defaultCameraLayerMask = o.defaultCameraLayerMask, this.defaultRenderableLayerMask = o.defaultRenderableLayerMask, r = this._engine = r || n.LastCreatedEngine, o.virtual ? r._virtualScenes.push(this) : (n._LastCreatedScene = this, r.scenes.push(this)), (r.getCreationOptions().useLargeWorldRendering || a?.useFloatingOrigin) && (oe(), this._floatingOriginScene = this, se.getScene = this._getFloatingOriginScene), this._uid = null, this._renderingManager = new le(this), ue && (this.postProcessManager = new ue(this)), i() && this.attachControl(), this._createUbo(), W && (this._imageProcessingConfiguration = new W()), this.setDefaultCandidateProviders(), o.useGeometryUniqueIdsMap && (this._geometriesByUniqueId = {}), this.useMaterialMeshMap = o.useMaterialMeshMap, this.useClonedMeshMap = o.useClonedMeshMap, (!a || !a.virtual) && r.onNewSceneAddedObservable.notifyObservers(this);
	}
	getClassName() {
		return "Scene";
	}
	_getDefaultMeshCandidates() {
		return this._defaultMeshCandidates.data = this.meshes, this._defaultMeshCandidates.length = this.meshes.length, this._defaultMeshCandidates;
	}
	_getDefaultSubMeshCandidates(e) {
		return this._defaultSubMeshCandidates.data = e.subMeshes, this._defaultSubMeshCandidates.length = e.subMeshes.length, this._defaultSubMeshCandidates;
	}
	setDefaultCandidateProviders() {
		this.getActiveMeshCandidates = () => this._getDefaultMeshCandidates(), this.getActiveSubMeshCandidates = (e) => this._getDefaultSubMeshCandidates(e), this.getIntersectingSubMeshCandidates = (e, t) => this._getDefaultSubMeshCandidates(e), this.getCollidingSubMeshCandidates = (e, t) => this._getDefaultSubMeshCandidates(e);
	}
	get meshUnderPointer() {
		return this._inputManager.meshUnderPointer;
	}
	get pointerX() {
		return this._inputManager.pointerX;
	}
	set pointerX(e) {
		this._inputManager.pointerX = e;
	}
	get pointerY() {
		return this._inputManager.pointerY;
	}
	set pointerY(e) {
		this._inputManager.pointerY = e;
	}
	getCachedMaterial() {
		return this._cachedMaterial;
	}
	getCachedEffect() {
		return this._cachedEffect;
	}
	getCachedVisibility() {
		return this._cachedVisibility;
	}
	isCachedMaterialInvalid(e, t, n = 1) {
		return this._cachedEffect !== t || this._cachedMaterial !== e || this._cachedVisibility !== n;
	}
	getEngine() {
		return this._engine;
	}
	getTotalVertices() {
		return this._totalVertices.current;
	}
	get totalVerticesPerfCounter() {
		return this._totalVertices;
	}
	getActiveIndices() {
		return this._activeIndices.current;
	}
	get totalActiveIndicesPerfCounter() {
		return this._activeIndices;
	}
	getActiveParticles() {
		return this._activeParticles.current;
	}
	get activeParticlesPerfCounter() {
		return this._activeParticles;
	}
	getActiveBones() {
		return this._activeBones.current;
	}
	get activeBonesPerfCounter() {
		return this._activeBones;
	}
	getActiveMeshes() {
		return this._activeMeshes;
	}
	getAnimationRatio() {
		return this._animationRatio === void 0 ? 1 : this._animationRatio;
	}
	getRenderId() {
		return this._renderId;
	}
	getFrameId() {
		return this._frameId;
	}
	incrementRenderId() {
		this._renderId++;
	}
	_createUbo() {
		this.setSceneUniformBuffer(this.createSceneUniformBuffer());
	}
	simulatePointerMove(e, t) {
		return this._inputManager.simulatePointerMove(e, t), this;
	}
	simulatePointerDown(e, t) {
		return this._inputManager.simulatePointerDown(e, t), this;
	}
	simulatePointerUp(e, t, n) {
		return this._inputManager.simulatePointerUp(e, t, n), this;
	}
	isPointerCaptured(e = 0) {
		return this._inputManager.isPointerCaptured(e);
	}
	attachControl(e = !0, t = !0, n = !0) {
		this._inputManager.attachControl(e, t, n);
	}
	detachControl() {
		this._inputManager.detachControl();
	}
	isReady(e = !0) {
		if (this._isDisposed) return !1;
		let t, n = this.getEngine(), r = n.currentRenderPassId;
		n.currentRenderPassId = this.activeCamera?.renderPassId ?? r;
		let i = !0;
		for (this._pendingData.length > 0 && (i = !1), this.prePassRenderer?.update(), this.useOrderIndependentTransparency && this.depthPeelingRenderer && (i &&= this.depthPeelingRenderer.isReady()), e && (this._processedMaterials.reset(), this._materialsRenderTargets.reset()), t = 0; t < this.meshes.length; t++) {
			let r = this.meshes[t];
			if (!r.subMeshes || r.subMeshes.length === 0) continue;
			if (!r.isReady(!0)) {
				i = !1;
				continue;
			}
			let a = r.hasThinInstances || r.getClassName() === "InstancedMesh" || r.getClassName() === "InstancedLinesMesh" || n.getCaps().instancedArrays && r.instances.length > 0;
			for (let e of this._isReadyForMeshStage) e.action(r, a) || (i = !1);
			if (!e) continue;
			let o = r.material || this.defaultMaterial;
			if (o) {
				if (o._storeEffectOnSubMeshes) for (let e of r.subMeshes) {
					let t = e.getMaterial();
					t && t.hasRenderTargetTextures && t.getRenderTargetTextures != null && this._processedMaterials.indexOf(t) === -1 && (this._processedMaterials.push(t), this._materialsRenderTargets.concatWithNoDuplicate(t.getRenderTargetTextures()));
				}
				else o.hasRenderTargetTextures && o.getRenderTargetTextures != null && this._processedMaterials.indexOf(o) === -1 && (this._processedMaterials.push(o), this._materialsRenderTargets.concatWithNoDuplicate(o.getRenderTargetTextures()));
			}
		}
		if (e) {
			for (t = 0; t < this._materialsRenderTargets.length; ++t) this._materialsRenderTargets.data[t].isReadyForRendering() || (i = !1);
			for (t = 0; t < this.customRenderTargets.length; ++t) this.customRenderTargets[t].isReadyForRendering() || (i = !1);
		}
		for (t = 0; t < this.geometries.length; t++) this.geometries[t].delayLoadState === 2 && (i = !1);
		if (this.activeCameras && this.activeCameras.length > 0) for (let e of this.activeCameras) e.isReady(!0) || (i = !1);
		else this.activeCamera && (this.activeCamera.isReady(!0) || (i = !1));
		for (let e of this.particleSystems) e.isReady() || (i = !1);
		if (this.proceduralTexturesEnabled) for (let e of this.proceduralTextures) e.isReady() || (i = !1);
		if (this.layers) for (let e of this.layers) e.isReady() || (i = !1);
		if (this.effectLayers) for (let e of this.effectLayers) e.isLayerReady() || (i = !1);
		for (let e of this._isReadyChecks) e.isReady() || (i = !1);
		return n.areAllEffectsReady() || (i = !1), n.currentRenderPassId = r, i;
	}
	resetCachedMaterial() {
		this._cachedMaterial = null, this._cachedEffect = null, this._cachedVisibility = null;
	}
	registerBeforeRender(e) {
		this.onBeforeRenderObservable.add(e);
	}
	unregisterBeforeRender(e) {
		this.onBeforeRenderObservable.removeCallback(e);
	}
	registerAfterRender(e) {
		this.onAfterRenderObservable.add(e);
	}
	unregisterAfterRender(e) {
		this.onAfterRenderObservable.removeCallback(e);
	}
	_executeOnceBeforeRender(e) {
		let t = () => {
			e(), setTimeout(() => {
				this.unregisterBeforeRender(t);
			});
		};
		this.registerBeforeRender(t);
	}
	executeOnceBeforeRender(e, t) {
		t === void 0 ? this._executeOnceBeforeRender(e) : setTimeout(() => {
			this._executeOnceBeforeRender(e);
		}, t);
	}
	addPendingData(e) {
		this._pendingData.push(e);
	}
	removePendingData(e) {
		let t = this.isLoading, n = this._pendingData.indexOf(e);
		n !== -1 && this._pendingData.splice(n, 1), t && !this.isLoading && this.onDataLoadedObservable.notifyObservers(this);
	}
	getWaitingItemsCount() {
		return this._pendingData.length;
	}
	get isLoading() {
		return this._pendingData.length > 0;
	}
	addIsReadyCheck(e) {
		this._isReadyChecks.indexOf(e) === -1 && this._isReadyChecks.push(e);
	}
	removeIsReadyCheck(e) {
		let t = this._isReadyChecks.indexOf(e);
		t !== -1 && this._isReadyChecks.splice(t, 1);
	}
	executeWhenReady(e, t = !1) {
		this.onReadyObservable.addOnce(e), this._executeWhenReadyTimeoutId === null && this._checkIsReady(t);
	}
	async whenReadyAsync(e = !1) {
		return await new Promise((t) => {
			this.executeWhenReady(() => {
				t();
			}, e);
		});
	}
	_clearReadynessChecksData() {
		this._timeoutChecksStartTime = 0, this.onReadyTimeoutObservable.clear(), this.onReadyObservable.clear(), this._executeWhenReadyTimeoutId = null;
	}
	_checkIsReady(e = !1) {
		if (this._registerTransientComponents(), this._timeoutChecksStartTime === 0) this._timeoutChecksStartTime = u.Now;
		else if (this.onReadyTimeoutDuration > 0 && u.Now - this._timeoutChecksStartTime > this.onReadyTimeoutDuration) {
			this.onReadyTimeoutObservable.notifyObservers(this), this._clearReadynessChecksData();
			return;
		}
		this.isReady(e) ? (this.onReadyObservable.notifyObservers(this), this._clearReadynessChecksData()) : this._isDisposed ? this._clearReadynessChecksData() : this._executeWhenReadyTimeoutId = setTimeout(() => {
			this.incrementRenderId(), this._checkIsReady(e);
		}, 100);
	}
	get animatables() {
		return this._activeAnimatables;
	}
	resetLastAnimationTimeFrame() {
		this._animationTimeLast = u.Now;
	}
	getViewMatrix() {
		return this._viewMatrix;
	}
	getProjectionMatrix() {
		return this._projectionMatrix;
	}
	getInverseProjectionMatrix() {
		return this._inverseProjectionMatrix;
	}
	getTransformMatrix() {
		return this._transformMatrix;
	}
	setTransformMatrix(e, t, n, r) {
		this._multiviewSceneUboIsActive = !!(n && r && this._multiviewSceneUbo), (this._viewUpdateFlag !== e.updateFlag || this._projectionUpdateFlag !== t.updateFlag) && (this._viewUpdateFlag = e.updateFlag, this._projectionUpdateFlag = t.updateFlag, this._viewMatrix = e, this._projectionMatrix = t, this._inverseProjectionMatrix ||= new h(), this._projectionMatrix.invertToRef(this._inverseProjectionMatrix), this._viewMatrix.multiplyToRef(this._projectionMatrix, this._transformMatrix), this._frustumPlanes ? z.GetPlanesToRef(this._transformMatrix, this._frustumPlanes) : this._frustumPlanes = z.GetPlanes(this._transformMatrix), this._multiviewSceneUboIsActive && this._multiviewSceneUbo.useUbo ? this._updateMultiviewUbo(n, r) : this._sceneUbo.useUbo && (this._sceneUbo.updateMatrix("viewProjection", this._transformMatrix), this._sceneUbo.updateMatrix("view", this._viewMatrix), this._sceneUbo.updateMatrix("projection", this._projectionMatrix), this._sceneUbo.updateMatrix("inverseProjection", this._inverseProjectionMatrix)));
	}
	getSceneUniformBuffer() {
		return this._multiviewSceneUboIsActive && this._multiviewSceneUbo ? this._multiviewSceneUbo : this._sceneUbo;
	}
	createSceneUniformBuffer(e, t) {
		let n = typeof t == "boolean" ? t : t?.trackUBOsInFrame, r = new N(this._engine, void 0, !1, e ?? "scene", void 0, n);
		return r.addUniform("viewProjection", 16), r.addUniform("view", 16), r.addUniform("projection", 16), r.addUniform("vEyePosition", 4), r.addUniform("inverseProjection", 16), r;
	}
	setSceneUniformBuffer(e) {
		this._sceneUbo = e, this._viewUpdateFlag = -1, this._projectionUpdateFlag = -1;
	}
	get floatingOriginMode() {
		return this._floatingOriginScene !== void 0;
	}
	get floatingOriginOffset() {
		return this.floatingOriginMode ? this._eyePosition : S.ZeroReadOnly;
	}
	getUniqueId() {
		return qe.UniqueId;
	}
	addMesh(e, t = !1) {
		if (!this._blockEntityCollection && (this.meshes.push(e), e._resyncLightSources(), e.parent || e._addToSceneRootNodes(), d.SetImmediate(() => {
			this.onNewMeshAddedObservable.notifyObservers(e);
		}), t)) {
			let t = e.getChildMeshes();
			for (let e of t) this.addMesh(e);
		}
	}
	removeMesh(e, t = !1) {
		let n = this.meshes.indexOf(e);
		if (n !== -1 && (this.meshes.splice(n, 1), e.parent || e._removeFromSceneRootNodes()), this._inputManager._invalidateMesh(e), this.onMeshRemovedObservable.notifyObservers(e), t) {
			let t = e.getChildMeshes();
			for (let e of t) this.removeMesh(e);
		}
		return n;
	}
	addTransformNode(e) {
		this._blockEntityCollection || (e.getScene() !== this || e._indexInSceneTransformNodesArray === -1) && (e._indexInSceneTransformNodesArray = this.transformNodes.length, this.transformNodes.push(e), e.parent || e._addToSceneRootNodes(), this.onNewTransformNodeAddedObservable.notifyObservers(e));
	}
	removeTransformNode(e) {
		let t = e._indexInSceneTransformNodesArray;
		if (t !== -1) {
			if (t !== this.transformNodes.length - 1) {
				let e = this.transformNodes[this.transformNodes.length - 1];
				this.transformNodes[t] = e, e._indexInSceneTransformNodesArray = t;
			}
			e._indexInSceneTransformNodesArray = -1, this.transformNodes.pop(), e.parent || e._removeFromSceneRootNodes();
		}
		return this.onTransformNodeRemovedObservable.notifyObservers(e), t;
	}
	removeSkeleton(e) {
		let t = this.skeletons.indexOf(e);
		return t !== -1 && (this.skeletons.splice(t, 1), this.onSkeletonRemovedObservable.notifyObservers(e), this._executeActiveContainerCleanup(this._activeSkeletons)), t;
	}
	removeMorphTargetManager(e) {
		let t = this.morphTargetManagers.indexOf(e);
		return t !== -1 && this.morphTargetManagers.splice(t, 1), t;
	}
	removeLight(e) {
		let t = this.lights.indexOf(e);
		if (t !== -1) {
			for (let t of this.meshes) t._removeLightSource(e, !1);
			this.lights.splice(t, 1), this.sortLightsByPriority(), e.parent || e._removeFromSceneRootNodes(), this.onLightRemovedObservable.notifyObservers(e);
		}
		return t;
	}
	removeCamera(e) {
		let t = this.cameras.indexOf(e);
		if (t !== -1 && (this.cameras.splice(t, 1), e.parent || e._removeFromSceneRootNodes()), this.activeCameras) {
			let t = this.activeCameras.indexOf(e);
			t !== -1 && this.activeCameras.splice(t, 1);
		}
		return this.activeCamera === e && (this.activeCamera = this.cameras.length > 0 ? this.cameras[0] : null), this.onCameraRemovedObservable.notifyObservers(e), t;
	}
	removeParticleSystem(e) {
		let t = this.particleSystems.indexOf(e);
		return t !== -1 && (this.particleSystems.splice(t, 1), this._executeActiveContainerCleanup(this._activeParticleSystems)), this.onParticleSystemRemovedObservable.notifyObservers(e), t;
	}
	removeAnimation(e) {
		let t = this.animations.indexOf(e);
		return t !== -1 && this.animations.splice(t, 1), t;
	}
	stopAnimation(e, t, n) {}
	removeAnimationGroup(e) {
		let t = this.animationGroups.indexOf(e);
		return t !== -1 && this.animationGroups.splice(t, 1), this.onAnimationGroupRemovedObservable.notifyObservers(e), t;
	}
	removeMultiMaterial(e) {
		let t = this.multiMaterials.indexOf(e);
		return t !== -1 && this.multiMaterials.splice(t, 1), this.onMultiMaterialRemovedObservable.notifyObservers(e), t;
	}
	removeMaterial(e) {
		let t = e._indexInSceneMaterialArray;
		if (t !== -1 && t < this.materials.length) {
			if (t !== this.materials.length - 1) {
				let e = this.materials[this.materials.length - 1];
				this.materials[t] = e, e._indexInSceneMaterialArray = t;
			}
			e._indexInSceneMaterialArray = -1, this.materials.pop();
		}
		return this.onMaterialRemovedObservable.notifyObservers(e), t;
	}
	removeActionManager(e) {
		let t = this.actionManagers.indexOf(e);
		return t !== -1 && this.actionManagers.splice(t, 1), t;
	}
	removeTexture(e) {
		let t = this.textures.indexOf(e);
		return t !== -1 && this.textures.splice(t, 1), this.onTextureRemovedObservable.notifyObservers(e), t;
	}
	removeFrameGraph(e) {
		let t = this.frameGraphs.indexOf(e);
		return t !== -1 && this.frameGraphs.splice(t, 1), this.onFrameGraphRemovedObservable.notifyObservers(e), t;
	}
	removeObjectRenderer(e) {
		let t = this.objectRenderers.indexOf(e);
		return t !== -1 && this.objectRenderers.splice(t, 1), this.onObjectRendererRemovedObservable.notifyObservers(e), t;
	}
	removePostProcess(e) {
		let t = this.postProcesses.indexOf(e);
		return t !== -1 && this.postProcesses.splice(t, 1), this.onPostProcessRemovedObservable.notifyObservers(e), t;
	}
	removeEffectLayer(e) {
		let t = this.effectLayers.indexOf(e);
		return t !== -1 && this.effectLayers.splice(t, 1), this.onEffectLayerRemovedObservable.notifyObservers(e), t;
	}
	addLight(e) {
		if (!this._blockEntityCollection) {
			this.lights.push(e), this.sortLightsByPriority(), e.parent || e._addToSceneRootNodes();
			for (let t of this.meshes) t.lightSources.indexOf(e) === -1 && (t.lightSources.push(e), t._resyncLightSources());
			d.SetImmediate(() => {
				this.onNewLightAddedObservable.notifyObservers(e);
			});
		}
	}
	sortLightsByPriority() {
		this.requireLightSorting && this.lights.sort(P.CompareLightsPriority);
	}
	addCamera(e) {
		this._blockEntityCollection || (this.cameras.push(e), d.SetImmediate(() => {
			this.onNewCameraAddedObservable.notifyObservers(e);
		}), e.parent || e._addToSceneRootNodes());
	}
	addSkeleton(e) {
		this._blockEntityCollection || (this.skeletons.push(e), d.SetImmediate(() => {
			this.onNewSkeletonAddedObservable.notifyObservers(e);
		}));
	}
	addParticleSystem(e) {
		this._blockEntityCollection || (this.particleSystems.push(e), d.SetImmediate(() => {
			this.onNewParticleSystemAddedObservable.notifyObservers(e);
		}));
	}
	addAnimation(e) {
		this._blockEntityCollection || this.animations.push(e);
	}
	addAnimationGroup(e) {
		this._blockEntityCollection || (this.animationGroups.push(e), d.SetImmediate(() => {
			this.onNewAnimationGroupAddedObservable.notifyObservers(e);
		}));
	}
	addMultiMaterial(e) {
		this._blockEntityCollection || (this.multiMaterials.push(e), d.SetImmediate(() => {
			this.onNewMultiMaterialAddedObservable.notifyObservers(e);
		}));
	}
	addMaterial(e) {
		this._blockEntityCollection || (e.getScene() !== this || e._indexInSceneMaterialArray === -1) && (e._indexInSceneMaterialArray = this.materials.length, this.materials.push(e), d.SetImmediate(() => {
			this.onNewMaterialAddedObservable.notifyObservers(e);
		}));
	}
	addMorphTargetManager(e) {
		this._blockEntityCollection || this.morphTargetManagers.push(e);
	}
	addGeometry(e) {
		this._blockEntityCollection || (this._geometriesByUniqueId && (this._geometriesByUniqueId[e.uniqueId] = this.geometries.length), this.geometries.push(e));
	}
	addActionManager(e) {
		this.actionManagers.push(e);
	}
	addTexture(e) {
		this._blockEntityCollection || (this.textures.push(e), this.onNewTextureAddedObservable.notifyObservers(e));
	}
	addFrameGraph(e) {
		this.frameGraphs.push(e), d.SetImmediate(() => {
			this.onNewFrameGraphAddedObservable.notifyObservers(e);
		});
	}
	addObjectRenderer(e) {
		this.objectRenderers.push(e), d.SetImmediate(() => {
			this.onNewObjectRendererAddedObservable.notifyObservers(e);
		});
	}
	addPostProcess(e) {
		this._blockEntityCollection || (this.postProcesses.push(e), d.SetImmediate(() => {
			this.onNewPostProcessAddedObservable.notifyObservers(e);
		}));
	}
	addEffectLayer(e) {
		this._blockEntityCollection || (this.effectLayers.push(e), d.SetImmediate(() => {
			this.onNewEffectLayerAddedObservable.notifyObservers(e);
		}));
	}
	switchActiveCamera(e, t = !0) {
		this._engine.getInputElement() && (this.activeCamera && this.activeCamera.detachControl(), this.activeCamera = e, t && e.attachControl());
	}
	setActiveCameraById(e) {
		let t = this.getCameraById(e);
		return t ? (this.activeCamera = t, t) : null;
	}
	setActiveCameraByName(e) {
		let t = this.getCameraByName(e);
		return t ? (this.activeCamera = t, t) : null;
	}
	getAnimationGroupByName(e) {
		for (let t = 0; t < this.animationGroups.length; t++) if (this.animationGroups[t].name === e) return this.animationGroups[t];
		return null;
	}
	_getMaterial(e, t) {
		for (let e = 0; e < this.materials.length; e++) {
			let n = this.materials[e];
			if (t(n)) return n;
		}
		if (e) for (let e = 0; e < this.multiMaterials.length; e++) {
			let n = this.multiMaterials[e];
			if (t(n)) return n;
		}
		return null;
	}
	getMaterialByUniqueID(e, t = !1) {
		return this.getMaterialByUniqueId(e, t);
	}
	getMaterialByUniqueId(e, t = !1) {
		return this._getMaterial(t, (t) => t.uniqueId === e);
	}
	getMaterialById(e, t = !1) {
		return this._getMaterial(t, (t) => t.id === e);
	}
	getMaterialByName(e, t = !1) {
		return this._getMaterial(t, (t) => t.name === e);
	}
	getLastMaterialById(e, t = !1) {
		for (let t = this.materials.length - 1; t >= 0; t--) if (this.materials[t].id === e) return this.materials[t];
		if (t) {
			for (let t = this.multiMaterials.length - 1; t >= 0; t--) if (this.multiMaterials[t].id === e) return this.multiMaterials[t];
		}
		return null;
	}
	getTextureByUniqueId(e) {
		for (let t = 0; t < this.textures.length; t++) if (this.textures[t].uniqueId === e) return this.textures[t];
		return null;
	}
	getTextureByName(e) {
		for (let t = 0; t < this.textures.length; t++) if (this.textures[t].name === e) return this.textures[t];
		return null;
	}
	getCameraById(e) {
		for (let t = 0; t < this.cameras.length; t++) if (this.cameras[t].id === e) return this.cameras[t];
		return null;
	}
	getCameraByUniqueId(e) {
		for (let t = 0; t < this.cameras.length; t++) if (this.cameras[t].uniqueId === e) return this.cameras[t];
		return null;
	}
	getCameraByName(e) {
		for (let t = 0; t < this.cameras.length; t++) if (this.cameras[t].name === e) return this.cameras[t];
		return null;
	}
	getBoneById(e) {
		for (let t = 0; t < this.skeletons.length; t++) {
			let n = this.skeletons[t];
			for (let t = 0; t < n.bones.length; t++) if (n.bones[t].id === e) return n.bones[t];
		}
		return null;
	}
	getBoneByName(e) {
		for (let t = 0; t < this.skeletons.length; t++) {
			let n = this.skeletons[t];
			for (let t = 0; t < n.bones.length; t++) if (n.bones[t].name === e) return n.bones[t];
		}
		return null;
	}
	getLightByName(e) {
		for (let t = 0; t < this.lights.length; t++) if (this.lights[t].name === e) return this.lights[t];
		return null;
	}
	getLightById(e) {
		for (let t = 0; t < this.lights.length; t++) if (this.lights[t].id === e) return this.lights[t];
		return null;
	}
	getLightByUniqueId(e) {
		for (let t = 0; t < this.lights.length; t++) if (this.lights[t].uniqueId === e) return this.lights[t];
		return null;
	}
	getParticleSystemById(e) {
		for (let t = 0; t < this.particleSystems.length; t++) if (this.particleSystems[t].id === e) return this.particleSystems[t];
		return null;
	}
	getGeometryById(e) {
		for (let t = 0; t < this.geometries.length; t++) if (this.geometries[t].id === e) return this.geometries[t];
		return null;
	}
	_getGeometryByUniqueId(e) {
		if (this._geometriesByUniqueId) {
			let t = this._geometriesByUniqueId[e];
			if (t !== void 0) return this.geometries[t];
		} else for (let t = 0; t < this.geometries.length; t++) if (this.geometries[t].uniqueId === e) return this.geometries[t];
		return null;
	}
	getFrameGraphByName(e) {
		for (let t = 0; t < this.frameGraphs.length; t++) if (this.frameGraphs[t].name === e) return this.frameGraphs[t];
		return null;
	}
	pushGeometry(e, t) {
		return !t && this._getGeometryByUniqueId(e.uniqueId) ? !1 : (this.addGeometry(e), d.SetImmediate(() => {
			this.onNewGeometryAddedObservable.notifyObservers(e);
		}), !0);
	}
	removeGeometry(e) {
		let t;
		if (this._geometriesByUniqueId) {
			if (t = this._geometriesByUniqueId[e.uniqueId], t === void 0) return !1;
		} else if (t = this.geometries.indexOf(e), t < 0) return !1;
		if (t !== this.geometries.length - 1) {
			let e = this.geometries[this.geometries.length - 1];
			e && (this.geometries[t] = e, this._geometriesByUniqueId && (this._geometriesByUniqueId[e.uniqueId] = t));
		}
		return this._geometriesByUniqueId && (this._geometriesByUniqueId[e.uniqueId] = void 0), this.geometries.pop(), this.onGeometryRemovedObservable.notifyObservers(e), !0;
	}
	getGeometries() {
		return this.geometries;
	}
	getMeshById(e) {
		for (let t = 0; t < this.meshes.length; t++) if (this.meshes[t].id === e) return this.meshes[t];
		return null;
	}
	getMeshesById(e) {
		return this.meshes.filter(function(t) {
			return t.id === e;
		});
	}
	getTransformNodeById(e) {
		for (let t = 0; t < this.transformNodes.length; t++) if (this.transformNodes[t].id === e) return this.transformNodes[t];
		return null;
	}
	getTransformNodeByUniqueId(e) {
		for (let t = 0; t < this.transformNodes.length; t++) if (this.transformNodes[t].uniqueId === e) return this.transformNodes[t];
		return null;
	}
	getTransformNodesById(e) {
		return this.transformNodes.filter(function(t) {
			return t.id === e;
		});
	}
	getMeshByUniqueId(e) {
		for (let t = 0; t < this.meshes.length; t++) if (this.meshes[t].uniqueId === e) return this.meshes[t];
		return null;
	}
	getLastMeshById(e) {
		for (let t = this.meshes.length - 1; t >= 0; t--) if (this.meshes[t].id === e) return this.meshes[t];
		return null;
	}
	getLastTransformNodeById(e) {
		for (let t = this.transformNodes.length - 1; t >= 0; t--) if (this.transformNodes[t].id === e) return this.transformNodes[t];
		return null;
	}
	getLastEntryById(e) {
		let t;
		for (t = this.meshes.length - 1; t >= 0; t--) if (this.meshes[t].id === e) return this.meshes[t];
		for (t = this.transformNodes.length - 1; t >= 0; t--) if (this.transformNodes[t].id === e) return this.transformNodes[t];
		for (t = this.cameras.length - 1; t >= 0; t--) if (this.cameras[t].id === e) return this.cameras[t];
		for (t = this.lights.length - 1; t >= 0; t--) if (this.lights[t].id === e) return this.lights[t];
		for (t = this.skeletons.length - 1; t >= 0; t--) {
			let n = this.skeletons[t];
			for (let t = n.bones.length - 1; t >= 0; t--) if (n.bones[t].id === e) return n.bones[t];
		}
		return null;
	}
	getNodeById(e) {
		return this.getMeshById(e) || this.getTransformNodeById(e) || this.getLightById(e) || this.getCameraById(e) || this.getBoneById(e) || null;
	}
	getNodeByName(e) {
		return this.getMeshByName(e) || this.getTransformNodeByName(e) || this.getLightByName(e) || this.getCameraByName(e) || this.getBoneByName(e) || null;
	}
	getMeshByName(e) {
		for (let t = 0; t < this.meshes.length; t++) if (this.meshes[t].name === e) return this.meshes[t];
		return null;
	}
	getTransformNodeByName(e) {
		for (let t = 0; t < this.transformNodes.length; t++) if (this.transformNodes[t].name === e) return this.transformNodes[t];
		return null;
	}
	getLastSkeletonById(e) {
		for (let t = this.skeletons.length - 1; t >= 0; t--) if (this.skeletons[t].id === e) return this.skeletons[t];
		return null;
	}
	getSkeletonByUniqueId(e) {
		for (let t = 0; t < this.skeletons.length; t++) if (this.skeletons[t].uniqueId === e) return this.skeletons[t];
		return null;
	}
	getSkeletonById(e) {
		for (let t = 0; t < this.skeletons.length; t++) if (this.skeletons[t].id === e) return this.skeletons[t];
		return null;
	}
	getSkeletonByName(e) {
		for (let t = 0; t < this.skeletons.length; t++) if (this.skeletons[t].name === e) return this.skeletons[t];
		return null;
	}
	getMorphTargetManagerById(e) {
		for (let t = 0; t < this.morphTargetManagers.length; t++) if (this.morphTargetManagers[t].uniqueId === e) return this.morphTargetManagers[t];
		return null;
	}
	getMorphTargetById(e) {
		for (let t = 0; t < this.morphTargetManagers.length; ++t) {
			let n = this.morphTargetManagers[t];
			for (let t = 0; t < n.numTargets; ++t) {
				let r = n.getTarget(t);
				if (r.id === e) return r;
			}
		}
		return null;
	}
	getMorphTargetByName(e) {
		for (let t = 0; t < this.morphTargetManagers.length; ++t) {
			let n = this.morphTargetManagers[t];
			for (let t = 0; t < n.numTargets; ++t) {
				let r = n.getTarget(t);
				if (r.name === e) return r;
			}
		}
		return null;
	}
	getPostProcessByName(e) {
		for (let t = 0; t < this.postProcesses.length; ++t) {
			let n = this.postProcesses[t];
			if (n.name === e) return n;
		}
		return null;
	}
	isActiveMesh(e) {
		return this._activeMeshes.indexOf(e) !== -1;
	}
	get uid() {
		return this._uid ||= A.RandomId(), this._uid;
	}
	addExternalData(e, t) {
		return this._externalData ||= new he(), this._externalData.add(e, t);
	}
	getExternalData(e) {
		return this._externalData ? this._externalData.get(e) : null;
	}
	getOrAddExternalDataWithFactory(e, t) {
		return this._externalData ||= new he(), this._externalData.getOrAddWithFactory(e, t);
	}
	removeExternalData(e) {
		return this._externalData.remove(e);
	}
	_evaluateSubMesh(e, t, n, r) {
		if (r || e.isInFrustum(this._frustumPlanes)) {
			for (let n of this._evaluateSubMeshStage) n.action(t, e);
			let n = e.getMaterial();
			n != null && (n.hasRenderTargetTextures && n.getRenderTargetTextures != null && this._processedMaterials.indexOf(n) === -1 && (this._processedMaterials.push(n), this._materialsRenderTargets.concatWithNoDuplicate(n.getRenderTargetTextures())), this._renderingManager.dispatch(e, t, n));
		}
	}
	freeProcessedMaterials() {
		this._processedMaterials.dispose();
	}
	get blockfreeActiveMeshesAndRenderingGroups() {
		return this._preventFreeActiveMeshesAndRenderingGroups;
	}
	set blockfreeActiveMeshesAndRenderingGroups(e) {
		this._preventFreeActiveMeshesAndRenderingGroups !== e && (e && (this.freeActiveMeshes(), this.freeRenderingGroups()), this._preventFreeActiveMeshesAndRenderingGroups = e);
	}
	freeActiveMeshes() {
		if (!this.blockfreeActiveMeshesAndRenderingGroups && (this._activeMeshes.dispose(), this.activeCamera && this.activeCamera._activeMeshes && this.activeCamera._activeMeshes.dispose(), this.activeCameras)) for (let e = 0; e < this.activeCameras.length; e++) {
			let t = this.activeCameras[e];
			t && t._activeMeshes && t._activeMeshes.dispose();
		}
	}
	freeRenderingGroups() {
		if (!this.blockfreeActiveMeshesAndRenderingGroups && (this._renderingManager && this._renderingManager.freeRenderingGroups(), this.textures)) for (let e = 0; e < this.textures.length; e++) {
			let t = this.textures[e];
			t && t.renderList && t.freeRenderingGroups();
		}
	}
	_isInIntermediateRendering() {
		return this._intermediateRendering;
	}
	_isInRenderingMeshEvaluation() {
		return this._renderingMeshEvaluationDepth > 0;
	}
	freezeActiveMeshes(e = !1, t, n, i = !0, a = !1) {
		if (this.frameGraph) {
			this._renderWithFrameGraph(!0, !1, !0);
			let o = this.frameGraph.getTasksByClassName(["FrameGraphObjectRendererTask", "FrameGraphGeometryRendererTask"]);
			for (let e of o) e.objectRenderer._freezeActiveMeshes(i);
			return this._freezeActiveMeshesCancel = c(() => {
				let e = !0, t = !0;
				for (let n of o) e &&= n.objectRenderer._isFrozen, t &&= n.objectRenderer._freezeActiveMeshesCancel !== null;
				if (e) return !0;
				if (!t) throw Error("Freezing active meshes was cancelled");
				return !1;
			}, () => {
				this._freezeActiveMeshesCancel = null, this._activeMeshesFrozen = !0, this._activeMeshesFrozenButKeepClipping = a, this._skipEvaluateActiveMeshesCompletely = e, t?.();
			}, (e, t) => {
				if (this._freezeActiveMeshesCancel = null, this.unfreezeActiveMeshes(), t) {
					let t = "Scene: Timeout while waiting for meshes to be frozen.";
					n ? n(t) : (r.Error(t), e && r.Error(e));
				} else {
					let t = "Scene: An unexpected error occurred while trying to freeze active meshes.";
					n ? n(t) : (r.Error(t), e && (r.Error(e), e.stack && r.Error(e.stack)));
				}
			}), this;
		}
		return this.executeWhenReady(() => {
			if (!this.activeCamera) n && n("No active camera found");
			else {
				if (this._frustumPlanes || this.updateTransformMatrix(), this._evaluateActiveMeshes(), this._activeMeshesFrozen = !0, this._activeMeshesFrozenButKeepClipping = a, this._skipEvaluateActiveMeshesCompletely = e, i) for (let e = 0; e < this._activeMeshes.length; e++) this._activeMeshes.data[e]._freeze();
				t && t();
			}
		}), this;
	}
	unfreezeActiveMeshes() {
		for (let e = 0; e < this.meshes.length; e++) {
			let t = this.meshes[e];
			t._internalAbstractMeshDataInfo && (t._internalAbstractMeshDataInfo._isActive = !1);
		}
		if (this._freezeActiveMeshesCancel?.(), this._freezeActiveMeshesCancel = null, this.frameGraph) {
			let e = this.frameGraph.getTasksByClassName(["FrameGraphObjectRendererTask", "FrameGraphGeometryRendererTask"]);
			for (let t of e) t.objectRenderer._unfreezeActiveMeshes();
		} else for (let e = 0; e < this._activeMeshes.length; e++) this._activeMeshes.data[e]._unFreeze();
		return this._activeMeshesFrozen = !1, this;
	}
	_executeActiveContainerCleanup(e) {
		!(this._engine.snapshotRendering && this._engine.snapshotRenderingMode === 1) && this._activeMeshesFrozen && this._activeMeshes.length || this.onBeforeRenderObservable.addOnce(() => e.dispose());
	}
	_evaluateActiveMeshes() {
		if (this._engine.snapshotRendering && this._engine.snapshotRenderingMode === 1) {
			this._activeMeshes.length > 0 && (this.activeCamera?._activeMeshes.reset(), this._activeMeshes.reset(), this._renderingManager.reset(), this._processedMaterials.reset(), this._activeParticleSystems.reset(), this._activeSkeletons.reset(), this._softwareSkinnedMeshes.reset());
			return;
		}
		if (this._activeMeshesFrozen && this._activeMeshes.length) {
			if (!this._skipEvaluateActiveMeshesCompletely) {
				let e = this._activeMeshes.length;
				for (let t = 0; t < e; t++) this._activeMeshes.data[t].computeWorldMatrix();
			}
			if (this._activeParticleSystems) {
				let e = this._activeParticleSystems.length;
				for (let t = 0; t < e; t++) this._activeParticleSystems.data[t].animate();
			}
			this._renderingManager.resetSprites();
			return;
		}
		if (!this.activeCamera) return;
		this.onBeforeActiveMeshesEvaluationObservable.notifyObservers(this), this.activeCamera._activeMeshes.reset(), this._activeMeshes.reset(), this._renderingManager.reset(), this._processedMaterials.reset(), this._activeParticleSystems.reset(), this._activeSkeletons.reset(), this._softwareSkinnedMeshes.reset(), this._materialsRenderTargets.reset();
		for (let e of this._beforeEvaluateActiveMeshStage) e.action();
		let e = this.getActiveMeshCandidates(), t = e.length;
		for (let n = 0; n < t; n++) {
			let t = e.data[n], r = t._internalAbstractMeshDataInfo._currentLOD.get(this.activeCamera);
			if (r ? r[1] = -1 : (r = [t, -1], t._internalAbstractMeshDataInfo._currentLOD.set(this.activeCamera, r)), t.isBlocked || (this._totalVertices.addCount(t.getTotalVertices(), !1), !t.isReady() || !t.isEnabled() || t.scaling.hasAZeroComponent)) continue;
			t.computeWorldMatrix(), t.actionManager && t.actionManager.hasSpecificTriggers2(12, 13) && this._meshesForIntersections.pushNoDuplicate(t);
			let i = this.customLODSelector ? this.customLODSelector(t, this.activeCamera) : t.getLOD(this.activeCamera);
			if (r[0] = i, r[1] = this._frameId, i != null && (i !== t && i.billboardMode !== 0 && i.computeWorldMatrix(), t._preActivate(), t.isVisible && t.visibility > 0 && (t.layerMask & this.activeCamera.layerMask) !== 0 && (this._skipFrustumClipping || t.alwaysSelectAsActiveMesh || t.isInFrustum(this._frustumPlanes)))) {
				this._activeMeshes.push(t), this.activeCamera._activeMeshes.push(t), i !== t && i._activate(this._renderId, !1);
				for (let e of this._preActiveMeshStage) e.action(t);
				t._activate(this._renderId, !1) && (t.isAnInstance ? t._internalAbstractMeshDataInfo._actAsRegularMesh && (i = t) : i._internalAbstractMeshDataInfo._onlyForInstances = !1, i._internalAbstractMeshDataInfo._isActive = !0, this._activeMesh(t, i)), t._postActivate();
			}
		}
		if (this.onAfterActiveMeshesEvaluationObservable.notifyObservers(this), this.particlesEnabled) {
			this.onBeforeParticlesRenderingObservable.notifyObservers(this);
			for (let e = 0; e < this.particleSystems.length; e++) {
				let t = this.particleSystems[e];
				if (!t.isStarted() || !t.emitter) continue;
				let n = t.emitter;
				(!n.position || n.isEnabled()) && (this._activeParticleSystems.push(t), t.animate(), this._renderingManager.dispatchParticles(t));
			}
			this.onAfterParticlesRenderingObservable.notifyObservers(this);
		}
	}
	_prepareSkeleton(e) {
		this._skeletonsEnabled && e.skeleton && (this._activeSkeletons.pushNoDuplicate(e.skeleton) && (e.skeleton.prepare(), this._activeBones.addCount(e.skeleton.bones.length, !1)), e.computeBonesUsingShaders || this._softwareSkinnedMeshes.pushNoDuplicate(e) && this.frameGraph && e.applySkeleton(e.skeleton));
	}
	_activeMesh(e, t) {
		this._prepareSkeleton(t);
		let n = e.hasInstances || e.isAnInstance || this.dispatchAllSubMeshesOfActiveMeshes || this._skipFrustumClipping || t.alwaysSelectAsActiveMesh;
		if (t && t.subMeshes && t.subMeshes.length > 0) {
			let r = this.getActiveSubMeshCandidates(t), i = r.length;
			n ||= i === 1;
			for (let a = 0; a < i; a++) {
				let i = r.data[a];
				this._evaluateSubMesh(i, t, e, n);
			}
		}
	}
	updateTransformMatrix(e) {
		let t = this.activeCamera;
		if (t) {
			if (t._renderingMultiview) {
				let n = t._rigCameras[0], r = t._rigCameras[1];
				this.setTransformMatrix(n.getViewMatrix(), n.getProjectionMatrix(e), r.getViewMatrix(), r.getProjectionMatrix(e));
			} else this.setTransformMatrix(t.getViewMatrix(), t.getProjectionMatrix(e));
		}
	}
	_bindFrameBuffer(e, t = !0) {
		this._useCurrentFrameBuffer || (e && e._multiviewTexture ? e._multiviewTexture._bindFrameBuffer() : e && e.outputRenderTarget ? e.outputRenderTarget._bindFrameBuffer() : this._engine._currentFrameBufferIsDefaultFrameBuffer() || this._engine.restoreDefaultFramebuffer()), t && this._clearFrameBuffer(e);
	}
	_clearFrameBuffer(e) {
		if (!(e && e._multiviewTexture)) {
			if (e && e.outputRenderTarget && !e._renderingMultiview) {
				let t = e.outputRenderTarget;
				t.onClearObservable.hasObservers() ? t.onClearObservable.notifyObservers(this._engine) : !t.skipInitialClear && !e.isRightCamera && (this.autoClear && this._engine.clear(t.clearColor || this._clearColor, !t._cleared, !0, !0), t._cleared = !0);
			} else this._defaultFrameBufferCleared ? this._engine.clear(null, !1, !0, !0) : (this._defaultFrameBufferCleared = !0, this._clear());
		}
	}
	_renderForCamera(e, t, n = !0) {
		if (e && e._skipRendering) return;
		let r = this._engine;
		if (this._activeCamera = e, !this.activeCamera) throw Error("Active camera not set");
		if (r.setViewport(this.activeCamera.viewport), this.resetCachedMaterial(), this._renderId++, !this.prePass && n) {
			let t = !0;
			e._renderingMultiview && e.outputRenderTarget && (t = e.outputRenderTarget.skipInitialClear, this.autoClear && (this._defaultFrameBufferCleared = !1, e.outputRenderTarget.skipInitialClear = !1)), this._bindFrameBuffer(this._activeCamera), e._renderingMultiview && e.outputRenderTarget && (e.outputRenderTarget.skipInitialClear = t);
		}
		this.updateTransformMatrix(), this.onBeforeCameraRenderObservable.notifyObservers(this.activeCamera), this._engine.currentRenderPassId = e.outputRenderTarget?.renderPassId ?? e.renderPassId ?? 0, this._evaluateActiveMeshes();
		for (let e = 0; e < this._softwareSkinnedMeshes.length; e++) {
			let t = this._softwareSkinnedMeshes.data[e];
			t.applySkeleton(t.skeleton);
		}
		this.onBeforeRenderTargetsRenderObservable.notifyObservers(this), this._renderTargets.concatWithNoDuplicate(this._materialsRenderTargets), e.customRenderTargets && e.customRenderTargets.length > 0 && this._renderTargets.concatWithNoDuplicate(e.customRenderTargets), t && t.customRenderTargets && t.customRenderTargets.length > 0 && this._renderTargets.concatWithNoDuplicate(t.customRenderTargets), this.environmentTexture && this.environmentTexture.isRenderTarget && this._renderTargets.pushNoDuplicate(this.environmentTexture);
		for (let e of this._gatherActiveCameraRenderTargetsStage) e.action(this._renderTargets);
		let i = !1;
		if (this.renderTargetsEnabled) {
			this._intermediateRendering = !0;
			let e;
			if (this._renderTargets.length > 0) {
				A.StartPerformanceCounter("Render targets", this._renderTargets.length > 0);
				let t = this.getBoundingBoxRenderer?.();
				for (let n = 0; n < this._renderTargets.length; n++) {
					let r = this._renderTargets.data[n];
					if (r._shouldRender()) {
						this._renderId++;
						let n = r.activeCamera && r.activeCamera !== this.activeCamera;
						t && !e && (e = t.renderList.length > 0 ? t.renderList.data.slice() : [], e.length = t.renderList.length), r.render(n, this.dumpNextRenderTargets), i = !0;
					}
				}
				t && e && (t.renderList.data = e, t.renderList.length = e.length), A.EndPerformanceCounter("Render targets", this._renderTargets.length > 0), this._renderId++;
			}
			if (this._cameraDrawRenderTargetStage.length > 0) {
				let t = this.getBoundingBoxRenderer?.();
				t && !e && (e = t.renderList.length > 0 ? t.renderList.data.slice() : [], e.length = t.renderList.length);
				for (let e of this._cameraDrawRenderTargetStage) i = e.action(this.activeCamera) || i;
				t && e && (t.renderList.data = e, t.renderList.length = e.length);
			}
			this._intermediateRendering = !1;
		}
		i && !this.prePass && (this._bindFrameBuffer(this._activeCamera, !1), this.updateTransformMatrix()), this.onAfterRenderTargetsRenderObservable.notifyObservers(this), this.postProcessManager && !e._multiviewTexture && !this.prePass && this.postProcessManager._prepareFrame();
		for (let e of this._beforeCameraDrawStage) e.action(this.activeCamera);
		this.onBeforeDrawPhaseObservable.notifyObservers(this);
		let a = r.snapshotRendering && r.snapshotRenderingMode === 1;
		a && this.finalizeSceneUbo(), this._renderingManager.render(null, null, !0, !a), this.onAfterDrawPhaseObservable.notifyObservers(this);
		for (let e of this._afterCameraDrawStage) e.action(this.activeCamera);
		if (this.postProcessManager && !e._multiviewTexture) {
			let t = e.outputRenderTarget ? e.outputRenderTarget.renderTarget : void 0;
			this.postProcessManager._finalizeFrame(e.isIntermediate, t);
		}
		for (let e of this._afterCameraPostProcessStage) e.action(this.activeCamera);
		this._renderTargets.reset(), this.onAfterCameraRenderObservable.notifyObservers(this.activeCamera);
	}
	_processSubCameras(e, t = !0) {
		if (e.cameraRigMode === 0 || e._renderingMultiview) e._renderingMultiview && !this._multiviewSceneUbo && this._createMultiviewUbo(), this._renderForCamera(e, void 0, t), this.onAfterRenderCameraObservable.notifyObservers(e);
		else {
			if (e._useMultiviewToSingleView) this._renderMultiviewToSingleView(e);
			else {
				this.onBeforeCameraRenderObservable.notifyObservers(e);
				for (let t = 0; t < e._rigCameras.length; t++) this._renderForCamera(e._rigCameras[t], e);
			}
			this._activeCamera = e, this.updateTransformMatrix(), this.onAfterRenderCameraObservable.notifyObservers(e);
		}
	}
	_checkIntersections() {
		for (let e = 0; e < this._meshesForIntersections.length; e++) {
			let t = this._meshesForIntersections.data[e];
			if (t.actionManager) for (let e = 0; t.actionManager && e < t.actionManager.actions.length; e++) {
				let n = t.actionManager.actions[e];
				if (n.trigger === 12 || n.trigger === 13) {
					let e = n.getTriggerParameter(), r = e.mesh ? e.mesh : e, i = r.intersectsMesh(t, e.usePreciseIntersection), a = t._intersectionsInProgress.indexOf(r);
					i && a === -1 ? n.trigger === 12 ? (n._executeCurrent(K.CreateNew(t, void 0, r)), t._intersectionsInProgress.push(r)) : n.trigger === 13 && t._intersectionsInProgress.push(r) : !i && a > -1 && (n.trigger === 13 && n._executeCurrent(K.CreateNew(t, void 0, r)), (!t.actionManager.hasSpecificTrigger(13, (e) => {
						let t = e.mesh ? e.mesh : e;
						return r === t;
					}) || n.trigger === 13) && t._intersectionsInProgress.splice(a, 1));
				}
			}
		}
	}
	_advancePhysicsEngineStep(e) {}
	_animate(e) {}
	animate() {
		if (this._engine.isDeterministicLockStep()) {
			let t = Math.max(e.MinDeltaTime, Math.min(this._engine.getDeltaTime(), e.MaxDeltaTime)) + this._timeAccumulator, n = this._engine.getTimeStep(), r = 1e3 / n / 1e3, i = 0, a = this._engine.getLockstepMaxSteps(), o = Math.floor(t / n);
			for (o = Math.min(o, a); t > 0 && i < o;) this.onBeforeStepObservable.notifyObservers(this), this._animationRatio = n * r, this._animate(n), this.onAfterAnimationsObservable.notifyObservers(this), this.physicsEnabled && this._advancePhysicsEngineStep(n), this.onAfterStepObservable.notifyObservers(this), this._currentStepId++, i++, t -= n;
			this._timeAccumulator = t < 0 ? 0 : t;
		} else {
			let t = this.useConstantAnimationDeltaTime ? 16 : Math.max(e.MinDeltaTime, Math.min(this._engine.getDeltaTime(), e.MaxDeltaTime));
			this._animationRatio = 60 / 1e3 * t, this._animate(), this.onAfterAnimationsObservable.notifyObservers(this), this.physicsEnabled && this._advancePhysicsEngineStep(t);
		}
	}
	_clear() {
		(this.autoClearDepthAndStencil || this.autoClear) && this._engine.clear(this._clearColor, this.autoClear || this.forceWireframe || this.forcePointsCloud, this.autoClearDepthAndStencil, this.autoClearDepthAndStencil);
	}
	_checkCameraRenderTarget(e) {
		if (e?.outputRenderTarget && !e?.isRigCamera && (e.outputRenderTarget._cleared = !1), e?.rigCameras?.length) for (let t = 0; t < e.rigCameras.length; ++t) {
			let n = e.rigCameras[t].outputRenderTarget;
			n && (n._cleared = !1);
		}
	}
	resetDrawCache(e) {
		if (this.meshes) for (let t of this.meshes) t.resetDrawCache(e);
	}
	_renderWithFrameGraph(e = !0, t = !1, n = !1) {
		if (this.activeCamera = null, this.activeCameras = null, e) {
			for (let e of this.cameras) if (e.update(), e.cameraRigMode !== 0) for (let t = 0; t < e._rigCameras.length; t++) e._rigCameras[t].update();
		}
		this.onBeforeRenderObservable.notifyObservers(this), this._renderingMeshEvaluationDepth++;
		try {
			this._renderWithFrameGraphAfterBeforeRender(n);
		} finally {
			this._renderingMeshEvaluationDepth--;
		}
	}
	_renderWithFrameGraphAfterBeforeRender(e) {
		this.onBeforeRenderTargetsRenderObservable.notifyObservers(this), this._renderTargets.reset();
		let t = this._frameGraph?.findMainCamera() ?? null;
		if (this.renderTargetsEnabled) {
			this.environmentTexture && this.environmentTexture.isRenderTarget && this._renderTargets.pushNoDuplicate(this.environmentTexture), this._renderTargets.concatWithNoDuplicate(this.customRenderTargets), A.StartPerformanceCounter("Custom render targets", this._renderTargets.length > 0);
			for (let e = 0; e < this._renderTargets.length; e++) {
				let n = this._renderTargets.data[e], r = n.activeCamera || t;
				this._renderRenderTarget(n, r, !0, this.dumpNextRenderTargets);
			}
			A.EndPerformanceCounter("Custom render targets", this._renderTargets.length > 0), this._renderId++;
		}
		this.onAfterRenderTargetsRenderObservable.notifyObservers(this);
		for (let e of this._beforeClearStage) e.action();
		if (this._engine.snapshotRendering && this._engine.snapshotRenderingMode === 1) this._activeParticleSystems.reset(), this._activeSkeletons.reset(), this._softwareSkinnedMeshes.reset();
		else {
			let t = this.getActiveMeshCandidates(), n = t.length;
			if (this._activeMeshesFrozen) {
				if (!this._skipEvaluateActiveMeshesCompletely) for (let e = 0; e < n; e++) {
					let n = t.data[e];
					n._internalAbstractMeshDataInfo._wasActiveLastFrame && n.computeWorldMatrix();
				}
				if (this.particlesEnabled) {
					let e = this._activeParticleSystems.length;
					for (let t = 0; t < e; t++) this._activeParticleSystems.data[t].animate();
				}
			} else {
				this._activeParticleSystems.reset(), this._activeSkeletons.reset(), this._softwareSkinnedMeshes.reset();
				for (let r = 0; r < n; r++) {
					let n = t.data[r];
					n._internalAbstractMeshDataInfo._wasActiveLastFrame = !1, !n.isBlocked && (this._totalVertices.addCount(n.getTotalVertices(), !1), n.isReady() && n.isEnabled() && !n.scaling.hasAZeroComponent && (n.computeWorldMatrix(e), n.actionManager && n.actionManager.hasSpecificTriggers2(12, 13) && this._meshesForIntersections.pushNoDuplicate(n)));
				}
				if (this.particlesEnabled) for (let e = 0; e < this.particleSystems.length; e++) {
					let t = this.particleSystems[e];
					if (!t.isStarted() || !t.emitter) continue;
					let n = t.emitter;
					(!n.position || n.isEnabled()) && (this._activeParticleSystems.push(t), t.animate());
				}
			}
		}
		this.frameGraph?.execute();
	}
	_renderRenderTarget(e, t, n = !1, r = !1) {
		if (this._intermediateRendering = !0, e._shouldRender()) {
			if (this._renderId++, this.activeCamera = t, !this.activeCamera) throw Error("Active camera not set");
			this._engine.setViewport(this.activeCamera.viewport), this.updateTransformMatrix(), e.render(n, r);
		}
		this._intermediateRendering = !1;
	}
	render(e = !0, t = !1) {
		if (this.isDisposed) return;
		let n = this._renderingMeshEvaluationDepth;
		try {
			this._renderFrame(e, t);
		} finally {
			this._renderingMeshEvaluationDepth = n;
		}
	}
	_renderFrame(e, t) {
		if (this.onReadyObservable.hasObservers() && this._executeWhenReadyTimeoutId === null && this._checkIsReady(), se.getScene = this._getFloatingOriginScene, this._frameId++, this._defaultFrameBufferCleared = !1, this._checkCameraRenderTarget(this.activeCamera), this.activeCameras?.length) for (let e of this.activeCameras) this._checkCameraRenderTarget(e);
		this._registerTransientComponents(), this._activeParticles.fetchNewFrame(), this._totalVertices.fetchNewFrame(), this._activeIndices.fetchNewFrame(), this._activeBones.fetchNewFrame(), this._meshesForIntersections.reset(), this.resetCachedMaterial(), this.onBeforeAnimationsObservable.notifyObservers(this), this.actionManager && this.actionManager.processTrigger(11), t || this.animate();
		for (let e of this._beforeCameraUpdateStage) e.action();
		if (e) {
			if (this.activeCameras && this.activeCameras.length > 0) for (let e = 0; e < this.activeCameras.length; e++) {
				let t = this.activeCameras[e];
				if (t.update(), t.cameraRigMode !== 0) for (let e = 0; e < t._rigCameras.length; e++) t._rigCameras[e].update();
			}
			else if (this.activeCamera && (this.activeCamera.update(), this.activeCamera.cameraRigMode !== 0)) for (let e = 0; e < this.activeCamera._rigCameras.length; e++) this.activeCamera._rigCameras[e].update();
		}
		if (this.customRenderFunction) this._renderId++, this._engine.currentRenderPassId = 0, this._renderingMeshEvaluationDepth++, this.customRenderFunction(e, t);
		else {
			this.onBeforeRenderObservable.notifyObservers(this), this._renderingMeshEvaluationDepth++, this.onBeforeRenderTargetsRenderObservable.notifyObservers(this);
			let e = this.activeCameras?.length ? this.activeCameras[0] : this.activeCamera;
			if (this.renderTargetsEnabled) {
				A.StartPerformanceCounter("Custom render targets", this.customRenderTargets.length > 0);
				for (let t = 0; t < this.customRenderTargets.length; t++) {
					let n = this.customRenderTargets[t], r = n.activeCamera || this.activeCamera;
					this._renderRenderTarget(n, r, e !== r, this.dumpNextRenderTargets);
				}
				A.EndPerformanceCounter("Custom render targets", this.customRenderTargets.length > 0), this._renderId++;
			}
			this._engine.currentRenderPassId = e?.renderPassId ?? 0, this.activeCamera = e, this._activeCamera && this._activeCamera.cameraRigMode !== 22 && !this.prePass && this._bindFrameBuffer(this._activeCamera, !1), this.onAfterRenderTargetsRenderObservable.notifyObservers(this);
			for (let e of this._beforeClearStage) e.action();
			this._clearFrameBuffer(this.activeCamera);
			for (let e of this._gatherRenderTargetsStage) e.action(this._renderTargets);
			if (this.activeCameras && this.activeCameras.length > 0) for (let e = 0; e < this.activeCameras.length; e++) this._processSubCameras(this.activeCameras[e], e > 0);
			else {
				if (!this.activeCamera) throw Error("No camera defined");
				this._processSubCameras(this.activeCamera, !!this.activeCamera.outputRenderTarget);
			}
		}
		this._inputManager._updateMeshUnderPointer(), this._checkIntersections();
		for (let e of this._afterRenderStage) e.action();
		if (this.afterRender && this.afterRender(), this.onAfterRenderObservable.notifyObservers(this), this._toBeDisposed.length) {
			for (let e = 0; e < this._toBeDisposed.length; e++) {
				let t = this._toBeDisposed[e];
				t && t.dispose();
			}
			this._toBeDisposed.length = 0;
		}
		this.dumpNextRenderTargets &&= !1, this._activeBones.addCount(0, !0), this._activeIndices.addCount(0, !0), this._activeParticles.addCount(0, !0), this._engine.restoreDefaultFramebuffer();
	}
	freezeMaterials() {
		for (let e = 0; e < this.materials.length; e++) this.materials[e].freeze();
	}
	unfreezeMaterials() {
		for (let e = 0; e < this.materials.length; e++) this.materials[e].unfreeze();
	}
	dispose() {
		if (this.isDisposed) return;
		if (this._isDisposing = !0, this.beforeRender = null, this.afterRender = null, this.metadata = null, this.skeletons.length = 0, this.morphTargetManagers.length = 0, this._transientComponents.length = 0, this._isReadyForMeshStage.clear(), this._beforeEvaluateActiveMeshStage.clear(), this._evaluateSubMeshStage.clear(), this._preActiveMeshStage.clear(), this._cameraDrawRenderTargetStage.clear(), this._beforeCameraDrawStage.clear(), this._beforeRenderTargetDrawStage.clear(), this._beforeRenderingGroupDrawStage.clear(), this._beforeRenderingMeshStage.clear(), this._afterRenderingMeshStage.clear(), this._afterRenderingGroupDrawStage.clear(), this._afterCameraDrawStage.clear(), this._afterRenderTargetDrawStage.clear(), this._afterRenderStage.clear(), this._beforeCameraUpdateStage.clear(), this._beforeClearStage.clear(), this._gatherRenderTargetsStage.clear(), this._gatherActiveCameraRenderTargetsStage.clear(), this._pointerMoveStage.clear(), this._pointerDownStage.clear(), this._pointerUpStage.clear(), this._isReadyChecks.length = 0, this.importedMeshesFiles = [], this._activeAnimatables && p(this.stopAllAnimations)) {
			for (let e of this._activeAnimatables) e.onAnimationEndObservable.clear(), e.onAnimationEnd = null;
			this.stopAllAnimations();
		}
		this.resetCachedMaterial(), this.activeCamera &&= (this.activeCamera._activeMeshes.dispose(), null), this.activeCameras = null, this._activeMeshes.dispose(), this._renderingManager.dispose(), this._processedMaterials.dispose(), this._activeParticleSystems.dispose(), this._activeSkeletons.dispose(), this._softwareSkinnedMeshes.dispose(), this._renderTargets.dispose(), this._materialsRenderTargets.dispose(), this._registeredForLateAnimationBindings.dispose(), this._animationWrites.length = 0, this._animationWriteCount = 0, this._animationStepWriteCount = 0, this._meshesForIntersections.dispose(), this._toBeDisposed.length = 0;
		let e = this._activeRequests.slice();
		for (let t of e) t.abort();
		this._activeRequests.length = 0;
		try {
			this.onDisposeObservable.notifyObservers(this);
		} catch (e) {
			r.Error("An error occurred while calling onDisposeObservable!", e);
		}
		if (this.detachControl(), this._engine.getInputElement?.()) for (let e = 0; e < this.cameras.length; e++) this.cameras[e].detachControl();
		this._disposeList(this.animationGroups), this._disposeList(this.lights), this._defaultMaterial && this._defaultMaterial.dispose(), this._disposeList(this.multiMaterials), this._disposeList(this.materials), this._disposeList(this.meshes, (e) => e.dispose(!0)), this._disposeList(this.transformNodes, (e) => e.dispose(!0));
		let t = this.cameras;
		this._disposeList(t), this._disposeList(this.particleSystems), this._disposeList(this.postProcesses), this._disposeList(this.textures), this._disposeList(this.morphTargetManagers), this._disposeList(this.frameGraphs), this._sceneUbo.dispose(), this._multiviewSceneUbo && this._multiviewSceneUbo.dispose(), this.postProcessManager.dispose(), this._disposeList(this._components);
		let i = this._engine.scenes.indexOf(this);
		if (i > -1 && this._engine.scenes.splice(i, 1), this._floatingOriginScene = void 0, this._engine.scenes.length === 0 && ce(), n._LastCreatedScene === this) {
			n._LastCreatedScene = null;
			let e = n.Instances.length - 1;
			for (; e >= 0;) {
				let t = n.Instances[e];
				if (t.scenes.length > 0) {
					n._LastCreatedScene = t.scenes[this._engine.scenes.length - 1];
					break;
				}
				e--;
			}
		}
		i = this._engine._virtualScenes.indexOf(this), i > -1 && this._engine._virtualScenes.splice(i, 1), this._engine.wipeCaches(!0), this.onDisposeObservable.clear(), this.onBeforeRenderObservable.clear(), this.onAfterRenderObservable.clear(), this.onBeforeRenderTargetsRenderObservable.clear(), this.onAfterRenderTargetsRenderObservable.clear(), this.onAfterStepObservable.clear(), this.onBeforeStepObservable.clear(), this.onBeforeActiveMeshesEvaluationObservable.clear(), this.onAfterActiveMeshesEvaluationObservable.clear(), this.onBeforeParticlesRenderingObservable.clear(), this.onAfterParticlesRenderingObservable.clear(), this.onBeforeDrawPhaseObservable.clear(), this.onAfterDrawPhaseObservable.clear(), this.onBeforeAnimationsObservable.clear(), this.onAfterAnimationsObservable.clear(), this.onDataLoadedObservable.clear(), this.onBeforeRenderingGroupObservable.clear(), this.onAfterRenderingGroupObservable.clear(), this.onMeshImportedObservable.clear(), this.onBeforeCameraRenderObservable.clear(), this.onAfterCameraRenderObservable.clear(), this.onAfterRenderCameraObservable.clear(), this.onReadyObservable.clear(), this.onNewCameraAddedObservable.clear(), this.onCameraRemovedObservable.clear(), this.onNewLightAddedObservable.clear(), this.onLightRemovedObservable.clear(), this.onNewGeometryAddedObservable.clear(), this.onGeometryRemovedObservable.clear(), this.onNewTransformNodeAddedObservable.clear(), this.onTransformNodeRemovedObservable.clear(), this.onNewMeshAddedObservable.clear(), this.onMeshRemovedObservable.clear(), this.onNewSkeletonAddedObservable.clear(), this.onSkeletonRemovedObservable.clear(), this.onNewMaterialAddedObservable.clear(), this.onNewMultiMaterialAddedObservable.clear(), this.onMaterialRemovedObservable.clear(), this.onMultiMaterialRemovedObservable.clear(), this.onNewTextureAddedObservable.clear(), this.onTextureRemovedObservable.clear(), this.onNewFrameGraphAddedObservable.clear(), this.onFrameGraphRemovedObservable.clear(), this.onNewObjectRendererAddedObservable.clear(), this.onObjectRendererRemovedObservable.clear(), this.onPrePointerObservable.clear(), this.onPointerObservable.clear(), this.onPreKeyboardObservable.clear(), this.onKeyboardObservable.clear(), this.onActiveCameraChanged.clear(), this.onScenePerformancePriorityChangedObservable.clear(), this.onClearColorChangedObservable.clear(), this.onEnvironmentTextureChangedObservable.clear(), this.onMeshUnderPointerUpdatedObservable.clear(), this._isDisposed = !0;
	}
	_disposeList(e, t) {
		let n = e.slice(0);
		t ??= ((e) => e.dispose());
		for (let e of n) t(e);
		e.length = 0;
	}
	get isDisposed() {
		return this._isDisposed;
	}
	clearCachedVertexData() {
		for (let e = 0; e < this.meshes.length; e++) {
			let t = this.meshes[e].geometry;
			t && t.clearCachedData();
		}
	}
	cleanCachedTextureBuffer() {
		for (let e of this.textures) e._buffer &&= null;
	}
	getWorldExtends(e) {
		let t = new S(Number.MAX_VALUE, Number.MAX_VALUE, Number.MAX_VALUE), n = new S(-Number.MAX_VALUE, -Number.MAX_VALUE, -Number.MAX_VALUE);
		e ||= (() => !0);
		let r = this.meshes.filter(e);
		for (let e of r) {
			if (e.computeWorldMatrix(!0), !e.subMeshes || e.subMeshes.length === 0 || e.infiniteDistance) continue;
			let r = e.getBoundingInfo(), i = r.boundingBox.minimumWorld, a = r.boundingBox.maximumWorld;
			S.CheckExtends(i, t, n), S.CheckExtends(a, t, n);
		}
		return t.x === Number.MAX_VALUE ? {
			min: S.Zero(),
			max: S.Zero()
		} : {
			min: t,
			max: n
		};
	}
	createPickingRay(e, t, n, r, i = !1) {
		throw o("Ray");
	}
	createPickingRayToRef(e, t, n, r, i, a = !1, s = !1) {
		throw o("Ray");
	}
	createPickingRayInCameraSpace(e, t, n) {
		throw o("Ray");
	}
	createPickingRayInCameraSpaceToRef(e, t, n, r) {
		throw o("Ray");
	}
	pick(e, t, n, i, a, s) {
		let c = o("Ray", !0);
		return c && r.Warn(c), new G();
	}
	pickWithBoundingInfo(e, t, n, i, a) {
		let s = o("Ray", !0);
		return s && r.Warn(s), new G();
	}
	pickWithRay(e, t, n, r) {
		throw o("Ray");
	}
	multiPick(e, t, n, r, i) {
		throw o("Ray");
	}
	multiPickWithRay(e, t, n) {
		throw o("Ray");
	}
	setPointerOverMesh(e, t, n) {
		this._inputManager.setPointerOverMesh(e, t, n);
	}
	getPointerOverMesh() {
		return this._inputManager.getPointerOverMesh();
	}
	_rebuildGeometries() {
		for (let e of this.geometries) e._rebuild();
		for (let e of this.meshes) e._rebuild();
		this.postProcessManager && this.postProcessManager._rebuild();
		for (let e of this._components) e.rebuild();
		for (let e of this.particleSystems) e.rebuild();
		if (this.spriteManagers) for (let e of this.spriteManagers) e.rebuild();
	}
	_rebuildTextures() {
		for (let e of this.textures) e._rebuild(!0);
		this.markAllMaterialsAsDirty(1);
	}
	_getByTags(e, t, n) {
		if (t === void 0) return e;
		let r = [];
		for (let i in e) {
			let a = e[i];
			O && O.MatchesQuery(a, t) && (!n || n(a)) && r.push(a);
		}
		return r;
	}
	getMeshesByTags(e, t) {
		return this._getByTags(this.meshes, e, t);
	}
	getCamerasByTags(e, t) {
		return this._getByTags(this.cameras, e, t);
	}
	getLightsByTags(e, t) {
		return this._getByTags(this.lights, e, t);
	}
	getMaterialByTags(e, t) {
		return this._getByTags(this.materials, e, t).concat(this._getByTags(this.multiMaterials, e, t));
	}
	getTransformNodesByTags(e, t) {
		return this._getByTags(this.transformNodes, e, t);
	}
	setRenderingOrder(e, t = null, n = null, r = null) {
		this._renderingManager.setRenderingOrder(e, t, n, r);
	}
	setRenderingAutoClearDepthStencil(e, t, n = !0, r = !0) {
		this._renderingManager.setRenderingAutoClearDepthStencil(e, t, n, r);
	}
	getAutoClearDepthStencilSetup(e) {
		return this._renderingManager.getAutoClearDepthStencilSetup(e);
	}
	_forceBlockMaterialDirtyMechanism(e) {
		this._blockMaterialDirtyMechanism = e;
	}
	get blockMaterialDirtyMechanism() {
		return this._blockMaterialDirtyMechanism;
	}
	set blockMaterialDirtyMechanism(e) {
		this._blockMaterialDirtyMechanism !== e && (this._blockMaterialDirtyMechanism = e, e || this.markAllMaterialsAsDirty(127));
	}
	markAllMaterialsAsDirty(e, t) {
		if (!this._blockMaterialDirtyMechanism) for (let n of this.materials) (!t || t(n)) && n.markAsDirty(e);
	}
	_loadFile(e, t, n, r, i, a, o) {
		let s = ie(e, t, n, r ? this.offlineProvider : void 0, i, a, o);
		return this._activeRequests.push(s), s.onCompleteObservable.add((e) => {
			this._activeRequests.splice(this._activeRequests.indexOf(e), 1);
		}), s;
	}
	async _loadFileAsync(e, t, n, r, i) {
		return await new Promise((a, o) => {
			this._loadFile(e, (e) => {
				a(e);
			}, t, n, r, (e, t) => {
				o(t);
			}, i);
		});
	}
	async _loadDelayedFileAsync(e, t, n) {
		this._delayedFileRequests ||= /* @__PURE__ */ new Map();
		let r = `${e}|${t ? "binary" : "string"}`, i = this._delayedFileRequests.get(r);
		if (!i) {
			i = t ? this._loadFileAsync(e, void 0, n, !0) : this._loadFileAsync(e, void 0, n, !1);
			let a = i;
			(async () => {
				try {
					await a;
				} catch {}
				this._delayedFileRequests?.delete(r);
			})(), this._delayedFileRequests.set(r, i);
		}
		return await i;
	}
	_requestFile(e, t, n, r, i, a, o) {
		let s = ae(e, t, n, r ? this.offlineProvider : void 0, i, a, o);
		return this._activeRequests.push(s), s.onCompleteObservable.add((e) => {
			this._activeRequests.splice(this._activeRequests.indexOf(e), 1);
		}), s;
	}
	async _requestFileAsync(e, t, n, r, i) {
		return await new Promise((a, o) => {
			this._requestFile(e, (e) => {
				a(e);
			}, t, n, r, (e) => {
				o(e);
			}, i);
		});
	}
	_readFile(e, t, n, r, i) {
		let a = re(e, t, n, r, i);
		return this._activeRequests.push(a), a.onCompleteObservable.add((e) => {
			this._activeRequests.splice(this._activeRequests.indexOf(e), 1);
		}), a;
	}
	async _readFileAsync(e, t, n) {
		return await new Promise((r, i) => {
			this._readFile(e, (e) => {
				r(e);
			}, t, n, (e) => {
				i(e);
			});
		});
	}
	getPerfCollector() {
		throw o("performanceViewerSceneExtension");
	}
	setActiveCameraByID(e) {
		return this.setActiveCameraById(e);
	}
	getMaterialByID(e) {
		return this.getMaterialById(e);
	}
	getLastMaterialByID(e) {
		return this.getLastMaterialById(e);
	}
	getTextureByUniqueID(e) {
		return this.getTextureByUniqueId(e);
	}
	getCameraByID(e) {
		return this.getCameraById(e);
	}
	getCameraByUniqueID(e) {
		return this.getCameraByUniqueId(e);
	}
	getBoneByID(e) {
		return this.getBoneById(e);
	}
	getLightByID(e) {
		return this.getLightById(e);
	}
	getLightByUniqueID(e) {
		return this.getLightByUniqueId(e);
	}
	getParticleSystemByID(e) {
		return this.getParticleSystemById(e);
	}
	getGeometryByID(e) {
		return this.getGeometryById(e);
	}
	getMeshByID(e) {
		return this.getMeshById(e);
	}
	getMeshByUniqueID(e) {
		return this.getMeshByUniqueId(e);
	}
	getLastMeshByID(e) {
		return this.getLastMeshById(e);
	}
	getMeshesByID(e) {
		return this.getMeshesById(e);
	}
	getTransformNodeByID(e) {
		return this.getTransformNodeById(e);
	}
	getTransformNodeByUniqueID(e) {
		return this.getTransformNodeByUniqueId(e);
	}
	getTransformNodesByID(e) {
		return this.getTransformNodesById(e);
	}
	getNodeByID(e) {
		return this.getNodeById(e);
	}
	getLastEntryByID(e) {
		return this.getLastEntryById(e);
	}
	getLastSkeletonByID(e) {
		return this.getLastSkeletonById(e);
	}
};
$.FOGMODE_NONE = 0, $.FOGMODE_EXP = 1, $.FOGMODE_EXP2 = 2, $.FOGMODE_LINEAR = 3, $.MinDeltaTime = 1, $.MaxDeltaTime = 1e3, $._OriginalDefaultMaterialFactory = $.DefaultMaterialFactory;
var Zt = !1;
function Qt() {
	Zt || (Zt = !0, C("BABYLON.Scene", $));
}
(Ye = $.prototype).sortActiveAnimatables ?? (Ye.sortActiveAnimatables = s("Scene", "sortActiveAnimatables")), (Xe = $.prototype).beginWeightedAnimation ?? (Xe.beginWeightedAnimation = s("Scene", "beginWeightedAnimation")), (Ze = $.prototype).beginAnimation ?? (Ze.beginAnimation = s("Scene", "beginAnimation")), (Qe = $.prototype).beginHierarchyAnimation ?? (Qe.beginHierarchyAnimation = s("Scene", "beginHierarchyAnimation")), ($e = $.prototype).beginDirectAnimation ?? ($e.beginDirectAnimation = s("Scene", "beginDirectAnimation")), (et = $.prototype).beginDirectHierarchyAnimation ?? (et.beginDirectHierarchyAnimation = s("Scene", "beginDirectHierarchyAnimation")), (tt = $.prototype).getAnimatableByTarget ?? (tt.getAnimatableByTarget = s("Scene", "getAnimatableByTarget")), (nt = $.prototype).getAllAnimatablesByTarget ?? (nt.getAllAnimatablesByTarget = s("Scene", "getAllAnimatablesByTarget")), (rt = $.prototype).stopAllAnimations ?? (rt.stopAllAnimations = s("Scene", "stopAllAnimations")), (it = $.prototype).getSoundByName ?? (it.getSoundByName = s("Scene", "getSoundByName")), (at = $.prototype).createOrUpdateSelectionOctree ?? (at.createOrUpdateSelectionOctree = s("Scene", "createOrUpdateSelectionOctree")), (ot = $.prototype).createDefaultLight ?? (ot.createDefaultLight = s("Scene", "createDefaultLight")), (st = $.prototype).createDefaultCamera ?? (st.createDefaultCamera = s("Scene", "createDefaultCamera")), (ct = $.prototype).createDefaultCameraOrLight ?? (ct.createDefaultCameraOrLight = s("Scene", "createDefaultCameraOrLight")), (lt = $.prototype).createDefaultSkybox ?? (lt.createDefaultSkybox = s("Scene", "createDefaultSkybox")), (ut = $.prototype).createDefaultEnvironment ?? (ut.createDefaultEnvironment = s("Scene", "createDefaultEnvironment")), (dt = $.prototype).createDefaultVRExperience ?? (dt.createDefaultVRExperience = s("Scene", "createDefaultVRExperience")), (ft = $.prototype).createDefaultXRExperienceAsync ?? (ft.createDefaultXRExperienceAsync = s("Scene", "createDefaultXRExperienceAsync")), (pt = $.prototype).getGlowLayerByName ?? (pt.getGlowLayerByName = s("Scene", "getGlowLayerByName")), (mt = $.prototype).getHighlightLayerByName ?? (mt.getHighlightLayerByName = s("Scene", "getHighlightLayerByName")), (ht = $.prototype).getSelectionOutlineLayerByName ?? (ht.getSelectionOutlineLayerByName = s("Scene", "getSelectionOutlineLayerByName")), (gt = $.prototype).removeLensFlareSystem ?? (gt.removeLensFlareSystem = s("Scene", "removeLensFlareSystem")), (_t = $.prototype).addLensFlareSystem ?? (_t.addLensFlareSystem = s("Scene", "addLensFlareSystem")), (vt = $.prototype).getLensFlareSystemByName ?? (vt.getLensFlareSystemByName = s("Scene", "getLensFlareSystemByName")), (yt = $.prototype).getLensFlareSystemByID ?? (yt.getLensFlareSystemByID = s("Scene", "getLensFlareSystemByID")), (bt = $.prototype).getLensFlareSystemById ?? (bt.getLensFlareSystemById = s("Scene", "getLensFlareSystemById")), (xt = $.prototype).getPhysicsEngine ?? (xt.getPhysicsEngine = s("Scene", "getPhysicsEngine")), (St = $.prototype).enablePhysics ?? (St.enablePhysics = s("Scene", "enablePhysics")), (Ct = $.prototype).disablePhysicsEngine ?? (Ct.disablePhysicsEngine = s("Scene", "disablePhysicsEngine")), (wt = $.prototype).isPhysicsEnabled ?? (wt.isPhysicsEnabled = s("Scene", "isPhysicsEnabled")), (Tt = $.prototype).deleteCompoundImpostor ?? (Tt.deleteCompoundImpostor = s("Scene", "deleteCompoundImpostor")), (Et = $.prototype).removeReflectionProbe ?? (Et.removeReflectionProbe = s("Scene", "removeReflectionProbe")), (Dt = $.prototype).addReflectionProbe ?? (Dt.addReflectionProbe = s("Scene", "addReflectionProbe")), (Ot = $.prototype).getBoundingBoxRenderer ?? (Ot.getBoundingBoxRenderer = s("Scene", "getBoundingBoxRenderer")), (kt = $.prototype).enableDepthRenderer ?? (kt.enableDepthRenderer = s("Scene", "enableDepthRenderer")), (At = $.prototype).disableDepthRenderer ?? (At.disableDepthRenderer = s("Scene", "disableDepthRenderer")), (jt = $.prototype).enableFluidRenderer ?? (jt.enableFluidRenderer = s("Scene", "enableFluidRenderer")), (Mt = $.prototype).disableFluidRenderer ?? (Mt.disableFluidRenderer = s("Scene", "disableFluidRenderer")), (Nt = $.prototype).enableGeometryBufferRenderer ?? (Nt.enableGeometryBufferRenderer = s("Scene", "enableGeometryBufferRenderer")), (Pt = $.prototype).disableGeometryBufferRenderer ?? (Pt.disableGeometryBufferRenderer = s("Scene", "disableGeometryBufferRenderer")), (Ft = $.prototype).enableIblCdfGenerator ?? (Ft.enableIblCdfGenerator = s("Scene", "enableIblCdfGenerator")), (It = $.prototype).disableIblCdfGenerator ?? (It.disableIblCdfGenerator = s("Scene", "disableIblCdfGenerator")), (Lt = $.prototype).getOutlineRenderer ?? (Lt.getOutlineRenderer = s("Scene", "getOutlineRenderer")), (Rt = $.prototype).enablePrePassRenderer ?? (Rt.enablePrePassRenderer = s("Scene", "enablePrePassRenderer")), (zt = $.prototype).disablePrePassRenderer ?? (zt.disablePrePassRenderer = s("Scene", "disablePrePassRenderer")), (Bt = $.prototype).enableSubSurfaceForPrePass ?? (Bt.enableSubSurfaceForPrePass = s("Scene", "enableSubSurfaceForPrePass")), (Vt = $.prototype).disableSubSurfaceForPrePass ?? (Vt.disableSubSurfaceForPrePass = s("Scene", "disableSubSurfaceForPrePass")), (Ht = $.prototype).pickSprite ?? (Ht.pickSprite = s("Scene", "pickSprite")), (Ut = $.prototype).pickSpriteWithRay ?? (Ut.pickSpriteWithRay = s("Scene", "pickSpriteWithRay")), (Wt = $.prototype).multiPickSprite ?? (Wt.multiPickSprite = s("Scene", "multiPickSprite")), (Gt = $.prototype).multiPickSpriteWithRay ?? (Gt.multiPickSpriteWithRay = s("Scene", "multiPickSpriteWithRay")), (Kt = $.prototype).setPointerOverSprite ?? (Kt.setPointerOverSprite = s("Scene", "setPointerOverSprite")), (qt = $.prototype).getPointerOverSprite ?? (qt.getPointerOverSprite = s("Scene", "getPointerOverSprite")), Object.getOwnPropertyDescriptor($.prototype, "mainSoundTrack") || Object.defineProperty($.prototype, "mainSoundTrack", f("Scene", "mainSoundTrack")), Object.getOwnPropertyDescriptor($.prototype, "soundTracks") || Object.defineProperty($.prototype, "soundTracks", f("Scene", "soundTracks")), Object.getOwnPropertyDescriptor($.prototype, "audioEnabled") || Object.defineProperty($.prototype, "audioEnabled", f("Scene", "audioEnabled")), Object.getOwnPropertyDescriptor($.prototype, "headphone") || Object.defineProperty($.prototype, "headphone", f("Scene", "headphone")), Object.getOwnPropertyDescriptor($.prototype, "audioListenerPositionProvider") || Object.defineProperty($.prototype, "audioListenerPositionProvider", f("Scene", "audioListenerPositionProvider")), Object.getOwnPropertyDescriptor($.prototype, "audioListenerRotationProvider") || Object.defineProperty($.prototype, "audioListenerRotationProvider", f("Scene", "audioListenerRotationProvider")), Object.getOwnPropertyDescriptor($.prototype, "audioPositioningRefreshRate") || Object.defineProperty($.prototype, "audioPositioningRefreshRate", f("Scene", "audioPositioningRefreshRate")), Object.getOwnPropertyDescriptor($.prototype, "selectionOctree") || Object.defineProperty($.prototype, "selectionOctree", f("Scene", "selectionOctree")), Object.getOwnPropertyDescriptor($.prototype, "debugLayer") || Object.defineProperty($.prototype, "debugLayer", f("Scene", "debugLayer")), Object.getOwnPropertyDescriptor($.prototype, "gamepadManager") || Object.defineProperty($.prototype, "gamepadManager", f("Scene", "gamepadManager")), Object.getOwnPropertyDescriptor($.prototype, "simplificationQueue") || Object.defineProperty($.prototype, "simplificationQueue", f("Scene", "simplificationQueue")), Object.getOwnPropertyDescriptor($.prototype, "onBeforePhysicsObservable") || Object.defineProperty($.prototype, "onBeforePhysicsObservable", f("Scene", "onBeforePhysicsObservable")), Object.getOwnPropertyDescriptor($.prototype, "onAfterPhysicsObservable") || Object.defineProperty($.prototype, "onAfterPhysicsObservable", f("Scene", "onAfterPhysicsObservable")), Object.getOwnPropertyDescriptor($.prototype, "reflectionProbes") || Object.defineProperty($.prototype, "reflectionProbes", f("Scene", "reflectionProbes")), Object.getOwnPropertyDescriptor($.prototype, "forceShowBoundingBoxes") || Object.defineProperty($.prototype, "forceShowBoundingBoxes", f("Scene", "forceShowBoundingBoxes")), Object.getOwnPropertyDescriptor($.prototype, "depthPeelingRenderer") || Object.defineProperty($.prototype, "depthPeelingRenderer", f("Scene", "depthPeelingRenderer")), Object.getOwnPropertyDescriptor($.prototype, "useOrderIndependentTransparency") || Object.defineProperty($.prototype, "useOrderIndependentTransparency", f("Scene", "useOrderIndependentTransparency")), Object.getOwnPropertyDescriptor($.prototype, "fluidRenderer") || Object.defineProperty($.prototype, "fluidRenderer", f("Scene", "fluidRenderer")), Object.getOwnPropertyDescriptor($.prototype, "geometryBufferRenderer") || Object.defineProperty($.prototype, "geometryBufferRenderer", f("Scene", "geometryBufferRenderer")), Object.getOwnPropertyDescriptor($.prototype, "iblCdfGenerator") || Object.defineProperty($.prototype, "iblCdfGenerator", f("Scene", "iblCdfGenerator")), Object.getOwnPropertyDescriptor($.prototype, "prePassRenderer") || Object.defineProperty($.prototype, "prePassRenderer", f("Scene", "prePassRenderer")), Object.getOwnPropertyDescriptor($.prototype, "subSurfaceConfiguration") || Object.defineProperty($.prototype, "subSurfaceConfiguration", f("Scene", "subSurfaceConfiguration")), Object.getOwnPropertyDescriptor($.prototype, "spriteManagers") || Object.defineProperty($.prototype, "spriteManagers", f("Scene", "spriteManagers")), Object.getOwnPropertyDescriptor($.prototype, "onBeforeSpritesRenderingObservable") || Object.defineProperty($.prototype, "onBeforeSpritesRenderingObservable", f("Scene", "onBeforeSpritesRenderingObservable")), Object.getOwnPropertyDescriptor($.prototype, "onAfterSpritesRenderingObservable") || Object.defineProperty($.prototype, "onAfterSpritesRenderingObservable", f("Scene", "onAfterSpritesRenderingObservable"));
//#endregion
export { G as a, z as c, X as i, R as l, $ as n, W as o, qe as r, je as s, Qt as t };
