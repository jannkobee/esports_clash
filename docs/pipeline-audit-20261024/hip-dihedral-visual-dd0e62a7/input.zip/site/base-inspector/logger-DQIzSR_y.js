//#region node_modules/@babylonjs/core/Misc/logger.js
var e = class e {
	static _CheckLimit(t, n) {
		let r = e._LogLimitOutputs[t];
		return r ? r.current++ : (r = {
			limit: n,
			current: 1
		}, e._LogLimitOutputs[t] = r), r.current <= r.limit;
	}
	static _GenerateLimitMessage(t, n = 1) {
		let r = e._LogLimitOutputs[t];
		if (!r || !e.MessageLimitReached) return;
		let i = this._Levels[n];
		r.current === r.limit && e[i.name](e.MessageLimitReached.replace(/%LIMIT%/g, "" + r.limit).replace(/%TYPE%/g, i.name ?? ""));
	}
	static _AddLogEntry(t) {
		e._LogCache = t + e._LogCache, e.OnNewCacheEntry && e.OnNewCacheEntry(t);
	}
	static _FormatMessage(e) {
		let t = (e) => e < 10 ? "0" + e : "" + e, n = /* @__PURE__ */ new Date();
		return "[" + t(n.getHours()) + ":" + t(n.getMinutes()) + ":" + t(n.getSeconds()) + "]: " + e;
	}
	static _LogDisabled(e, t) {}
	static _LogEnabled(t = 1, n, r) {
		let i = Array.isArray(n) ? n[0] : n;
		if (r !== void 0 && !e._CheckLimit(i, r)) return;
		let a = e._FormatMessage(i), o = this._Levels[t], s = Array.isArray(n) ? n.slice(1) : [];
		o.logFunc && o.logFunc("BJS - " + a, ...s);
		let c = `<div style='color:${o.color}'>${a}</div><br>`;
		e._AddLogEntry(c), e._GenerateLimitMessage(i, t);
	}
	static get LogCache() {
		return e._LogCache;
	}
	static ClearLogCache() {
		e._LogCache = "", e._LogLimitOutputs = {}, e.errorsCount = 0;
	}
	static set LogLevels(t) {
		e.Log = e._LogDisabled, e.Warn = e._LogDisabled, e.Error = e._LogDisabled;
		let n = [
			e.MessageLogLevel,
			e.WarningLogLevel,
			e.ErrorLogLevel
		];
		for (let r of n) if ((t & r) === r) {
			let t = this._Levels[r];
			e[t.name] = e._LogEnabled.bind(e, r);
		}
	}
};
e.NoneLogLevel = 0, e.MessageLogLevel = 1, e.WarningLogLevel = 2, e.ErrorLogLevel = 4, e.AllLogLevel = 7, e.MessageLimitReached = "Too many %TYPE%s (%LIMIT%), no more %TYPE%s will be reported for this message.", e._LogCache = "", e._LogLimitOutputs = {}, e._Levels = [
	{},
	{
		color: "white",
		logFunc: console.log,
		name: "Log"
	},
	{
		color: "orange",
		logFunc: console.warn,
		name: "Warn"
	},
	{},
	{
		color: "red",
		logFunc: console.error,
		name: "Error"
	}
], e.errorsCount = 0, e.Log = e._LogEnabled.bind(e, e.MessageLogLevel), e.Warn = e._LogEnabled.bind(e, e.WarningLogLevel), e.Error = e._LogEnabled.bind(e, e.ErrorLogLevel);
//#endregion
export { e as t };
