import { t as e } from "./logger-DQIzSR_y.js";
import { n as t } from "./typeStore-pENEWnX2.js";
import { t as n } from "./flowGraphExecutionBlockWithOutSignal-XngQvXka.js";
import { n as r, u as i } from "./flowGraphRichTypes.pure-BpKU4EZT.js";
//#region node_modules/@babylonjs/core/FlowGraph/Blocks/Execution/flowGraphConsoleLogBlock.pure.js
var a = class extends n {
	constructor(e) {
		if (super(e), this.message = this.registerDataInput("message", r), this.logType = this.registerDataInput("logType", i, "log"), typeof e?.messageTemplate == "string") {
			let t = this._getTemplateMatches(e.messageTemplate), n = /* @__PURE__ */ new Set();
			for (let e of t) n.has(e.name) || (n.add(e.name), this.registerDataInput(e.name, r));
		}
	}
	_execute(t) {
		let n = this.logType.getValue(t), r = this._getMessageValue(t);
		n === "warn" ? e.Warn(r) : n === "error" ? e.Error(r) : e.Log(r), this.out._activateSignal(t);
	}
	getClassName() {
		return "FlowGraphConsoleLogBlock";
	}
	_serializeValue(e) {
		if (e == null) return String(e);
		if (typeof e == "object") {
			let t = e.toString();
			if (t === "[object Object]") try {
				return JSON.stringify(e);
			} catch {
				return t;
			}
			return t;
		}
		return String(e);
	}
	_getMessageValue(e) {
		if (typeof this.config?.messageTemplate == "string") {
			let t = this.config.messageTemplate, n = this._getTemplateMatches(t), r = this.message.getValue(e), i = typeof r == "object" && r ? r : null, a = /* @__PURE__ */ new Map();
			for (let t of n) {
				if (a.has(t.name)) continue;
				let n;
				n = i !== null && t.name in i ? i[t.name] : this.getDataInput(t.name)?.getValue(e), a.set(t.name, n === void 0 ? void 0 : this._serializeValue(n).replace(/[{}]/g, "$&$&"));
			}
			for (let e = n.length - 1; e >= 0; e--) {
				let r = n[e], i = a.get(r.name);
				i !== void 0 && (t = t.substring(0, r.start) + i + t.substring(r.end + 1));
			}
			return t.replace(/\{\{/g, "{").replace(/\}\}/g, "}");
		}
		return this.message.getValue(e);
	}
	_getTemplateMatches(e) {
		let t = 0, n = -1, r = [];
		for (let i = 0; i < e.length; i++) {
			let a = e[i];
			if (a === "{") {
				if (t === 0) t = 1;
				else if (t === 1) t = 0;
				else return [];
			} else if (a === "}") {
				if (t === 0) t = 3;
				else if (t === 3) t = 0;
				else if (t === 2) r.push({
					name: e.substring(n + 1, i),
					start: n,
					end: i
				}), t = 0;
				else return [];
			} else if (t === 1) n = i - 1, t = 2;
			else if (t === 3) return [];
		}
		return t === 0 ? r : [];
	}
}, o = !1;
function s() {
	o || (o = !0, t("FlowGraphConsoleLogBlock", a));
}
//#endregion
export { a as FlowGraphConsoleLogBlock, s as RegisterFlowGraphConsoleLogBlock };
