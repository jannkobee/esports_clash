//#region node_modules/@babylonjs/core/FlowGraph/flowGraphAssetsContext.js
var e;
(function(e) {
	e.Animation = "Animation", e.AnimationGroup = "AnimationGroup", e.Mesh = "Mesh", e.Material = "Material", e.Camera = "Camera", e.Light = "Light";
})(e ||= {});
function t(e, t, n, r) {
	switch (t) {
		case "Animation": return r ? e.animations.find((e) => e.uniqueId === n) ?? null : e.animations[n] ?? null;
		case "AnimationGroup": return r ? e.animationGroups.find((e) => e.uniqueId === n) ?? null : e.animationGroups[n] ?? null;
		case "Mesh": return r ? e.meshes.find((e) => e.uniqueId === n) ?? null : e.meshes[n] ?? null;
		case "Material": return r ? e.materials.find((e) => e.uniqueId === n) ?? null : e.materials[n] ?? null;
		case "Camera": return r ? e.cameras.find((e) => e.uniqueId === n) ?? null : e.cameras[n] ?? null;
		case "Light": return r ? e.lights.find((e) => e.uniqueId === n) ?? null : e.lights[n] ?? null;
		default: return null;
	}
}
//#endregion
export { t };
