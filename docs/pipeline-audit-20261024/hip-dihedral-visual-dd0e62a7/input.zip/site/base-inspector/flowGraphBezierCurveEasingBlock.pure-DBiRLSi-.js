import { n as e } from "./typeStore-pENEWnX2.js";
import { n as t } from "./easing-Dodn8ZBp.js";
import { t as n } from "./flowGraphBlock-BTSj91tT.js";
import { c as r, d as i, n as a } from "./flowGraphRichTypes.pure-BpKU4EZT.js";
//#region node_modules/@babylonjs/core/FlowGraph/Blocks/Execution/Animation/flowGraphBezierCurveEasingBlock.pure.js
function o(e, t, n, r, i) {
	if (e <= 0) return 0;
	if (e >= 1) return 1;
	let a = 1 - 3 * r + 3 * t, o = 3 * r - 6 * t, s = 3 * t, c = 0, l = 1, u = e;
	for (let t = 0; t < 8; t++) {
		let t = u * u, n = t * u * a + o * t + s * u - e;
		if (Math.abs(n) < 1e-7) break;
		n > 0 ? l = u : c = u;
		let r = 3 * a * t + 2 * o * u + s, i = Math.abs(r) > 1e-7 ? u - n / r : NaN;
		u = Number.isFinite(i) && i > c && i < l ? i : (c + l) * .5;
	}
	let d = 1 - 3 * i + 3 * n, f = 3 * i - 6 * n, p = 3 * n;
	return d * u * u * u + f * u * u + p * u;
}
var s = class extends t {
	easeInCore(e) {
		return o(e, this.x1, this.y1, this.x2, this.y2);
	}
}, c = class extends n {
	constructor(e) {
		super(e), this.config = e, this._easingFunctions = {}, this.mode = this.registerDataInput("mode", r, 0), this.controlPoint1 = this.registerDataInput("controlPoint1", i), this.controlPoint2 = this.registerDataInput("controlPoint2", i), this.easingFunction = this.registerDataOutput("easingFunction", a);
	}
	_updateOutputs(e) {
		let t = this.mode.getValue(e), n = this.controlPoint1.getValue(e), r = this.controlPoint2.getValue(e);
		if (t === void 0) return;
		let i = `${t}-${n.x}-${n.y}-${r.x}-${r.y}`;
		if (!this._easingFunctions[i]) {
			let e = new s(n.x, n.y, r.x, r.y);
			e.setEasingMode(t), this._easingFunctions[i] = e;
		}
		this.easingFunction.setValue(this._easingFunctions[i], e);
	}
	getClassName() {
		return "FlowGraphBezierCurveEasing";
	}
}, l = !1;
function u() {
	l || (l = !0, e("FlowGraphBezierCurveEasing", c));
}
//#endregion
export { c as FlowGraphBezierCurveEasingBlock, u as RegisterFlowGraphBezierCurveEasingBlock };
