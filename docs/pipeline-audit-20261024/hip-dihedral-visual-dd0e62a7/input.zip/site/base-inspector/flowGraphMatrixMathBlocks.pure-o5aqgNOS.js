import { a as e, o as t, u as n } from "./math.color.pure-CPmbqLkh.js";
import { n as r } from "./typeStore-pENEWnX2.js";
import { c as i, s as a, t as o } from "./flowGraphBlock-BTSj91tT.js";
import { a as s, c, f as l, g as u, l as d, r as f } from "./flowGraphRichTypes.pure-BpKU4EZT.js";
import { t as p } from "./flowGraphCachedOperationBlock-BsIcMusH.js";
import { t as m } from "./flowGraphBinaryOperationBlock-CDgwbjsR.js";
import { t as h } from "./flowGraphUnaryOperationBlock-CzhraRE5.js";
//#region node_modules/@babylonjs/core/FlowGraph/Blocks/Data/Math/flowGraphMatrixMathBlocks.pure.js
var g = 1e-6;
function _(t) {
	return t === "Matrix2D" ? new a([
		0,
		0,
		0,
		0
	]) : t === "Matrix3D" ? new i([
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0
	]) : e.FromArray(Array(16).fill(0));
}
var v = class extends h {
	constructor(t) {
		super(u(t?.matrixType || "Matrix"), u(t?.matrixType || "Matrix"), (t) => t.transpose ? t.transpose() : e.Transpose(t), "FlowGraphTransposeBlock", t);
	}
}, y = class extends h {
	constructor(e) {
		super(u(e?.matrixType || "Matrix"), c, (e) => e.determinant(), "FlowGraphDeterminantBlock", e);
	}
}, b = class extends p {
	constructor(e) {
		super(u(e?.matrixType || "Matrix"), e), this._matrixType = e?.matrixType || "Matrix", this.a = this.registerDataInput("a", u(e?.matrixType || "Matrix"));
	}
	_doOperation(t) {
		let n = this.a.getValue(t), r = n.determinant();
		if (r !== 0 && Number.isFinite(r)) return n.inverse ? n.inverse() : e.Invert(n);
	}
	_getInvalidOutputValue() {
		return _(this._matrixType);
	}
	getClassName() {
		return "FlowGraphInvertMatrixBlock";
	}
}, x = class extends m {
	constructor(e) {
		super(u(e?.matrixType || "Matrix"), u(e?.matrixType || "Matrix"), u(e?.matrixType || "Matrix"), (e, t) => t.multiply(e), "FlowGraphMatrixMultiplicationBlock", e);
	}
}, S = class extends o {
	constructor(e) {
		super(e), this.input = this.registerDataInput("input", s), this.position = this.registerDataOutput("position", l), this.rotationQuaternion = this.registerDataOutput("rotationQuaternion", d), this.scaling = this.registerDataOutput("scaling", l), this.isValid = this.registerDataOutput("isValid", f, !1);
	}
	_updateOutputs(r) {
		let i = r._getExecutionVariable(this, "executionId", -1), a = r._getExecutionVariable(this, "cachedPosition", null), o = r._getExecutionVariable(this, "cachedRotation", null), s = r._getExecutionVariable(this, "cachedScaling", null), c = r._getExecutionVariable(this, "cachedIsValid", null);
		if (i === r.executionId && a && o && s && c !== null) {
			this.isValid.setValue(c, r), this.position.setValue(a, r), this.rotationQuaternion.setValue(o, r), this.scaling.setValue(s, r);
			return;
		}
		let l = this.input.getValue(r).m, u = !!this.config?.keepDegenerateComponents, d = new n(l[12], l[13], l[14]), f = Math.sqrt(l[0] * l[0] + l[1] * l[1] + l[2] * l[2]), p = Math.sqrt(l[4] * l[4] + l[5] * l[5] + l[6] * l[6]), m = Math.sqrt(l[8] * l[8] + l[9] * l[9] + l[10] * l[10]), h = (e) => ({
			isValid: !1,
			rotationQuaternion: t.Identity(),
			position: e ? d : n.Zero(),
			scaling: e ? new n(f, p, m) : n.One()
		}), _, v = Number.isFinite(f) && Number.isFinite(p) && Number.isFinite(m), y = Number.isFinite(l[12]) && Number.isFinite(l[13]) && Number.isFinite(l[14]);
		if (!v || !u && !y) _ = h(u);
		else if (f === 0 || p === 0 || m === 0) _ = h(!0);
		else {
			let r = (l[0] * (l[5] * l[10] - l[6] * l[9]) - l[4] * (l[1] * l[10] - l[2] * l[9]) + l[8] * (l[1] * l[6] - l[2] * l[5])) / (f * p * m);
			if (Math.abs(r) < g) _ = h(u);
			else {
				let r = e.FromValues(l[0], l[1], l[2], 0, l[4], l[5], l[6], 0, l[8], l[9], l[10], 0, l[12], l[13], l[14], 1), i = new n(), a = new t(), o = new n();
				r.decompose(i, a, o), _ = {
					isValid: !0,
					position: o,
					rotationQuaternion: a,
					scaling: i
				};
			}
		}
		this.isValid.setValue(_.isValid, r), this.position.setValue(_.position, r), this.rotationQuaternion.setValue(_.rotationQuaternion, r), this.scaling.setValue(_.scaling, r), r._setExecutionVariable(this, "cachedIsValid", _.isValid), r._setExecutionVariable(this, "cachedPosition", _.position), r._setExecutionVariable(this, "cachedRotation", _.rotationQuaternion), r._setExecutionVariable(this, "cachedScaling", _.scaling), r._setExecutionVariable(this, "executionId", r.executionId);
	}
	getClassName() {
		return "FlowGraphMatrixDecompose";
	}
}, C = class extends o {
	constructor(e) {
		super(e), this.position = this.registerDataInput("position", l), this.rotationQuaternion = this.registerDataInput("rotationQuaternion", d), this.scaling = this.registerDataInput("scaling", l), this.value = this.registerDataOutput("value", s);
	}
	_updateOutputs(t) {
		let n = t._getExecutionVariable(this, "executionId", -1), r = t._getExecutionVariable(this, "cachedMatrix", null);
		if (n === t.executionId && r) this.value.setValue(r, t);
		else {
			let n = e.Compose(this.scaling.getValue(t), this.rotationQuaternion.getValue(t), this.position.getValue(t));
			this.value.setValue(n, t), t._setExecutionVariable(this, "cachedMatrix", n), t._setExecutionVariable(this, "executionId", t.executionId);
		}
	}
	getClassName() {
		return "FlowGraphMatrixCompose";
	}
}, w = !1;
function T() {
	w || (w = !0, r("FlowGraphTransposeBlock", v), r("FlowGraphDeterminantBlock", y), r("FlowGraphInvertMatrixBlock", b), r("FlowGraphMatrixMultiplicationBlock", x), r("FlowGraphMatrixDecompose", S), r("FlowGraphMatrixCompose", C));
}
//#endregion
export { y as FlowGraphDeterminantBlock, b as FlowGraphInvertMatrixBlock, C as FlowGraphMatrixComposeBlock, S as FlowGraphMatrixDecomposeBlock, x as FlowGraphMatrixMultiplicationBlock, v as FlowGraphTransposeBlock, T as RegisterFlowGraphMatrixMathBlocks };
