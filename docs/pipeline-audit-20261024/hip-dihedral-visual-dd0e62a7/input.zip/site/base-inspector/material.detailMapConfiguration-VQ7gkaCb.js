import { t as e } from "./shaderStore-CXjvw9c2.js";
import { f as t } from "./tools.functions-DEecYKlu.js";
import { _ as n, b as r, f as i, i as a, n as o, v as s, y as c } from "./decorators-BldPRAAT.js";
import { t as l } from "./decorators.serialization-CGAHzP43.js";
import { S as u, d, j as f, t as p } from "./material.pure-BwKfnJ6P.js";
import { u as m } from "./imageProcessing-DRHeoyEC.js";
//#region node_modules/@babylonjs/core/Materials/materialPluginManager.pure.js
var h = /*#__PURE__*/ RegExp("^([gimus]+)!"), g = class n {
	constructor(e) {
		this._plugins = [], this._activePlugins = [], this._activePluginsForExtraEvents = [], this._material = e, this._scene = e.getScene(), this._engine = this._scene.getEngine();
	}
	_addPlugin(e) {
		for (let t = 0; t < this._plugins.length; ++t) if (this._plugins[t].name === e.name) return !1;
		if (this._material._uniformBufferLayoutBuilt && (this._material.resetDrawCache(), this._material._createUniformBuffer()), !e.isCompatible(this._material.shaderLanguage)) throw `The plugin "${e.name}" can't be added to the material "${this._material.name}" because the plugin is not compatible with the shader language of the material.`;
		let t = e.getClassName();
		n._MaterialPluginClassToMainDefine[t] || (n._MaterialPluginClassToMainDefine[t] = "MATERIALPLUGIN_" + ++n._MaterialPluginCounter), this._material._callbackPluginEventGeneric = (e, t) => this._handlePluginEvent(e, t), this._plugins.push(e), this._plugins.sort((e, t) => e.priority - t.priority), this._codeInjectionPoints = {};
		let r = {};
		r[n._MaterialPluginClassToMainDefine[t]] = {
			type: "boolean",
			default: !0
		};
		for (let e of this._plugins) e.collectDefines(r), this._collectPointNames("vertex", e.getCustomCode("vertex", this._material.shaderLanguage)), this._collectPointNames("fragment", e.getCustomCode("fragment", this._material.shaderLanguage));
		return this._defineNamesFromPlugins = r, !0;
	}
	_activatePlugin(e) {
		this._activePlugins.indexOf(e) === -1 && (this._activePlugins.push(e), this._activePlugins.sort((e, t) => e.priority - t.priority), this._material._callbackPluginEventIsReadyForSubMesh = this._handlePluginEventIsReadyForSubMesh.bind(this), this._material._callbackPluginEventPrepareDefinesBeforeAttributes = this._handlePluginEventPrepareDefinesBeforeAttributes.bind(this), this._material._callbackPluginEventPrepareDefines = this._handlePluginEventPrepareDefines.bind(this), this._material._callbackPluginEventBindForSubMesh = this._handlePluginEventBindForSubMesh.bind(this), e.registerForExtraEvents && (this._activePluginsForExtraEvents.push(e), this._activePluginsForExtraEvents.sort((e, t) => e.priority - t.priority), this._material._callbackPluginEventHasRenderTargetTextures = this._handlePluginEventHasRenderTargetTextures.bind(this), this._material._callbackPluginEventFillRenderTargetTextures = this._handlePluginEventFillRenderTargetTextures.bind(this), this._material._callbackPluginEventHardBindForSubMesh = this._handlePluginEventHardBindForSubMesh.bind(this)));
	}
	getPlugin(e) {
		for (let t = 0; t < this._plugins.length; ++t) if (this._plugins[t].name === e) return this._plugins[t];
		return null;
	}
	_handlePluginEventIsReadyForSubMesh(e) {
		let t = !0;
		for (let n of this._activePlugins) t &&= n.isReadyForSubMesh(e.defines, this._scene, this._engine, e.subMesh);
		e.isReadyForSubMesh = t;
	}
	_handlePluginEventPrepareDefinesBeforeAttributes(e) {
		for (let t of this._activePlugins) t.prepareDefinesBeforeAttributes(e.defines, this._scene, e.mesh);
	}
	_handlePluginEventPrepareDefines(e) {
		for (let t of this._activePlugins) t.prepareDefines(e.defines, this._scene, e.mesh);
	}
	_handlePluginEventHardBindForSubMesh(e) {
		for (let t of this._activePluginsForExtraEvents) t.hardBindForSubMesh(this._material._uniformBuffer, this._scene, this._engine, e.subMesh);
	}
	_handlePluginEventBindForSubMesh(e) {
		for (let t of this._activePlugins) t.bindForSubMesh(this._material._uniformBuffer, this._scene, this._engine, e.subMesh);
	}
	_handlePluginEventHasRenderTargetTextures(e) {
		let t = !1;
		for (let e of this._activePluginsForExtraEvents) if (t = e.hasRenderTargetTextures(), t) break;
		e.hasRenderTargetTextures = t;
	}
	_handlePluginEventFillRenderTargetTextures(e) {
		for (let t of this._activePluginsForExtraEvents) t.fillRenderTargetTextures(e.renderTargets);
	}
	_handlePluginEvent(e, t) {
		switch (e) {
			case 512: {
				let e = t;
				for (let t of this._activePlugins) t.getActiveTextures(e.activeTextures);
				break;
			}
			case 256: {
				let e = t;
				for (let t of this._activePlugins) t.getAnimatables(e.animatables);
				break;
			}
			case 1024: {
				let e = t, n = !1;
				for (let t of this._activePlugins) if (n = t.hasTexture(e.texture), n) break;
				e.hasTexture = n;
				break;
			}
			case 2: {
				let e = t;
				for (let t of this._plugins) t.dispose(e.forceDisposeTextures);
				break;
			}
			case 4: {
				let e = t;
				e.defineNames = this._defineNamesFromPlugins;
				break;
			}
			case 128: {
				let e = t;
				for (let t of this._activePlugins) e.fallbackRank = t.addFallbacks(e.defines, e.fallbacks, e.fallbackRank), t.getAttributes(e.attributes, this._scene, e.mesh);
				this._uniformList.length > 0 && e.uniforms.push(...this._uniformList), this._samplerList.length > 0 && e.samplers.push(...this._samplerList), this._uboList.length > 0 && e.uniformBuffersNames.push(...this._uboList), e.customCode = this._injectCustomCode(e, e.customCode);
				break;
			}
			case 8: {
				let e = t;
				this._uboDeclaration = "", this._vertexDeclaration = "", this._fragmentDeclaration = "", this._uniformList = [], this._samplerList = [], this._uboList = [];
				let n = this._material.shaderLanguage === 1;
				for (let t of this._plugins) {
					let r = t.getUniforms(this._material.shaderLanguage);
					if (r) {
						if (r.ubo) for (let t of r.ubo) {
							if (t.size && t.type) {
								let r = t.arraySize ?? 0;
								if (e.ubo.addUniform(t.name, t.size, r), n) {
									let e;
									switch (t.type) {
										case "mat4":
											e = "mat4x4f";
											break;
										case "float":
											e = "f32";
											break;
										default: e = `${t.type}f`;
									}
									r > 0 ? this._uboDeclaration += `uniform ${t.name}: array<${e}, ${r}>;\n` : this._uboDeclaration += `uniform ${t.name}: ${e};\n`;
								} else this._uboDeclaration += `${t.type} ${t.name}${r > 0 ? `[${r}]` : ""};\n`;
							}
							this._uniformList.push(t.name);
						}
						r.vertex && (this._vertexDeclaration += r.vertex + "\n"), r.fragment && (this._fragmentDeclaration += r.fragment + "\n"), r.externalUniforms && this._uniformList.push(...r.externalUniforms);
					}
					t.getSamplers(this._samplerList), t.getUniformBuffersNames(this._uboList);
				}
				break;
			}
		}
	}
	_collectPointNames(e, t) {
		if (t) for (let n in t) this._codeInjectionPoints[e] || (this._codeInjectionPoints[e] = {}), this._codeInjectionPoints[e][n] = !0;
	}
	_injectCustomCode(n, r) {
		return (i, a) => {
			r && (a = r(i, a)), this._uboDeclaration && (a = a.replace("#define ADDITIONAL_UBO_DECLARATION", this._uboDeclaration)), this._vertexDeclaration && (a = a.replace("#define ADDITIONAL_VERTEX_DECLARATION", this._vertexDeclaration)), this._fragmentDeclaration && (a = a.replace("#define ADDITIONAL_FRAGMENT_DECLARATION", this._fragmentDeclaration));
			let o = this._codeInjectionPoints?.[i];
			if (!o) return a;
			let s = null;
			for (let r in o) {
				let o = "";
				for (let a of this._activePlugins) {
					let c = this._material.shaderLanguage, l = a.getCustomCode(i, c)?.[r];
					l && (a.resolveIncludes && (s === null && (s = {
						defines: [],
						indexParameters: n.indexParameters,
						isFragment: !1,
						shouldUseHighPrecisionShader: this._engine._shouldUseHighPrecisionShader,
						processor: void 0,
						supportsUniformBuffers: this._engine.supportsUniformBuffers,
						shadersRepository: e.GetShadersRepository(c),
						includesShadersStore: e.GetIncludesShadersStore(c),
						version: void 0,
						platformName: this._engine.shaderPlatformName,
						processingContext: void 0,
						isNDCHalfZRange: this._engine.isNDCHalfZRange,
						useReverseDepthBuffer: this._engine.useReverseDepthBuffer,
						processCodeAfterIncludes: void 0
					}), s.isFragment = i === "fragment", t(l, s, (e) => l = e)), o += l + "\n");
				}
				if (o.length > 0) {
					if (r.charAt(0) === "!") {
						r = r.substring(1);
						let e = "g";
						if (r.charAt(0) === "!") e = "", r = r.substring(1);
						else {
							let t = h.exec(r);
							t && t.length >= 2 && (e = t[1], r = r.substring(e.length + 1));
						}
						e.indexOf("g") < 0 && (e += "g");
						let t = new RegExp(r, e), n = t.exec(a);
						for (; n !== null;) {
							let { index: e } = n, r = _(o, n);
							a = a.substring(0, e) + r + a.substring(e + n[0].length), t.lastIndex = e + r.length, n = t.exec(a);
						}
					} else {
						let e = "#define " + r;
						a = a.replace(e, "\n" + o + "\n" + e);
					}
				}
			}
			return a;
		};
	}
};
g._MaterialPluginClassToMainDefine = {}, g._MaterialPluginCounter = 0;
function _(e, t) {
	return e.replace(/\$(\d+)/g, (e, n) => {
		let r = Number(n);
		return r < t.length ? t[r] : "";
	});
}
//#endregion
//#region node_modules/@babylonjs/core/Materials/materialPluginBase.pure.js
var v = (() => {
	var e;
	let t, n = [], i = [], o, s = [], u = [], d, f = [], p = [], m, h = [], _ = [];
	return e = class {
		isCompatible(e) {
			switch (e) {
				case 0: return !0;
				default: return !1;
			}
		}
		_enable(e) {
			e && this._pluginManager._activatePlugin(this);
		}
		constructor(e, t, a, o, c = !0, l = !1, d = !1) {
			this.name = r(this, n, void 0), this.priority = (r(this, i), r(this, s, 500)), this.resolveIncludes = (r(this, u), r(this, f, !1)), this.registerForExtraEvents = (r(this, p), r(this, h, !1)), this.doNotSerialize = (r(this, _), !1), this._material = e, this.name = t, this.priority = a, this.resolveIncludes = d, e.pluginManager || (e.pluginManager = new g(e), e.onDisposeObservable.add(() => {
				e.pluginManager = void 0;
			})), this._pluginDefineNames = o, this._pluginManager = e.pluginManager, c && this._pluginManager._addPlugin(this), l && this._enable(!0), this.markAllDefinesAsDirty = e._dirtyCallbacks[127];
		}
		getClassName() {
			return "MaterialPluginBase";
		}
		isReadyForSubMesh(e, t, n, r) {
			return !0;
		}
		hardBindForSubMesh(e, t, n, r) {}
		bindForSubMesh(e, t, n, r) {}
		dispose(e) {}
		getCustomCode(e, t = 0) {
			return null;
		}
		collectDefines(e) {
			if (this._pluginDefineNames) for (let t of Object.keys(this._pluginDefineNames)) {
				if (t[0] === "_") continue;
				let n = typeof this._pluginDefineNames[t];
				e[t] = {
					type: n === "number" ? "number" : n === "string" ? "string" : n === "boolean" ? "boolean" : "object",
					default: this._pluginDefineNames[t]
				};
			}
		}
		prepareDefinesBeforeAttributes(e, t, n) {}
		prepareDefines(e, t, n) {}
		hasTexture(e) {
			return !1;
		}
		hasRenderTargetTextures() {
			return !1;
		}
		fillRenderTargetTextures(e) {}
		getActiveTextures(e) {}
		getAnimatables(e) {}
		addFallbacks(e, t, n) {
			return n;
		}
		getSamplers(e) {}
		getAttributes(e, t, n) {}
		getUniformBuffersNames(e) {}
		getUniforms(e = 0) {
			return {};
		}
		copyTo(e) {
			l.Clone(() => e, this);
		}
		serialize() {
			return l.Serialize(this);
		}
		parse(e, t, n) {
			l.Parse(() => this, e, t, n);
		}
	}, (() => {
		let r = typeof Symbol == "function" && Symbol.metadata ? Object.create(null) : void 0;
		t = [a()], o = [a()], d = [a()], m = [a()], c(null, null, t, {
			kind: "field",
			name: "name",
			static: !1,
			private: !1,
			access: {
				has: (e) => "name" in e,
				get: (e) => e.name,
				set: (e, t) => {
					e.name = t;
				}
			},
			metadata: r
		}, n, i), c(null, null, o, {
			kind: "field",
			name: "priority",
			static: !1,
			private: !1,
			access: {
				has: (e) => "priority" in e,
				get: (e) => e.priority,
				set: (e, t) => {
					e.priority = t;
				}
			},
			metadata: r
		}, s, u), c(null, null, d, {
			kind: "field",
			name: "resolveIncludes",
			static: !1,
			private: !1,
			access: {
				has: (e) => "resolveIncludes" in e,
				get: (e) => e.resolveIncludes,
				set: (e, t) => {
					e.resolveIncludes = t;
				}
			},
			metadata: r
		}, f, p), c(null, null, m, {
			kind: "field",
			name: "registerForExtraEvents",
			static: !1,
			private: !1,
			access: {
				has: (e) => "registerForExtraEvents" in e,
				get: (e) => e.registerForExtraEvents,
				set: (e, t) => {
					e.registerForExtraEvents = t;
				}
			},
			metadata: r
		}, h, _), r && Object.defineProperty(e, Symbol.metadata, {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: r
		});
	})(), e;
})(), y = class extends m {
	constructor() {
		super(...arguments), this.DETAIL = !1, this.DETAILDIRECTUV = 0, this.DETAIL_NORMALBLENDMETHOD = 0;
	}
}, b = (() => {
	var e, t, l, m;
	let h = v, g, _ = [], b = [], x, S = [], C = [], w, T = [], E = [], D, O = [], k = [], A, j = [], M = [], N, P = [], F = [];
	return e = class extends h {
		get texture() {
			return n(this, t, "f");
		}
		set texture(e) {
			s(this, t, e, "f");
		}
		get normalBlendMethod() {
			return n(this, l, "f");
		}
		set normalBlendMethod(e) {
			s(this, l, e, "f");
		}
		get isEnabled() {
			return n(this, m, "f");
		}
		set isEnabled(e) {
			s(this, m, e, "f");
		}
		_markAllSubMeshesAsTexturesDirty() {
			this._enable(this._isEnabled), this._internalMarkAllSubMeshesAsTexturesDirty();
		}
		isCompatible() {
			return !0;
		}
		constructor(e, n = !0) {
			super(e, "DetailMap", 140, new y(), n), this._texture = null, t.set(this, r(this, _, void 0)), this.diffuseBlendLevel = (r(this, b), r(this, S, 1)), this.roughnessBlendLevel = (r(this, C), r(this, T, 1)), this.bumpLevel = (r(this, E), r(this, O, 1)), this._normalBlendMethod = (r(this, k), p.MATERIAL_NORMALBLENDMETHOD_WHITEOUT), l.set(this, r(this, j, void 0)), this._isEnabled = (r(this, M), !1), m.set(this, r(this, P, !1)), this._internalMarkAllSubMeshesAsTexturesDirty = r(this, F), this._internalMarkAllSubMeshesAsTexturesDirty = e._dirtyCallbacks[1];
		}
		isReadyForSubMesh(e, t, n) {
			return !this._isEnabled || !(e._areTexturesDirty && t.texturesEnabled && n.getCaps().standardDerivatives && this._texture && f.DetailTextureEnabled && !this._texture.isReady());
		}
		prepareDefines(e, t) {
			if (this._isEnabled) {
				e.DETAIL_NORMALBLENDMETHOD = this._normalBlendMethod;
				let n = t.getEngine();
				e._areTexturesDirty && (n.getCaps().standardDerivatives && this._texture && f.DetailTextureEnabled && this._isEnabled ? (u(this._texture, e, "DETAIL"), e.DETAIL_NORMALBLENDMETHOD = this._normalBlendMethod) : e.DETAIL = !1);
			} else e.DETAIL = !1;
		}
		bindForSubMesh(e, t) {
			if (!this._isEnabled) return;
			let n = this._material.isFrozen;
			(!e.useUbo || !n || !e.isSync) && this._texture && f.DetailTextureEnabled && (e.updateFloat4("vDetailInfos", this._texture.coordinatesIndex, this.diffuseBlendLevel, this.bumpLevel, this.roughnessBlendLevel), d(this._texture, e, "detail")), t.texturesEnabled && this._texture && f.DetailTextureEnabled && e.setTexture("detailSampler", this._texture);
		}
		hasTexture(e) {
			return this._texture === e;
		}
		getActiveTextures(e) {
			this._texture && e.push(this._texture);
		}
		getAnimatables(e) {
			this._texture && this._texture.animations && this._texture.animations.length > 0 && e.push(this._texture);
		}
		dispose(e) {
			e && this._texture?.dispose();
		}
		getClassName() {
			return "DetailMapConfiguration";
		}
		getSamplers(e) {
			e.push("detailSampler");
		}
		getUniforms() {
			return { ubo: [{
				name: "vDetailInfos",
				size: 4,
				type: "vec4"
			}, {
				name: "detailMatrix",
				size: 16,
				type: "mat4"
			}] };
		}
	}, t = /* @__PURE__ */ new WeakMap(), l = /* @__PURE__ */ new WeakMap(), m = /* @__PURE__ */ new WeakMap(), (() => {
		let t = typeof Symbol == "function" && Symbol.metadata ? Object.create(h[Symbol.metadata] ?? null) : void 0;
		g = [i("detailTexture"), o("_markAllSubMeshesAsTexturesDirty")], x = [a()], w = [a()], D = [a()], A = [a(), o("_markAllSubMeshesAsTexturesDirty")], N = [a(), o("_markAllSubMeshesAsTexturesDirty")], c(e, null, g, {
			kind: "accessor",
			name: "texture",
			static: !1,
			private: !1,
			access: {
				has: (e) => "texture" in e,
				get: (e) => e.texture,
				set: (e, t) => {
					e.texture = t;
				}
			},
			metadata: t
		}, _, b), c(e, null, A, {
			kind: "accessor",
			name: "normalBlendMethod",
			static: !1,
			private: !1,
			access: {
				has: (e) => "normalBlendMethod" in e,
				get: (e) => e.normalBlendMethod,
				set: (e, t) => {
					e.normalBlendMethod = t;
				}
			},
			metadata: t
		}, j, M), c(e, null, N, {
			kind: "accessor",
			name: "isEnabled",
			static: !1,
			private: !1,
			access: {
				has: (e) => "isEnabled" in e,
				get: (e) => e.isEnabled,
				set: (e, t) => {
					e.isEnabled = t;
				}
			},
			metadata: t
		}, P, F), c(null, null, x, {
			kind: "field",
			name: "diffuseBlendLevel",
			static: !1,
			private: !1,
			access: {
				has: (e) => "diffuseBlendLevel" in e,
				get: (e) => e.diffuseBlendLevel,
				set: (e, t) => {
					e.diffuseBlendLevel = t;
				}
			},
			metadata: t
		}, S, C), c(null, null, w, {
			kind: "field",
			name: "roughnessBlendLevel",
			static: !1,
			private: !1,
			access: {
				has: (e) => "roughnessBlendLevel" in e,
				get: (e) => e.roughnessBlendLevel,
				set: (e, t) => {
					e.roughnessBlendLevel = t;
				}
			},
			metadata: t
		}, T, E), c(null, null, D, {
			kind: "field",
			name: "bumpLevel",
			static: !1,
			private: !1,
			access: {
				has: (e) => "bumpLevel" in e,
				get: (e) => e.bumpLevel,
				set: (e, t) => {
					e.bumpLevel = t;
				}
			},
			metadata: t
		}, O, k), t && Object.defineProperty(e, Symbol.metadata, {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: t
		});
	})(), e;
})();
//#endregion
export { v as n, b as t };
