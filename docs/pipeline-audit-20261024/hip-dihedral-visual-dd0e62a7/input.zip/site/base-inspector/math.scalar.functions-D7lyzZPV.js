//#region \0rolldown/runtime.js
var e = Object.defineProperty, t = (t, n) => {
	let r = {};
	for (var i in t) e(r, i, {
		get: t[i],
		enumerable: !0
	});
	return n || e(r, Symbol.toStringTag, { value: "Module" }), r;
}, n = /* @__PURE__ */ t({
	Clamp: () => f,
	DeltaAngle: () => y,
	Denormalize: () => v,
	ExtractAsInt: () => r,
	Hermite: () => u,
	Hermite1stDerivative: () => d,
	HighestCommonFactor: () => E,
	ILog2: () => h,
	InverseLerp: () => l,
	Lerp: () => s,
	LerpAngle: () => c,
	MoveTowards: () => S,
	MoveTowardsAngle: () => C,
	Normalize: () => _,
	NormalizeRadians: () => p,
	OutsideRange: () => a,
	PercentToRange: () => T,
	PingPong: () => b,
	RandomRange: () => o,
	RangeToPercent: () => w,
	Repeat: () => g,
	SmoothStep: () => x,
	ToHex: () => m,
	WithinEpsilon: () => i
});
function r(e) {
	return parseInt(e.toString().replace(/\W/g, ""));
}
function i(e, t, n = 1401298e-51) {
	return Math.abs(e - t) <= n;
}
function a(e, t, n, r = 1401298e-51) {
	return e < t - r || e > n + r;
}
function o(e, t) {
	return e === t ? e : Math.random() * (t - e) + e;
}
function s(e, t, n) {
	return e + (t - e) * n;
}
function c(e, t, n) {
	let r = g(t - e, 360);
	return r > 180 && (r -= 360), e + r * f(n);
}
function l(e, t, n) {
	let r;
	return r = e == t ? 0 : f((n - e) / (t - e)), r;
}
function u(e, t, n, r, i) {
	let a = i * i, o = i * a, s = 2 * o - 3 * a + 1, c = -2 * o + 3 * a, l = o - 2 * a + i, u = o - a;
	return e * s + n * c + t * l + r * u;
}
function d(e, t, n, r, i) {
	let a = i * i;
	return (a - i) * 6 * e + (3 * a - 4 * i + 1) * t + (-a + i) * 6 * n + (3 * a - 2 * i) * r;
}
function f(e, t = 0, n = 1) {
	return Math.min(n, Math.max(t, e));
}
function p(e) {
	return e -= Math.PI * 2 * Math.floor((e + Math.PI) / (Math.PI * 2)), e;
}
function m(e) {
	let t = e.toString(16);
	return e <= 15 ? ("0" + t).toUpperCase() : t.toUpperCase();
}
function h(e) {
	if (Math.log2) return Math.floor(Math.log2(e));
	if (e < 0) return NaN;
	if (e === 0) return -Infinity;
	let t = 0;
	if (e < 1) {
		for (; e < 1;) t++, e *= 2;
		t = -t;
	} else if (e > 1) for (; e > 1;) t++, e = Math.floor(e / 2);
	return t;
}
function g(e, t) {
	return e - Math.floor(e / t) * t;
}
function _(e, t, n) {
	return (e - t) / (n - t);
}
function v(e, t, n) {
	return e * (n - t) + t;
}
function y(e, t) {
	let n = g(t - e, 360);
	return n > 180 && (n -= 360), n;
}
function b(e, t) {
	let n = g(e, t * 2);
	return t - Math.abs(n - t);
}
function x(e, t, n) {
	let r = f(n);
	return r = -2 * r * r * r + 3 * r * r, t * r + e * (1 - r);
}
function S(e, t, n) {
	let r;
	return r = Math.abs(t - e) <= n ? t : e + Math.sign(t - e) * n, r;
}
function C(e, t, n) {
	let r = y(e, t), i;
	return -n < r && r < n ? i = t : (t = e + r, i = S(e, t, n)), i;
}
function w(e, t, n) {
	return (e - t) / (n - t);
}
function T(e, t, n) {
	return (n - t) * e + t;
}
function E(e, t) {
	let n = e % t;
	return n === 0 ? t : E(t, n);
}
//#endregion
export { s as a, m as c, t as d, h as i, i as l, u as n, p as o, E as r, o as s, f as t, n as u };
