//#region node_modules/@babylonjs/core/Engines/shaderStore.js
var e = class e {
	static GetShadersRepository(t = 0) {
		return t === 0 ? e.ShadersRepository : e.ShadersRepositoryWGSL;
	}
	static GetShadersStore(t = 0) {
		return t === 0 ? e.ShadersStore : e.ShadersStoreWGSL;
	}
	static GetIncludesShadersStore(t = 0) {
		return t === 0 ? e.IncludesShadersStore : e.IncludesShadersStoreWGSL;
	}
};
e.ShadersRepository = "src/Shaders/", e.ShadersStore = {}, e.IncludesShadersStore = {}, e.ShadersRepositoryWGSL = "src/ShadersWGSL/", e.ShadersStoreWGSL = {}, e.IncludesShadersStoreWGSL = {};
//#endregion
export { e as t };
