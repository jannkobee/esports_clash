import { t as e } from "./logger-DQIzSR_y.js";
import { n as t } from "./typeStore-pENEWnX2.js";
import { a as n } from "./flowGraphBlock-BTSj91tT.js";
import { t as r } from "./flowGraphCoordinator-0kjQDTdY.js";
import { t as i } from "./flowGraphEventBlock-Dyv9PqYT.js";
import { g as a, u as o } from "./flowGraphRichTypes.pure-BpKU4EZT.js";
//#region node_modules/@babylonjs/core/FlowGraph/Blocks/Event/flowGraphReceiveCustomEventBlock.pure.js
function s(e) {
	return `custom:${encodeURIComponent(e)}`;
}
var c = class extends i {
	get eventKey() {
		return s(this.config.eventId);
	}
	constructor(e) {
		super(e), this.config = e, this.initPriority = 1;
		for (let e of Object.keys(this.config.eventData ?? {})) {
			let t = this.config.eventData[e], n = typeof t.type == "string" ? t.type : t.type?.typeName, r = typeof t.type?.serialize == "function" ? t.type : a(n);
			t.type = r, this.registerDataOutput(e, r, t.value);
		}
		this.eventRef = this.config.eventData && Object.prototype.hasOwnProperty.call(this.config.eventData, "event") ? this.getDataOutput("event") : this.registerDataOutput("event", o);
	}
	_updateOutputs(e) {
		this.eventRef.setValue(e.getEventReference(this.eventKey), e);
	}
	_preparePendingTasks(e) {
		let t = e.configuration.coordinator.getCustomEventObservable(this.config.eventId);
		if (t && t.hasObservers() && t.observers.length > r.MaxEventsPerType) {
			this._reportError(e, `FlowGraphReceiveCustomEventBlock: Too many observers for event ${this.config.eventId}. Max is ${r.MaxEventsPerType}.`);
			return;
		}
		let n = t.add((t, n) => {
			e.configuration.coordinator._beginEventDispatch(this.eventKey, n);
			try {
				for (let n of Object.keys(this.config.eventData ?? {})) {
					let r = this.getDataOutput(n);
					if (!r) continue;
					let i = t?.[n];
					r.setValue(i === void 0 ? this._getEventDataDefault(n) : i, e);
				}
				this.eventRef.setValue(e.getEventReference(this.eventKey), e), this._execute(e);
			} finally {
				e.configuration.coordinator._endEventDispatch();
			}
		});
		e._setExecutionVariable(this, "_eventObserver", n);
	}
	_getEventDataDefault(e) {
		let t = this.config.eventData && Object.prototype.hasOwnProperty.call(this.config.eventData, e) ? this.config.eventData[e] : void 0;
		return t?.value === void 0 ? t?.type?.defaultValue : t.value;
	}
	_cancelPendingTasks(t) {
		let n = t.configuration.coordinator.getCustomEventObservable(this.config.eventId);
		if (n) {
			let e = t._getExecutionVariable(this, "_eventObserver", null);
			n.remove(e);
		} else e.Warn(`FlowGraphReceiveCustomEventBlock: Missing observable for event ${this.config.eventId}`);
	}
	_executeEvent(e, t) {
		return !0;
	}
	serialize(e = {}) {
		super.serialize(e);
		let t = Object.create(null);
		for (let e of Object.keys(this.config.eventData ?? {})) {
			let r = this.config.eventData[e], i = { type: r.type.typeName };
			r.value !== void 0 && n("value", r.value, i), Object.defineProperty(t, e, {
				configurable: !0,
				enumerable: !0,
				value: i,
				writable: !0
			});
		}
		e.config.eventData = t;
	}
	getClassName() {
		return "FlowGraphReceiveCustomEventBlock";
	}
}, l = !1;
function u() {
	l || (l = !0, t("FlowGraphReceiveCustomEventBlock", c));
}
//#endregion
export { c as FlowGraphReceiveCustomEventBlock, s as GetFlowGraphCustomEventKey, u as RegisterFlowGraphReceiveCustomEventBlock };
