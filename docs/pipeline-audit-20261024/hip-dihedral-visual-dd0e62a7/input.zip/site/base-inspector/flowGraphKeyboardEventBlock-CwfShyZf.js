import { o as e } from "./utils-Cc6lHVNn.js";
import { t } from "./flowGraphEventBlock-Dyv9PqYT.js";
import { r as n, u as r } from "./flowGraphRichTypes.pure-BpKU4EZT.js";
//#region node_modules/@babylonjs/core/FlowGraph/Blocks/Event/flowGraphKeyboardEventBlock.js
var i = class extends t {
	constructor(e) {
		super(e), this.key = this.registerDataInput("key", r), this.keyCode = this.registerDataOutput("keyCode", r), this.keyValue = this.registerDataOutput("keyValue", r), this.shiftKey = this.registerDataOutput("shiftKey", n), this.ctrlKey = this.registerDataOutput("ctrlKey", n), this.altKey = this.registerDataOutput("altKey", n), this.metaKey = this.registerDataOutput("metaKey", n), this.commandOrCtrl = this.registerDataOutput("commandOrCtrl", n);
	}
	_executeEvent(t, n) {
		let r = n.event, i = this.key.getValue(t);
		return i && i !== r.code ? !0 : (this.keyCode.setValue(r.code, t), this.keyValue.setValue(r.key, t), this.shiftKey.setValue(r.shiftKey, t), this.ctrlKey.setValue(r.ctrlKey, t), this.altKey.setValue(r.altKey, t), this.metaKey.setValue(r.metaKey, t), this.commandOrCtrl.setValue(e ? r.metaKey : r.ctrlKey, t), this._execute(t), !this.config?.stopPropagation);
	}
	_preparePendingTasks(e) {}
	_cancelPendingTasks(e) {}
};
//#endregion
export { i as t };
