import { n as e } from "./engineStore-D0BoPdea.js";
import { r as t } from "./abstractEngine.pure-C608BZav.js";
import { n } from "./buffer.pure-CgsgX1aa.js";
import { t as r } from "./drawWrapper-DZNPKXXG.js";
//#region node_modules/@babylonjs/core/Maths/math.viewport.js
var i = class e {
	constructor(e, t, n, r) {
		this.x = e, this.y = t, this.width = n, this.height = r;
	}
	toGlobal(t, n) {
		return new e(this.x * t, this.y * n, this.width * t, this.height * n);
	}
	toGlobalToRef(e, t, n) {
		return n.x = this.x * e, n.y = this.y * t, n.width = this.width * e, n.height = this.height * t, this;
	}
	clone() {
		return new e(this.x, this.y, this.width, this.height);
	}
}, a = {
	positions: [
		1,
		1,
		-1,
		1,
		-1,
		-1,
		1,
		-1
	],
	indices: [
		0,
		1,
		2,
		0,
		2,
		3
	]
}, o = class {
	constructor(e, t = a) {
		this._fullscreenViewport = new i(0, 0, 1, 1);
		let r = t.positions ?? a.positions, o = t.indices ?? a.indices;
		this.engine = e, this._vertexBuffers = { [n.PositionKind]: new n(e, r, n.PositionKind, !1, !1, 2) }, this._indexBuffer = e.createIndexBuffer(o), this._indexBufferLength = o.length, this._onContextRestoredObserver = e.onContextRestoredObservable.add(() => {
			this._indexBuffer = e.createIndexBuffer(o);
			for (let e in this._vertexBuffers) this._vertexBuffers[e]._rebuild();
		});
	}
	setViewport(e = this._fullscreenViewport) {
		this.engine.setViewport(e);
	}
	bindBuffers(e) {
		this.engine.bindBuffers(this._vertexBuffers, this._indexBuffer, e);
	}
	applyEffectWrapper(e, t = !1, n = !1) {
		this.engine.setState(!0), this.engine.depthCullingState.depthTest = t, this.engine.stencilState.stencilTest = n, this.engine.enableEffect(e.drawWrapper), this.bindBuffers(e.effect), e.onApplyObservable.notifyObservers({});
	}
	saveStates() {
		this._savedStateDepthTest = this.engine.depthCullingState.depthTest, this._savedStateStencilTest = this.engine.stencilState.stencilTest;
	}
	restoreStates() {
		this.engine.depthCullingState.depthTest = this._savedStateDepthTest, this.engine.stencilState.stencilTest = this._savedStateStencilTest;
	}
	draw() {
		this.engine.drawElementsType(0, 0, this._indexBufferLength);
	}
	_isRenderTargetTexture(e) {
		return e.renderTarget !== void 0;
	}
	render(e, t = null) {
		if (!e.effect.isReady()) return;
		this.saveStates(), this.setViewport();
		let n = t === null ? null : this._isRenderTargetTexture(t) ? t.renderTarget : t;
		n && this.engine.bindFramebuffer(n), this.applyEffectWrapper(e), this.draw(), n && this.engine.unBindFramebuffer(n), this.restoreStates();
	}
	dispose() {
		let e = this._vertexBuffers[n.PositionKind];
		e && (e.dispose(), delete this._vertexBuffers[n.PositionKind]), this._indexBuffer && this.engine._releaseBuffer(this._indexBuffer), this._onContextRestoredObserver &&= (this.engine.onContextRestoredObservable.remove(this._onContextRestoredObserver), null);
	}
}, s = class n {
	static RegisterShaderCodeProcessing(e, t) {
		t ? n._CustomShaderCodeProcessing[e ?? ""] = t : delete n._CustomShaderCodeProcessing[e ?? ""];
	}
	static _GetShaderCodeProcessing(e) {
		return n._CustomShaderCodeProcessing[e] ?? n._CustomShaderCodeProcessing[""];
	}
	get name() {
		return this.options.name;
	}
	set name(e) {
		this.options.name = e;
	}
	isReady() {
		return this._drawWrapper.effect?.isReady() ?? !1;
	}
	get drawWrapper() {
		return this._drawWrapper;
	}
	get effect() {
		return this._drawWrapper.effect;
	}
	set effect(e) {
		this._drawWrapper.effect = e;
	}
	constructor(t) {
		this.alphaMode = 0, this.onEffectCreatedObservable = new e(void 0, !0), this.onApplyObservable = new e(), this._shadersLoaded = !1, this._webGPUReady = !1, this._importPromises = [], this.options = {
			...t,
			name: t.name || "effectWrapper",
			engine: t.engine,
			uniforms: t.uniforms || t.uniformNames || [],
			uniformNames: void 0,
			samplers: t.samplers || t.samplerNames || [],
			samplerNames: void 0,
			attributeNames: t.attributeNames || ["position"],
			uniformBuffers: t.uniformBuffers || [],
			defines: t.defines || "",
			useShaderStore: t.useShaderStore || !1,
			vertexUrl: t.vertexUrl || t.vertexShader || "postprocess",
			vertexShader: void 0,
			fragmentShader: t.fragmentShader || "pass",
			indexParameters: t.indexParameters,
			blockCompilation: t.blockCompilation || !1,
			shaderLanguage: t.shaderLanguage || 0,
			onCompiled: t.onCompiled || void 0,
			onError: t.onError || void 0,
			extraInitializations: t.extraInitializations || void 0,
			extraInitializationsAsync: t.extraInitializationsAsync || void 0,
			useAsPostProcess: t.useAsPostProcess ?? !1,
			allowEmptySourceTexture: t.allowEmptySourceTexture ?? !1
		}, this.options.uniformNames = this.options.uniforms, this.options.samplerNames = this.options.samplers, this.options.vertexShader = this.options.vertexUrl, this.options.useAsPostProcess && (!this.options.allowEmptySourceTexture && this.options.samplers.indexOf("textureSampler") === -1 && this.options.samplers.push("textureSampler"), this.options.uniforms.indexOf("scale") === -1 && this.options.uniforms.push("scale")), t.vertexUrl || t.vertexShader ? this._shaderPath = { vertexSource: this.options.vertexShader } : (this.options.useAsPostProcess || (this.options.uniforms.push("scale"), this.onApplyObservable.add(() => {
			this.effect.setFloat2("scale", 1, 1);
		})), this._shaderPath = { vertex: this.options.vertexShader }), this._shaderPath.fragmentSource = this.options.fragmentShader, this._shaderPath.spectorName = this.options.name, this.options.useShaderStore && (this._shaderPath.fragment = this._shaderPath.fragmentSource, this._shaderPath.vertex || (this._shaderPath.vertex = this._shaderPath.vertexSource), delete this._shaderPath.fragmentSource, delete this._shaderPath.vertexSource), this.onApplyObservable.add(() => {
			this.bind();
		}), this.options.useShaderStore || (this._onContextRestoredObserver = this.options.engine.onContextRestoredObservable.add(() => {
			this.effect._pipelineContext = null, this.effect._prepareEffect();
		})), this._drawWrapper = new r(this.options.engine), this._webGPUReady = this.options.shaderLanguage === 1;
		let n = Array.isArray(this.options.defines) ? this.options.defines.join("\n") : this.options.defines;
		this._postConstructor(this.options.blockCompilation, n, this.options.extraInitializations);
	}
	_gatherImports(e = !1, t) {}
	_postConstructor(e, t = null, r, i) {
		this._importPromises.length = 0, i && this._importPromises.push(...i);
		let a = this.options.engine.isWebGPU && !n.ForceGLSL;
		this._gatherImports(a, this._importPromises), this.options.useShaderStore && this._shaderPath.vertex === "postprocess" && this._importPromises.push(a && this._webGPUReady ? import("./postprocess.vertex-DpZYH6av.js") : import("./postprocess.vertex-7rFBNJhZ.js")), r !== void 0 && r(a, this._importPromises), a && this._webGPUReady && (this.options.shaderLanguage = 1), e || this.updateEffect(t);
	}
	updateEffect(e = null, r = null, i = null, a, o, s, c, l) {
		let u = n._GetShaderCodeProcessing(this.name);
		if (u?.defineCustomBindings) {
			let t = r?.slice() ?? [];
			t.push(...this.options.uniforms);
			let n = i?.slice() ?? [];
			n.push(...this.options.samplers), e = u.defineCustomBindings(this.name, e, t, n), r = t, i = n;
		}
		this.options.defines = e || "";
		let d = this._shadersLoaded || this._importPromises.length === 0 ? void 0 : async () => {
			await Promise.all(this._importPromises), this._shadersLoaded = !0;
		}, f;
		f = this.options.extraInitializationsAsync ? async () => {
			await d?.(), await this.options.extraInitializationsAsync();
		} : d, this.options.useShaderStore ? this._drawWrapper.effect = this.options.engine.createEffect({
			vertex: c ?? this._shaderPath.vertex,
			fragment: l ?? this._shaderPath.fragment
		}, {
			attributes: this.options.attributeNames,
			uniformsNames: r || this.options.uniforms,
			uniformBuffersNames: this.options.uniformBuffers,
			samplers: i || this.options.samplers,
			defines: e === null ? "" : e,
			fallbacks: null,
			onCompiled: o ?? this.options.onCompiled,
			onError: s ?? this.options.onError,
			indexParameters: a || this.options.indexParameters,
			processCodeAfterIncludes: u?.processCodeAfterIncludes ? (e, t) => u.processCodeAfterIncludes(this.name, e, t) : null,
			processFinalCode: u?.processFinalCode ? (e, t) => u.processFinalCode(this.name, e, t) : null,
			shaderLanguage: this.options.shaderLanguage,
			extraInitializationsAsync: f
		}, this.options.engine) : this._drawWrapper.effect = new t(this._shaderPath, this.options.attributeNames, r || this.options.uniforms, i || this.options.samplerNames, this.options.engine, e, void 0, o || this.options.onCompiled, s ?? this.options.onError, void 0, void 0, this.options.shaderLanguage, f), this.onEffectCreatedObservable.notifyObservers(this._drawWrapper.effect);
	}
	bind(e = !1) {
		this.options.useAsPostProcess && !e && (this.options.engine.setAlphaMode(this.alphaMode), this.drawWrapper.effect.setFloat2("scale", 1, 1)), n._GetShaderCodeProcessing(this.name)?.bindCustomBindings?.(this.name, this._drawWrapper.effect);
	}
	dispose(e = !1) {
		this._onContextRestoredObserver &&= (this.effect.getEngine().onContextRestoredObservable.remove(this._onContextRestoredObserver), null), this.onEffectCreatedObservable.clear(), this._drawWrapper.dispose(!0);
	}
};
s.ForceGLSL = !1, s._CustomShaderCodeProcessing = {};
//#endregion
export { s as n, i as r, o as t };
