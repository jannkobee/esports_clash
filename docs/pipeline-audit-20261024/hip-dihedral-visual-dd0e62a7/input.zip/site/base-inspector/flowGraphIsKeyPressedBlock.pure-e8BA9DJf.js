import { n as e } from "./typeStore-pENEWnX2.js";
import { t } from "./flowGraphBlock-BTSj91tT.js";
import { r as n, u as r } from "./flowGraphRichTypes.pure-BpKU4EZT.js";
//#region node_modules/@babylonjs/core/FlowGraph/Blocks/Data/flowGraphIsKeyPressedBlock.pure.js
var i = class extends t {
	constructor(e) {
		super(e), this.key = this.registerDataInput("key", r), this.withShift = this.registerDataInput("withShift", n), this.withCtrl = this.registerDataInput("withCtrl", n), this.withAlt = this.registerDataInput("withAlt", n), this.withMeta = this.registerDataInput("withMeta", n), this.withCommandOrCtrl = this.registerDataInput("withCommandOrCtrl", n), this.isPressed = this.registerDataOutput("isPressed", n);
	}
	_updateOutputs(e) {
		let t = e.configuration.sceneEventCoordinator;
		if (!t) {
			this.isPressed.setValue(!1, e);
			return;
		}
		let n = t.pressedKeys, r = this.key.getValue(e), i = !r || n.has(r);
		i && this.withShift.getValue(e) && (i = n.has("ShiftLeft") || n.has("ShiftRight")), i && this.withCtrl.getValue(e) && (i = n.has("ControlLeft") || n.has("ControlRight")), i && this.withAlt.getValue(e) && (i = n.has("AltLeft") || n.has("AltRight")), i && this.withMeta.getValue(e) && (i = n.has("MetaLeft") || n.has("MetaRight")), i && this.withCommandOrCtrl.getValue(e) && (i = n.has("CommandOrControl")), this.isPressed.setValue(i, e);
	}
	getClassName() {
		return "FlowGraphIsKeyPressedBlock";
	}
}, a = !1;
function o() {
	a || (a = !0, e("FlowGraphIsKeyPressedBlock", i));
}
//#endregion
export { i as FlowGraphIsKeyPressedBlock, o as RegisterFlowGraphIsKeyPressedBlock };
