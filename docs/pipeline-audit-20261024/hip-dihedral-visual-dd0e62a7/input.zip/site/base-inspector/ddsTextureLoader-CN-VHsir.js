import { n as e } from "./sphericalPolynomial.pure-DQ1oR6Od.js";
import { DDSTools as t } from "./dds.pure-DSPAJ2ph.js";
//#region node_modules/@babylonjs/core/Materials/Textures/Loaders/ddsTextureLoader.js
var n = class {
	constructor() {
		this.supportCascades = !0;
	}
	loadCubeData(n, r, i, a) {
		let o = r.getEngine(), s, c = !1, l = 1e3;
		if (Array.isArray(n)) for (let e = 0; e < n.length; e++) {
			let i = n[e];
			s = t.GetDDSInfo(i), r.width = s.width, r.height = s.height, c = (s.isRGB || s.isLuminance || s.mipmapCount > 1) && r.generateMipMaps, o._unpackFlipY(s.isCompressed), t.UploadDDSLevels(o, r, i, s, c, 6, -1, e), !s.isFourCC && s.mipmapCount === 1 ? o.generateMipMapsForCubemap(r) : l = s.mipmapCount - 1;
		}
		else {
			let a = n;
			s = t.GetDDSInfo(a), r.width = s.width, r.height = s.height, i && (s.sphericalPolynomial = new e()), c = (s.isRGB || s.isLuminance || s.mipmapCount > 1) && r.generateMipMaps, o._unpackFlipY(s.isCompressed), t.UploadDDSLevels(o, r, a, s, c, 6), !s.isFourCC && s.mipmapCount === 1 ? o.generateMipMapsForCubemap(r, !1) : l = s.mipmapCount - 1;
		}
		o._setCubeMapTextureParams(r, c, l), r.isReady = !0, r.onLoadedObservable.notifyObservers(r), r.onLoadedObservable.clear(), a && a({
			isDDS: !0,
			width: r.width,
			info: s,
			data: n,
			texture: r
		});
	}
	loadData(e, n, r) {
		let i = t.GetDDSInfo(e), a = (i.isRGB || i.isLuminance || i.mipmapCount > 1) && n.generateMipMaps && Math.max(i.width, i.height) >> i.mipmapCount - 1 == 1;
		r(i.width, i.height, a, i.isFourCC, () => {
			t.UploadDDSLevels(n.getEngine(), n, e, i, a, 1);
		});
	}
};
//#endregion
export { n as _DDSTextureLoader };
