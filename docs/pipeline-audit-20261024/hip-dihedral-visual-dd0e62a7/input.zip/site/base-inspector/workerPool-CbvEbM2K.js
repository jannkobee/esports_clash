//#region node_modules/@babylonjs/core/Misc/workerPool.js
var e = class {
	constructor(e) {
		this._pendingActions = [], this._workerInfos = e.map((e) => ({
			workerPromise: Promise.resolve(e),
			idle: !0
		}));
	}
	dispose() {
		for (let e of this._workerInfos) e.workerPromise.then((e) => {
			e.terminate();
		});
		this._workerInfos.length = 0, this._pendingActions.length = 0;
	}
	push(e) {
		this._executeOnIdleWorker(e) || this._pendingActions.push(e);
	}
	_executeOnIdleWorker(e) {
		for (let t of this._workerInfos) if (t.idle) return this._execute(t, e), !0;
		return !1;
	}
	_execute(e, t) {
		e.idle = !1, e.workerPromise.then((n) => {
			t(n, () => {
				let t = this._pendingActions.shift();
				t ? this._execute(e, t) : e.idle = !0;
			});
		});
	}
}, t = class t extends e {
	constructor(e, n, r = t.DefaultOptions) {
		super([]), this._maxWorkers = e, this._createWorkerAsync = n, this._options = r;
	}
	push(e) {
		if (!this._executeOnIdleWorker(e)) {
			if (this._workerInfos.length < this._maxWorkers) {
				let t = {
					workerPromise: this._createWorkerAsync(),
					idle: !1
				};
				this._workerInfos.push(t), this._execute(t, e);
			} else this._pendingActions.push(e);
		}
	}
	_execute(e, t) {
		e.timeoutId && (clearTimeout(e.timeoutId), delete e.timeoutId), super._execute(e, (n, r) => {
			t(n, () => {
				r(), e.idle && (e.timeoutId = setTimeout(() => {
					e.workerPromise.then((e) => {
						e.terminate();
					});
					let t = this._workerInfos.indexOf(e);
					t !== -1 && this._workerInfos.splice(t, 1);
				}, this._options.idleTimeElapsedBeforeRelease));
			});
		});
	}
};
t.DefaultOptions = { idleTimeElapsedBeforeRelease: 1e3 };
//#endregion
export { t };
