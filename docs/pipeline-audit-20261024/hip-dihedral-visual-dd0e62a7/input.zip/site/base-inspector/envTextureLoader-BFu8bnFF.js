import { t as e } from "./baseTexture.pure-CQS3PJ87.js";
import { n as t, r as n, t as r } from "./environmentTextureTools.pure-Bosla8aw.js";
import { t as i } from "./cubemapToSphericalPolynomial-Df-crXSp.js";
//#region node_modules/@babylonjs/core/Materials/Textures/baseTexture.polynomial.pure.js
var a = !1;
function o() {
	a || (a = !0, e.prototype._sphericalPolynomialTargetSize = 0, e.prototype.forceSphericalPolynomialsRecompute = function() {
		this._texture && (this._texture._sphericalPolynomial = null, this._texture._sphericalPolynomialPromise = null, this._texture._sphericalPolynomialComputed = !1);
	}, Object.defineProperty(e.prototype, "sphericalPolynomial", {
		get: function() {
			if (this._texture) {
				if (this._texture._sphericalPolynomial || this._texture._sphericalPolynomialComputed) return this._texture._sphericalPolynomial;
				if (this._texture.isReady) return this._texture._sphericalPolynomialPromise || (this._texture._sphericalPolynomialPromise = i.ConvertCubeMapTextureToSphericalPolynomial(this), this._texture._sphericalPolynomialPromise === null ? this._texture._sphericalPolynomialComputed = !0 : this._texture._sphericalPolynomialPromise.then((e) => {
					this._texture._sphericalPolynomial = e, this._texture._sphericalPolynomialComputed = !0;
				})), null;
			}
			return null;
		},
		set: function(e) {
			this._texture && (this._texture._sphericalPolynomial = e);
		},
		enumerable: !0,
		configurable: !0
	}));
}
//#endregion
//#region node_modules/@babylonjs/core/Materials/Textures/Loaders/envTextureLoader.js
var s = class {
	constructor() {
		this.supportCascades = !1;
	}
	loadCubeData(e, i, a, s, c) {
		if (Array.isArray(e)) return;
		let l = r(e);
		if (l) {
			i.width = l.width, i.height = l.width;
			try {
				o(), n(i, l), t(i, e, l).then(() => {
					i.isReady = !0, i.onLoadedObservable.notifyObservers(i), i.onLoadedObservable.clear(), s && s();
				}, (e) => {
					c?.("Can not upload environment levels", e);
				});
			} catch (e) {
				c?.("Can not upload environment file", e);
			}
		} else c && c("Can not parse the environment file", null);
	}
	loadData() {
		throw ".env not supported in 2d.";
	}
};
//#endregion
export { s as _ENVTextureLoader };
