import { t as e } from "./math.scalar.functions-D7lyzZPV.js";
import { t } from "./logger-DQIzSR_y.js";
import { r as n } from "./tools.pure-Dy2G52NL.js";
import { n as r, r as i, t as a } from "./halfFloat-CieD0yV9.js";
//#region node_modules/@babylonjs/core/Materials/Textures/Loaders/EXR/exrLoader.interfaces.js
var o = 65536, s = 8192, c = 65537, l = 16384, u = 16383, d;
(function(e) {
	e[e.NO_COMPRESSION = 0] = "NO_COMPRESSION", e[e.RLE_COMPRESSION = 1] = "RLE_COMPRESSION", e[e.ZIPS_COMPRESSION = 2] = "ZIPS_COMPRESSION", e[e.ZIP_COMPRESSION = 3] = "ZIP_COMPRESSION", e[e.PIZ_COMPRESSION = 4] = "PIZ_COMPRESSION", e[e.PXR24_COMPRESSION = 5] = "PXR24_COMPRESSION";
})(d ||= {});
var f;
(function(e) {
	e[e.INCREASING_Y = 0] = "INCREASING_Y", e[e.DECREASING_Y = 1] = "DECREASING_Y";
})(f ||= {});
function p(e, t) {
	let n = new Uint8Array(e), r = 0;
	for (; n[t.value + r] != 0;) r += 1;
	let i = new TextDecoder().decode(n.slice(t.value, t.value + r));
	return t.value = t.value + r + 1, i;
}
function m(e, t) {
	let n = e.getInt32(t.value, !0);
	return t.value += 4, n;
}
function h(e, t) {
	let n = e.getUint32(t.value, !0);
	return t.value += 4, n;
}
function g(e, t) {
	let n = e.getUint8(t.value);
	return t.value += 1, n;
}
function _(e, t) {
	let n = e.getUint16(t.value, !0);
	return t.value += 2, n;
}
function v(e, t) {
	let n = e[t.value];
	return t.value += 1, n;
}
function y(e, t) {
	let n;
	return n = "getBigInt64" in DataView.prototype ? Number(e.getBigInt64(t.value, !0)) : e.getUint32(t.value + 4, !0) + Number(e.getUint32(t.value, !0) << 32), t.value += 8, n;
}
function b(e, t) {
	let n = e.getFloat32(t.value, !0);
	return t.value += 4, n;
}
function x(e, t) {
	return a(_(e, t));
}
function S(t, n) {
	return i(e(b(t, n), -r, r));
}
function C(e, t, n) {
	let r = new TextDecoder().decode(new Uint8Array(e).slice(t.value, t.value + n));
	return t.value += n, r;
}
function ee(e, t) {
	return [m(e, t), h(e, t)];
}
function te(e, t) {
	return [h(e, t), h(e, t)];
}
function ne(e, t) {
	return [b(e, t), b(e, t)];
}
function re(e, t) {
	return [
		b(e, t),
		b(e, t),
		b(e, t)
	];
}
function ie(e, t, n) {
	let r = t.value, i = [];
	for (; t.value < r + n - 1;) {
		let n = p(e.buffer, t), r = m(e, t), a = g(e, t);
		t.value += 3;
		let o = m(e, t), s = m(e, t);
		i.push({
			name: n,
			pixelType: r,
			pLinear: a,
			xSampling: o,
			ySampling: s
		});
	}
	return t.value += 1, i;
}
function ae(e, t) {
	return {
		redX: b(e, t),
		redY: b(e, t),
		greenX: b(e, t),
		greenY: b(e, t),
		blueX: b(e, t),
		blueY: b(e, t),
		whiteX: b(e, t),
		whiteY: b(e, t)
	};
}
function w(e, t) {
	return g(e, t);
}
function T(e, t) {
	return {
		xMin: m(e, t),
		yMin: m(e, t),
		xMax: m(e, t),
		yMax: m(e, t)
	};
}
function E(e, t) {
	let n = g(e, t);
	return f[n];
}
function D(e, t, n, r) {
	switch (n) {
		case "string":
		case "stringvector":
		case "iccProfile": return C(e.buffer, t, r);
		case "chlist": return ie(e, t, r);
		case "chromaticities": return ae(e, t);
		case "compression": return w(e, t);
		case "box2i": return T(e, t);
		case "lineOrder": return E(e, t);
		case "float": return b(e, t);
		case "v2f": return ne(e, t);
		case "v3f": return re(e, t);
		case "int": return m(e, t);
		case "rational": return ee(e, t);
		case "timecode": return te(e, t);
		case "preview": return t.value += r, "skipped";
		default:
			t.value += r;
			return;
	}
}
function O(e) {
	for (let t = 1; t < e.length; t++) {
		let n = e[t - 1] + e[t] - 128;
		e[t] = n;
	}
}
function k(e, t) {
	let n = 0, r = Math.floor((e.length + 1) / 2), i = 0, a = e.length - 1;
	for (; !(i > a || (t[i++] = e[n++], i > a));) t[i++] = e[r++];
}
//#endregion
//#region node_modules/@babylonjs/core/Materials/Textures/Loaders/EXR/exrLoader.header.js
var A = 20000630;
function oe(e, n) {
	if (e.getUint32(0, !0) != A) throw Error("Incorrect OpenEXR format");
	let r = e.getUint8(4), i = e.getUint8(5), a = {
		singleTile: !!(i & 2),
		longName: !!(i & 4),
		deepFormat: !!(i & 8),
		multiPart: !!(i & 16)
	};
	n.value = 8;
	let o = {}, s = !0;
	for (; s;) {
		let r = p(e.buffer, n);
		if (!r) s = !1;
		else {
			let i = p(e.buffer, n), a = D(e, n, i, h(e, n));
			a === void 0 ? t.Warn(`Unknown header attribute type ${i}'.`) : o[r] = a;
		}
	}
	if (i & -5) throw Error("Unsupported file format");
	return {
		version: r,
		spec: a,
		...o
	};
}
//#endregion
//#region node_modules/@babylonjs/core/Materials/Textures/Loaders/EXR/exrLoader.compression.huf.js
var se = 32768, j = 65535;
function M(e, t) {
	let n = 0;
	for (let r = 0; r < o; ++r) (r == 0 || e[r >> 3] & 1 << (r & 7)) && (t[n++] = r);
	let r = n - 1;
	for (; n < o;) t[n++] = 0;
	return r;
}
function N(e) {
	for (let t = 0; t < l; t++) e[t] = {}, e[t].len = 0, e[t].lit = 0, e[t].p = null;
}
function P(e, t, n, r, i) {
	for (; n < e;) t = t << 8 | v(r, i), n += 8;
	return n -= e, {
		l: t >> n & (1 << e) - 1,
		c: t,
		lc: n
	};
}
function F(e, t, n, r) {
	return e = e << 8 | v(n, r), t += 8, {
		c: e,
		lc: t
	};
}
function I(e, t, n, r, i, a, o, s, c) {
	if (e == t) {
		if (r < 8) {
			let e = F(n, r, i, a);
			n = e.c, r = e.lc;
		}
		r -= 8;
		let e = n >> r;
		if (e = new Uint8Array([e])[0], s.value + e > c) return null;
		let t = o[s.value - 1];
		for (; e-- > 0;) o[s.value++] = t;
	} else if (s.value < c) o[s.value++] = e;
	else return null;
	return {
		c: n,
		lc: r
	};
}
var L = Array(59);
function R(e) {
	for (let e = 0; e <= 58; ++e) L[e] = 0;
	for (let t = 0; t < c; ++t) L[e[t]] += 1;
	let t = 0;
	for (let e = 58; e > 0; --e) {
		let n = t + L[e] >> 1;
		L[e] = t, t = n;
	}
	for (let t = 0; t < c; ++t) {
		let n = e[t];
		n > 0 && (e[t] = n | L[n]++ << 6);
	}
}
function z(e, t, n, r, i, a) {
	let o = t, s = 0, c = 0;
	for (; r <= i; r++) {
		if (o.value - t.value > n) return;
		let l = P(6, s, c, e, o), u = l.l;
		if (s = l.c, c = l.lc, a[r] = u, u == 63) {
			if (o.value - t.value > n) throw Error("Error in HufUnpackEncTable");
			l = P(8, s, c, e, o);
			let u = l.l + 6;
			if (s = l.c, c = l.lc, r + u > i + 1) throw Error("Error in HufUnpackEncTable");
			for (; u--;) a[r++] = 0;
			r--;
		} else if (u >= 59) {
			let e = u - 59 + 2;
			if (r + e > i + 1) throw Error("Error in HufUnpackEncTable");
			for (; e--;) a[r++] = 0;
			r--;
		}
	}
	R(a);
}
function B(e) {
	return e & 63;
}
function V(e) {
	return e >> 6;
}
function H(e, t, n, r) {
	for (; t <= n; t++) {
		let n = V(e[t]), i = B(e[t]);
		if (n >> i) throw Error("Invalid table entry");
		if (i > 14) {
			let e = r[n >> i - 14];
			if (e.len) throw Error("Invalid table entry");
			if (e.lit++, e.p) {
				let t = e.p;
				e.p = Array(e.lit);
				for (let n = 0; n < e.lit - 1; ++n) e.p[n] = t[n];
			} else e.p = [,];
			e.p[e.lit - 1] = t;
		} else if (i) {
			let e = 0;
			for (let a = 1 << 14 - i; a > 0; a--) {
				let a = r[(n << 14 - i) + e];
				if (a.len || a.p) throw Error("Invalid table entry");
				a.len = i, a.lit = t, e++;
			}
		}
	}
	return !0;
}
function U(e, t, n, r, i, a, o, s, c) {
	let l = 0, d = 0, f = o, p = Math.trunc(r.value + (i + 7) / 8);
	for (; r.value < p;) {
		let i = F(l, d, n, r);
		for (l = i.c, d = i.lc; d >= 14;) {
			let o = t[l >> d - 14 & u];
			if (o.len) {
				d -= o.len;
				let e = I(o.lit, a, l, d, n, r, s, c, f);
				e && (l = e.c, d = e.lc);
			} else {
				if (!o.p) throw Error("hufDecode issues");
				let t = 0;
				for (; t < o.lit; t++) {
					let u = B(e[o.p[t]]);
					for (; d < u && r.value < p;) i = F(l, d, n, r), l = i.c, d = i.lc;
					if (d >= u && V(e[o.p[t]]) == (l >> d - u & (1 << u) - 1)) {
						d -= u;
						let e = I(o.p[t], a, l, d, n, r, s, c, f);
						e && (l = e.c, d = e.lc);
						break;
					}
				}
				if (t == o.lit) throw Error("HufDecode issues");
			}
		}
	}
	let m = 8 - i & 7;
	for (l >>= m, d -= m; d > 0;) {
		let e = t[l << 14 - d & u];
		if (e.len) {
			d -= e.len;
			let t = I(e.lit, a, l, d, n, r, s, c, f);
			t && (l = t.c, d = t.lc);
		} else throw Error("HufDecode issues");
	}
	return !0;
}
function W(e, t, n, r, i, a) {
	let o = { value: 0 }, s = n.value, u = h(t, n), d = h(t, n);
	n.value += 4;
	let f = h(t, n);
	if (n.value += 4, u < 0 || u >= 65537 || d < 0 || d >= 65537) throw Error("Wrong HUF_ENCSIZE");
	let p = Array(c), m = Array(l);
	if (N(m), z(e, n, r - (n.value - s), u, d, p), f > 8 * (r - (n.value - s))) throw Error("Wrong hufUncompress");
	H(p, u, d, m), U(p, m, e, n, f, d, a, i, o);
}
function G(e) {
	return e & 65535;
}
function K(e) {
	let t = G(e);
	return t > 32767 ? t - 65536 : t;
}
function q(e, t) {
	let n = K(e), r = K(t), i = n + (r & 1) + (r >> 1);
	return {
		a: i,
		b: i - r
	};
}
function J(e, t) {
	let n = G(e), r = G(t), i = n - (r >> 1) & j;
	return {
		a: r + i - se & j,
		b: i
	};
}
function ce(e, t, n, r, i, a, o) {
	let s = o < 16384, c = n > i ? i : n, l = 1, u, d;
	for (; l <= c;) l <<= 1;
	for (l >>= 1, u = l, l >>= 1; l >= 1;) {
		d = 0;
		let o = d + a * (i - u), c = a * l, f = a * u, p = r * l, m = r * u, h, g, _, v;
		for (; d <= o; d += f) {
			let i = d, a = d + r * (n - u);
			for (; i <= a; i += m) {
				let n = i + p, r = i + c, a = r + p;
				if (s) {
					let o = q(e[i + t], e[r + t]);
					h = o.a, _ = o.b, o = q(e[n + t], e[a + t]), g = o.a, v = o.b, o = q(h, g), e[i + t] = o.a, e[n + t] = o.b, o = q(_, v), e[r + t] = o.a, e[a + t] = o.b;
				} else {
					let o = J(e[i + t], e[r + t]);
					h = o.a, _ = o.b, o = J(e[n + t], e[a + t]), g = o.a, v = o.b, o = J(h, g), e[i + t] = o.a, e[n + t] = o.b, o = J(_, v), e[r + t] = o.a, e[a + t] = o.b;
				}
			}
			if (n & l) {
				let n = i + c, r;
				r = s ? q(e[i + t], e[n + t]) : J(e[i + t], e[n + t]), h = r.a, e[n + t] = r.b, e[i + t] = h;
			}
		}
		if (i & l) {
			let i = d, a = d + r * (n - u);
			for (; i <= a; i += m) {
				let n = i + p, r;
				r = s ? q(e[i + t], e[n + t]) : J(e[i + t], e[n + t]), h = r.a, e[n + t] = r.b, e[i + t] = h;
			}
		}
		u = l, l >>= 1;
	}
	return d;
}
function le(e, t, n) {
	for (let r = 0; r < n; ++r) t[r] = e[t[r]];
}
//#endregion
//#region node_modules/@babylonjs/core/Materials/Textures/Loaders/EXR/exrLoader.compression.rle.js
function ue(e) {
	let t = e.byteLength, n = [], r = 0, i = new DataView(e);
	for (; t > 0;) {
		let e = i.getInt8(r++);
		if (e < 0) {
			let a = -e;
			t -= a + 1;
			for (let e = 0; e < a; e++) n.push(i.getUint8(r++));
		} else {
			let a = e;
			t -= 2;
			let o = i.getUint8(r++);
			for (let e = 0; e < a + 1; e++) n.push(o);
		}
	}
	return n;
}
//#endregion
//#region node_modules/@babylonjs/core/Materials/Textures/Loaders/EXR/exrLoader.compression.js
function Y(e) {
	return new DataView(e.array.buffer, e.offset.value, e.size);
}
function de(e) {
	let t = e.viewer.buffer.slice(e.offset.value, e.offset.value + e.size), n = new Uint8Array(ue(t)), r = new Uint8Array(n.length);
	return O(n), k(n, r), new DataView(r.buffer);
}
function X(e) {
	let t = e.array.slice(e.offset.value, e.offset.value + e.size), n = fflate.unzlibSync(t), r = new Uint8Array(n.length);
	return O(n), k(n, r), new DataView(r.buffer);
}
function fe(e) {
	let t = e.array.slice(e.offset.value, e.offset.value + e.size), n = fflate.unzlibSync(t), r = e.lines * e.channels * e.width, i = e.type == 1 ? new Uint16Array(r) : new Uint32Array(r), a = 0, o = 0, s = [
		,
		,
		,
		,
	];
	for (let t = 0; t < e.lines; t++) for (let t = 0; t < e.channels; t++) {
		let t = 0;
		switch (e.type) {
			case 1:
				s[0] = a, s[1] = s[0] + e.width, a = s[1] + e.width;
				for (let r = 0; r < e.width; ++r) {
					let e = n[s[0]++] << 8 | n[s[1]++];
					t += e, i[o] = t, o++;
				}
				break;
			case 2:
				s[0] = a, s[1] = s[0] + e.width, s[2] = s[1] + e.width, a = s[2] + e.width;
				for (let r = 0; r < e.width; ++r) {
					let e = n[s[0]++] << 24 | n[s[1]++] << 16 | n[s[2]++] << 8;
					t += e, i[o] = t, o++;
				}
		}
	}
	return new DataView(i.buffer);
}
function Z(e) {
	let t = e.viewer, n = { value: e.offset.value }, r = new Uint16Array(e.width * e.scanlineBlockSize * (e.channels * e.type)), i = new Uint8Array(s), a = 0, c = Array(e.channels);
	for (let t = 0; t < e.channels; t++) c[t] = {}, c[t].start = a, c[t].end = c[t].start, c[t].nx = e.width, c[t].ny = e.lines, c[t].size = e.type, a += c[t].nx * c[t].ny * c[t].size;
	let l = _(t, n), u = _(t, n);
	if (u >= 8192) throw Error("Wrong PIZ_COMPRESSION BITMAP_SIZE");
	if (l <= u) for (let e = 0; e < u - l + 1; e++) i[e + l] = g(t, n);
	let d = new Uint16Array(o), f = M(i, d), p = h(t, n);
	W(e.array, t, n, p, r, a);
	for (let t = 0; t < e.channels; ++t) {
		let e = c[t];
		for (let n = 0; n < c[t].size; ++n) ce(r, e.start + n, e.nx, e.size, e.ny, e.nx * e.size, f);
	}
	le(d, r, a);
	let m = 0, v = new Uint8Array(r.buffer.byteLength);
	for (let t = 0; t < e.lines; t++) for (let t = 0; t < e.channels; t++) {
		let e = c[t], n = e.nx * e.size, i = new Uint8Array(r.buffer, e.end * 2, n * 2);
		v.set(i, m), m += n * 2, e.end += n;
	}
	return new DataView(v.buffer);
}
//#endregion
//#region node_modules/@babylonjs/core/Materials/Textures/Loaders/EXR/exrLoader.configuration.js
var Q;
(function(e) {
	e[e.Float = 0] = "Float", e[e.HalfFloat = 1] = "HalfFloat";
})(Q ||= {});
var $ = class {};
$.DefaultOutputType = Q.HalfFloat, $.FFLATEUrl = "https://unpkg.com/fflate@0.8.2";
//#endregion
//#region node_modules/@babylonjs/core/Materials/Textures/Loaders/EXR/exrLoader.decoder.js
async function pe(e, t, r, i) {
	let a = {
		size: 0,
		viewer: t,
		array: new Uint8Array(t.buffer),
		offset: r,
		width: e.dataWindow.xMax - e.dataWindow.xMin + 1,
		height: e.dataWindow.yMax - e.dataWindow.yMin + 1,
		channels: e.channels.length,
		channelLineOffsets: {},
		scanOrder: () => 0,
		bytesPerLine: 0,
		outLineWidth: 0,
		lines: 0,
		scanlineBlockSize: 0,
		inputSize: null,
		type: 0,
		uncompress: null,
		getter: () => 0,
		format: 5,
		outputChannels: 0,
		decodeChannels: {},
		blockCount: null,
		byteArray: null,
		linearSpace: !1,
		textureType: 0
	};
	switch (e.compression) {
		case d.NO_COMPRESSION:
			a.lines = 1, a.uncompress = Y;
			break;
		case d.RLE_COMPRESSION:
			a.lines = 1, a.uncompress = de;
			break;
		case d.ZIPS_COMPRESSION:
			a.lines = 1, a.uncompress = X, await n.LoadScriptAsync($.FFLATEUrl);
			break;
		case d.ZIP_COMPRESSION:
			a.lines = 16, a.uncompress = X, await n.LoadScriptAsync($.FFLATEUrl);
			break;
		case d.PIZ_COMPRESSION:
			a.lines = 32, a.uncompress = Z;
			break;
		case d.PXR24_COMPRESSION:
			a.lines = 16, a.uncompress = fe, await n.LoadScriptAsync($.FFLATEUrl);
			break;
		default: throw Error(d[e.compression] + " is unsupported");
	}
	a.scanlineBlockSize = a.lines;
	let o = {};
	for (let t of e.channels) switch (t.name) {
		case "R":
		case "G":
		case "B":
		case "A":
			o[t.name] = !0, a.type = t.pixelType;
			break;
		case "Y": o[t.name] = !0, a.type = t.pixelType;
	}
	let s = !1;
	if (o.R && o.G && o.B && o.A) a.outputChannels = 4, a.decodeChannels = {
		R: 0,
		G: 1,
		B: 2,
		A: 3
	};
	else if (o.R && o.G && o.B) s = !0, a.outputChannels = 4, a.decodeChannels = {
		R: 0,
		G: 1,
		B: 2,
		A: 3
	};
	else if (o.R && o.G) a.outputChannels = 2, a.decodeChannels = {
		R: 0,
		G: 1
	};
	else if (o.R) a.outputChannels = 1, a.decodeChannels = { R: 0 };
	else if (o.Y) a.outputChannels = 1, a.decodeChannels = { Y: 0 };
	else throw Error("EXRLoader.parse: file contains unsupported data channels.");
	if (a.type === 1) switch (i) {
		case Q.Float:
			a.getter = x, a.inputSize = 2;
			break;
		case Q.HalfFloat: a.getter = _, a.inputSize = 2;
	}
	else if (a.type === 2) switch (i) {
		case Q.Float:
			a.getter = b, a.inputSize = 4;
			break;
		case Q.HalfFloat: a.getter = S, a.inputSize = 4;
	}
	else throw Error("Unsupported pixelType " + a.type + " for " + e.compression);
	a.blockCount = a.height / a.scanlineBlockSize;
	for (let e = 0; e < a.blockCount; e++) y(t, r);
	let c = a.width * a.height * a.outputChannels;
	switch (i) {
		case Q.Float:
			a.byteArray = new Float32Array(c), a.textureType = 1, s && a.byteArray.fill(1, 0, c);
			break;
		case Q.HalfFloat:
			a.byteArray = new Uint16Array(c), a.textureType = 2, s && a.byteArray.fill(15360, 0, c);
			break;
		default: throw Error("Unsupported type: " + i);
	}
	let l = 0;
	for (let t of e.channels) a.decodeChannels[t.name] !== void 0 && (a.channelLineOffsets[t.name] = l * a.width), l += t.pixelType * 2;
	return a.bytesPerLine = a.width * l, a.outLineWidth = a.width * a.outputChannels, a.scanOrder = e.lineOrder === "INCREASING_Y" ? (e) => e : (e) => a.height - 1 - e, a.outputChannels == 4 ? (a.format = 5, a.linearSpace = !0) : (a.format = 6, a.linearSpace = !1), a;
}
function me(e, t, n, r) {
	let i = { value: 0 };
	for (let a = 0; a < e.height / e.scanlineBlockSize; a++) {
		let o = m(n, r) - t.dataWindow.yMin;
		e.size = h(n, r), e.lines = o + e.scanlineBlockSize > e.height ? e.height - o : e.scanlineBlockSize;
		let s = e.size < e.lines * e.bytesPerLine && e.uncompress ? e.uncompress(e) : Y(e);
		r.value += e.size;
		for (let n = 0; n < e.scanlineBlockSize; n++) {
			let r = a * e.scanlineBlockSize, o = n + e.scanOrder(r);
			if (o >= e.height) continue;
			let c = n * e.bytesPerLine, l = (e.height - 1 - o) * e.outLineWidth;
			for (let n = 0; n < e.channels; n++) {
				let r = t.channels[n].name, a = e.channelLineOffsets[r], o = e.decodeChannels[r];
				if (o !== void 0) {
					i.value = c + a;
					for (let t = 0; t < e.width; t++) {
						let n = l + t * e.outputChannels + o;
						e.byteArray && (e.byteArray[n] = e.getter(s, i));
					}
				}
			}
		}
	}
}
//#endregion
//#region node_modules/@babylonjs/core/Materials/Textures/Loaders/exrTextureLoader.js
var he = class {
	constructor() {
		this.supportCascades = !1;
	}
	loadCubeData(e, t, n, r, i) {
		throw ".exr not supported in Cube.";
	}
	loadData(e, n, r) {
		let i = new DataView(e.buffer), a = { value: 0 }, o = oe(i, a);
		pe(o, i, a, $.DefaultOutputType).then((e) => {
			me(e, o, i, a), r(o.dataWindow.xMax - o.dataWindow.xMin + 1, o.dataWindow.yMax - o.dataWindow.yMin + 1, n.generateMipMaps, !1, () => {
				let t = n.getEngine();
				n.format = o.format, n.type = e.textureType, n.invertY = !1, n._gammaSpace = !o.linearSpace, e.byteArray && t._uploadDataToTextureDirectly(n, e.byteArray, 0, 0, void 0, !0);
			});
		}).catch((e) => {
			t.Error("Failed to load EXR texture: ", e);
		});
	}
};
//#endregion
export { he as _ExrTextureLoader };
