import { u as e } from "./math.color.pure-CPmbqLkh.js";
import { n as t } from "./typeStore-pENEWnX2.js";
import { f as n, n as r } from "./flowGraphRichTypes.pure-BpKU4EZT.js";
import { t as i } from "./flowGraphCachedOperationBlock-BsIcMusH.js";
//#region node_modules/@babylonjs/core/FlowGraph/Blocks/Data/Physics/flowGraphGetLinearVelocityBlock.pure.js
var a = class extends i {
	constructor(e) {
		super(n, e), this.body = this.registerDataInput("body", r);
	}
	_doOperation(t) {
		let n = this.body.getValue(t);
		if (!n) return;
		let r = t._getExecutionVariable(this, "_cachedVelocity", null);
		return r || (r = new e(), t._setExecutionVariable(this, "_cachedVelocity", r)), n.getLinearVelocityToRef(r), r;
	}
	getClassName() {
		return "FlowGraphGetLinearVelocityBlock";
	}
}, o = !1;
function s() {
	o || (o = !0, t("FlowGraphGetLinearVelocityBlock", a));
}
//#endregion
export { a as FlowGraphGetLinearVelocityBlock, s as RegisterFlowGraphGetLinearVelocityBlock };
