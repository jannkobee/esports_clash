import { a as e, u as t } from "./math.color.pure-CPmbqLkh.js";
import { t as n } from "./flowGraphExecutionBlock-CX4ysaWA.js";
import { c as r, f as i, n as a, u as o } from "./flowGraphRichTypes.pure-BpKU4EZT.js";
import { GetInteractivityObjectReference as s } from "./flowGraphObjectReferenceBlock-AGIGm7JM.js";
//#region node_modules/@babylonjs/loaders/glTF/2.0/Extensions/KHR_interactivity/flowGraphEventReferenceBlock.js
var c = class extends n {
	constructor(n) {
		super(n), this.config = n, this._assetInverse = e.Identity(), this._selectionPointValue = t.Zero(), this._selectionRayOriginValue = t.Zero();
		let s = new t(NaN, NaN, NaN);
		this.node = this.registerDataInput("node", a), this.controllerIndexInput = this.registerDataInput("controllerIndexInput", r, -1), this.selectionPointInput = this.registerDataInput("selectionPointInput", i, s), this.selectionRayOriginInput = this.registerDataInput("selectionRayOriginInput", i, s), this.nodeReference = this.registerDataOutput("nodeReference", o, ""), this.controllerIndex = this.registerDataOutput("controllerIndex", r, -1), this.selectionPoint = this.registerDataOutput("selectionPoint", i, s), this.selectionRayOrigin = this.registerDataOutput("selectionRayOrigin", i, s), this.value = this.registerDataOutput("value", o, ""), this.out = this._registerSignalOutput("out");
	}
	_execute(e) {
		this.nodeReference.setValue(s(e, this.node.getValue(e)), e);
		let n = this.controllerIndexInput.getValue(e);
		if (n < 0) this.controllerIndex.setValue(-1, e);
		else {
			let t = e._getGlobalContextVariable("khrInteractivityControllerIndices", /* @__PURE__ */ new Map()), r = t.get(n);
			r === void 0 && (r = t.size, t.set(n, r), e._setGlobalContextVariable("khrInteractivityControllerIndices", t)), this.controllerIndex.setValue(r, e);
		}
		let r = this.node.getValue(e)?.parent;
		for (; r?.parent;) r = r.parent;
		r?.getWorldMatrix ? (r.getWorldMatrix().invertToRef(this._assetInverse), t.TransformCoordinatesToRef(this.selectionPointInput.getValue(e), this._assetInverse, this._selectionPointValue), t.TransformCoordinatesToRef(this.selectionRayOriginInput.getValue(e), this._assetInverse, this._selectionRayOriginValue), this.selectionPoint.setValue(this._selectionPointValue, e), this.selectionRayOrigin.setValue(this._selectionRayOriginValue, e)) : (this.selectionPoint.setValue(this.selectionPointInput.getValue(e), e), this.selectionRayOrigin.setValue(this.selectionRayOriginInput.getValue(e), e)), this.value.setValue(e.getEventReference(this.config.eventKey ?? "gltf:manual"), e), this.out._activateSignal(e);
	}
	getClassName() {
		return "FlowGraphEventReferenceBlock";
	}
};
//#endregion
export { c as FlowGraphEventReferenceBlock };
