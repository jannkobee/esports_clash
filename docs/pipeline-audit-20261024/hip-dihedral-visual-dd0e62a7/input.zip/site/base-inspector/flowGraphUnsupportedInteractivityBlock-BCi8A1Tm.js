import { a as e, d as t, l as n, u as r } from "./math.color.pure-CPmbqLkh.js";
import { t as i } from "./flowGraphInteger.pure-DqL1vt3x.js";
import { c as a, s as o } from "./flowGraphBlock-BTSj91tT.js";
import { t as s } from "./flowGraphExecutionBlock-CX4ysaWA.js";
import { g as c } from "./flowGraphRichTypes.pure-BpKU4EZT.js";
//#region node_modules/@babylonjs/loaders/glTF/2.0/Extensions/KHR_interactivity/flowGraphUnsupportedInteractivityBlock.js
function l(s) {
	switch (s) {
		case "bool": return !1;
		case "int": return new i(0);
		case "float": return NaN;
		case "float2": return new n(NaN, NaN);
		case "float3": return new r(NaN, NaN, NaN);
		case "float4": return new t(NaN, NaN, NaN, NaN);
		case "float2x2": return new o([
			NaN,
			NaN,
			NaN,
			NaN
		]);
		case "float3x3": return new a([
			NaN,
			NaN,
			NaN,
			NaN,
			NaN,
			NaN,
			NaN,
			NaN,
			NaN
		]);
		case "float4x4": return e.FromArray([
			NaN,
			NaN,
			NaN,
			NaN,
			NaN,
			NaN,
			NaN,
			NaN,
			NaN,
			NaN,
			NaN,
			NaN,
			NaN,
			NaN,
			NaN,
			NaN
		]);
		case "ref": return "";
		default: return;
	}
}
var u = class extends s {
	constructor(e) {
		super(e), this.config = e, this._unregisterSignalInput("in"), this._unregisterSignalOutput("error");
		for (let t of e.inputValueSockets ?? []) this.registerDataInput(t.name, c(t.type));
		for (let t of e.outputValueSockets ?? []) this.registerDataOutput(t.name, c(t.type), l(t.signature));
		for (let t of e.inputFlowSockets ?? []) this._registerSignalInput(t);
		for (let t of e.outputFlowSockets ?? []) this._registerSignalOutput(t);
	}
	_execute(e, t) {}
	getClassName() {
		return "FlowGraphUnsupportedInteractivityBlock";
	}
};
//#endregion
export { u as FlowGraphUnsupportedInteractivityBlock };
