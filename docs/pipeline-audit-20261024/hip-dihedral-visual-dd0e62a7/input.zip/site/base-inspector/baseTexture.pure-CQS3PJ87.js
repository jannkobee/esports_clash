import { n as e, t } from "./engineStore-D0BoPdea.js";
import { b as n, x as r } from "./tools.functions-DEecYKlu.js";
import { a as i } from "./math.color.pure-CPmbqLkh.js";
import { t as a } from "./math.size-Cv1hlevD.js";
import { b as o, f as s, i as c, y as l } from "./decorators-BldPRAAT.js";
import { t as u } from "./guid-DXeovnrE.js";
import { t as d } from "./decorators.serialization-CGAHzP43.js";
//#region node_modules/@babylonjs/core/Materials/Textures/thinTexture.js
var f = class e {
	get wrapU() {
		return this._wrapU;
	}
	set wrapU(e) {
		this._wrapU = e;
	}
	get wrapV() {
		return this._wrapV;
	}
	set wrapV(e) {
		this._wrapV = e;
	}
	get coordinatesMode() {
		return 0;
	}
	get isCube() {
		return this._texture ? this._texture.isCube : !1;
	}
	set isCube(e) {
		this._texture && (this._texture.isCube = e);
	}
	get is3D() {
		return this._texture ? this._texture.is3D : !1;
	}
	set is3D(e) {
		this._texture && (this._texture.is3D = e);
	}
	get is2DArray() {
		return this._texture ? this._texture.is2DArray : !1;
	}
	set is2DArray(e) {
		this._texture && (this._texture.is2DArray = e);
	}
	getClassName() {
		return "ThinTexture";
	}
	static _IsRenderTargetWrapper(e) {
		return e?.shareDepth !== void 0;
	}
	constructor(t) {
		this._wrapU = 1, this._wrapV = 1, this.wrapR = 1, this.anisotropicFilteringLevel = 4, this.delayLoadState = 0, this._texture = null, this._engine = null, this._cachedSize = a.Zero(), this._cachedBaseSize = a.Zero(), this._initialSamplingMode = 2, this._texture = e._IsRenderTargetWrapper(t) ? t.texture : t, this._texture && (this._engine = this._texture.getEngine(), this.wrapU = this._texture._cachedWrapU ?? this.wrapU, this.wrapV = this._texture._cachedWrapV ?? this.wrapV, this.wrapR = this._texture._cachedWrapR ?? this.wrapR);
	}
	isReady() {
		return this.delayLoadState === 4 ? (this.delayLoad(), !1) : this._texture ? this._texture.isReady : !1;
	}
	delayLoad() {}
	getInternalTexture() {
		return this._texture;
	}
	getSize() {
		if (this._texture) {
			if (this._texture.width) return this._cachedSize.width = this._texture.width, this._cachedSize.height = this._texture.height, this._cachedSize;
			if (this._texture._size) return this._cachedSize.width = this._texture._size, this._cachedSize.height = this._texture._size, this._cachedSize;
		}
		return this._cachedSize;
	}
	getBaseSize() {
		return !this.isReady() || !this._texture ? (this._cachedBaseSize.width = 0, this._cachedBaseSize.height = 0, this._cachedBaseSize) : this._texture._size ? (this._cachedBaseSize.width = this._texture._size, this._cachedBaseSize.height = this._texture._size, this._cachedBaseSize) : (this._cachedBaseSize.width = this._texture.baseWidth, this._cachedBaseSize.height = this._texture.baseHeight, this._cachedBaseSize);
	}
	get samplingMode() {
		return this._texture ? this._texture.samplingMode : this._initialSamplingMode;
	}
	updateSamplingMode(e, t = !1) {
		this._texture && this._engine && this._engine.updateTextureSamplingMode(e, this._texture, this._texture.generateMipMaps && t);
	}
	releaseInternalTexture() {
		this._texture &&= (this._texture.dispose(), null);
	}
	dispose() {
		this._texture && (this.releaseInternalTexture(), this._engine = null);
	}
}, p, m = (() => {
	var n;
	let r = f, a = [], p, m = [], ee = [], h, g = [], _ = [], v, y = [], b = [], x, S = [], C = [], w, T = [], E = [], D, O = [], k = [], A, j = [], M = [], N, P = [], F = [], I, L = [], R = [], te, z = [], B = [], V, H, U, W = [], G = [], K, q = [], J = [], Y, X, Z, Q, ne, re = [], ie = [], ae, oe = [], $ = [], se, ce, le, ue, de, fe = [], pe = [];
	return n = class extends r {
		set hasAlpha(e) {
			this._hasAlpha !== e && (this._hasAlpha = e, this._scene && this._scene.markAllMaterialsAsDirty(1, (e) => e.hasTexture(this)));
		}
		get hasAlpha() {
			return this._hasAlpha;
		}
		set getAlphaFromRGB(e) {
			this._getAlphaFromRGB !== e && (this._getAlphaFromRGB = e, this._scene && this._scene.markAllMaterialsAsDirty(1, (e) => e.hasTexture(this)));
		}
		get getAlphaFromRGB() {
			return this._getAlphaFromRGB;
		}
		set coordinatesIndex(e) {
			this._coordinatesIndex !== e && (this._coordinatesIndex = e, this._scene && this._scene.markAllMaterialsAsDirty(1, (e) => e.hasTexture(this)));
		}
		get coordinatesIndex() {
			return this._coordinatesIndex;
		}
		set coordinatesMode(e) {
			this._coordinatesMode !== e && (this._coordinatesMode = e, this._scene && this._scene.markAllMaterialsAsDirty(1, (e) => e.hasTexture(this)));
		}
		get coordinatesMode() {
			return this._coordinatesMode;
		}
		get wrapU() {
			return this._wrapU;
		}
		set wrapU(e) {
			this._wrapU = e;
		}
		get wrapV() {
			return this._wrapV;
		}
		set wrapV(e) {
			this._wrapV = e;
		}
		get isCube() {
			return this._texture ? this._texture.isCube : this._isCube;
		}
		set isCube(e) {
			this._texture ? this._texture.isCube = e : this._isCube = e;
		}
		get is3D() {
			return this._texture ? this._texture.is3D : !1;
		}
		set is3D(e) {
			this._texture && (this._texture.is3D = e);
		}
		get is2DArray() {
			return this._texture ? this._texture.is2DArray : !1;
		}
		set is2DArray(e) {
			this._texture && (this._texture.is2DArray = e);
		}
		get gammaSpace() {
			if (this._texture) this._texture._gammaSpace === null && (this._texture._gammaSpace = this._gammaSpace);
			else return this._gammaSpace;
			return this._texture._gammaSpace && !this._texture._useSRGBBuffer;
		}
		set gammaSpace(e) {
			if (this._texture) {
				if (this._texture._gammaSpace === e) return;
				this._texture._gammaSpace = e;
			} else {
				if (this._gammaSpace === e) return;
				this._gammaSpace = e;
			}
			this.getScene()?.markAllMaterialsAsDirty(1, (e) => e.hasTexture(this));
		}
		get isRGBD() {
			return this._texture != null && this._texture._isRGBD;
		}
		set isRGBD(e) {
			e !== this.isRGBD && (this._texture && (this._texture._isRGBD = e), this.getScene()?.markAllMaterialsAsDirty(1, (e) => e.hasTexture(this)));
		}
		get noMipmap() {
			return !1;
		}
		get lodGenerationOffset() {
			return this._texture ? this._texture._lodGenerationOffset : 0;
		}
		set lodGenerationOffset(e) {
			this._texture && (this._texture._lodGenerationOffset = e);
		}
		get lodGenerationScale() {
			return this._texture ? this._texture._lodGenerationScale : 0;
		}
		set lodGenerationScale(e) {
			this._texture && (this._texture._lodGenerationScale = e);
		}
		get linearSpecularLOD() {
			return this._texture ? this._texture._linearSpecularLOD : !1;
		}
		set linearSpecularLOD(e) {
			this._texture && (this._texture._linearSpecularLOD = e);
		}
		get irradianceTexture() {
			return this._texture ? this._texture._irradianceTexture : null;
		}
		set irradianceTexture(e) {
			this._texture && (this._texture._irradianceTexture = e);
		}
		get uid() {
			return this._uid ||= u(), this._uid;
		}
		toString() {
			return this.name;
		}
		getClassName() {
			return "BaseTexture";
		}
		set onDispose(e) {
			this._onDisposeObserver && this.onDisposeObservable.remove(this._onDisposeObserver), this._onDisposeObserver = this.onDisposeObservable.add(e);
		}
		get isBlocking() {
			return !0;
		}
		get loadingError() {
			return this._loadingError;
		}
		get errorObject() {
			return this._errorObject;
		}
		constructor(r, i = null) {
			super(null), this.uniqueId = (o(this, a), o(this, m, void 0)), this.name = (o(this, ee), o(this, g, void 0)), this.displayName = (o(this, _), o(this, y, void 0)), this.metadata = (o(this, b), o(this, S, null)), this._internalMetadata = o(this, C), this.reservedDataStore = null, this._hasAlpha = o(this, T, !1), this._getAlphaFromRGB = (o(this, E), o(this, O, !1)), this.level = (o(this, k), o(this, j, 1)), this._coordinatesIndex = (o(this, M), o(this, P, 0)), this.optimizeUVAllocation = (o(this, F), o(this, L, !0)), this._coordinatesMode = (o(this, R), o(this, z, 0)), this.wrapR = (o(this, B), o(this, W, 1)), this.anisotropicFilteringLevel = (o(this, G), o(this, q, n.DEFAULT_ANISOTROPIC_FILTERING_LEVEL)), this._isCube = (o(this, J), !1), this._gammaSpace = !0, this.invertZ = o(this, re, !1), this.lodLevelInAlpha = (o(this, ie), o(this, oe, !1)), this._dominantDirection = (o(this, $), null), this.isRenderTarget = o(this, fe, !1), this._prefiltered = (o(this, pe), !1), this._forceSerialize = !1, this.animations = [], this.onDisposeObservable = new e(), this._onDisposeObserver = null, this._scene = null, this._uid = null, this._parentContainer = null, this._loadingError = !1, r ? n._IsScene(r) ? this._scene = r : this._engine = r : this._scene = t.LastCreatedScene, this._scene && (this.uniqueId = this._scene.getUniqueId(), this._scene.addTexture(this), this._engine = this._scene.getEngine()), this._texture = i, this._uid = null;
		}
		getScene() {
			return this._scene;
		}
		_getEngine() {
			return this._engine;
		}
		getTextureMatrix() {
			return i.IdentityReadOnly;
		}
		getReflectionTextureMatrix() {
			return i.IdentityReadOnly;
		}
		getRefractionTextureMatrix() {
			return this.getReflectionTextureMatrix();
		}
		isReadyOrNotBlocking() {
			return !this.isBlocking || this.isReady() || this.loadingError;
		}
		scale(e) {}
		get canRescale() {
			return !1;
		}
		_getFromCache(e, t, n, r, i, a) {
			let o = this._getEngine();
			if (!o) return null;
			let s = o._getUseSRGBBuffer(!!i, t), c = o.getLoadedTexturesCache();
			for (let o = 0; o < c.length; o++) {
				let l = c[o];
				if ((!l._loadError || l.isReady) && (i === void 0 || s === l._useSRGBBuffer) && (r === void 0 || r === l.invertY) && l.url === e && l.generateMipMaps === !t && (!n || n === l.samplingMode) && (a === void 0 || a === l.isCube)) return l.incrementReferences(), l;
			}
			return null;
		}
		_rebuild(e = !1) {}
		clone() {
			return null;
		}
		get textureType() {
			return this._texture ? this._texture.type === void 0 ? 0 : this._texture.type : 0;
		}
		get textureFormat() {
			return this._texture ? this._texture.format === void 0 ? 5 : this._texture.format : 5;
		}
		_markAllSubMeshesAsTexturesDirty() {
			let e = this.getScene();
			e && e.markAllMaterialsAsDirty(1);
		}
		readPixels(e = 0, t = 0, n = null, r = !0, i = !1, a = 0, o = 0, s = Number.MAX_VALUE, c = Number.MAX_VALUE) {
			if (!this._texture) return null;
			let l = this._getEngine();
			if (!l) return null;
			let u = this.getSize(), d = u.width, f = u.height;
			t !== 0 && (d /= 2 ** t, f /= 2 ** t, d = Math.round(d), f = Math.round(f)), s = Math.min(d, s), c = Math.min(f, c);
			try {
				return this._texture.isCube || this._texture.is2DArray ? l._readTexturePixels(this._texture, s, c, e, t, n, r, i, a, o) : l._readTexturePixels(this._texture, s, c, -1, t, n, r, i, a, o);
			} catch {
				return null;
			}
		}
		_readPixelsSync(e = 0, t = 0, n = null, r = !0, i = !1) {
			if (!this._texture) return null;
			let a = this.getSize(), o = a.width, s = a.height, c = this._getEngine();
			if (!c) return null;
			t != 0 && (o /= 2 ** t, s /= 2 ** t, o = Math.round(o), s = Math.round(s));
			try {
				return this._texture.isCube ? c._readTexturePixelsSync(this._texture, o, s, e, t, n, r, i) : c._readTexturePixelsSync(this._texture, o, s, -1, t, n, r, i);
			} catch {
				return null;
			}
		}
		get _lodTextureHigh() {
			return this._texture ? this._texture._lodTextureHigh : null;
		}
		get _lodTextureMid() {
			return this._texture ? this._texture._lodTextureMid : null;
		}
		get _lodTextureLow() {
			return this._texture ? this._texture._lodTextureLow : null;
		}
		dispose() {
			if (this._scene) {
				this._scene.stopAnimation && this._scene.stopAnimation(this), this._scene.removePendingData(this);
				let e = this._scene.textures.indexOf(this);
				if (e >= 0 && this._scene.textures.splice(e, 1), this._scene.onTextureRemovedObservable.notifyObservers(this), this._scene = null, this._parentContainer) {
					let e = this._parentContainer.textures.indexOf(this);
					e > -1 && this._parentContainer.textures.splice(e, 1), this._parentContainer = null;
				}
			}
			this.onDisposeObservable.notifyObservers(this), this.onDisposeObservable.clear(), this.metadata = null, super.dispose();
		}
		serialize(e = !1) {
			if (!this.name && !e) return null;
			let t = d.Serialize(this);
			return d.AppendSerializedAnimations(this, t), t;
		}
		static WhenAllReady(e, t) {
			let n = e.length;
			if (n === 0) t();
			else for (let r = 0; r < e.length; r++) {
				let i = e[r];
				if (i.isReady()) --n === 0 && t();
				else {
					let e = i.onLoadObservable;
					e ? e.addOnce(() => {
						--n === 0 && t();
					}) : --n === 0 && t();
				}
			}
		}
		static _IsScene(e) {
			return e.getClassName() === "Scene";
		}
	}, (() => {
		let e = typeof Symbol == "function" && Symbol.metadata ? Object.create(r[Symbol.metadata] ?? null) : void 0;
		p = [c()], h = [c()], v = [c()], x = [c()], w = [c("hasAlpha")], D = [c("getAlphaFromRGB")], A = [c()], N = [c("coordinatesIndex")], I = [c()], te = [c("coordinatesMode")], V = [c()], H = [c()], U = [c()], K = [c()], Y = [c()], X = [c()], Z = [c()], Q = [c()], ne = [c()], ae = [c()], se = [c()], ce = [c()], le = [c()], ue = [s()], de = [c()], l(n, null, V, {
			kind: "getter",
			name: "wrapU",
			static: !1,
			private: !1,
			access: {
				has: (e) => "wrapU" in e,
				get: (e) => e.wrapU
			},
			metadata: e
		}, null, a), l(n, null, H, {
			kind: "getter",
			name: "wrapV",
			static: !1,
			private: !1,
			access: {
				has: (e) => "wrapV" in e,
				get: (e) => e.wrapV
			},
			metadata: e
		}, null, a), l(n, null, Y, {
			kind: "getter",
			name: "isCube",
			static: !1,
			private: !1,
			access: {
				has: (e) => "isCube" in e,
				get: (e) => e.isCube
			},
			metadata: e
		}, null, a), l(n, null, X, {
			kind: "getter",
			name: "is3D",
			static: !1,
			private: !1,
			access: {
				has: (e) => "is3D" in e,
				get: (e) => e.is3D
			},
			metadata: e
		}, null, a), l(n, null, Z, {
			kind: "getter",
			name: "is2DArray",
			static: !1,
			private: !1,
			access: {
				has: (e) => "is2DArray" in e,
				get: (e) => e.is2DArray
			},
			metadata: e
		}, null, a), l(n, null, Q, {
			kind: "getter",
			name: "gammaSpace",
			static: !1,
			private: !1,
			access: {
				has: (e) => "gammaSpace" in e,
				get: (e) => e.gammaSpace
			},
			metadata: e
		}, null, a), l(n, null, se, {
			kind: "getter",
			name: "lodGenerationOffset",
			static: !1,
			private: !1,
			access: {
				has: (e) => "lodGenerationOffset" in e,
				get: (e) => e.lodGenerationOffset
			},
			metadata: e
		}, null, a), l(n, null, ce, {
			kind: "getter",
			name: "lodGenerationScale",
			static: !1,
			private: !1,
			access: {
				has: (e) => "lodGenerationScale" in e,
				get: (e) => e.lodGenerationScale
			},
			metadata: e
		}, null, a), l(n, null, le, {
			kind: "getter",
			name: "linearSpecularLOD",
			static: !1,
			private: !1,
			access: {
				has: (e) => "linearSpecularLOD" in e,
				get: (e) => e.linearSpecularLOD
			},
			metadata: e
		}, null, a), l(n, null, ue, {
			kind: "getter",
			name: "irradianceTexture",
			static: !1,
			private: !1,
			access: {
				has: (e) => "irradianceTexture" in e,
				get: (e) => e.irradianceTexture
			},
			metadata: e
		}, null, a), l(null, null, p, {
			kind: "field",
			name: "uniqueId",
			static: !1,
			private: !1,
			access: {
				has: (e) => "uniqueId" in e,
				get: (e) => e.uniqueId,
				set: (e, t) => {
					e.uniqueId = t;
				}
			},
			metadata: e
		}, m, ee), l(null, null, h, {
			kind: "field",
			name: "name",
			static: !1,
			private: !1,
			access: {
				has: (e) => "name" in e,
				get: (e) => e.name,
				set: (e, t) => {
					e.name = t;
				}
			},
			metadata: e
		}, g, _), l(null, null, v, {
			kind: "field",
			name: "displayName",
			static: !1,
			private: !1,
			access: {
				has: (e) => "displayName" in e,
				get: (e) => e.displayName,
				set: (e, t) => {
					e.displayName = t;
				}
			},
			metadata: e
		}, y, b), l(null, null, x, {
			kind: "field",
			name: "metadata",
			static: !1,
			private: !1,
			access: {
				has: (e) => "metadata" in e,
				get: (e) => e.metadata,
				set: (e, t) => {
					e.metadata = t;
				}
			},
			metadata: e
		}, S, C), l(null, null, w, {
			kind: "field",
			name: "_hasAlpha",
			static: !1,
			private: !1,
			access: {
				has: (e) => "_hasAlpha" in e,
				get: (e) => e._hasAlpha,
				set: (e, t) => {
					e._hasAlpha = t;
				}
			},
			metadata: e
		}, T, E), l(null, null, D, {
			kind: "field",
			name: "_getAlphaFromRGB",
			static: !1,
			private: !1,
			access: {
				has: (e) => "_getAlphaFromRGB" in e,
				get: (e) => e._getAlphaFromRGB,
				set: (e, t) => {
					e._getAlphaFromRGB = t;
				}
			},
			metadata: e
		}, O, k), l(null, null, A, {
			kind: "field",
			name: "level",
			static: !1,
			private: !1,
			access: {
				has: (e) => "level" in e,
				get: (e) => e.level,
				set: (e, t) => {
					e.level = t;
				}
			},
			metadata: e
		}, j, M), l(null, null, N, {
			kind: "field",
			name: "_coordinatesIndex",
			static: !1,
			private: !1,
			access: {
				has: (e) => "_coordinatesIndex" in e,
				get: (e) => e._coordinatesIndex,
				set: (e, t) => {
					e._coordinatesIndex = t;
				}
			},
			metadata: e
		}, P, F), l(null, null, I, {
			kind: "field",
			name: "optimizeUVAllocation",
			static: !1,
			private: !1,
			access: {
				has: (e) => "optimizeUVAllocation" in e,
				get: (e) => e.optimizeUVAllocation,
				set: (e, t) => {
					e.optimizeUVAllocation = t;
				}
			},
			metadata: e
		}, L, R), l(null, null, te, {
			kind: "field",
			name: "_coordinatesMode",
			static: !1,
			private: !1,
			access: {
				has: (e) => "_coordinatesMode" in e,
				get: (e) => e._coordinatesMode,
				set: (e, t) => {
					e._coordinatesMode = t;
				}
			},
			metadata: e
		}, z, B), l(null, null, U, {
			kind: "field",
			name: "wrapR",
			static: !1,
			private: !1,
			access: {
				has: (e) => "wrapR" in e,
				get: (e) => e.wrapR,
				set: (e, t) => {
					e.wrapR = t;
				}
			},
			metadata: e
		}, W, G), l(null, null, K, {
			kind: "field",
			name: "anisotropicFilteringLevel",
			static: !1,
			private: !1,
			access: {
				has: (e) => "anisotropicFilteringLevel" in e,
				get: (e) => e.anisotropicFilteringLevel,
				set: (e, t) => {
					e.anisotropicFilteringLevel = t;
				}
			},
			metadata: e
		}, q, J), l(null, null, ne, {
			kind: "field",
			name: "invertZ",
			static: !1,
			private: !1,
			access: {
				has: (e) => "invertZ" in e,
				get: (e) => e.invertZ,
				set: (e, t) => {
					e.invertZ = t;
				}
			},
			metadata: e
		}, re, ie), l(null, null, ae, {
			kind: "field",
			name: "lodLevelInAlpha",
			static: !1,
			private: !1,
			access: {
				has: (e) => "lodLevelInAlpha" in e,
				get: (e) => e.lodLevelInAlpha,
				set: (e, t) => {
					e.lodLevelInAlpha = t;
				}
			},
			metadata: e
		}, oe, $), l(null, null, de, {
			kind: "field",
			name: "isRenderTarget",
			static: !1,
			private: !1,
			access: {
				has: (e) => "isRenderTarget" in e,
				get: (e) => e.isRenderTarget,
				set: (e, t) => {
					e.isRenderTarget = t;
				}
			},
			metadata: e
		}, fe, pe), e && Object.defineProperty(n, Symbol.metadata, {
			enumerable: !0,
			configurable: !0,
			writable: !0,
			value: e
		});
	})(), n.DEFAULT_ANISOTROPIC_FILTERING_LEVEL = 4, n;
})();
(p = m.prototype).forceSphericalPolynomialsRecompute ?? (p.forceSphericalPolynomialsRecompute = n("BaseTexture", "forceSphericalPolynomialsRecompute")), Object.getOwnPropertyDescriptor(m.prototype, "sphericalPolynomial") || Object.defineProperty(m.prototype, "sphericalPolynomial", r("BaseTexture", "sphericalPolynomial"));
//#endregion
export { m as t };
