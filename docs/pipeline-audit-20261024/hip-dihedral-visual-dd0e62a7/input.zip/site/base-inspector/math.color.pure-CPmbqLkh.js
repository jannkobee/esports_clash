import { a as e, c as t, l as n, o as r, s as i, t as a } from "./math.scalar.functions-D7lyzZPV.js";
import { t as o } from "./engineStore-D0BoPdea.js";
import { t as s } from "./performanceConfigurator-DBCxCnir.js";
import { n as c } from "./typeStore-pENEWnX2.js";
//#region node_modules/@babylonjs/core/Maths/math.constants.js
var l = 1 / 2.2, u = 2.2;
(1 + Math.sqrt(5)) / 2;
var d = .001;
//#endregion
//#region node_modules/@babylonjs/core/Misc/arrayTools.js
function f(e, t) {
	let n = [];
	for (let r = 0; r < e; ++r) n.push(t());
	return n;
}
function p(e, t) {
	return f(e, t);
}
function m(e, t, n) {
	let r = e[t];
	if (typeof r != "function") return null;
	let i = function() {
		let r = e.length, a = i.previous.apply(e, arguments);
		return n(t, r), a;
	};
	return r.next = i, i.previous = r, e[t] = i, () => {
		let n = i.previous;
		if (!n) return;
		let r = i.next;
		r ? (n.next = r, r.previous = n) : (n.next = void 0, e[t] = n), i.next = void 0, i.previous = void 0;
	};
}
var h = [
	"push",
	"splice",
	"pop",
	"shift",
	"unshift"
];
function g(e, t) {
	let n = h.map((n) => m(e, n, t));
	return () => {
		for (let e of n) e?.();
	};
}
//#endregion
//#region node_modules/@babylonjs/core/Maths/ThinMaths/thinMath.matrix.functions.js
var _ = class {};
_._UpdateFlagSeed = 0;
function v(e) {
	e.updateFlag = _._UpdateFlagSeed++;
}
function y(e, t, n, r = 0) {
	let i = e.asArray(), a = t.asArray(), o = i[0], s = i[1], c = i[2], l = i[3], u = i[4], d = i[5], f = i[6], p = i[7], m = i[8], h = i[9], g = i[10], _ = i[11], v = i[12], y = i[13], b = i[14], x = i[15], S = a[0], C = a[1], w = a[2], T = a[3], E = a[4], D = a[5], O = a[6], k = a[7], A = a[8], j = a[9], M = a[10], N = a[11], P = a[12], F = a[13], I = a[14], L = a[15];
	n[r] = o * S + s * E + c * A + l * P, n[r + 1] = o * C + s * D + c * j + l * F, n[r + 2] = o * w + s * O + c * M + l * I, n[r + 3] = o * T + s * k + c * N + l * L, n[r + 4] = u * S + d * E + f * A + p * P, n[r + 5] = u * C + d * D + f * j + p * F, n[r + 6] = u * w + d * O + f * M + p * I, n[r + 7] = u * T + d * k + f * N + p * L, n[r + 8] = m * S + h * E + g * A + _ * P, n[r + 9] = m * C + h * D + g * j + _ * F, n[r + 10] = m * w + h * O + g * M + _ * I, n[r + 11] = m * T + h * k + g * N + _ * L, n[r + 12] = v * S + y * E + b * A + x * P, n[r + 13] = v * C + y * D + b * j + x * F, n[r + 14] = v * w + y * O + b * M + x * I, n[r + 15] = v * T + y * k + b * N + x * L;
}
function b(e, t, n, r = 0) {
	y(e, t, n.asArray(), r), v(n);
}
function x(e, t, n = 0) {
	let r = e.asArray();
	t[n] = r[0], t[n + 1] = r[1], t[n + 2] = r[2], t[n + 3] = r[3], t[n + 4] = r[4], t[n + 5] = r[5], t[n + 6] = r[6], t[n + 7] = r[7], t[n + 8] = r[8], t[n + 9] = r[9], t[n + 10] = r[10], t[n + 11] = r[11], t[n + 12] = r[12], t[n + 13] = r[13], t[n + 14] = r[14], t[n + 15] = r[15];
}
function S(e, t) {
	let n = C(e, t.asArray());
	return n && v(t), n;
}
function C(e, t) {
	let n = e.asArray(), r = n[0], i = n[1], a = n[2], o = n[3], s = n[4], c = n[5], l = n[6], u = n[7], d = n[8], f = n[9], p = n[10], m = n[11], h = n[12], g = n[13], _ = n[14], v = n[15], y = p * v - _ * m, b = f * v - g * m, x = f * _ - g * p, S = d * v - h * m, C = d * _ - p * h, w = d * g - h * f, T = +(c * y - l * b + u * x), E = -(s * y - l * S + u * C), D = +(s * b - c * S + u * w), O = -(s * x - c * C + l * w), k = r * T + i * E + a * D + o * O;
	if (k === 0) return !1;
	let A = 1 / k, j = l * v - _ * u, M = c * v - g * u, N = c * _ - g * l, P = s * v - h * u, F = s * _ - h * l, I = s * g - h * c, L = l * m - p * u, R = c * m - f * u, z = c * p - f * l, B = s * m - d * u, V = s * p - d * l, H = s * f - d * c, U = -(i * y - a * b + o * x), W = +(r * y - a * S + o * C), G = -(r * b - i * S + o * w), K = +(r * x - i * C + a * w), q = +(i * j - a * M + o * N), J = -(r * j - a * P + o * F), Y = +(r * M - i * P + o * I), X = -(r * N - i * F + a * I), Z = -(i * L - a * R + o * z), Q = +(r * L - a * B + o * V), $ = -(r * R - i * B + o * H), ee = +(r * z - i * V + a * H);
	return t[0] = T * A, t[1] = U * A, t[2] = q * A, t[3] = Z * A, t[4] = E * A, t[5] = W * A, t[6] = J * A, t[7] = Q * A, t[8] = D * A, t[9] = G * A, t[10] = Y * A, t[11] = $ * A, t[12] = O * A, t[13] = K * A, t[14] = X * A, t[15] = ee * A, !0;
}
//#endregion
//#region node_modules/@babylonjs/core/Maths/math.vector.pure.js
var w = (e) => parseInt(e.toString().replace(/\W/g, "")), T = class e {
	constructor(e = 0, t = 0) {
		this.x = e, this.y = t;
	}
	toString() {
		return `{X: ${this.x} Y: ${this.y}}`;
	}
	getClassName() {
		return "Vector2";
	}
	getHashCode() {
		let e = w(this.x), t = w(this.y), n = e;
		return n = n * 397 ^ t, n;
	}
	toArray(e, t = 0) {
		return e[t] = this.x, e[t + 1] = this.y, this;
	}
	fromArray(t, n = 0) {
		return e.FromArrayToRef(t, n, this), this;
	}
	asArray() {
		return [this.x, this.y];
	}
	copyFrom(e) {
		return this.x = e.x, this.y = e.y, this;
	}
	copyFromFloats(e, t) {
		return this.x = e, this.y = t, this;
	}
	set(e, t) {
		return this.copyFromFloats(e, t);
	}
	setAll(e) {
		return this.copyFromFloats(e, e);
	}
	add(t) {
		return new e(this.x + t.x, this.y + t.y);
	}
	addToRef(e, t) {
		return t.x = this.x + e.x, t.y = this.y + e.y, t;
	}
	addInPlace(e) {
		return this.x += e.x, this.y += e.y, this;
	}
	addInPlaceFromFloats(e, t) {
		return this.x += e, this.y += t, this;
	}
	addVector3(t) {
		return new e(this.x + t.x, this.y + t.y);
	}
	subtract(t) {
		return new e(this.x - t.x, this.y - t.y);
	}
	subtractToRef(e, t) {
		return t.x = this.x - e.x, t.y = this.y - e.y, t;
	}
	subtractInPlace(e) {
		return this.x -= e.x, this.y -= e.y, this;
	}
	multiplyInPlace(e) {
		return this.x *= e.x, this.y *= e.y, this;
	}
	multiply(t) {
		return new e(this.x * t.x, this.y * t.y);
	}
	multiplyToRef(e, t) {
		return t.x = this.x * e.x, t.y = this.y * e.y, t;
	}
	multiplyByFloats(t, n) {
		return new e(this.x * t, this.y * n);
	}
	divide(t) {
		return new e(this.x / t.x, this.y / t.y);
	}
	divideToRef(e, t) {
		return t.x = this.x / e.x, t.y = this.y / e.y, t;
	}
	divideInPlace(e) {
		return this.x /= e.x, this.y /= e.y, this;
	}
	minimizeInPlace(e) {
		return this.minimizeInPlaceFromFloats(e.x, e.y);
	}
	maximizeInPlace(e) {
		return this.maximizeInPlaceFromFloats(e.x, e.y);
	}
	minimizeInPlaceFromFloats(e, t) {
		return this.x = Math.min(e, this.x), this.y = Math.min(t, this.y), this;
	}
	maximizeInPlaceFromFloats(e, t) {
		return this.x = Math.max(e, this.x), this.y = Math.max(t, this.y), this;
	}
	subtractFromFloats(t, n) {
		return new e(this.x - t, this.y - n);
	}
	subtractFromFloatsToRef(e, t, n) {
		return n.x = this.x - e, n.y = this.y - t, n;
	}
	negate() {
		return new e(-this.x, -this.y);
	}
	negateInPlace() {
		return this.x *= -1, this.y *= -1, this;
	}
	negateToRef(e) {
		return e.x = -this.x, e.y = -this.y, e;
	}
	scaleInPlace(e) {
		return this.x *= e, this.y *= e, this;
	}
	scale(t) {
		return new e(this.x * t, this.y * t);
	}
	scaleToRef(e, t) {
		return t.x = this.x * e, t.y = this.y * e, t;
	}
	scaleAndAddToRef(e, t) {
		return t.x += this.x * e, t.y += this.y * e, t;
	}
	equals(e) {
		return e && this.x === e.x && this.y === e.y;
	}
	equalsWithEpsilon(e, t = d) {
		return e && n(this.x, e.x, t) && n(this.y, e.y, t);
	}
	equalsToFloats(e, t) {
		return this.x === e && this.y === t;
	}
	floor() {
		return new e(Math.floor(this.x), Math.floor(this.y));
	}
	floorToRef(e) {
		return e.x = Math.floor(this.x), e.y = Math.floor(this.y), e;
	}
	fract() {
		return new e(this.x - Math.floor(this.x), this.y - Math.floor(this.y));
	}
	fractToRef(e) {
		return e.x = this.x - Math.floor(this.x), e.y = this.y - Math.floor(this.y), e;
	}
	rotate(t) {
		return this.rotateToRef(t, new e());
	}
	rotateToRef(e, t) {
		let n = Math.cos(e), r = Math.sin(e);
		return t.x = n * this.x - r * this.y, t.y = r * this.x + n * this.y, t;
	}
	length() {
		return Math.sqrt(this.x * this.x + this.y * this.y);
	}
	lengthSquared() {
		return this.x * this.x + this.y * this.y;
	}
	normalize() {
		return this.normalizeFromLength(this.length());
	}
	normalizeFromLength(e) {
		return e === 0 || e === 1 ? this : this.scaleInPlace(1 / e);
	}
	normalizeToNew() {
		let t = new e();
		return this.normalizeToRef(t), t;
	}
	normalizeToRef(e) {
		let t = this.length();
		return t === 0 || t === 1 ? (e.x = this.x, e.y = this.y, e) : this.scaleToRef(1 / t, e);
	}
	clone() {
		return new e(this.x, this.y);
	}
	dot(e) {
		return this.x * e.x + this.y * e.y;
	}
	static Zero() {
		return new e(0, 0);
	}
	static One() {
		return new e(1, 1);
	}
	static Random(t = 0, n = 1) {
		return new e(i(t, n), i(t, n));
	}
	static RandomToRef(e = 0, t = 1, n) {
		return n.copyFromFloats(i(e, t), i(e, t));
	}
	static get ZeroReadOnly() {
		return e._ZeroReadOnly;
	}
	static FromArray(t, n = 0) {
		return new e(t[n], t[n + 1]);
	}
	static FromArrayToRef(e, t, n) {
		return n.x = e[t], n.y = e[t + 1], n;
	}
	static FromFloatsToRef(e, t, n) {
		return n.copyFromFloats(e, t), n;
	}
	static CatmullRom(t, n, r, i, a) {
		let o = a * a, s = a * o, c = .5 * (2 * n.x + (-t.x + r.x) * a + (2 * t.x - 5 * n.x + 4 * r.x - i.x) * o + (-t.x + 3 * n.x - 3 * r.x + i.x) * s), l = .5 * (2 * n.y + (-t.y + r.y) * a + (2 * t.y - 5 * n.y + 4 * r.y - i.y) * o + (-t.y + 3 * n.y - 3 * r.y + i.y) * s);
		return new e(c, l);
	}
	static ClampToRef(e, t, n, r) {
		return r.x = a(e.x, t.x, n.x), r.y = a(e.y, t.y, n.y), r;
	}
	static Clamp(t, n, r) {
		let i = a(t.x, n.x, r.x), o = a(t.y, n.y, r.y);
		return new e(i, o);
	}
	static Hermite(t, n, r, i, a) {
		let o = a * a, s = a * o, c = 2 * s - 3 * o + 1, l = -2 * s + 3 * o, u = s - 2 * o + a, d = s - o, f = t.x * c + r.x * l + n.x * u + i.x * d, p = t.y * c + r.y * l + n.y * u + i.y * d;
		return new e(f, p);
	}
	static Hermite1stDerivative(t, n, r, i, a) {
		return this.Hermite1stDerivativeToRef(t, n, r, i, a, new e());
	}
	static Hermite1stDerivativeToRef(e, t, n, r, i, a) {
		let o = i * i;
		return a.x = (o - i) * 6 * e.x + (3 * o - 4 * i + 1) * t.x + (-o + i) * 6 * n.x + (3 * o - 2 * i) * r.x, a.y = (o - i) * 6 * e.y + (3 * o - 4 * i + 1) * t.y + (-o + i) * 6 * n.y + (3 * o - 2 * i) * r.y, a;
	}
	static Lerp(t, n, r) {
		return e.LerpToRef(t, n, r, new e());
	}
	static LerpToRef(e, t, n, r) {
		return r.x = e.x + (t.x - e.x) * n, r.y = e.y + (t.y - e.y) * n, r;
	}
	static Dot(e, t) {
		return e.x * t.x + e.y * t.y;
	}
	static Normalize(t) {
		return e.NormalizeToRef(t, new e());
	}
	static NormalizeToRef(e, t) {
		return e.normalizeToRef(t), t;
	}
	static Minimize(t, n) {
		let r = t.x < n.x ? t.x : n.x, i = t.y < n.y ? t.y : n.y;
		return new e(r, i);
	}
	static Maximize(t, n) {
		let r = t.x > n.x ? t.x : n.x, i = t.y > n.y ? t.y : n.y;
		return new e(r, i);
	}
	static Transform(t, n) {
		return e.TransformToRef(t, n, new e());
	}
	static TransformToRef(e, t, n) {
		let r = t.m, i = e.x * r[0] + e.y * r[4] + r[12], a = e.x * r[1] + e.y * r[5] + r[13];
		return n.x = i, n.y = a, n;
	}
	static PointInTriangle(e, t, n, r) {
		let i = 1 / 2 * (-n.y * r.x + t.y * (-n.x + r.x) + t.x * (n.y - r.y) + n.x * r.y), a = i < 0 ? -1 : 1, o = (t.y * r.x - t.x * r.y + (r.y - t.y) * e.x + (t.x - r.x) * e.y) * a, s = (t.x * n.y - t.y * n.x + (t.y - n.y) * e.x + (n.x - t.x) * e.y) * a;
		return o > 0 && s > 0 && o + s < 2 * i * a;
	}
	static Distance(t, n) {
		return Math.sqrt(e.DistanceSquared(t, n));
	}
	static DistanceSquared(e, t) {
		let n = e.x - t.x, r = e.y - t.y;
		return n * n + r * r;
	}
	static Center(t, n) {
		return e.CenterToRef(t, n, new e());
	}
	static CenterToRef(e, t, n) {
		return n.copyFromFloats((e.x + t.x) / 2, (e.y + t.y) / 2);
	}
	static DistanceOfPointFromSegment(t, n, r) {
		let i = e.DistanceSquared(n, r);
		if (i === 0) return e.Distance(t, n);
		let a = r.subtract(n), o = Math.max(0, Math.min(1, e.Dot(t.subtract(n), a) / i)), s = n.add(a.multiplyByFloats(o, o));
		return e.Distance(t, s);
	}
};
T._V8PerformanceHack = /*#__PURE__*/ new T(.5, .5), T._ZeroReadOnly = /*#__PURE__*/ T.Zero();
var E = class t {
	get x() {
		return this._x;
	}
	set x(e) {
		this._x = e, this._isDirty = !0;
	}
	get y() {
		return this._y;
	}
	set y(e) {
		this._y = e, this._isDirty = !0;
	}
	get z() {
		return this._z;
	}
	set z(e) {
		this._z = e, this._isDirty = !0;
	}
	constructor(e = 0, t = 0, n = 0) {
		this._isDirty = !0, this._x = e, this._y = t, this._z = n;
	}
	toString() {
		return `{X: ${this._x} Y: ${this._y} Z: ${this._z}}`;
	}
	getClassName() {
		return "Vector3";
	}
	getHashCode() {
		let e = w(this._x), t = w(this._y), n = w(this._z), r = e;
		return r = r * 397 ^ t, r = r * 397 ^ n, r;
	}
	asArray() {
		return [
			this._x,
			this._y,
			this._z
		];
	}
	toArray(e, t = 0) {
		return e[t] = this._x, e[t + 1] = this._y, e[t + 2] = this._z, this;
	}
	fromArray(e, n = 0) {
		return t.FromArrayToRef(e, n, this), this;
	}
	toQuaternion() {
		return O.RotationYawPitchRoll(this._y, this._x, this._z);
	}
	addInPlace(e) {
		return this._x += e._x, this._y += e._y, this._z += e._z, this._isDirty = !0, this;
	}
	addInPlaceFromFloats(e, t, n) {
		return this._x += e, this._y += t, this._z += n, this._isDirty = !0, this;
	}
	add(e) {
		return new t(this._x + e._x, this._y + e._y, this._z + e._z);
	}
	addToRef(e, t) {
		return t._x = this._x + e._x, t._y = this._y + e._y, t._z = this._z + e._z, t._isDirty = !0, t;
	}
	subtractInPlace(e) {
		return this._x -= e._x, this._y -= e._y, this._z -= e._z, this._isDirty = !0, this;
	}
	subtract(e) {
		return new t(this._x - e._x, this._y - e._y, this._z - e._z);
	}
	subtractToRef(e, t) {
		return this.subtractFromFloatsToRef(e._x, e._y, e._z, t);
	}
	subtractFromFloats(e, n, r) {
		return new t(this._x - e, this._y - n, this._z - r);
	}
	subtractFromFloatsToRef(e, t, n, r) {
		return r._x = this._x - e, r._y = this._y - t, r._z = this._z - n, r._isDirty = !0, r;
	}
	negate() {
		return new t(-this._x, -this._y, -this._z);
	}
	negateInPlace() {
		return this._x *= -1, this._y *= -1, this._z *= -1, this._isDirty = !0, this;
	}
	negateToRef(e) {
		return e._x = this._x * -1, e._y = this._y * -1, e._z = this._z * -1, e._isDirty = !0, e;
	}
	scaleInPlace(e) {
		return this._x *= e, this._y *= e, this._z *= e, this._isDirty = !0, this;
	}
	scale(e) {
		return new t(this._x * e, this._y * e, this._z * e);
	}
	scaleToRef(e, t) {
		return t._x = this._x * e, t._y = this._y * e, t._z = this._z * e, t._isDirty = !0, t;
	}
	getNormalToRef(e) {
		let t = this.length(), n = Math.acos(this._y / t), r = Math.atan2(this._z, this._x);
		n > Math.PI / 2 ? n -= Math.PI / 2 : n += Math.PI / 2;
		let i = t * Math.sin(n) * Math.cos(r), a = t * Math.cos(n), o = t * Math.sin(n) * Math.sin(r);
		return e.set(i, a, o), e;
	}
	applyRotationQuaternionToRef(e, t) {
		let n = this._x, r = this._y, i = this._z, a = e._x, o = e._y, s = e._z, c = e._w, l = 2 * (o * i - s * r), u = 2 * (s * n - a * i), d = 2 * (a * r - o * n);
		return t._x = n + c * l + o * d - s * u, t._y = r + c * u + s * l - a * d, t._z = i + c * d + a * u - o * l, t._isDirty = !0, t;
	}
	applyRotationQuaternionInPlace(e) {
		return this.applyRotationQuaternionToRef(e, this);
	}
	applyRotationQuaternion(e) {
		return this.applyRotationQuaternionToRef(e, new t());
	}
	scaleAndAddToRef(e, t) {
		return t._x += this._x * e, t._y += this._y * e, t._z += this._z * e, t._isDirty = !0, t;
	}
	projectOnPlane(e, n) {
		return this.projectOnPlaneToRef(e, n, new t());
	}
	projectOnPlaneToRef(e, n, r) {
		let i = e.normal, a = e.d, o = A.Vector3[0];
		this.subtractToRef(n, o), o.normalize();
		let s = t.Dot(o, i);
		if (Math.abs(s) < 1e-10) r.setAll(Infinity);
		else {
			let e = -(t.Dot(n, i) + a) / s, c = o.scaleInPlace(e);
			n.addToRef(c, r);
		}
		return r;
	}
	equals(e) {
		return e && this._x === e._x && this._y === e._y && this._z === e._z;
	}
	equalsWithEpsilon(e, t = d) {
		return e && n(this._x, e._x, t) && n(this._y, e._y, t) && n(this._z, e._z, t);
	}
	equalsToFloats(e, t, n) {
		return this._x === e && this._y === t && this._z === n;
	}
	multiplyInPlace(e) {
		return this._x *= e._x, this._y *= e._y, this._z *= e._z, this._isDirty = !0, this;
	}
	multiply(e) {
		return this.multiplyByFloats(e._x, e._y, e._z);
	}
	multiplyToRef(e, t) {
		return t._x = this._x * e._x, t._y = this._y * e._y, t._z = this._z * e._z, t._isDirty = !0, t;
	}
	multiplyByFloats(e, n, r) {
		return new t(this._x * e, this._y * n, this._z * r);
	}
	divide(e) {
		return new t(this._x / e._x, this._y / e._y, this._z / e._z);
	}
	divideToRef(e, t) {
		return t._x = this._x / e._x, t._y = this._y / e._y, t._z = this._z / e._z, t._isDirty = !0, t;
	}
	divideInPlace(e) {
		return this._x /= e._x, this._y /= e._y, this._z /= e._z, this._isDirty = !0, this;
	}
	minimizeInPlace(e) {
		return this.minimizeInPlaceFromFloats(e._x, e._y, e._z);
	}
	maximizeInPlace(e) {
		return this.maximizeInPlaceFromFloats(e._x, e._y, e._z);
	}
	minimizeInPlaceFromFloats(e, t, n) {
		return e < this._x && (this.x = e), t < this._y && (this.y = t), n < this._z && (this.z = n), this;
	}
	maximizeInPlaceFromFloats(e, t, n) {
		return e > this._x && (this.x = e), t > this._y && (this.y = t), n > this._z && (this.z = n), this;
	}
	isNonUniformWithinEpsilon(e) {
		let t = Math.abs(this._x), r = Math.abs(this._y);
		if (!n(t, r, e)) return !0;
		let i = Math.abs(this._z);
		return !n(t, i, e) || !n(r, i, e);
	}
	get isNonUniform() {
		let e = Math.abs(this._x);
		return e !== Math.abs(this._y) || e !== Math.abs(this._z);
	}
	floorToRef(e) {
		return e._x = Math.floor(this._x), e._y = Math.floor(this._y), e._z = Math.floor(this._z), e._isDirty = !0, e;
	}
	floor() {
		return new t(Math.floor(this._x), Math.floor(this._y), Math.floor(this._z));
	}
	fractToRef(e) {
		return e._x = this._x - Math.floor(this._x), e._y = this._y - Math.floor(this._y), e._z = this._z - Math.floor(this._z), e._isDirty = !0, e;
	}
	fract() {
		return new t(this._x - Math.floor(this._x), this._y - Math.floor(this._y), this._z - Math.floor(this._z));
	}
	length() {
		return Math.sqrt(this.lengthSquared());
	}
	lengthSquared() {
		return this._x * this._x + this._y * this._y + this._z * this._z;
	}
	get hasAZeroComponent() {
		return this._x * this._y * this._z === 0;
	}
	normalize() {
		return this.normalizeFromLength(this.length());
	}
	reorderInPlace(e) {
		if (e = e.toLowerCase(), e === "xyz") return this;
		let t = A.Vector3[0].copyFrom(this);
		return this.x = t[e[0]], this.y = t[e[1]], this.z = t[e[2]], this;
	}
	rotateByQuaternionToRef(e, n) {
		return e.toRotationMatrix(A.Matrix[0]), t.TransformCoordinatesToRef(this, A.Matrix[0], n), n;
	}
	rotateByQuaternionAroundPointToRef(e, t, n) {
		return this.subtractToRef(t, A.Vector3[0]), A.Vector3[0].rotateByQuaternionToRef(e, A.Vector3[0]), t.addToRef(A.Vector3[0], n), n;
	}
	cross(e) {
		return t.CrossToRef(this, e, new t());
	}
	normalizeFromLength(e) {
		return e === 0 || e === 1 ? this : this.scaleInPlace(1 / e);
	}
	normalizeToNew() {
		return this.normalizeToRef(new t());
	}
	normalizeToRef(e) {
		let t = this.length();
		return t === 0 || t === 1 ? (e._x = this._x, e._y = this._y, e._z = this._z, e._isDirty = !0, e) : this.scaleToRef(1 / t, e);
	}
	clone() {
		return new t(this._x, this._y, this._z);
	}
	copyFrom(e) {
		return this.copyFromFloats(e._x, e._y, e._z);
	}
	copyFromFloats(e, t, n) {
		return this._x = e, this._y = t, this._z = n, this._isDirty = !0, this;
	}
	set(e, t, n) {
		return this.copyFromFloats(e, t, n);
	}
	setAll(e) {
		return this._x = this._y = this._z = e, this._isDirty = !0, this;
	}
	static GetClipFactor(e, n, r, i) {
		let a = t.Dot(e, r), o = t.Dot(n, r);
		return (a - i) / (a - o);
	}
	static GetAngleBetweenVectors(e, n, r) {
		let i = e.normalizeToRef(A.Vector3[1]), o = n.normalizeToRef(A.Vector3[2]), s = t.Dot(i, o);
		s = a(s, -1, 1);
		let c = Math.acos(s), l = A.Vector3[3];
		return t.CrossToRef(i, o, l), t.Dot(l, r) > 0 ? isNaN(c) ? 0 : c : isNaN(c) ? -Math.PI : -Math.acos(s);
	}
	static GetAngleBetweenVectorsOnPlane(e, n, i) {
		A.Vector3[0].copyFrom(e);
		let a = A.Vector3[0];
		A.Vector3[1].copyFrom(n);
		let o = A.Vector3[1];
		A.Vector3[2].copyFrom(i);
		let s = A.Vector3[2], c = A.Vector3[3], l = A.Vector3[4];
		a.normalize(), o.normalize(), s.normalize(), t.CrossToRef(s, a, c), t.CrossToRef(c, s, l);
		let u = Math.atan2(t.Dot(o, c), t.Dot(o, l));
		return r(u);
	}
	static PitchYawRollToMoveBetweenPointsToRef(e, t, n) {
		let r = j.Vector3[0];
		return t.subtractToRef(e, r), n._y = Math.atan2(r.x, r.z) || 0, n._x = Math.atan2(Math.sqrt(r.x ** 2 + r.z ** 2), r.y) || 0, n._z = 0, n._isDirty = !0, n;
	}
	static PitchYawRollToMoveBetweenPoints(e, n) {
		let r = t.Zero();
		return t.PitchYawRollToMoveBetweenPointsToRef(e, n, r);
	}
	static SlerpToRef(n, r, i, o) {
		i = a(i, 0, 1);
		let s = A.Vector3[0], c = A.Vector3[1];
		s.copyFrom(n);
		let l = s.length();
		s.normalizeFromLength(l), c.copyFrom(r);
		let u = c.length();
		c.normalizeFromLength(u);
		let d = t.Dot(s, c), f, p;
		if (d < .999) {
			let e = Math.acos(d), t = 1 / Math.sin(e);
			f = Math.sin((1 - i) * e) * t, p = Math.sin(i * e) * t;
		} else f = 1 - i, p = i;
		return s.scaleInPlace(f), c.scaleInPlace(p), o.copyFrom(s).addInPlace(c), o.scaleInPlace(e(l, u, i)), o;
	}
	static SmoothToRef(e, n, r, i, a) {
		return t.SlerpToRef(e, n, i === 0 ? 1 : r / i, a), a;
	}
	static FromArray(e, n = 0) {
		return new t(e[n], e[n + 1], e[n + 2]);
	}
	static FromFloatArray(e, n) {
		return t.FromArray(e, n);
	}
	static FromArrayToRef(e, t, n) {
		return n._x = e[t], n._y = e[t + 1], n._z = e[t + 2], n._isDirty = !0, n;
	}
	static FromFloatArrayToRef(e, n, r) {
		return t.FromArrayToRef(e, n, r);
	}
	static FromFloatsToRef(e, t, n, r) {
		return r.copyFromFloats(e, t, n), r;
	}
	static Zero() {
		return new t(0, 0, 0);
	}
	static One() {
		return new t(1, 1, 1);
	}
	static Up() {
		return new t(0, 1, 0);
	}
	static get UpReadOnly() {
		return t._UpReadOnly;
	}
	static get DownReadOnly() {
		return t._DownReadOnly;
	}
	static get RightReadOnly() {
		return t._RightReadOnly;
	}
	static get LeftReadOnly() {
		return t._LeftReadOnly;
	}
	static get LeftHandedForwardReadOnly() {
		return t._LeftHandedForwardReadOnly;
	}
	static get RightHandedForwardReadOnly() {
		return t._RightHandedForwardReadOnly;
	}
	static get LeftHandedBackwardReadOnly() {
		return t._LeftHandedBackwardReadOnly;
	}
	static get RightHandedBackwardReadOnly() {
		return t._RightHandedBackwardReadOnly;
	}
	static get ZeroReadOnly() {
		return t._ZeroReadOnly;
	}
	static get OneReadOnly() {
		return t._OneReadOnly;
	}
	static Down() {
		return new t(0, -1, 0);
	}
	static Forward(e = !1) {
		return new t(0, 0, e ? -1 : 1);
	}
	static Backward(e = !1) {
		return new t(0, 0, e ? 1 : -1);
	}
	static Right() {
		return new t(1, 0, 0);
	}
	static Left() {
		return new t(-1, 0, 0);
	}
	static Random(e = 0, n = 1) {
		return new t(i(e, n), i(e, n), i(e, n));
	}
	static RandomToRef(e = 0, t = 1, n) {
		return n.copyFromFloats(i(e, t), i(e, t), i(e, t));
	}
	static TransformCoordinates(e, n) {
		let r = t.Zero();
		return t.TransformCoordinatesToRef(e, n, r), r;
	}
	static TransformCoordinatesToRef(e, n, r) {
		return t.TransformCoordinatesFromFloatsToRef(e._x, e._y, e._z, n, r), r;
	}
	static TransformCoordinatesFromFloatsToRef(e, t, n, r, i) {
		let a = r.m, o = e * a[0] + t * a[4] + n * a[8] + a[12], s = e * a[1] + t * a[5] + n * a[9] + a[13], c = e * a[2] + t * a[6] + n * a[10] + a[14], l = 1 / (e * a[3] + t * a[7] + n * a[11] + a[15]);
		return i._x = o * l, i._y = s * l, i._z = c * l, i._isDirty = !0, i;
	}
	static TransformNormal(e, n) {
		let r = t.Zero();
		return t.TransformNormalToRef(e, n, r), r;
	}
	static TransformNormalToRef(e, t, n) {
		return this.TransformNormalFromFloatsToRef(e._x, e._y, e._z, t, n), n;
	}
	static TransformNormalFromFloatsToRef(e, t, n, r, i) {
		let a = r.m;
		return i._x = e * a[0] + t * a[4] + n * a[8], i._y = e * a[1] + t * a[5] + n * a[9], i._z = e * a[2] + t * a[6] + n * a[10], i._isDirty = !0, i;
	}
	static CatmullRom(e, n, r, i, a) {
		let o = a * a, s = a * o, c = .5 * (2 * n._x + (-e._x + r._x) * a + (2 * e._x - 5 * n._x + 4 * r._x - i._x) * o + (-e._x + 3 * n._x - 3 * r._x + i._x) * s), l = .5 * (2 * n._y + (-e._y + r._y) * a + (2 * e._y - 5 * n._y + 4 * r._y - i._y) * o + (-e._y + 3 * n._y - 3 * r._y + i._y) * s), u = .5 * (2 * n._z + (-e._z + r._z) * a + (2 * e._z - 5 * n._z + 4 * r._z - i._z) * o + (-e._z + 3 * n._z - 3 * r._z + i._z) * s);
		return new t(c, l, u);
	}
	static Clamp(e, n, r) {
		let i = new t();
		return t.ClampToRef(e, n, r, i), i;
	}
	static ClampToRef(e, t, n, r) {
		let i = e._x;
		i = i > n._x ? n._x : i, i = i < t._x ? t._x : i;
		let a = e._y;
		a = a > n._y ? n._y : a, a = a < t._y ? t._y : a;
		let o = e._z;
		return o = o > n._z ? n._z : o, o = o < t._z ? t._z : o, r.copyFromFloats(i, a, o), r;
	}
	static CheckExtends(e, t, n) {
		t.minimizeInPlace(e), n.maximizeInPlace(e);
	}
	static Hermite(e, n, r, i, a) {
		let o = a * a, s = a * o, c = 2 * s - 3 * o + 1, l = -2 * s + 3 * o, u = s - 2 * o + a, d = s - o, f = e._x * c + r._x * l + n._x * u + i._x * d, p = e._y * c + r._y * l + n._y * u + i._y * d, m = e._z * c + r._z * l + n._z * u + i._z * d;
		return new t(f, p, m);
	}
	static Hermite1stDerivative(e, n, r, i, a) {
		let o = new t();
		return this.Hermite1stDerivativeToRef(e, n, r, i, a, o), o;
	}
	static Hermite1stDerivativeToRef(e, t, n, r, i, a) {
		let o = i * i;
		return a._x = (o - i) * 6 * e._x + (3 * o - 4 * i + 1) * t._x + (-o + i) * 6 * n._x + (3 * o - 2 * i) * r._x, a._y = (o - i) * 6 * e._y + (3 * o - 4 * i + 1) * t._y + (-o + i) * 6 * n._y + (3 * o - 2 * i) * r._y, a._z = (o - i) * 6 * e._z + (3 * o - 4 * i + 1) * t._z + (-o + i) * 6 * n._z + (3 * o - 2 * i) * r._z, a._isDirty = !0, a;
	}
	static Lerp(e, n, r) {
		let i = new t(0, 0, 0);
		return t.LerpToRef(e, n, r, i), i;
	}
	static LerpToRef(e, t, n, r) {
		return r._x = e._x + (t._x - e._x) * n, r._y = e._y + (t._y - e._y) * n, r._z = e._z + (t._z - e._z) * n, r._isDirty = !0, r;
	}
	static Dot(e, t) {
		return e._x * t._x + e._y * t._y + e._z * t._z;
	}
	dot(e) {
		return this._x * e._x + this._y * e._y + this._z * e._z;
	}
	static Cross(e, n) {
		let r = new t();
		return t.CrossToRef(e, n, r), r;
	}
	static CrossToRef(e, t, n) {
		let r = e._y * t._z - e._z * t._y, i = e._z * t._x - e._x * t._z, a = e._x * t._y - e._y * t._x;
		return n.copyFromFloats(r, i, a), n;
	}
	static Normalize(e) {
		let n = t.Zero();
		return t.NormalizeToRef(e, n), n;
	}
	static NormalizeToRef(e, t) {
		return e.normalizeToRef(t), t;
	}
	static Project(e, n, r, i) {
		let a = new t();
		return t.ProjectToRef(e, n, r, i, a), a;
	}
	static ProjectToRef(e, n, r, i, a) {
		let s = i.width, c = i.height, l = i.x, u = i.y, d = A.Matrix[1], f = o.LastCreatedEngine?.isNDCHalfZRange, p = f ? 1 : .5, m = f ? 0 : .5;
		k.FromValuesToRef(s / 2, 0, 0, 0, 0, -c / 2, 0, 0, 0, 0, p, 0, l + s / 2, c / 2 + u, m, 1, d);
		let h = A.Matrix[0];
		return n.multiplyToRef(r, h), h.multiplyToRef(d, h), t.TransformCoordinatesToRef(e, h, a), a;
	}
	static Reflect(e, n) {
		return this.ReflectToRef(e, n, new t());
	}
	static ReflectToRef(e, n, r) {
		let i = j.Vector3[0];
		return i.copyFrom(n).scaleInPlace(2 * t.Dot(e, n)), r.copyFrom(e).subtractInPlace(i);
	}
	static UnprojectFromTransform(e, t, n, r, i) {
		return this.Unproject(e, t, n, r, i, k.IdentityReadOnly);
	}
	static Unproject(e, n, r, i, a, o) {
		let s = new t();
		return t.UnprojectToRef(e, n, r, i, a, o, s), s;
	}
	static UnprojectToRef(e, n, r, i, a, o, s) {
		return t.UnprojectFloatsToRef(e._x, e._y, e._z, n, r, i, a, o, s), s;
	}
	static UnprojectFloatsToRef(e, n, r, i, a, s, c, l, u) {
		let d = A.Matrix[0];
		s.multiplyToRef(c, d), d.multiplyToRef(l, d), d.invert();
		let f = A.Vector3[0];
		return f.x = e / i * 2 - 1, f.y = -(n / a * 2 - 1), f.z = o.LastCreatedEngine?.isNDCHalfZRange ? r : 2 * r - 1, t.TransformCoordinatesToRef(f, d, u), u;
	}
	static Minimize(e, n) {
		let r = new t();
		return r.copyFrom(e), r.minimizeInPlace(n), r;
	}
	static Maximize(e, n) {
		let r = new t();
		return r.copyFrom(e), r.maximizeInPlace(n), r;
	}
	static Distance(e, n) {
		return Math.sqrt(t.DistanceSquared(e, n));
	}
	static DistanceSquared(e, t) {
		let n = e._x - t._x, r = e._y - t._y, i = e._z - t._z;
		return n * n + r * r + i * i;
	}
	static ProjectOnTriangleToRef(e, n, r, i, o) {
		let s = A.Vector3[0], c = A.Vector3[1], l = A.Vector3[2], u = A.Vector3[3], f = A.Vector3[4];
		r.subtractToRef(n, s), i.subtractToRef(n, c), i.subtractToRef(r, l);
		let p = s.length(), m = c.length(), h = l.length();
		if (p < .001 || m < .001 || h < .001) return o.copyFrom(n), t.Distance(e, n);
		e.subtractToRef(n, f), t.CrossToRef(s, c, u);
		let g = u.length();
		if (g < .001) return o.copyFrom(n), t.Distance(e, n);
		u.normalizeFromLength(g);
		let _ = f.length();
		if (_ < .001) return o.copyFrom(n), 0;
		f.normalizeFromLength(_);
		let v = t.Dot(u, f), y = A.Vector3[5], b = A.Vector3[6];
		y.copyFrom(u).scaleInPlace(-_ * v), b.copyFrom(e).addInPlace(y);
		let x = A.Vector3[4], S = A.Vector3[5], C = A.Vector3[7], w = A.Vector3[8];
		x.copyFrom(s).scaleInPlace(1 / p), w.copyFrom(c).scaleInPlace(1 / m), x.addInPlace(w).scaleInPlace(-1), S.copyFrom(s).scaleInPlace(-1 / p), w.copyFrom(l).scaleInPlace(1 / h), S.addInPlace(w).scaleInPlace(-1), C.copyFrom(l).scaleInPlace(-1 / h), w.copyFrom(c).scaleInPlace(-1 / m), C.addInPlace(w).scaleInPlace(-1);
		let T = A.Vector3[9], E;
		T.copyFrom(b).subtractInPlace(n), t.CrossToRef(x, T, w), E = t.Dot(w, u);
		let D = E;
		T.copyFrom(b).subtractInPlace(r), t.CrossToRef(S, T, w), E = t.Dot(w, u);
		let O = E;
		T.copyFrom(b).subtractInPlace(i), t.CrossToRef(C, T, w), E = t.Dot(w, u);
		let k = E, j = A.Vector3[10], M, N;
		D > 0 && O < 0 ? (j.copyFrom(s), M = n, N = r) : O > 0 && k < 0 ? (j.copyFrom(l), M = r, N = i) : (j.copyFrom(c).scaleInPlace(-1), M = i, N = n);
		let P = A.Vector3[9], F = A.Vector3[4];
		if (M.subtractToRef(b, w), N.subtractToRef(b, P), t.CrossToRef(w, P, F), !(t.Dot(F, u) < 0)) return o.copyFrom(b), Math.abs(_ * v);
		let I = A.Vector3[5];
		t.CrossToRef(j, F, I), I.normalize();
		let L = A.Vector3[9];
		L.copyFrom(M).subtractInPlace(b);
		let R = L.length();
		if (R < .001) return o.copyFrom(M), t.Distance(e, M);
		L.normalizeFromLength(R);
		let z = t.Dot(I, L), B = A.Vector3[7];
		B.copyFrom(b).addInPlace(I.scaleInPlace(R * z)), w.copyFrom(B).subtractInPlace(M), _ = j.length(), j.normalizeFromLength(_);
		let V = t.Dot(w, j) / Math.max(_, d);
		return V = a(V, 0, 1), B.copyFrom(M).addInPlace(j.scaleInPlace(V * _)), o.copyFrom(B), t.Distance(e, B);
	}
	static Center(e, n) {
		return t.CenterToRef(e, n, t.Zero());
	}
	static CenterToRef(e, t, n) {
		return n.copyFromFloats((e._x + t._x) / 2, (e._y + t._y) / 2, (e._z + t._z) / 2);
	}
	static RotationFromAxis(e, n, r) {
		let i = new t();
		return t.RotationFromAxisToRef(e, n, r, i), i;
	}
	static RotationFromAxisToRef(e, t, n, r) {
		let i = A.Quaternion[0];
		return O.RotationQuaternionFromAxisToRef(e, t, n, i), i.toEulerAnglesToRef(r), r;
	}
};
E._V8PerformanceHack = /*#__PURE__*/ new E(.5, .5, .5), E._UpReadOnly = /*#__PURE__*/ E.Up(), E._DownReadOnly = /*#__PURE__*/ E.Down(), E._LeftHandedForwardReadOnly = /*#__PURE__*/ E.Forward(!1), E._RightHandedForwardReadOnly = /*#__PURE__*/ E.Forward(!0), E._LeftHandedBackwardReadOnly = /*#__PURE__*/ E.Backward(!1), E._RightHandedBackwardReadOnly = /*#__PURE__*/ E.Backward(!0), E._RightReadOnly = /*#__PURE__*/ E.Right(), E._LeftReadOnly = /*#__PURE__*/ E.Left(), E._ZeroReadOnly = /*#__PURE__*/ E.Zero(), E._OneReadOnly = /*#__PURE__*/ E.One();
var D = class e {
	get x() {
		return this._x;
	}
	set x(e) {
		this._x = e, this._isDirty = !0;
	}
	get y() {
		return this._y;
	}
	set y(e) {
		this._y = e, this._isDirty = !0;
	}
	get z() {
		return this._z;
	}
	set z(e) {
		this._z = e, this._isDirty = !0;
	}
	get w() {
		return this._w;
	}
	set w(e) {
		this._w = e, this._isDirty = !0;
	}
	constructor(e = 0, t = 0, n = 0, r = 0) {
		this._isDirty = !0, this._x = e, this._y = t, this._z = n, this._w = r;
	}
	toString() {
		return `{X: ${this._x} Y: ${this._y} Z: ${this._z} W: ${this._w}}`;
	}
	getClassName() {
		return "Vector4";
	}
	getHashCode() {
		let e = w(this._x), t = w(this._y), n = w(this._z), r = w(this._w), i = e;
		return i = i * 397 ^ t, i = i * 397 ^ n, i = i * 397 ^ r, i;
	}
	asArray() {
		return [
			this._x,
			this._y,
			this._z,
			this._w
		];
	}
	toArray(e, t) {
		return t === void 0 && (t = 0), e[t] = this._x, e[t + 1] = this._y, e[t + 2] = this._z, e[t + 3] = this._w, this;
	}
	fromArray(t, n = 0) {
		return e.FromArrayToRef(t, n, this), this;
	}
	addInPlace(e) {
		return this.x += e._x, this.y += e._y, this.z += e._z, this.w += e._w, this;
	}
	addInPlaceFromFloats(e, t, n, r) {
		return this.x += e, this.y += t, this.z += n, this.w += r, this;
	}
	add(t) {
		return new e(this._x + t.x, this._y + t.y, this._z + t.z, this._w + t.w);
	}
	addToRef(e, t) {
		return t.x = this._x + e.x, t.y = this._y + e.y, t.z = this._z + e.z, t.w = this._w + e.w, t;
	}
	subtractInPlace(e) {
		return this.x -= e.x, this.y -= e.y, this.z -= e.z, this.w -= e.w, this;
	}
	subtract(t) {
		return new e(this._x - t.x, this._y - t.y, this._z - t.z, this._w - t.w);
	}
	subtractToRef(e, t) {
		return t.x = this._x - e.x, t.y = this._y - e.y, t.z = this._z - e.z, t.w = this._w - e.w, t;
	}
	subtractFromFloats(t, n, r, i) {
		return new e(this._x - t, this._y - n, this._z - r, this._w - i);
	}
	subtractFromFloatsToRef(e, t, n, r, i) {
		return i.x = this._x - e, i.y = this._y - t, i.z = this._z - n, i.w = this._w - r, i;
	}
	negate() {
		return new e(-this._x, -this._y, -this._z, -this._w);
	}
	negateInPlace() {
		return this.x *= -1, this.y *= -1, this.z *= -1, this.w *= -1, this;
	}
	negateToRef(e) {
		return e.x = -this._x, e.y = -this._y, e.z = -this._z, e.w = -this._w, e;
	}
	scaleInPlace(e) {
		return this.x *= e, this.y *= e, this.z *= e, this.w *= e, this;
	}
	scale(t) {
		return new e(this._x * t, this._y * t, this._z * t, this._w * t);
	}
	scaleToRef(e, t) {
		return t.x = this._x * e, t.y = this._y * e, t.z = this._z * e, t.w = this._w * e, t;
	}
	scaleAndAddToRef(e, t) {
		return t.x += this._x * e, t.y += this._y * e, t.z += this._z * e, t.w += this._w * e, t;
	}
	equals(e) {
		return e && this._x === e.x && this._y === e.y && this._z === e.z && this._w === e.w;
	}
	equalsWithEpsilon(e, t = d) {
		return e && n(this._x, e.x, t) && n(this._y, e.y, t) && n(this._z, e.z, t) && n(this._w, e.w, t);
	}
	equalsToFloats(e, t, n, r) {
		return this._x === e && this._y === t && this._z === n && this._w === r;
	}
	multiplyInPlace(e) {
		return this.x *= e.x, this.y *= e.y, this.z *= e.z, this.w *= e.w, this;
	}
	multiply(t) {
		return new e(this._x * t.x, this._y * t.y, this._z * t.z, this._w * t.w);
	}
	multiplyToRef(e, t) {
		return t.x = this._x * e.x, t.y = this._y * e.y, t.z = this._z * e.z, t.w = this._w * e.w, t;
	}
	multiplyByFloats(t, n, r, i) {
		return new e(this._x * t, this._y * n, this._z * r, this._w * i);
	}
	divide(t) {
		return new e(this._x / t.x, this._y / t.y, this._z / t.z, this._w / t.w);
	}
	divideToRef(e, t) {
		return t.x = this._x / e.x, t.y = this._y / e.y, t.z = this._z / e.z, t.w = this._w / e.w, t;
	}
	divideInPlace(e) {
		return this.divideToRef(e, this);
	}
	minimizeInPlace(e) {
		return e.x < this._x && (this.x = e.x), e.y < this._y && (this.y = e.y), e.z < this._z && (this.z = e.z), e.w < this._w && (this.w = e.w), this;
	}
	maximizeInPlace(e) {
		return e.x > this._x && (this.x = e.x), e.y > this._y && (this.y = e.y), e.z > this._z && (this.z = e.z), e.w > this._w && (this.w = e.w), this;
	}
	minimizeInPlaceFromFloats(e, t, n, r) {
		return this.x = Math.min(e, this._x), this.y = Math.min(t, this._y), this.z = Math.min(n, this._z), this.w = Math.min(r, this._w), this;
	}
	maximizeInPlaceFromFloats(e, t, n, r) {
		return this.x = Math.max(e, this._x), this.y = Math.max(t, this._y), this.z = Math.max(n, this._z), this.w = Math.max(r, this._w), this;
	}
	floorToRef(e) {
		return e.x = Math.floor(this._x), e.y = Math.floor(this._y), e.z = Math.floor(this._z), e.w = Math.floor(this._w), e;
	}
	floor() {
		return new e(Math.floor(this._x), Math.floor(this._y), Math.floor(this._z), Math.floor(this._w));
	}
	fractToRef(e) {
		return e.x = this._x - Math.floor(this._x), e.y = this._y - Math.floor(this._y), e.z = this._z - Math.floor(this._z), e.w = this._w - Math.floor(this._w), e;
	}
	fract() {
		return new e(this._x - Math.floor(this._x), this._y - Math.floor(this._y), this._z - Math.floor(this._z), this._w - Math.floor(this._w));
	}
	length() {
		return Math.sqrt(this._x * this._x + this._y * this._y + this._z * this._z + this._w * this._w);
	}
	lengthSquared() {
		return this._x * this._x + this._y * this._y + this._z * this._z + this._w * this._w;
	}
	normalize() {
		return this.normalizeFromLength(this.length());
	}
	normalizeFromLength(e) {
		return e === 0 || e === 1 ? this : this.scaleInPlace(1 / e);
	}
	normalizeToNew() {
		return this.normalizeToRef(new e());
	}
	normalizeToRef(e) {
		let t = this.length();
		return t === 0 || t === 1 ? (e.x = this._x, e.y = this._y, e.z = this._z, e.w = this._w, e) : this.scaleToRef(1 / t, e);
	}
	toVector3() {
		return new E(this._x, this._y, this._z);
	}
	clone() {
		return new e(this._x, this._y, this._z, this._w);
	}
	copyFrom(e) {
		return this.x = e.x, this.y = e.y, this.z = e.z, this.w = e.w, this;
	}
	copyFromFloats(e, t, n, r) {
		return this.x = e, this.y = t, this.z = n, this.w = r, this;
	}
	set(e, t, n, r) {
		return this.copyFromFloats(e, t, n, r);
	}
	setAll(e) {
		return this.x = this.y = this.z = this.w = e, this;
	}
	dot(e) {
		return this._x * e.x + this._y * e.y + this._z * e.z + this._w * e.w;
	}
	static FromArray(t, n) {
		return n ||= 0, new e(t[n], t[n + 1], t[n + 2], t[n + 3]);
	}
	static FromArrayToRef(e, t, n) {
		return n.x = e[t], n.y = e[t + 1], n.z = e[t + 2], n.w = e[t + 3], n;
	}
	static FromFloatArrayToRef(t, n, r) {
		return e.FromArrayToRef(t, n, r), r;
	}
	static FromFloatsToRef(e, t, n, r, i) {
		return i.x = e, i.y = t, i.z = n, i.w = r, i;
	}
	static Zero() {
		return new e(0, 0, 0, 0);
	}
	static One() {
		return new e(1, 1, 1, 1);
	}
	static Random(t = 0, n = 1) {
		return new e(i(t, n), i(t, n), i(t, n), i(t, n));
	}
	static RandomToRef(e = 0, t = 1, n) {
		return n.x = i(e, t), n.y = i(e, t), n.z = i(e, t), n.w = i(e, t), n;
	}
	static Clamp(t, n, r) {
		return e.ClampToRef(t, n, r, new e());
	}
	static ClampToRef(e, t, n, r) {
		return r.x = a(e.x, t.x, n.x), r.y = a(e.y, t.y, n.y), r.z = a(e.z, t.z, n.z), r.w = a(e.w, t.w, n.w), r;
	}
	static CheckExtends(e, t, n) {
		t.minimizeInPlace(e), n.maximizeInPlace(e);
	}
	static get ZeroReadOnly() {
		return e._ZeroReadOnly;
	}
	static Normalize(t) {
		return e.NormalizeToRef(t, new e());
	}
	static NormalizeToRef(e, t) {
		return e.normalizeToRef(t), t;
	}
	static Minimize(t, n) {
		let r = new e();
		return r.copyFrom(t), r.minimizeInPlace(n), r;
	}
	static Maximize(t, n) {
		let r = new e();
		return r.copyFrom(t), r.maximizeInPlace(n), r;
	}
	static Distance(t, n) {
		return Math.sqrt(e.DistanceSquared(t, n));
	}
	static DistanceSquared(e, t) {
		let n = e.x - t.x, r = e.y - t.y, i = e.z - t.z, a = e.w - t.w;
		return n * n + r * r + i * i + a * a;
	}
	static Center(t, n) {
		return e.CenterToRef(t, n, new e());
	}
	static CenterToRef(e, t, n) {
		return n.x = (e.x + t.x) / 2, n.y = (e.y + t.y) / 2, n.z = (e.z + t.z) / 2, n.w = (e.w + t.w) / 2, n;
	}
	static TransformCoordinates(t, n) {
		return e.TransformCoordinatesToRef(t, n, new e());
	}
	static TransformCoordinatesToRef(t, n, r) {
		return e.TransformCoordinatesFromFloatsToRef(t._x, t._y, t._z, n, r), r;
	}
	static TransformCoordinatesFromFloatsToRef(e, t, n, r, i) {
		let a = r.m, o = e * a[0] + t * a[4] + n * a[8] + a[12], s = e * a[1] + t * a[5] + n * a[9] + a[13], c = e * a[2] + t * a[6] + n * a[10] + a[14], l = e * a[3] + t * a[7] + n * a[11] + a[15];
		return i.x = o, i.y = s, i.z = c, i.w = l, i;
	}
	static TransformNormal(t, n) {
		return e.TransformNormalToRef(t, n, new e());
	}
	static TransformNormalToRef(e, t, n) {
		let r = t.m, i = e.x * r[0] + e.y * r[4] + e.z * r[8], a = e.x * r[1] + e.y * r[5] + e.z * r[9], o = e.x * r[2] + e.y * r[6] + e.z * r[10];
		return n.x = i, n.y = a, n.z = o, n.w = e.w, n;
	}
	static TransformNormalFromFloatsToRef(e, t, n, r, i, a) {
		let o = i.m;
		return a.x = e * o[0] + t * o[4] + n * o[8], a.y = e * o[1] + t * o[5] + n * o[9], a.z = e * o[2] + t * o[6] + n * o[10], a.w = r, a;
	}
	static FromVector3(t, n = 0) {
		return new e(t._x, t._y, t._z, n);
	}
	static Dot(e, t) {
		return e.x * t.x + e.y * t.y + e.z * t.z + e.w * t.w;
	}
};
D._V8PerformanceHack = /*#__PURE__*/ new D(.5, .5, .5, .5), D._ZeroReadOnly = /*#__PURE__*/ D.Zero();
var O = class e {
	get x() {
		return this._x;
	}
	set x(e) {
		this._x = e, this._isDirty = !0;
	}
	get y() {
		return this._y;
	}
	set y(e) {
		this._y = e, this._isDirty = !0;
	}
	get z() {
		return this._z;
	}
	set z(e) {
		this._z = e, this._isDirty = !0;
	}
	get w() {
		return this._w;
	}
	set w(e) {
		this._w = e, this._isDirty = !0;
	}
	constructor(e = 0, t = 0, n = 0, r = 1) {
		this._isDirty = !0, this._x = e, this._y = t, this._z = n, this._w = r;
	}
	toString() {
		return `{X: ${this._x} Y: ${this._y} Z: ${this._z} W: ${this._w}}`;
	}
	getClassName() {
		return "Quaternion";
	}
	getHashCode() {
		let e = w(this._x), t = w(this._y), n = w(this._z), r = w(this._w), i = e;
		return i = i * 397 ^ t, i = i * 397 ^ n, i = i * 397 ^ r, i;
	}
	asArray() {
		return [
			this._x,
			this._y,
			this._z,
			this._w
		];
	}
	toArray(e, t = 0) {
		return e[t] = this._x, e[t + 1] = this._y, e[t + 2] = this._z, e[t + 3] = this._w, this;
	}
	fromArray(t, n = 0) {
		return e.FromArrayToRef(t, n, this);
	}
	equals(e) {
		return e && this._x === e._x && this._y === e._y && this._z === e._z && this._w === e._w;
	}
	equalsWithEpsilon(e, t = d) {
		return e && n(this._x, e._x, t) && n(this._y, e._y, t) && n(this._z, e._z, t) && n(this._w, e._w, t);
	}
	isApprox(e, t = d) {
		return e && (n(this._x, e._x, t) && n(this._y, e._y, t) && n(this._z, e._z, t) && n(this._w, e._w, t) || n(this._x, -e._x, t) && n(this._y, -e._y, t) && n(this._z, -e._z, t) && n(this._w, -e._w, t));
	}
	clone() {
		return new e(this._x, this._y, this._z, this._w);
	}
	copyFrom(e) {
		return this._x = e._x, this._y = e._y, this._z = e._z, this._w = e._w, this._isDirty = !0, this;
	}
	copyFromFloats(e, t, n, r) {
		return this._x = e, this._y = t, this._z = n, this._w = r, this._isDirty = !0, this;
	}
	set(e, t, n, r) {
		return this.copyFromFloats(e, t, n, r);
	}
	setAll(e) {
		return this.copyFromFloats(e, e, e, e);
	}
	add(t) {
		return new e(this._x + t._x, this._y + t._y, this._z + t._z, this._w + t._w);
	}
	addInPlace(e) {
		return this._x += e._x, this._y += e._y, this._z += e._z, this._w += e._w, this._isDirty = !0, this;
	}
	addToRef(e, t) {
		return t._x = this._x + e._x, t._y = this._y + e._y, t._z = this._z + e._z, t._w = this._w + e._w, t._isDirty = !0, t;
	}
	addInPlaceFromFloats(e, t, n, r) {
		return this._x += e, this._y += t, this._z += n, this._w += r, this._isDirty = !0, this;
	}
	subtractToRef(e, t) {
		return t._x = this._x - e._x, t._y = this._y - e._y, t._z = this._z - e._z, t._w = this._w - e._w, t._isDirty = !0, t;
	}
	subtractFromFloats(t, n, r, i) {
		return this.subtractFromFloatsToRef(t, n, r, i, new e());
	}
	subtractFromFloatsToRef(e, t, n, r, i) {
		return i._x = this._x - e, i._y = this._y - t, i._z = this._z - n, i._w = this._w - r, i._isDirty = !0, i;
	}
	subtract(t) {
		return new e(this._x - t._x, this._y - t._y, this._z - t._z, this._w - t._w);
	}
	subtractInPlace(e) {
		return this._x -= e._x, this._y -= e._y, this._z -= e._z, this._w -= e._w, this._isDirty = !0, this;
	}
	scale(t) {
		return new e(this._x * t, this._y * t, this._z * t, this._w * t);
	}
	scaleToRef(e, t) {
		return t._x = this._x * e, t._y = this._y * e, t._z = this._z * e, t._w = this._w * e, t._isDirty = !0, t;
	}
	scaleInPlace(e) {
		return this._x *= e, this._y *= e, this._z *= e, this._w *= e, this._isDirty = !0, this;
	}
	scaleAndAddToRef(e, t) {
		return t._x += this._x * e, t._y += this._y * e, t._z += this._z * e, t._w += this._w * e, t._isDirty = !0, t;
	}
	multiply(t) {
		let n = new e(0, 0, 0, 1);
		return this.multiplyToRef(t, n), n;
	}
	multiplyToRef(e, t) {
		let n = this._x * e._w + this._y * e._z - this._z * e._y + this._w * e._x, r = -this._x * e._z + this._y * e._w + this._z * e._x + this._w * e._y, i = this._x * e._y - this._y * e._x + this._z * e._w + this._w * e._z, a = -this._x * e._x - this._y * e._y - this._z * e._z + this._w * e._w;
		return t.copyFromFloats(n, r, i, a), t;
	}
	multiplyInPlace(e) {
		return this.multiplyToRef(e, this);
	}
	multiplyByFloats(e, t, n, r) {
		return this._x *= e, this._y *= t, this._z *= n, this._w *= r, this._isDirty = !0, this;
	}
	divide(e) {
		throw ReferenceError("Can not divide a quaternion");
	}
	divideToRef(e, t) {
		throw ReferenceError("Can not divide a quaternion");
	}
	divideInPlace(e) {
		throw ReferenceError("Can not divide a quaternion");
	}
	minimizeInPlace() {
		throw ReferenceError("Can not minimize a quaternion");
	}
	minimizeInPlaceFromFloats() {
		throw ReferenceError("Can not minimize a quaternion");
	}
	maximizeInPlace() {
		throw ReferenceError("Can not maximize a quaternion");
	}
	maximizeInPlaceFromFloats() {
		throw ReferenceError("Can not maximize a quaternion");
	}
	negate() {
		return this.negateToRef(new e());
	}
	negateInPlace() {
		return this._x = -this._x, this._y = -this._y, this._z = -this._z, this._w = -this._w, this._isDirty = !0, this;
	}
	negateToRef(e) {
		return e._x = -this._x, e._y = -this._y, e._z = -this._z, e._w = -this._w, e._isDirty = !0, e;
	}
	equalsToFloats(e, t, n, r) {
		return this._x === e && this._y === t && this._z === n && this._w === r;
	}
	floorToRef(e) {
		throw ReferenceError("Can not floor a quaternion");
	}
	floor() {
		throw ReferenceError("Can not floor a quaternion");
	}
	fractToRef(e) {
		throw ReferenceError("Can not fract a quaternion");
	}
	fract() {
		throw ReferenceError("Can not fract a quaternion");
	}
	conjugateToRef(e) {
		return e.copyFromFloats(-this._x, -this._y, -this._z, this._w), e;
	}
	conjugateInPlace() {
		return this._x *= -1, this._y *= -1, this._z *= -1, this._isDirty = !0, this;
	}
	conjugate() {
		return new e(-this._x, -this._y, -this._z, this._w);
	}
	invert() {
		let e = this.conjugate(), t = this.lengthSquared();
		return t == 0 || t == 1 || e.scaleInPlace(1 / t), e;
	}
	invertInPlace() {
		this.conjugateInPlace();
		let e = this.lengthSquared();
		return e == 0 || e == 1 || this.scaleInPlace(1 / e), this;
	}
	lengthSquared() {
		return this._x * this._x + this._y * this._y + this._z * this._z + this._w * this._w;
	}
	length() {
		return Math.sqrt(this.lengthSquared());
	}
	normalize() {
		return this.normalizeFromLength(this.length());
	}
	normalizeFromLength(e) {
		return e === 0 || e === 1 ? this : this.scaleInPlace(1 / e);
	}
	normalizeToNew() {
		let t = new e(0, 0, 0, 1);
		return this.normalizeToRef(t), t;
	}
	normalizeToRef(e) {
		let t = this.length();
		return t === 0 || t === 1 ? e.copyFromFloats(this._x, this._y, this._z, this._w) : this.scaleToRef(1 / t, e);
	}
	toEulerAngles() {
		let e = E.Zero();
		return this.toEulerAnglesToRef(e), e;
	}
	toEulerAnglesToRef(e) {
		let t = this._z, n = this._x, r = this._y, i = this._w, a = r * t - n * i;
		if (a < -.4999999) e._y = 2 * Math.atan2(r, i), e._x = Math.PI / 2, e._z = 0, e._isDirty = !0;
		else if (a > .4999999) e._y = 2 * Math.atan2(r, i), e._x = -Math.PI / 2, e._z = 0, e._isDirty = !0;
		else {
			let o = i * i, s = t * t, c = n * n, l = r * r;
			e._z = Math.atan2(2 * (n * r + t * i), -s - c + l + o), e._x = Math.asin(-2 * a), e._y = Math.atan2(2 * (t * n + r * i), s - c - l + o), e._isDirty = !0;
		}
		return e;
	}
	toAlphaBetaGammaToRef(e) {
		let t = this._z, n = this._x, r = this._y, i = this._w, a = Math.sqrt(n * n + r * r), o = Math.sqrt(t * t + i * i), s = 2 * Math.atan2(a, o), c = 2 * Math.atan2(t, i), l = 2 * Math.atan2(r, n), u = (c + l) / 2, d = (c - l) / 2;
		return e.set(d, s, u), e;
	}
	toRotationMatrix(e) {
		return k.FromQuaternionToRef(this, e), e;
	}
	fromRotationMatrix(t) {
		return e.FromRotationMatrixToRef(t, this), this;
	}
	dot(e) {
		return this._x * e._x + this._y * e._y + this._z * e._z + this._w * e._w;
	}
	toAxisAngle() {
		let e = E.Zero();
		return {
			axis: e,
			angle: this.toAxisAngleToRef(e)
		};
	}
	toAxisAngleToRef(e) {
		let t, n = Math.sqrt(this._x * this._x + this._y * this._y + this._z * this._z), r = this._w;
		return n > 0 ? (t = 2 * Math.atan2(n, r), e.set(this._x / n, this._y / n, this._z / n)) : (t = 0, e.set(1, 0, 0)), t;
	}
	static FromRotationMatrix(t) {
		let n = new e();
		return e.FromRotationMatrixToRef(t, n), n;
	}
	static FromRotationMatrixToRef(e, t) {
		let n = e.m, r = n[0], i = n[4], a = n[8], o = n[1], s = n[5], c = n[9], l = n[2], u = n[6], d = n[10], f = r + s + d, p;
		return f > 0 ? (p = .5 / Math.sqrt(f + 1), t._w = .25 / p, t._x = (u - c) * p, t._y = (a - l) * p, t._z = (o - i) * p, t._isDirty = !0) : r > s && r > d ? (p = 2 * Math.sqrt(1 + r - s - d), t._w = (u - c) / p, t._x = .25 * p, t._y = (i + o) / p, t._z = (a + l) / p, t._isDirty = !0) : s > d ? (p = 2 * Math.sqrt(1 + s - r - d), t._w = (a - l) / p, t._x = (i + o) / p, t._y = .25 * p, t._z = (c + u) / p, t._isDirty = !0) : (p = 2 * Math.sqrt(1 + d - r - s), t._w = (o - i) / p, t._x = (a + l) / p, t._y = (c + u) / p, t._z = .25 * p, t._isDirty = !0), t;
	}
	static Dot(e, t) {
		return e._x * t._x + e._y * t._y + e._z * t._z + e._w * t._w;
	}
	static AreClose(t, n, r = .1) {
		let i = e.Dot(t, n);
		return 1 - i * i <= r;
	}
	static SmoothToRef(t, n, r, i, o) {
		let s = i === 0 ? 1 : r / i;
		return s = a(s, 0, 1), e.SlerpToRef(t, n, s, o), o;
	}
	static Zero() {
		return new e(0, 0, 0, 0);
	}
	static Inverse(t) {
		return new e(-t._x, -t._y, -t._z, t._w);
	}
	static InverseToRef(e, t) {
		return t.set(-e._x, -e._y, -e._z, e._w), t;
	}
	static Identity() {
		return new e(0, 0, 0, 1);
	}
	static IsIdentity(e) {
		return e && e._x === 0 && e._y === 0 && e._z === 0 && e._w === 1;
	}
	static RotationAxis(t, n) {
		return e.RotationAxisToRef(t, n, new e());
	}
	static RotationAxisToRef(e, t, n) {
		n._w = Math.cos(t / 2);
		let r = Math.sin(t / 2) / e.length();
		return n._x = e._x * r, n._y = e._y * r, n._z = e._z * r, n._isDirty = !0, n;
	}
	static FromArray(t, n) {
		return n ||= 0, new e(t[n], t[n + 1], t[n + 2], t[n + 3]);
	}
	static FromArrayToRef(e, t, n) {
		return n._x = e[t], n._y = e[t + 1], n._z = e[t + 2], n._w = e[t + 3], n._isDirty = !0, n;
	}
	static FromFloatsToRef(e, t, n, r, i) {
		return i.copyFromFloats(e, t, n, r), i;
	}
	static FromEulerAngles(t, n, r) {
		let i = new e();
		return e.RotationYawPitchRollToRef(n, t, r, i), i;
	}
	static FromEulerAnglesToRef(t, n, r, i) {
		return e.RotationYawPitchRollToRef(n, t, r, i), i;
	}
	static FromEulerVector(t) {
		let n = new e();
		return e.RotationYawPitchRollToRef(t._y, t._x, t._z, n), n;
	}
	static FromEulerVectorToRef(t, n) {
		return e.RotationYawPitchRollToRef(t._y, t._x, t._z, n), n;
	}
	static FromUnitVectorsToRef(e, t, n, r = d) {
		let i = E.Dot(e, t) + 1;
		return i < r ? Math.abs(e.x) > Math.abs(e.z) ? n.set(-e.y, e.x, 0, 0) : n.set(0, -e.z, e.y, 0) : (E.CrossToRef(e, t, j.Vector3[0]), n.set(j.Vector3[0].x, j.Vector3[0].y, j.Vector3[0].z, i)), n.normalize();
	}
	static RotationYawPitchRoll(t, n, r) {
		let i = new e();
		return e.RotationYawPitchRollToRef(t, n, r, i), i;
	}
	static RotationYawPitchRollToRef(e, t, n, r) {
		let i = n * .5, a = t * .5, o = e * .5, s = Math.sin(i), c = Math.cos(i), l = Math.sin(a), u = Math.cos(a), d = Math.sin(o), f = Math.cos(o);
		return r._x = f * l * c + d * u * s, r._y = d * u * c - f * l * s, r._z = f * u * s - d * l * c, r._w = f * u * c + d * l * s, r._isDirty = !0, r;
	}
	static RotationAlphaBetaGamma(t, n, r) {
		let i = new e();
		return e.RotationAlphaBetaGammaToRef(t, n, r, i), i;
	}
	static RotationAlphaBetaGammaToRef(e, t, n, r) {
		let i = (n + e) * .5, a = (n - e) * .5, o = t * .5;
		return r._x = Math.cos(a) * Math.sin(o), r._y = Math.sin(a) * Math.sin(o), r._z = Math.sin(i) * Math.cos(o), r._w = Math.cos(i) * Math.cos(o), r._isDirty = !0, r;
	}
	static RotationQuaternionFromAxis(t, n, r) {
		let i = new e(0, 0, 0, 0);
		return e.RotationQuaternionFromAxisToRef(t, n, r, i), i;
	}
	static RotationQuaternionFromAxisToRef(t, n, r, i) {
		let a = A.Matrix[0];
		return t = t.normalizeToRef(A.Vector3[0]), n = n.normalizeToRef(A.Vector3[1]), r = r.normalizeToRef(A.Vector3[2]), k.FromXYZAxesToRef(t, n, r, a), e.FromRotationMatrixToRef(a, i), i;
	}
	static FromLookDirectionLH(t, n) {
		let r = new e();
		return e.FromLookDirectionLHToRef(t, n, r), r;
	}
	static FromLookDirectionLHToRef(t, n, r) {
		let i = A.Matrix[0];
		return k.LookDirectionLHToRef(t, n, i), e.FromRotationMatrixToRef(i, r), r;
	}
	static FromLookDirectionRH(t, n) {
		let r = new e();
		return e.FromLookDirectionRHToRef(t, n, r), r;
	}
	static FromLookDirectionRHToRef(t, n, r) {
		let i = A.Matrix[0];
		return k.LookDirectionRHToRef(t, n, i), e.FromRotationMatrixToRef(i, r);
	}
	static Slerp(t, n, r) {
		let i = e.Identity();
		return e.SlerpToRef(t, n, r, i), i;
	}
	static SlerpToRef(e, t, n, r) {
		let i, a, o = e._x * t._x + e._y * t._y + e._z * t._z + e._w * t._w, s = !1;
		if (o < 0 && (s = !0, o = -o), o > .999999) a = 1 - n, i = s ? -n : n;
		else {
			let e = Math.acos(o), t = 1 / Math.sin(e);
			a = Math.sin((1 - n) * e) * t, i = s ? -Math.sin(n * e) * t : Math.sin(n * e) * t;
		}
		return r._x = a * e._x + i * t._x, r._y = a * e._y + i * t._y, r._z = a * e._z + i * t._z, r._w = a * e._w + i * t._w, r._isDirty = !0, r;
	}
	static Hermite(t, n, r, i, a) {
		let o = a * a, s = a * o, c = 2 * s - 3 * o + 1, l = -2 * s + 3 * o, u = s - 2 * o + a, d = s - o, f = t._x * c + r._x * l + n._x * u + i._x * d, p = t._y * c + r._y * l + n._y * u + i._y * d, m = t._z * c + r._z * l + n._z * u + i._z * d, h = t._w * c + r._w * l + n._w * u + i._w * d;
		return new e(f, p, m, h);
	}
	static Hermite1stDerivative(t, n, r, i, a) {
		let o = new e();
		return this.Hermite1stDerivativeToRef(t, n, r, i, a, o), o;
	}
	static Hermite1stDerivativeToRef(e, t, n, r, i, a) {
		let o = i * i;
		return a._x = (o - i) * 6 * e._x + (3 * o - 4 * i + 1) * t._x + (-o + i) * 6 * n._x + (3 * o - 2 * i) * r._x, a._y = (o - i) * 6 * e._y + (3 * o - 4 * i + 1) * t._y + (-o + i) * 6 * n._y + (3 * o - 2 * i) * r._y, a._z = (o - i) * 6 * e._z + (3 * o - 4 * i + 1) * t._z + (-o + i) * 6 * n._z + (3 * o - 2 * i) * r._z, a._w = (o - i) * 6 * e._w + (3 * o - 4 * i + 1) * t._w + (-o + i) * 6 * n._w + (3 * o - 2 * i) * r._w, a._isDirty = !0, a;
	}
	static Normalize(t) {
		let n = e.Zero();
		return e.NormalizeToRef(t, n), n;
	}
	static NormalizeToRef(e, t) {
		return e.normalizeToRef(t), t;
	}
	static Clamp(t, n, r) {
		let i = new e();
		return e.ClampToRef(t, n, r, i), i;
	}
	static ClampToRef(e, t, n, r) {
		return r.copyFromFloats(a(e.x, t.x, n.x), a(e.y, t.y, n.y), a(e.z, t.z, n.z), a(e.w, t.w, n.w));
	}
	static Random(t = 0, n = 1) {
		return new e(i(t, n), i(t, n), i(t, n), i(t, n));
	}
	static RandomToRef(e = 0, t = 1, n) {
		return n.copyFromFloats(i(e, t), i(e, t), i(e, t), i(e, t));
	}
	static Minimize() {
		throw ReferenceError("Quaternion.Minimize does not make sense");
	}
	static Maximize() {
		throw ReferenceError("Quaternion.Maximize does not make sense");
	}
	static Distance(t, n) {
		return Math.sqrt(e.DistanceSquared(t, n));
	}
	static DistanceSquared(e, t) {
		let n = e.x - t.x, r = e.y - t.y, i = e.z - t.z, a = e.w - t.w;
		return n * n + r * r + i * i + a * a;
	}
	static Center(t, n) {
		return e.CenterToRef(t, n, e.Zero());
	}
	static CenterToRef(e, t, n) {
		return n.copyFromFloats((e.x + t.x) / 2, (e.y + t.y) / 2, (e.z + t.z) / 2, (e.w + t.w) / 2);
	}
};
O._V8PerformanceHack = /*#__PURE__*/ new O(.5, .5, .5, .5);
var k = class e {
	static get Use64Bits() {
		return s.MatrixUse64Bits;
	}
	get m() {
		return this._m;
	}
	markAsUpdated() {
		this.updateFlag = _._UpdateFlagSeed++, this._isIdentity = !1, this._isIdentity3x2 = !1, this._isIdentityDirty = !0, this._isIdentity3x2Dirty = !0;
	}
	_updateIdentityStatus(e, t = !1, n = !1, r = !0) {
		this._isIdentity = e, this._isIdentity3x2 = e || n, this._isIdentityDirty = !this._isIdentity && t, this._isIdentity3x2Dirty = !this._isIdentity3x2 && r;
	}
	constructor() {
		this._isIdentity = !1, this._isIdentityDirty = !0, this._isIdentity3x2 = !0, this._isIdentity3x2Dirty = !0, this.updateFlag = -1, s.MatrixTrackPrecisionChange && s.MatrixTrackedMatrices.push(this), this._m = new s.MatrixCurrentType(16), this.markAsUpdated();
	}
	isIdentity() {
		if (this._isIdentityDirty) {
			this._isIdentityDirty = !1;
			let e = this._m;
			this._isIdentity = e[0] === 1 && e[1] === 0 && e[2] === 0 && e[3] === 0 && e[4] === 0 && e[5] === 1 && e[6] === 0 && e[7] === 0 && e[8] === 0 && e[9] === 0 && e[10] === 1 && e[11] === 0 && e[12] === 0 && e[13] === 0 && e[14] === 0 && e[15] === 1;
		}
		return this._isIdentity;
	}
	isIdentityAs3x2() {
		return this._isIdentity3x2Dirty && (this._isIdentity3x2Dirty = !1, this._isIdentity3x2 = this._m[0] !== 1 || this._m[5] !== 1 || this._m[15] !== 1 ? !1 : this._m[1] === 0 && this._m[2] === 0 && this._m[3] === 0 && this._m[4] === 0 && this._m[6] === 0 && this._m[7] === 0 && this._m[8] === 0 && this._m[9] === 0 && this._m[10] === 0 && this._m[11] === 0 && this._m[12] === 0 && this._m[13] === 0 && this._m[14] === 0), this._isIdentity3x2;
	}
	determinant() {
		if (this._isIdentity === !0) return 1;
		let e = this._m, t = e[0], n = e[1], r = e[2], i = e[3], a = e[4], o = e[5], s = e[6], c = e[7], l = e[8], u = e[9], d = e[10], f = e[11], p = e[12], m = e[13], h = e[14], g = e[15], _ = d * g - h * f, v = u * g - m * f, y = u * h - m * d, b = l * g - p * f, x = l * h - d * p, S = l * m - p * u, C = +(o * _ - s * v + c * y), w = -(a * _ - s * b + c * x), T = +(a * v - o * b + c * S), E = -(a * y - o * x + s * S);
		return t * C + n * w + r * T + i * E;
	}
	toString() {
		return `{${this.m[0]}, ${this.m[1]}, ${this.m[2]}, ${this.m[3]}\n${this.m[4]}, ${this.m[5]}, ${this.m[6]}, ${this.m[7]}\n${this.m[8]}, ${this.m[9]}, ${this.m[10]}, ${this.m[11]}\n${this.m[12]}, ${this.m[13]}, ${this.m[14]}, ${this.m[15]}}`;
	}
	toArray(e = null, t = 0) {
		if (!e) return this._m;
		let n = this._m;
		for (let r = 0; r < 16; r++) e[t + r] = n[r];
		return this;
	}
	asArray() {
		return this._m;
	}
	fromArray(t, n = 0) {
		return e.FromArrayToRef(t, n, this);
	}
	copyFromFloats(...t) {
		return e.FromArrayToRef(t, 0, this);
	}
	set(...e) {
		let t = this._m;
		for (let n = 0; n < 16; n++) t[n] = e[n];
		return this.markAsUpdated(), this;
	}
	setAll(e) {
		let t = this._m;
		for (let n = 0; n < 16; n++) t[n] = e;
		return this.markAsUpdated(), this;
	}
	invert() {
		return this.invertToRef(this), this;
	}
	reset() {
		return e.FromValuesToRef(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, this), this._updateIdentityStatus(!1), this;
	}
	add(t) {
		let n = new e();
		return this.addToRef(t, n), n;
	}
	addToRef(e, t) {
		let n = this._m, r = t._m, i = e.m;
		for (let e = 0; e < 16; e++) r[e] = n[e] + i[e];
		return t.markAsUpdated(), t;
	}
	addToSelf(e) {
		let t = this._m, n = e.m;
		return t[0] += n[0], t[1] += n[1], t[2] += n[2], t[3] += n[3], t[4] += n[4], t[5] += n[5], t[6] += n[6], t[7] += n[7], t[8] += n[8], t[9] += n[9], t[10] += n[10], t[11] += n[11], t[12] += n[12], t[13] += n[13], t[14] += n[14], t[15] += n[15], this.markAsUpdated(), this;
	}
	addInPlace(e) {
		let t = this._m, n = e.m;
		for (let e = 0; e < 16; e++) t[e] += n[e];
		return this.markAsUpdated(), this;
	}
	addInPlaceFromFloats(...e) {
		let t = this._m;
		for (let n = 0; n < 16; n++) t[n] += e[n];
		return this.markAsUpdated(), this;
	}
	subtract(e) {
		let t = this._m, n = e.m;
		for (let e = 0; e < 16; e++) t[e] -= n[e];
		return this.markAsUpdated(), this;
	}
	subtractToRef(e, t) {
		let n = this._m, r = e.m, i = t._m;
		for (let e = 0; e < 16; e++) i[e] = n[e] - r[e];
		return t.markAsUpdated(), t;
	}
	subtractInPlace(e) {
		let t = this._m, n = e.m;
		for (let e = 0; e < 16; e++) t[e] -= n[e];
		return this.markAsUpdated(), this;
	}
	subtractFromFloats(...t) {
		return this.subtractFromFloatsToRef(...t, new e());
	}
	subtractFromFloatsToRef(...e) {
		let t = e.pop(), n = this._m, r = t._m, i = e;
		for (let e = 0; e < 16; e++) r[e] = n[e] - i[e];
		return t.markAsUpdated(), t;
	}
	invertToRef(t) {
		return this._isIdentity === !0 ? (e.IdentityToRef(t), t) : (C(this, t.asArray()) ? t.markAsUpdated() : t.copyFrom(this), t);
	}
	addAtIndex(e, t) {
		return this._m[e] += t, this.markAsUpdated(), this;
	}
	multiplyAtIndex(e, t) {
		return this._m[e] *= t, this.markAsUpdated(), this;
	}
	setTranslationFromFloats(e, t, n) {
		return this._m[12] = e, this._m[13] = t, this._m[14] = n, this.markAsUpdated(), this;
	}
	addTranslationFromFloats(e, t, n) {
		return this._m[12] += e, this._m[13] += t, this._m[14] += n, this.markAsUpdated(), this;
	}
	setTranslation(e) {
		return this.setTranslationFromFloats(e._x, e._y, e._z);
	}
	getTranslation() {
		return new E(this._m[12], this._m[13], this._m[14]);
	}
	getTranslationToRef(e) {
		return e.x = this._m[12], e.y = this._m[13], e.z = this._m[14], e;
	}
	removeRotationAndScaling() {
		let t = this.m;
		return e.FromValuesToRef(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, t[12], t[13], t[14], t[15], this), this._updateIdentityStatus(t[12] === 0 && t[13] === 0 && t[14] === 0 && t[15] === 1), this;
	}
	copyFrom(e) {
		e.copyToArray(this._m);
		let t = e;
		return this.updateFlag = t.updateFlag, this._updateIdentityStatus(t._isIdentity, t._isIdentityDirty, t._isIdentity3x2, t._isIdentity3x2Dirty), this;
	}
	copyToArray(e, t = 0) {
		return x(this, e, t), this;
	}
	multiply(t) {
		let n = new e();
		return this.multiplyToRef(t, n), n;
	}
	multiplyInPlace(e) {
		let t = this._m, n = e.m;
		for (let e = 0; e < 16; e++) t[e] *= n[e];
		return this.markAsUpdated(), this;
	}
	multiplyByFloats(...e) {
		let t = this._m;
		for (let n = 0; n < 16; n++) t[n] *= e[n];
		return this.markAsUpdated(), this;
	}
	multiplyByFloatsToRef(...e) {
		let t = e.pop(), n = this._m, r = t._m, i = e;
		for (let e = 0; e < 16; e++) r[e] = n[e] * i[e];
		return t.markAsUpdated(), t;
	}
	multiplyToRef(e, t) {
		return this._isIdentity ? (t.copyFrom(e), t) : e._isIdentity ? (t.copyFrom(this), t) : (this.multiplyToArray(e, t._m, 0), t.markAsUpdated(), t);
	}
	multiplyToArray(e, t, n) {
		return y(this, e, t, n), this;
	}
	divide(t) {
		return this.divideToRef(t, new e());
	}
	divideToRef(e, t) {
		let n = this._m, r = e.m, i = t._m;
		for (let e = 0; e < 16; e++) i[e] = n[e] / r[e];
		return t.markAsUpdated(), t;
	}
	divideInPlace(e) {
		let t = this._m, n = e.m;
		for (let e = 0; e < 16; e++) t[e] /= n[e];
		return this.markAsUpdated(), this;
	}
	minimizeInPlace(e) {
		let t = this._m, n = e.m;
		for (let e = 0; e < 16; e++) t[e] = Math.min(t[e], n[e]);
		return this.markAsUpdated(), this;
	}
	minimizeInPlaceFromFloats(...e) {
		let t = this._m;
		for (let n = 0; n < 16; n++) t[n] = Math.min(t[n], e[n]);
		return this.markAsUpdated(), this;
	}
	maximizeInPlace(e) {
		let t = this._m, n = e.m;
		for (let e = 0; e < 16; e++) t[e] = Math.max(t[e], n[e]);
		return this.markAsUpdated(), this;
	}
	maximizeInPlaceFromFloats(...e) {
		let t = this._m;
		for (let n = 0; n < 16; n++) t[n] = Math.max(t[n], e[n]);
		return this.markAsUpdated(), this;
	}
	negate() {
		return this.negateToRef(new e());
	}
	negateInPlace() {
		let e = this._m;
		for (let t = 0; t < 16; t++) e[t] = -e[t];
		return this.markAsUpdated(), this;
	}
	negateToRef(e) {
		let t = this._m, n = e._m;
		for (let e = 0; e < 16; e++) n[e] = -t[e];
		return e.markAsUpdated(), e;
	}
	equals(e) {
		let t = e;
		if (!t) return !1;
		if ((this._isIdentity || t._isIdentity) && !this._isIdentityDirty && !t._isIdentityDirty) return this._isIdentity && t._isIdentity;
		let n = this.m, r = t.m;
		return n[0] === r[0] && n[1] === r[1] && n[2] === r[2] && n[3] === r[3] && n[4] === r[4] && n[5] === r[5] && n[6] === r[6] && n[7] === r[7] && n[8] === r[8] && n[9] === r[9] && n[10] === r[10] && n[11] === r[11] && n[12] === r[12] && n[13] === r[13] && n[14] === r[14] && n[15] === r[15];
	}
	equalsWithEpsilon(e, t = 0) {
		let r = this._m, i = e.m;
		for (let e = 0; e < 16; e++) if (!n(r[e], i[e], t)) return !1;
		return !0;
	}
	equalsToFloats(...e) {
		let t = this._m;
		for (let n = 0; n < 16; n++) if (t[n] != e[n]) return !1;
		return !0;
	}
	floor() {
		return this.floorToRef(new e());
	}
	floorToRef(e) {
		let t = this._m, n = e._m;
		for (let e = 0; e < 16; e++) n[e] = Math.floor(t[e]);
		return e.markAsUpdated(), e;
	}
	fract() {
		return this.fractToRef(new e());
	}
	fractToRef(e) {
		let t = this._m, n = e._m;
		for (let e = 0; e < 16; e++) n[e] = t[e] - Math.floor(t[e]);
		return e.markAsUpdated(), e;
	}
	clone() {
		let t = new e();
		return t.copyFrom(this), t;
	}
	getClassName() {
		return "Matrix";
	}
	getHashCode() {
		let e = w(this._m[0]);
		for (let t = 1; t < 16; t++) e = e * 397 ^ w(this._m[t]);
		return e;
	}
	decomposeToTransformNode(e) {
		return e.rotationQuaternion = e.rotationQuaternion || new O(), this.decompose(e.scaling, e.rotationQuaternion, e.position);
	}
	decompose(t, n, r, i, a = !0) {
		if (this._isIdentity) return r && r.setAll(0), t && t.setAll(1), n && n.copyFromFloats(0, 0, 0, 1), !0;
		let o = this._m;
		if (r && r.copyFromFloats(o[12], o[13], o[14]), t ||= A.Vector3[0], t.x = Math.sqrt(o[0] * o[0] + o[1] * o[1] + o[2] * o[2]), t.y = Math.sqrt(o[4] * o[4] + o[5] * o[5] + o[6] * o[6]), t.z = Math.sqrt(o[8] * o[8] + o[9] * o[9] + o[10] * o[10]), i) {
			let e = (a ? i.absoluteScaling.x : i.scaling.x) < 0 ? -1 : 1, n = (a ? i.absoluteScaling.y : i.scaling.y) < 0 ? -1 : 1, r = (a ? i.absoluteScaling.z : i.scaling.z) < 0 ? -1 : 1;
			t.x *= e, t.y *= n, t.z *= r;
		} else this.determinant() <= 0 && (t.y *= -1);
		if (t._x === 0 || t._y === 0 || t._z === 0) return n && n.copyFromFloats(0, 0, 0, 1), !1;
		if (n) {
			let r = 1 / t._x, i = 1 / t._y, a = 1 / t._z;
			e.FromValuesToRef(o[0] * r, o[1] * r, o[2] * r, 0, o[4] * i, o[5] * i, o[6] * i, 0, o[8] * a, o[9] * a, o[10] * a, 0, 0, 0, 0, 1, A.Matrix[0]), O.FromRotationMatrixToRef(A.Matrix[0], n);
		}
		return !0;
	}
	getRow(e) {
		if (e < 0 || e > 3) return null;
		let t = e * 4;
		return new D(this._m[t + 0], this._m[t + 1], this._m[t + 2], this._m[t + 3]);
	}
	getRowToRef(e, t) {
		if (e >= 0 && e <= 3) {
			let n = e * 4;
			t.x = this._m[n + 0], t.y = this._m[n + 1], t.z = this._m[n + 2], t.w = this._m[n + 3];
		}
		return t;
	}
	setRow(e, t) {
		return this.setRowFromFloats(e, t.x, t.y, t.z, t.w);
	}
	transpose() {
		let t = new e();
		return e.TransposeToRef(this, t), t;
	}
	transposeToRef(t) {
		return e.TransposeToRef(this, t), t;
	}
	setRowFromFloats(e, t, n, r, i) {
		if (e < 0 || e > 3) return this;
		let a = e * 4;
		return this._m[a + 0] = t, this._m[a + 1] = n, this._m[a + 2] = r, this._m[a + 3] = i, this.markAsUpdated(), this;
	}
	scale(t) {
		let n = new e();
		return this.scaleToRef(t, n), n;
	}
	scaleToRef(e, t) {
		for (let n = 0; n < 16; n++) t._m[n] = this._m[n] * e;
		return t.markAsUpdated(), t;
	}
	scaleAndAddToRef(e, t) {
		for (let n = 0; n < 16; n++) t._m[n] += this._m[n] * e;
		return t.markAsUpdated(), t;
	}
	scaleInPlace(e) {
		let t = this._m;
		for (let n = 0; n < 16; n++) t[n] *= e;
		return this.markAsUpdated(), this;
	}
	toNormalMatrix(t) {
		let n = A.Matrix[0];
		this.invertToRef(n), n.transposeToRef(t);
		let r = t._m;
		return e.FromValuesToRef(r[0], r[1], r[2], 0, r[4], r[5], r[6], 0, r[8], r[9], r[10], 0, 0, 0, 0, 1, t), t;
	}
	getRotationMatrix() {
		let t = new e();
		return this.getRotationMatrixToRef(t), t;
	}
	getRotationMatrixToRef(t) {
		let n = A.Vector3[0];
		if (!this.decompose(n)) return e.IdentityToRef(t), t;
		let r = this._m, i = 1 / n._x, a = 1 / n._y, o = 1 / n._z;
		return e.FromValuesToRef(r[0] * i, r[1] * i, r[2] * i, 0, r[4] * a, r[5] * a, r[6] * a, 0, r[8] * o, r[9] * o, r[10] * o, 0, 0, 0, 0, 1, t), t;
	}
	toggleModelMatrixHandInPlace() {
		let e = this._m;
		return e[2] *= -1, e[6] *= -1, e[8] *= -1, e[9] *= -1, e[14] *= -1, this.markAsUpdated(), this;
	}
	toggleProjectionMatrixHandInPlace() {
		let e = this._m;
		return e[8] *= -1, e[9] *= -1, e[10] *= -1, e[11] *= -1, this.markAsUpdated(), this;
	}
	_convertProjectionToHalfZRangeInPlace() {
		return this.multiplyToRef(M, this), this;
	}
	static FromArray(t, n = 0) {
		let r = new e();
		return e.FromArrayToRef(t, n, r), r;
	}
	static FromArrayToRef(e, t, n) {
		for (let r = 0; r < 16; r++) n._m[r] = e[r + t];
		return n.markAsUpdated(), n;
	}
	static FromFloat32ArrayToRefScaled(e, t, n, r) {
		return r._m[0] = e[0 + t] * n, r._m[1] = e[1 + t] * n, r._m[2] = e[2 + t] * n, r._m[3] = e[3 + t] * n, r._m[4] = e[4 + t] * n, r._m[5] = e[5 + t] * n, r._m[6] = e[6 + t] * n, r._m[7] = e[7 + t] * n, r._m[8] = e[8 + t] * n, r._m[9] = e[9 + t] * n, r._m[10] = e[10 + t] * n, r._m[11] = e[11 + t] * n, r._m[12] = e[12 + t] * n, r._m[13] = e[13 + t] * n, r._m[14] = e[14 + t] * n, r._m[15] = e[15 + t] * n, r.markAsUpdated(), r;
	}
	static get IdentityReadOnly() {
		return e._IdentityReadOnly;
	}
	static FromValuesToRef(e, t, n, r, i, a, o, s, c, l, u, d, f, p, m, h, g) {
		let _ = g._m;
		_[0] = e, _[1] = t, _[2] = n, _[3] = r, _[4] = i, _[5] = a, _[6] = o, _[7] = s, _[8] = c, _[9] = l, _[10] = u, _[11] = d, _[12] = f, _[13] = p, _[14] = m, _[15] = h, g.markAsUpdated();
	}
	static FromValues(t, n, r, i, a, o, s, c, l, u, d, f, p, m, h, g) {
		let _ = new e(), v = _._m;
		return v[0] = t, v[1] = n, v[2] = r, v[3] = i, v[4] = a, v[5] = o, v[6] = s, v[7] = c, v[8] = l, v[9] = u, v[10] = d, v[11] = f, v[12] = p, v[13] = m, v[14] = h, v[15] = g, _.markAsUpdated(), _;
	}
	static Compose(t, n, r) {
		let i = new e();
		return e.ComposeToRef(t, n, r, i), i;
	}
	static ComposeToRef(e, t, n, r) {
		let i = r._m, a = t._x, o = t._y, s = t._z, c = t._w, l = a + a, u = o + o, d = s + s, f = a * l, p = a * u, m = a * d, h = o * u, g = o * d, _ = s * d, v = c * l, y = c * u, b = c * d, x = e._x, S = e._y, C = e._z;
		return i[0] = (1 - (h + _)) * x, i[1] = (p + b) * x, i[2] = (m - y) * x, i[3] = 0, i[4] = (p - b) * S, i[5] = (1 - (f + _)) * S, i[6] = (g + v) * S, i[7] = 0, i[8] = (m + y) * C, i[9] = (g - v) * C, i[10] = (1 - (f + h)) * C, i[11] = 0, i[12] = n._x, i[13] = n._y, i[14] = n._z, i[15] = 1, r.markAsUpdated(), r;
	}
	static Identity() {
		let t = e.FromValues(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);
		return t._updateIdentityStatus(!0), t;
	}
	static IdentityToRef(t) {
		return e.FromValuesToRef(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, t), t._updateIdentityStatus(!0), t;
	}
	static Zero() {
		let t = e.FromValues(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
		return t._updateIdentityStatus(!1), t;
	}
	static RotationX(t) {
		let n = new e();
		return e.RotationXToRef(t, n), n;
	}
	static Invert(t) {
		let n = new e();
		return t.invertToRef(n), n;
	}
	static RotationXToRef(t, n) {
		let r = Math.sin(t), i = Math.cos(t);
		return e.FromValuesToRef(1, 0, 0, 0, 0, i, r, 0, 0, -r, i, 0, 0, 0, 0, 1, n), n._updateIdentityStatus(i === 1 && r === 0), n;
	}
	static RotationY(t) {
		let n = new e();
		return e.RotationYToRef(t, n), n;
	}
	static RotationYToRef(t, n) {
		let r = Math.sin(t), i = Math.cos(t);
		return e.FromValuesToRef(i, 0, -r, 0, 0, 1, 0, 0, r, 0, i, 0, 0, 0, 0, 1, n), n._updateIdentityStatus(i === 1 && r === 0), n;
	}
	static RotationZ(t) {
		let n = new e();
		return e.RotationZToRef(t, n), n;
	}
	static RotationZToRef(t, n) {
		let r = Math.sin(t), i = Math.cos(t);
		return e.FromValuesToRef(i, r, 0, 0, -r, i, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, n), n._updateIdentityStatus(i === 1 && r === 0), n;
	}
	static RotationAxis(t, n) {
		let r = new e();
		return e.RotationAxisToRef(t, n, r), r;
	}
	static RotationAxisToRef(e, t, n) {
		let r = Math.sin(-t), i = Math.cos(-t), a = 1 - i;
		e = e.normalizeToRef(A.Vector3[0]);
		let o = n._m;
		return o[0] = e._x * e._x * a + i, o[1] = e._x * e._y * a - e._z * r, o[2] = e._x * e._z * a + e._y * r, o[3] = 0, o[4] = e._y * e._x * a + e._z * r, o[5] = e._y * e._y * a + i, o[6] = e._y * e._z * a - e._x * r, o[7] = 0, o[8] = e._z * e._x * a - e._y * r, o[9] = e._z * e._y * a + e._x * r, o[10] = e._z * e._z * a + i, o[11] = 0, o[12] = 0, o[13] = 0, o[14] = 0, o[15] = 1, n.markAsUpdated(), n;
	}
	static RotationAlignToRef(e, t, n, r = !1) {
		let i = E.Dot(t, e), a = n._m;
		if (i < -.999) a[0] = -1, a[1] = 0, a[2] = 0, a[3] = 0, a[4] = 0, a[5] = r ? 1 : -1, a[6] = 0, a[7] = 0, a[8] = 0, a[9] = 0, a[10] = r ? -1 : 1, a[11] = 0;
		else {
			let n = E.Cross(t, e), r = 1 / (1 + i);
			a[0] = n._x * n._x * r + i, a[1] = n._y * n._x * r - n._z, a[2] = n._z * n._x * r + n._y, a[3] = 0, a[4] = n._x * n._y * r + n._z, a[5] = n._y * n._y * r + i, a[6] = n._z * n._y * r - n._x, a[7] = 0, a[8] = n._x * n._z * r - n._y, a[9] = n._y * n._z * r + n._x, a[10] = n._z * n._z * r + i, a[11] = 0;
		}
		return a[12] = 0, a[13] = 0, a[14] = 0, a[15] = 1, n.markAsUpdated(), n;
	}
	static RotationYawPitchRoll(t, n, r) {
		let i = new e();
		return e.RotationYawPitchRollToRef(t, n, r, i), i;
	}
	static RotationYawPitchRollToRef(e, t, n, r) {
		return O.RotationYawPitchRollToRef(e, t, n, A.Quaternion[0]), A.Quaternion[0].toRotationMatrix(r), r;
	}
	static Scaling(t, n, r) {
		let i = new e();
		return e.ScalingToRef(t, n, r, i), i;
	}
	static ScalingToRef(t, n, r, i) {
		return e.FromValuesToRef(t, 0, 0, 0, 0, n, 0, 0, 0, 0, r, 0, 0, 0, 0, 1, i), i._updateIdentityStatus(t === 1 && n === 1 && r === 1), i;
	}
	static Translation(t, n, r) {
		let i = new e();
		return e.TranslationToRef(t, n, r, i), i;
	}
	static TranslationToRef(t, n, r, i) {
		return e.FromValuesToRef(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, t, n, r, 1, i), i._updateIdentityStatus(t === 0 && n === 0 && r === 0), i;
	}
	static Lerp(t, n, r) {
		let i = new e();
		return e.LerpToRef(t, n, r, i), i;
	}
	static LerpToRef(e, t, n, r) {
		let i = r._m, a = e.m, o = t.m;
		for (let e = 0; e < 16; e++) i[e] = a[e] * (1 - n) + o[e] * n;
		return r.markAsUpdated(), r;
	}
	static DecomposeLerp(t, n, r) {
		let i = new e();
		return e.DecomposeLerpToRef(t, n, r, i), i;
	}
	static DecomposeLerpToRef(t, n, r, i) {
		let a = A.Vector3[0], o = A.Quaternion[0], s = A.Vector3[1];
		t.decompose(a, o, s);
		let c = A.Vector3[2], l = A.Quaternion[1], u = A.Vector3[3];
		n.decompose(c, l, u);
		let d = A.Vector3[4];
		E.LerpToRef(a, c, r, d);
		let f = A.Quaternion[2];
		O.SlerpToRef(o, l, r, f);
		let p = A.Vector3[5];
		return E.LerpToRef(s, u, r, p), e.ComposeToRef(d, f, p, i), i;
	}
	static LookAtLH(t, n, r) {
		let i = new e();
		return e.LookAtLHToRef(t, n, r, i), i;
	}
	static LookAtLHToRef(t, n, r, i) {
		let a = A.Vector3[0], o = A.Vector3[1], s = A.Vector3[2];
		n.subtractToRef(t, s), s.normalize(), E.CrossToRef(r, s, a);
		let c = a.lengthSquared();
		c === 0 ? a.x = 1 : a.normalizeFromLength(Math.sqrt(c)), E.CrossToRef(s, a, o), o.normalize();
		let l = -E.Dot(a, t), u = -E.Dot(o, t), d = -E.Dot(s, t);
		return e.FromValuesToRef(a._x, o._x, s._x, 0, a._y, o._y, s._y, 0, a._z, o._z, s._z, 0, l, u, d, 1, i), i;
	}
	static LookAtRH(t, n, r) {
		let i = new e();
		return e.LookAtRHToRef(t, n, r, i), i;
	}
	static LookAtRHToRef(t, n, r, i) {
		let a = A.Vector3[0], o = A.Vector3[1], s = A.Vector3[2];
		t.subtractToRef(n, s), s.normalize(), E.CrossToRef(r, s, a);
		let c = a.lengthSquared();
		c === 0 ? a.x = 1 : a.normalizeFromLength(Math.sqrt(c)), E.CrossToRef(s, a, o), o.normalize();
		let l = -E.Dot(a, t), u = -E.Dot(o, t), d = -E.Dot(s, t);
		return e.FromValuesToRef(a._x, o._x, s._x, 0, a._y, o._y, s._y, 0, a._z, o._z, s._z, 0, l, u, d, 1, i), i;
	}
	static LookDirectionLH(t, n) {
		let r = new e();
		return e.LookDirectionLHToRef(t, n, r), r;
	}
	static LookDirectionLHToRef(t, n, r) {
		let i = A.Vector3[0];
		i.copyFrom(t), i.scaleInPlace(-1);
		let a = A.Vector3[1];
		return E.CrossToRef(n, i, a), e.FromValuesToRef(a._x, a._y, a._z, 0, n._x, n._y, n._z, 0, i._x, i._y, i._z, 0, 0, 0, 0, 1, r), r;
	}
	static LookDirectionRH(t, n) {
		let r = new e();
		return e.LookDirectionRHToRef(t, n, r), r;
	}
	static LookDirectionRHToRef(t, n, r) {
		let i = A.Vector3[2];
		return E.CrossToRef(n, t, i), e.FromValuesToRef(i._x, i._y, i._z, 0, n._x, n._y, n._z, 0, t._x, t._y, t._z, 0, 0, 0, 0, 1, r), r;
	}
	static OrthoLH(t, n, r, i, a) {
		let o = new e();
		return e.OrthoLHToRef(t, n, r, i, o, a), o;
	}
	static OrthoLHToRef(t, n, r, i, a, o) {
		let s = r, c = i, l = 2 / t, u = 2 / n, d = 2 / (c - s), f = -(c + s) / (c - s);
		return e.FromValuesToRef(l, 0, 0, 0, 0, u, 0, 0, 0, 0, d, 0, 0, 0, f, 1, a), o && a.multiplyToRef(M, a), a._updateIdentityStatus(l === 1 && u === 1 && d === 1 && f === 0), a;
	}
	static OrthoOffCenterLH(t, n, r, i, a, o, s) {
		let c = new e();
		return e.OrthoOffCenterLHToRef(t, n, r, i, a, o, c, s), c;
	}
	static OrthoOffCenterLHToRef(t, n, r, i, a, o, s, c) {
		let l = a, u = o, d = 2 / (n - t), f = 2 / (i - r), p = 2 / (u - l), m = -(u + l) / (u - l), h = (t + n) / (t - n), g = (i + r) / (r - i);
		return e.FromValuesToRef(d, 0, 0, 0, 0, f, 0, 0, 0, 0, p, 0, h, g, m, 1, s), c && s.multiplyToRef(M, s), s.markAsUpdated(), s;
	}
	static ObliqueOffCenterLHToRef(t, n, r, i, a, o, s, c, l, u, d) {
		let f = -s * Math.cos(c), p = -s * Math.sin(c);
		return e.TranslationToRef(0, 0, -l, A.Matrix[1]), e.FromValuesToRef(1, 0, 0, 0, 0, 1, 0, 0, f, p, 1, 0, 0, 0, 0, 1, A.Matrix[0]), A.Matrix[1].multiplyToRef(A.Matrix[0], A.Matrix[0]), e.TranslationToRef(0, 0, l, A.Matrix[1]), A.Matrix[0].multiplyToRef(A.Matrix[1], A.Matrix[0]), e.OrthoOffCenterLHToRef(t, n, r, i, a, o, u, d), A.Matrix[0].multiplyToRef(u, u), u;
	}
	static OrthoOffCenterRH(t, n, r, i, a, o, s) {
		let c = new e();
		return e.OrthoOffCenterRHToRef(t, n, r, i, a, o, c, s), c;
	}
	static OrthoOffCenterRHToRef(t, n, r, i, a, o, s, c) {
		return e.OrthoOffCenterLHToRef(t, n, r, i, a, o, s, c), s._m[10] *= -1, s;
	}
	static ObliqueOffCenterRHToRef(t, n, r, i, a, o, s, c, l, u, d) {
		let f = s * Math.cos(c), p = s * Math.sin(c);
		return e.TranslationToRef(0, 0, l, A.Matrix[1]), e.FromValuesToRef(1, 0, 0, 0, 0, 1, 0, 0, f, p, 1, 0, 0, 0, 0, 1, A.Matrix[0]), A.Matrix[1].multiplyToRef(A.Matrix[0], A.Matrix[0]), e.TranslationToRef(0, 0, -l, A.Matrix[1]), A.Matrix[0].multiplyToRef(A.Matrix[1], A.Matrix[0]), e.OrthoOffCenterRHToRef(t, n, r, i, a, o, u, d), A.Matrix[0].multiplyToRef(u, u), u;
	}
	static PerspectiveLH(t, n, r, i, a, o = 0) {
		let s = new e(), c = r, l = i, u = 2 * c / t, d = 2 * c / n, f = (l + c) / (l - c), p = -2 * l * c / (l - c), m = Math.tan(o);
		return e.FromValuesToRef(u, 0, 0, 0, 0, d, 0, m, 0, 0, f, 1, 0, 0, p, 0, s), a && s.multiplyToRef(M, s), s._updateIdentityStatus(!1), s;
	}
	static PerspectiveFovLH(t, n, r, i, a, o = 0, s = !1) {
		let c = new e();
		return e.PerspectiveFovLHToRef(t, n, r, i, c, !0, a, o, s), c;
	}
	static PerspectiveFovLHToRef(t, n, r, i, a, o = !0, s, c = 0, l = !1) {
		let u = r, d = i, f = 1 / Math.tan(t * .5), p = o ? f / n : f, m = o ? f : f * n, h = l && u === 0 ? -1 : d === 0 ? 1 : (d + u) / (d - u), g = l && u === 0 ? 2 * d : d === 0 ? -2 * u : -2 * d * u / (d - u), _ = Math.tan(c);
		return e.FromValuesToRef(p, 0, 0, 0, 0, m, 0, _, 0, 0, h, 1, 0, 0, g, 0, a), s && a.multiplyToRef(M, a), a._updateIdentityStatus(!1), a;
	}
	static PerspectiveFovReverseLHToRef(t, n, r, i, a, o = !0, s, c = 0) {
		let l = 1 / Math.tan(t * .5), u = o ? l / n : l, d = o ? l : l * n, f = Math.tan(c);
		return e.FromValuesToRef(u, 0, 0, 0, 0, d, 0, f, 0, 0, -r, 1, 0, 0, 1, 0, a), s && a.multiplyToRef(M, a), a._updateIdentityStatus(!1), a;
	}
	static PerspectiveFovRH(t, n, r, i, a, o = 0, s = !1) {
		let c = new e();
		return e.PerspectiveFovRHToRef(t, n, r, i, c, !0, a, o, s), c;
	}
	static PerspectiveFovRHToRef(t, n, r, i, a, o = !0, s, c = 0, l = !1) {
		let u = r, d = i, f = 1 / Math.tan(t * .5), p = o ? f / n : f, m = o ? f : f * n, h = l && u === 0 ? 1 : d === 0 ? -1 : -(d + u) / (d - u), g = l && u === 0 ? 2 * d : d === 0 ? -2 * u : -2 * d * u / (d - u), _ = Math.tan(c);
		return e.FromValuesToRef(p, 0, 0, 0, 0, m, 0, _, 0, 0, h, -1, 0, 0, g, 0, a), s && a.multiplyToRef(M, a), a._updateIdentityStatus(!1), a;
	}
	static PerspectiveFovReverseRHToRef(t, n, r, i, a, o = !0, s, c = 0) {
		let l = 1 / Math.tan(t * .5), u = o ? l / n : l, d = o ? l : l * n, f = Math.tan(c);
		return e.FromValuesToRef(u, 0, 0, 0, 0, d, 0, f, 0, 0, -r, -1, 0, 0, -1, 0, a), s && a.multiplyToRef(M, a), a._updateIdentityStatus(!1), a;
	}
	static GetFinalMatrix(t, n, r, i, a, o) {
		let s = t.width, c = t.height, l = t.x, u = t.y, d = e.FromValues(s / 2, 0, 0, 0, 0, -c / 2, 0, 0, 0, 0, o - a, 0, l + s / 2, c / 2 + u, a, 1), f = new e();
		return n.multiplyToRef(r, f), f.multiplyToRef(i, f), f.multiplyToRef(d, f);
	}
	static GetAsMatrix2x2(e) {
		let t = e.m, n = [
			t[0],
			t[1],
			t[4],
			t[5]
		];
		return s.MatrixUse64Bits ? n : new Float32Array(n);
	}
	static GetAsMatrix3x3(e) {
		let t = e.m, n = [
			t[0],
			t[1],
			t[2],
			t[4],
			t[5],
			t[6],
			t[8],
			t[9],
			t[10]
		];
		return s.MatrixUse64Bits ? n : new Float32Array(n);
	}
	static Transpose(t) {
		let n = new e();
		return e.TransposeToRef(t, n), n;
	}
	static TransposeToRef(e, t) {
		let n = e.m, r = n[0], i = n[4], a = n[8], o = n[12], s = n[1], c = n[5], l = n[9], u = n[13], d = n[2], f = n[6], p = n[10], m = n[14], h = n[3], g = n[7], _ = n[11], v = n[15], y = t._m;
		return y[0] = r, y[1] = i, y[2] = a, y[3] = o, y[4] = s, y[5] = c, y[6] = l, y[7] = u, y[8] = d, y[9] = f, y[10] = p, y[11] = m, y[12] = h, y[13] = g, y[14] = _, y[15] = v, t.markAsUpdated(), t._updateIdentityStatus(e._isIdentity, e._isIdentityDirty), t;
	}
	static Reflection(t) {
		let n = new e();
		return e.ReflectionToRef(t, n), n;
	}
	static ReflectionToRef(t, n) {
		t.normalize();
		let r = t.normal.x, i = t.normal.y, a = t.normal.z, o = -2 * r, s = -2 * i, c = -2 * a;
		return e.FromValuesToRef(o * r + 1, s * r, c * r, 0, o * i, s * i + 1, c * i, 0, o * a, s * a, c * a + 1, 0, o * t.d, s * t.d, c * t.d, 1, n), n;
	}
	static FromXYZAxesToRef(t, n, r, i) {
		return e.FromValuesToRef(t._x, t._y, t._z, 0, n._x, n._y, n._z, 0, r._x, r._y, r._z, 0, 0, 0, 0, 1, i), i;
	}
	static FromQuaternionToRef(e, t) {
		let n = e._x * e._x, r = e._y * e._y, i = e._z * e._z, a = e._x * e._y, o = e._z * e._w, s = e._z * e._x, c = e._y * e._w, l = e._y * e._z, u = e._x * e._w;
		return t._m[0] = 1 - 2 * (r + i), t._m[1] = 2 * (a + o), t._m[2] = 2 * (s - c), t._m[3] = 0, t._m[4] = 2 * (a - o), t._m[5] = 1 - 2 * (i + n), t._m[6] = 2 * (l + u), t._m[7] = 0, t._m[8] = 2 * (s + c), t._m[9] = 2 * (l - u), t._m[10] = 1 - 2 * (r + n), t._m[11] = 0, t._m[12] = 0, t._m[13] = 0, t._m[14] = 0, t._m[15] = 1, t.markAsUpdated(), t;
	}
};
k._IdentityReadOnly = /*#__PURE__*/ k.Identity();
var A = class {};
A.Vector3 = /*#__PURE__*/ p(11, E.Zero), A.Matrix = /*#__PURE__*/ p(2, k.Identity), A.Quaternion = /*#__PURE__*/ p(3, O.Zero);
var j = class {};
j.Vector2 = /*#__PURE__*/ p(3, T.Zero), j.Vector3 = /*#__PURE__*/ p(13, E.Zero), j.Vector4 = /*#__PURE__*/ p(3, D.Zero), j.Quaternion = /*#__PURE__*/ p(3, O.Zero), j.Matrix = /*#__PURE__*/ p(8, k.Identity);
var M = /*#__PURE__*/ k.FromValues(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, .5, 0, 0, 0, .5, 1), N = !1;
function P() {
	N || (N = !0, Object.defineProperties(T.prototype, {
		dimension: { value: [2] },
		rank: { value: 1 }
	}), Object.defineProperties(E.prototype, {
		dimension: { value: [3] },
		rank: { value: 1 }
	}), Object.defineProperties(D.prototype, {
		dimension: { value: [4] },
		rank: { value: 1 }
	}), Object.defineProperties(O.prototype, {
		dimension: { value: [4] },
		rank: { value: 1 }
	}), Object.defineProperties(k.prototype, {
		dimension: { value: [4, 4] },
		rank: { value: 2 }
	}), c("BABYLON.Vector2", T), c("BABYLON.Vector3", E), c("BABYLON.Vector4", D), c("BABYLON.Matrix", k));
}
//#endregion
//#region node_modules/@babylonjs/core/Maths/math.color.pure.js
function F(e) {
	return e ** +u;
}
function I(e) {
	return e <= .04045 ? .0773993808 * e : (.947867299 * (e + .055)) ** 2.4;
}
function L(e) {
	return e ** +l;
}
function R(e) {
	return e <= .0031308 ? 12.92 * e : 1.055 * e ** .41666 - .055;
}
var z = class e {
	constructor(e = 0, t = 0, n = 0) {
		this.r = e, this.g = t, this.b = n;
	}
	toString() {
		return "{R: " + this.r + " G:" + this.g + " B:" + this.b + "}";
	}
	getClassName() {
		return "Color3";
	}
	getHashCode() {
		let e = this.r * 255 | 0;
		return e = e * 397 ^ (this.g * 255 | 0), e = e * 397 ^ (this.b * 255 | 0), e;
	}
	toArray(e, t = 0) {
		return e[t] = this.r, e[t + 1] = this.g, e[t + 2] = this.b, this;
	}
	fromArray(t, n = 0) {
		return e.FromArrayToRef(t, n, this), this;
	}
	toColor4(e = 1) {
		return new B(this.r, this.g, this.b, e);
	}
	asArray() {
		return [
			this.r,
			this.g,
			this.b
		];
	}
	toLuminance() {
		return this.r * .3 + this.g * .59 + this.b * .11;
	}
	multiply(t) {
		return new e(this.r * t.r, this.g * t.g, this.b * t.b);
	}
	multiplyToRef(e, t) {
		return t.r = this.r * e.r, t.g = this.g * e.g, t.b = this.b * e.b, t;
	}
	multiplyInPlace(e) {
		return this.r *= e.r, this.g *= e.g, this.b *= e.b, this;
	}
	multiplyByFloats(t, n, r) {
		return new e(this.r * t, this.g * n, this.b * r);
	}
	divide(e) {
		throw ReferenceError("Can not divide a color");
	}
	divideToRef(e, t) {
		throw ReferenceError("Can not divide a color");
	}
	divideInPlace(e) {
		throw ReferenceError("Can not divide a color");
	}
	minimizeInPlace(e) {
		return this.minimizeInPlaceFromFloats(e.r, e.g, e.b);
	}
	maximizeInPlace(e) {
		return this.maximizeInPlaceFromFloats(e.r, e.g, e.b);
	}
	minimizeInPlaceFromFloats(e, t, n) {
		return this.r = Math.min(e, this.r), this.g = Math.min(t, this.g), this.b = Math.min(n, this.b), this;
	}
	maximizeInPlaceFromFloats(e, t, n) {
		return this.r = Math.max(e, this.r), this.g = Math.max(t, this.g), this.b = Math.max(n, this.b), this;
	}
	floorToRef(e) {
		throw ReferenceError("Can not floor a color");
	}
	floor() {
		throw ReferenceError("Can not floor a color");
	}
	fractToRef(e) {
		throw ReferenceError("Can not fract a color");
	}
	fract() {
		throw ReferenceError("Can not fract a color");
	}
	equals(e) {
		return e && this.r === e.r && this.g === e.g && this.b === e.b;
	}
	equalsFloats(e, t, n) {
		return this.equalsToFloats(e, t, n);
	}
	equalsToFloats(e, t, n) {
		return this.r === e && this.g === t && this.b === n;
	}
	equalsWithEpsilon(e, t = d) {
		return n(this.r, e.r, t) && n(this.g, e.g, t) && n(this.b, e.b, t);
	}
	negate() {
		throw ReferenceError("Can not negate a color");
	}
	negateInPlace() {
		throw ReferenceError("Can not negate a color");
	}
	negateToRef(e) {
		throw ReferenceError("Can not negate a color");
	}
	scale(t) {
		return new e(this.r * t, this.g * t, this.b * t);
	}
	scaleInPlace(e) {
		return this.r *= e, this.g *= e, this.b *= e, this;
	}
	scaleToRef(e, t) {
		return t.r = this.r * e, t.g = this.g * e, t.b = this.b * e, t;
	}
	scaleAndAddToRef(e, t) {
		return t.r += this.r * e, t.g += this.g * e, t.b += this.b * e, t;
	}
	clampToRef(e = 0, t = 1, n) {
		return n.r = a(this.r, e, t), n.g = a(this.g, e, t), n.b = a(this.b, e, t), n;
	}
	add(t) {
		return new e(this.r + t.r, this.g + t.g, this.b + t.b);
	}
	addInPlace(e) {
		return this.r += e.r, this.g += e.g, this.b += e.b, this;
	}
	addInPlaceFromFloats(e, t, n) {
		return this.r += e, this.g += t, this.b += n, this;
	}
	addToRef(e, t) {
		return t.r = this.r + e.r, t.g = this.g + e.g, t.b = this.b + e.b, t;
	}
	subtract(t) {
		return new e(this.r - t.r, this.g - t.g, this.b - t.b);
	}
	subtractToRef(e, t) {
		return t.r = this.r - e.r, t.g = this.g - e.g, t.b = this.b - e.b, t;
	}
	subtractInPlace(e) {
		return this.r -= e.r, this.g -= e.g, this.b -= e.b, this;
	}
	subtractFromFloats(t, n, r) {
		return new e(this.r - t, this.g - n, this.b - r);
	}
	subtractFromFloatsToRef(e, t, n, r) {
		return r.r = this.r - e, r.g = this.g - t, r.b = this.b - n, r;
	}
	clone() {
		return new e(this.r, this.g, this.b);
	}
	copyFrom(e) {
		return this.r = e.r, this.g = e.g, this.b = e.b, this;
	}
	copyFromFloats(e, t, n) {
		return this.r = e, this.g = t, this.b = n, this;
	}
	set(e, t, n) {
		return this.copyFromFloats(e, t, n);
	}
	setAll(e) {
		return this.r = this.g = this.b = e, this;
	}
	toHexString() {
		let e = Math.round(this.r * 255), n = Math.round(this.g * 255), r = Math.round(this.b * 255);
		return "#" + t(e) + t(n) + t(r);
	}
	fromHexString(e) {
		return e.substring(0, 1) !== "#" || e.length !== 7 || (this.r = parseInt(e.substring(1, 3), 16) / 255, this.g = parseInt(e.substring(3, 5), 16) / 255, this.b = parseInt(e.substring(5, 7), 16) / 255), this;
	}
	toHSV() {
		return this.toHSVToRef(new e());
	}
	toHSVToRef(e) {
		let t = this.r, n = this.g, r = this.b, i = Math.max(t, n, r), a = Math.min(t, n, r), o = 0, s = 0, c = i, l = i - a;
		return i !== 0 && (s = l / i), i != a && (i == t ? (o = (n - r) / l, n < r && (o += 6)) : i == n ? o = (r - t) / l + 2 : i == r && (o = (t - n) / l + 4), o *= 60), e.r = o, e.g = s, e.b = c, e;
	}
	toLinearSpace(t = !1) {
		let n = new e();
		return this.toLinearSpaceToRef(n, t), n;
	}
	toLinearSpaceToRef(e, t = !1) {
		return t ? (e.r = I(this.r), e.g = I(this.g), e.b = I(this.b)) : (e.r = F(this.r), e.g = F(this.g), e.b = F(this.b)), this;
	}
	toGammaSpace(t = !1) {
		let n = new e();
		return this.toGammaSpaceToRef(n, t), n;
	}
	toGammaSpaceToRef(e, t = !1) {
		return t ? (e.r = R(this.r), e.g = R(this.g), e.b = R(this.b)) : (e.r = L(this.r), e.g = L(this.g), e.b = L(this.b)), this;
	}
	static HSVtoRGBToRef(e, t, n, r) {
		let i = n * t, a = e / 60, o = i * (1 - Math.abs(a % 2 - 1)), s = 0, c = 0, l = 0;
		a >= 0 && a <= 1 ? (s = i, c = o) : a >= 1 && a <= 2 ? (s = o, c = i) : a >= 2 && a <= 3 ? (c = i, l = o) : a >= 3 && a <= 4 ? (c = o, l = i) : a >= 4 && a <= 5 ? (s = o, l = i) : a >= 5 && a <= 6 && (s = i, l = o);
		let u = n - i;
		return r.r = s + u, r.g = c + u, r.b = l + u, r;
	}
	static FromHSV(t, n, r) {
		let i = new e(0, 0, 0);
		return e.HSVtoRGBToRef(t, n, r, i), i;
	}
	static FromHexString(t) {
		return new e(0, 0, 0).fromHexString(t);
	}
	static FromArray(t, n = 0) {
		return new e(t[n], t[n + 1], t[n + 2]);
	}
	static FromArrayToRef(e, t = 0, n) {
		n.r = e[t], n.g = e[t + 1], n.b = e[t + 2];
	}
	static FromInts(t, n, r) {
		return new e(t / 255, n / 255, r / 255);
	}
	static Lerp(t, n, r) {
		let i = new e(0, 0, 0);
		return e.LerpToRef(t, n, r, i), i;
	}
	static LerpToRef(e, t, n, r) {
		r.r = e.r + (t.r - e.r) * n, r.g = e.g + (t.g - e.g) * n, r.b = e.b + (t.b - e.b) * n;
	}
	static Hermite(t, n, r, i, a) {
		let o = a * a, s = a * o, c = 2 * s - 3 * o + 1, l = -2 * s + 3 * o, u = s - 2 * o + a, d = s - o, f = t.r * c + r.r * l + n.r * u + i.r * d, p = t.g * c + r.g * l + n.g * u + i.g * d, m = t.b * c + r.b * l + n.b * u + i.b * d;
		return new e(f, p, m);
	}
	static Hermite1stDerivative(t, n, r, i, a) {
		let o = e.Black();
		return this.Hermite1stDerivativeToRef(t, n, r, i, a, o), o;
	}
	static Hermite1stDerivativeToRef(e, t, n, r, i, a) {
		let o = i * i;
		a.r = (o - i) * 6 * e.r + (3 * o - 4 * i + 1) * t.r + (-o + i) * 6 * n.r + (3 * o - 2 * i) * r.r, a.g = (o - i) * 6 * e.g + (3 * o - 4 * i + 1) * t.g + (-o + i) * 6 * n.g + (3 * o - 2 * i) * r.g, a.b = (o - i) * 6 * e.b + (3 * o - 4 * i + 1) * t.b + (-o + i) * 6 * n.b + (3 * o - 2 * i) * r.b;
	}
	static Red() {
		return new e(1, 0, 0);
	}
	static Green() {
		return new e(0, 1, 0);
	}
	static Blue() {
		return new e(0, 0, 1);
	}
	static Black() {
		return new e(0, 0, 0);
	}
	static get BlackReadOnly() {
		return e._BlackReadOnly;
	}
	static White() {
		return new e(1, 1, 1);
	}
	static Purple() {
		return new e(.5, 0, .5);
	}
	static Magenta() {
		return new e(1, 0, 1);
	}
	static Yellow() {
		return new e(1, 1, 0);
	}
	static Gray() {
		return new e(.5, .5, .5);
	}
	static Teal() {
		return new e(0, 1, 1);
	}
	static Random() {
		return new e(Math.random(), Math.random(), Math.random());
	}
};
z._V8PerformanceHack = /*#__PURE__*/ new z(.5, .5, .5), z._BlackReadOnly = /*#__PURE__*/ z.Black();
var B = class e {
	constructor(e = 0, t = 0, n = 0, r = 1) {
		this.r = e, this.g = t, this.b = n, this.a = r;
	}
	asArray() {
		return [
			this.r,
			this.g,
			this.b,
			this.a
		];
	}
	toArray(e, t = 0) {
		return e[t] = this.r, e[t + 1] = this.g, e[t + 2] = this.b, e[t + 3] = this.a, this;
	}
	fromArray(e, t = 0) {
		return this.r = e[t], this.g = e[t + 1], this.b = e[t + 2], this.a = e[t + 3], this;
	}
	equals(e) {
		return e && this.r === e.r && this.g === e.g && this.b === e.b && this.a === e.a;
	}
	add(t) {
		return new e(this.r + t.r, this.g + t.g, this.b + t.b, this.a + t.a);
	}
	addToRef(e, t) {
		return t.r = this.r + e.r, t.g = this.g + e.g, t.b = this.b + e.b, t.a = this.a + e.a, t;
	}
	addInPlace(e) {
		return this.r += e.r, this.g += e.g, this.b += e.b, this.a += e.a, this;
	}
	addInPlaceFromFloats(e, t, n, r) {
		return this.r += e, this.g += t, this.b += n, this.a += r, this;
	}
	subtract(t) {
		return new e(this.r - t.r, this.g - t.g, this.b - t.b, this.a - t.a);
	}
	subtractToRef(e, t) {
		return t.r = this.r - e.r, t.g = this.g - e.g, t.b = this.b - e.b, t.a = this.a - e.a, t;
	}
	subtractInPlace(e) {
		return this.r -= e.r, this.g -= e.g, this.b -= e.b, this.a -= e.a, this;
	}
	subtractFromFloats(t, n, r, i) {
		return new e(this.r - t, this.g - n, this.b - r, this.a - i);
	}
	subtractFromFloatsToRef(e, t, n, r, i) {
		return i.r = this.r - e, i.g = this.g - t, i.b = this.b - n, i.a = this.a - r, i;
	}
	scale(t) {
		return new e(this.r * t, this.g * t, this.b * t, this.a * t);
	}
	scaleInPlace(e) {
		return this.r *= e, this.g *= e, this.b *= e, this.a *= e, this;
	}
	scaleToRef(e, t) {
		return t.r = this.r * e, t.g = this.g * e, t.b = this.b * e, t.a = this.a * e, t;
	}
	scaleAndAddToRef(e, t) {
		return t.r += this.r * e, t.g += this.g * e, t.b += this.b * e, t.a += this.a * e, t;
	}
	clampToRef(e = 0, t = 1, n) {
		return n.r = a(this.r, e, t), n.g = a(this.g, e, t), n.b = a(this.b, e, t), n.a = a(this.a, e, t), n;
	}
	multiply(t) {
		return new e(this.r * t.r, this.g * t.g, this.b * t.b, this.a * t.a);
	}
	multiplyToRef(e, t) {
		return t.r = this.r * e.r, t.g = this.g * e.g, t.b = this.b * e.b, t.a = this.a * e.a, t;
	}
	multiplyInPlace(e) {
		return this.r *= e.r, this.g *= e.g, this.b *= e.b, this.a *= e.a, this;
	}
	multiplyByFloats(t, n, r, i) {
		return new e(this.r * t, this.g * n, this.b * r, this.a * i);
	}
	divide(e) {
		throw ReferenceError("Can not divide a color");
	}
	divideToRef(e, t) {
		throw ReferenceError("Can not divide a color");
	}
	divideInPlace(e) {
		throw ReferenceError("Can not divide a color");
	}
	minimizeInPlace(e) {
		return this.r = Math.min(this.r, e.r), this.g = Math.min(this.g, e.g), this.b = Math.min(this.b, e.b), this.a = Math.min(this.a, e.a), this;
	}
	maximizeInPlace(e) {
		return this.r = Math.max(this.r, e.r), this.g = Math.max(this.g, e.g), this.b = Math.max(this.b, e.b), this.a = Math.max(this.a, e.a), this;
	}
	minimizeInPlaceFromFloats(e, t, n, r) {
		return this.r = Math.min(e, this.r), this.g = Math.min(t, this.g), this.b = Math.min(n, this.b), this.a = Math.min(r, this.a), this;
	}
	maximizeInPlaceFromFloats(e, t, n, r) {
		return this.r = Math.max(e, this.r), this.g = Math.max(t, this.g), this.b = Math.max(n, this.b), this.a = Math.max(r, this.a), this;
	}
	floorToRef(e) {
		throw ReferenceError("Can not floor a color");
	}
	floor() {
		throw ReferenceError("Can not floor a color");
	}
	fractToRef(e) {
		throw ReferenceError("Can not fract a color");
	}
	fract() {
		throw ReferenceError("Can not fract a color");
	}
	negate() {
		throw ReferenceError("Can not negate a color");
	}
	negateInPlace() {
		throw ReferenceError("Can not negate a color");
	}
	negateToRef(e) {
		throw ReferenceError("Can not negate a color");
	}
	equalsWithEpsilon(e, t = d) {
		return n(this.r, e.r, t) && n(this.g, e.g, t) && n(this.b, e.b, t) && n(this.a, e.a, t);
	}
	equalsToFloats(e, t, n, r) {
		return this.r === e && this.g === t && this.b === n && this.a === r;
	}
	toString() {
		return "{R: " + this.r + " G:" + this.g + " B:" + this.b + " A:" + this.a + "}";
	}
	getClassName() {
		return "Color4";
	}
	getHashCode() {
		let e = this.r * 255 | 0;
		return e = e * 397 ^ (this.g * 255 | 0), e = e * 397 ^ (this.b * 255 | 0), e = e * 397 ^ (this.a * 255 | 0), e;
	}
	clone() {
		return new e().copyFrom(this);
	}
	copyFrom(e) {
		return this.r = e.r, this.g = e.g, this.b = e.b, this.a = e.a, this;
	}
	copyFromFloats(e, t, n, r) {
		return this.r = e, this.g = t, this.b = n, this.a = r, this;
	}
	set(e, t, n, r) {
		return this.copyFromFloats(e, t, n, r);
	}
	setAll(e) {
		return this.r = this.g = this.b = this.a = e, this;
	}
	toHexString(e = !1) {
		let n = Math.round(this.r * 255), r = Math.round(this.g * 255), i = Math.round(this.b * 255);
		if (e) return "#" + t(n) + t(r) + t(i);
		let a = Math.round(this.a * 255);
		return "#" + t(n) + t(r) + t(i) + t(a);
	}
	fromHexString(e) {
		return e.substring(0, 1) !== "#" || e.length !== 9 && e.length !== 7 || (this.r = parseInt(e.substring(1, 3), 16) / 255, this.g = parseInt(e.substring(3, 5), 16) / 255, this.b = parseInt(e.substring(5, 7), 16) / 255, e.length === 9 && (this.a = parseInt(e.substring(7, 9), 16) / 255)), this;
	}
	toLinearSpace(t = !1) {
		let n = new e();
		return this.toLinearSpaceToRef(n, t), n;
	}
	toLinearSpaceToRef(e, t = !1) {
		return t ? (e.r = I(this.r), e.g = I(this.g), e.b = I(this.b)) : (e.r = F(this.r), e.g = F(this.g), e.b = F(this.b)), e.a = this.a, this;
	}
	toGammaSpace(t = !1) {
		let n = new e();
		return this.toGammaSpaceToRef(n, t), n;
	}
	toGammaSpaceToRef(e, t = !1) {
		return t ? (e.r = R(this.r), e.g = R(this.g), e.b = R(this.b)) : (e.r = L(this.r), e.g = L(this.g), e.b = L(this.b)), e.a = this.a, this;
	}
	static FromHexString(t) {
		return t.substring(0, 1) !== "#" || t.length !== 9 && t.length !== 7 ? new e(0, 0, 0, 0) : new e(0, 0, 0, 1).fromHexString(t);
	}
	static Lerp(t, n, r) {
		return e.LerpToRef(t, n, r, new e());
	}
	static LerpToRef(e, t, n, r) {
		return r.r = e.r + (t.r - e.r) * n, r.g = e.g + (t.g - e.g) * n, r.b = e.b + (t.b - e.b) * n, r.a = e.a + (t.a - e.a) * n, r;
	}
	static Hermite(t, n, r, i, a) {
		let o = a * a, s = a * o, c = 2 * s - 3 * o + 1, l = -2 * s + 3 * o, u = s - 2 * o + a, d = s - o, f = t.r * c + r.r * l + n.r * u + i.r * d, p = t.g * c + r.g * l + n.g * u + i.g * d, m = t.b * c + r.b * l + n.b * u + i.b * d, h = t.a * c + r.a * l + n.a * u + i.a * d;
		return new e(f, p, m, h);
	}
	static Hermite1stDerivative(t, n, r, i, a) {
		let o = new e();
		return this.Hermite1stDerivativeToRef(t, n, r, i, a, o), o;
	}
	static Hermite1stDerivativeToRef(e, t, n, r, i, a) {
		let o = i * i;
		a.r = (o - i) * 6 * e.r + (3 * o - 4 * i + 1) * t.r + (-o + i) * 6 * n.r + (3 * o - 2 * i) * r.r, a.g = (o - i) * 6 * e.g + (3 * o - 4 * i + 1) * t.g + (-o + i) * 6 * n.g + (3 * o - 2 * i) * r.g, a.b = (o - i) * 6 * e.b + (3 * o - 4 * i + 1) * t.b + (-o + i) * 6 * n.b + (3 * o - 2 * i) * r.b, a.a = (o - i) * 6 * e.a + (3 * o - 4 * i + 1) * t.a + (-o + i) * 6 * n.a + (3 * o - 2 * i) * r.a;
	}
	static FromColor3(t, n = 1) {
		return new e(t.r, t.g, t.b, n);
	}
	static FromArray(t, n = 0) {
		return new e(t[n], t[n + 1], t[n + 2], t[n + 3]);
	}
	static FromArrayToRef(e, t = 0, n) {
		n.r = e[t], n.g = e[t + 1], n.b = e[t + 2], n.a = e[t + 3];
	}
	static FromInts(t, n, r, i) {
		return new e(t / 255, n / 255, r / 255, i / 255);
	}
	static CheckColors4(e, t) {
		if (e.length === t * 3) {
			let t = [];
			for (let n = 0; n < e.length; n += 3) {
				let r = n / 3 * 4;
				t[r] = e[n], t[r + 1] = e[n + 1], t[r + 2] = e[n + 2], t[r + 3] = 1;
			}
			return t;
		}
		return e;
	}
};
B._V8PerformanceHack = /*#__PURE__*/ new B(.5, .5, .5, .5);
var V = class {};
V.Color3 = /*#__PURE__*/ f(3, z.Black), V.Color4 = /*#__PURE__*/ f(3, () => new B(0, 0, 0, 0));
var H = !1;
function U() {
	H || (H = !0, Object.defineProperties(z.prototype, {
		dimension: { value: [3] },
		rank: { value: 1 }
	}), Object.defineProperties(B.prototype, {
		dimension: { value: [4] },
		rank: { value: 1 }
	}), c("BABYLON.Color3", z), c("BABYLON.Color4", B));
}
//#endregion
export { u as _, k as a, j as c, D as d, S as f, d as g, g as h, V as i, T as l, f as m, B as n, O as o, b as p, U as r, P as s, z as t, E as u };
