import { t as e } from "./logger-DQIzSR_y.js";
import { c as t, t as n } from "./thinEngine.pure-CFnvxmRZ.js";
import { g as r, v as i, y as a } from "./tools.pure-Dy2G52NL.js";
//#region node_modules/@babylonjs/core/Engines/Extensions/engine.dynamicBuffer.pure.js
var o = !1;
function s() {
	o || (o = !0, n.prototype.updateDynamicIndexBuffer = function(e, t, n = 0) {
		this._currentBoundBuffer[this._gl.ELEMENT_ARRAY_BUFFER] = null, this.bindIndexBuffer(e);
		let r;
		r = e.is32Bits ? t instanceof Uint32Array ? t : new Uint32Array(t) : t instanceof Uint16Array ? t : new Uint16Array(t), this._gl.bufferData(this._gl.ELEMENT_ARRAY_BUFFER, r, this._gl.DYNAMIC_DRAW), this._resetIndexBufferBinding();
	}, n.prototype.updateDynamicVertexBuffer = function(e, t, n, r) {
		this.bindArrayBuffer(e), n === void 0 && (n = 0);
		let i = t.byteLength || t.length;
		r === void 0 || r >= i && n === 0 ? t instanceof Array ? this._gl.bufferSubData(this._gl.ARRAY_BUFFER, n, new Float32Array(t)) : this._gl.bufferSubData(this._gl.ARRAY_BUFFER, n, t) : t instanceof Array ? this._gl.bufferSubData(this._gl.ARRAY_BUFFER, n, new Float32Array(t).subarray(0, r / 4)) : (t = ArrayBuffer.isView(t) ? new Uint8Array(t.buffer, t.byteOffset, r) : new Uint8Array(t, 0, r), this._gl.bufferSubData(this._gl.ARRAY_BUFFER, n, t)), this._resetVertexBufferBinding();
	});
}
//#endregion
//#region node_modules/@babylonjs/core/Buffers/buffer.pure.js
var c = class {
	get isDisposed() {
		return this._isDisposed;
	}
	constructor(e, n, r, i = 0, a = !1, o = !1, c = !1, l, u) {
		this._isAlreadyOwned = !1, this._isDisposed = !1, s(), this._engine = e && e.getScene ? e.getScene().getEngine() : e, this._updatable = r, this._instanced = o, this._divisor = l || 1, this._label = u, n instanceof t ? (this._data = null, this._buffer = n) : (this._data = n, this._buffer = null), this.byteStride = c ? i : i * Float32Array.BYTES_PER_ELEMENT, a || this.create();
	}
	createVertexBuffer(e, t, n, r, i, a = !1, o) {
		let s = a ? t : t * Float32Array.BYTES_PER_ELEMENT, c = r ? a ? r : r * Float32Array.BYTES_PER_ELEMENT : this.byteStride;
		return new l(this._engine, this, e, this._updatable, !0, c, i === void 0 ? this._instanced : i, s, n, void 0, void 0, !0, this._divisor || o);
	}
	isUpdatable() {
		return this._updatable;
	}
	getData() {
		return this._data;
	}
	getBuffer() {
		return this._buffer;
	}
	getStrideSize() {
		return this.byteStride / Float32Array.BYTES_PER_ELEMENT;
	}
	create(e = null) {
		(e || !this._buffer) && (e ||= this._data, e && (this._buffer ? this._updatable && (this._engine.updateDynamicVertexBuffer(this._buffer, e), this._data = e) : this._updatable ? (this._buffer = this._engine.createDynamicVertexBuffer(e, this._label), this._data = e) : this._buffer = this._engine.createVertexBuffer(e, void 0, this._label)));
	}
	_rebuild() {
		if (this._data) this._buffer = null, this.create(this._data);
		else {
			if (!this._buffer) return;
			if (this._buffer.capacity > 0) {
				this._buffer = this._updatable ? this._engine.createDynamicVertexBuffer(this._buffer.capacity, this._label) : this._engine.createVertexBuffer(this._buffer.capacity, void 0, this._label);
				return;
			}
			e.Warn(`Missing data for buffer "${this._label}" ${this._buffer ? "(uniqueId: " + this._buffer.uniqueId + ")" : ""}. Buffer reconstruction failed.`), this._buffer = null;
		}
	}
	update(e) {
		this.create(e);
	}
	updateDirectly(e, t, n, r = !1) {
		this._buffer && this._updatable && (this._engine.updateDynamicVertexBuffer(this._buffer, e, r ? t : t * Float32Array.BYTES_PER_ELEMENT, n ? n * this.byteStride : void 0), this._data = t === 0 && n === void 0 ? e : null);
	}
	_increaseReferences() {
		this._buffer && (this._isAlreadyOwned ? this._buffer.references++ : this._isAlreadyOwned = !0);
	}
	dispose() {
		this._buffer && this._engine._releaseBuffer(this._buffer) && (this._isDisposed = !0, this._data = null, this._buffer = null);
	}
}, l = class e {
	get isDisposed() {
		return this._isDisposed;
	}
	get instanceDivisor() {
		return this._instanceDivisor;
	}
	set instanceDivisor(e) {
		let t = e != 0;
		this._instanceDivisor = e, t !== this._instanced && (this._instanced = t, this._computeHashCode());
	}
	get _maxVerticesCount() {
		let e = this.getData();
		return e ? Array.isArray(e) ? e.length / (this.byteStride / 4) - this.byteOffset / 4 : (e.byteLength - this.byteOffset) / this.byteStride : 0;
	}
	constructor(t, n, r, i, o, s, l, f, p, m, h = !1, g = !1, _ = 1, v = !1) {
		this._isDisposed = !1;
		let y;
		if (this.engine = t, typeof i == "object" && i ? (y = i.updatable ?? !1, o = i.postponeInternalCreation, s = i.stride, l = i.instanced, f = i.offset, p = i.size, m = i.type, h = i.normalized ?? !1, g = i.useBytes ?? !1, _ = i.divisor ?? 1, v = i.takeBufferOwnership ?? !1, this._label = i.label) : y = !!i, n instanceof c ? (this._buffer = n, this._ownsBuffer = v) : (this._buffer = new c(t, n, y, s, o, l, g, _, this._label), this._ownsBuffer = !0), this.uniqueId = e._Counter++, this._kind = r, m === void 0) {
			let t = this.getData();
			this.type = t ? d(t) : e.FLOAT;
		} else this.type = m;
		let b = a(this.type);
		g ? (this._size = p || (s ? s / b : u(r)), this.byteStride = s || this._buffer.byteStride || this._size * b, this.byteOffset = f || 0) : (this._size = p || s || u(r), this.byteStride = s ? s * b : this._buffer.byteStride || this._size * b, this.byteOffset = (f || 0) * b), this.normalized = h, this._instanced = l !== void 0 && l, this._instanceDivisor = l ? _ : 0, this._alignBuffer(), this._computeHashCode();
	}
	static _GetTypeHashIndex(t) {
		switch (t) {
			case e.BYTE: return 0;
			case e.UNSIGNED_BYTE: return 1;
			case e.SHORT: return 2;
			case e.UNSIGNED_SHORT: return 3;
			case e.INT: return 4;
			case e.UNSIGNED_INT: return 5;
			case e.FLOAT: return 6;
			case e.HALF_FLOAT: return 7;
			default: throw Error(`Invalid vertex buffer type '${t}'`);
		}
	}
	_computeHashCode() {
		this.hashCode = (e._GetTypeHashIndex(this.type) | 0) + (!!this.normalized << 3) + (this._size - 1 << 4) + (!!this._instanced << 6) + (this.byteStride << 12);
	}
	_rebuild() {
		this._buffer?._rebuild();
	}
	getKind() {
		return this._kind;
	}
	isUpdatable() {
		return this._buffer.isUpdatable();
	}
	getData() {
		return this._buffer.getData();
	}
	getFloatData(e, t) {
		let n = this.getData();
		return n ? i(n, this._size, this.type, this.byteOffset, this.byteStride, this.normalized, e, t) : null;
	}
	getBuffer() {
		return this._buffer.getBuffer();
	}
	getWrapperBuffer() {
		return this._buffer;
	}
	getStrideSize() {
		return this.byteStride / a(this.type);
	}
	getOffset() {
		return this.byteOffset / a(this.type);
	}
	getSize(e = !1) {
		return e ? this._size * a(this.type) : this._size;
	}
	getIsInstanced() {
		return this._instanced;
	}
	getInstanceDivisor() {
		return this._instanceDivisor;
	}
	create(e) {
		this._buffer.create(e), this._alignBuffer();
	}
	update(e) {
		this._buffer.update(e), this._alignBuffer();
	}
	updateDirectly(e, t, n = !1) {
		this._buffer.updateDirectly(e, t, void 0, n), this._alignBuffer();
	}
	dispose() {
		this._ownsBuffer && this._buffer.dispose(), this._isDisposed = !0;
	}
	forEach(e, t) {
		r(this._buffer.getData(), this.byteOffset, this.byteStride, this._size, this.type, e, this.normalized, (e, n) => {
			for (let r = 0; r < this._size; r++) t(e[r], n + r);
		});
	}
	_alignBuffer() {}
};
l._Counter = 0, l.BYTE = 5120, l.UNSIGNED_BYTE = 5121, l.SHORT = 5122, l.UNSIGNED_SHORT = 5123, l.INT = 5124, l.UNSIGNED_INT = 5125, l.FLOAT = 5126, l.HALF_FLOAT = 5131, l.PositionKind = "position", l.NormalKind = "normal", l.TangentKind = "tangent", l.UVKind = "uv", l.UV2Kind = "uv2", l.UV3Kind = "uv3", l.UV4Kind = "uv4", l.UV5Kind = "uv5", l.UV6Kind = "uv6", l.ColorKind = "color", l.ColorInstanceKind = "instanceColor", l.MatricesIndicesKind = "matricesIndices", l.MatricesWeightsKind = "matricesWeights", l.MatricesIndicesExtraKind = "matricesIndicesExtra", l.MatricesWeightsExtraKind = "matricesWeightsExtra";
function u(e) {
	switch (e) {
		case l.UVKind:
		case l.UV2Kind:
		case l.UV3Kind:
		case l.UV4Kind:
		case l.UV5Kind:
		case l.UV6Kind: return 2;
		case l.NormalKind:
		case l.PositionKind: return 3;
		case l.ColorKind:
		case l.ColorInstanceKind:
		case l.MatricesIndicesKind:
		case l.MatricesIndicesExtraKind:
		case l.MatricesWeightsKind:
		case l.MatricesWeightsExtraKind:
		case l.TangentKind: return 4;
		default: throw Error("Invalid kind '" + e + "'");
	}
}
function d(e) {
	return e instanceof Int8Array ? l.BYTE : e instanceof Uint8Array ? l.UNSIGNED_BYTE : e instanceof Int16Array ? l.SHORT : e instanceof Uint16Array ? l.UNSIGNED_SHORT : e instanceof Int32Array ? l.INT : e instanceof Uint32Array ? l.UNSIGNED_INT : l.FLOAT;
}
function f(e) {
	return a(e);
}
function p(e, t, n, i, a, o, s, c) {
	r(e, t, n, i, a, o, s, (e, t) => {
		for (let n = 0; n < i; n++) c(e[n], t + n);
	});
}
//#endregion
export { f as a, p as i, l as n, s as o, u as r, c as t };
