import { t as e } from "./math.scalar.functions-D7lyzZPV.js";
import { _ as t, t as n, u as r } from "./math.color.pure-CPmbqLkh.js";
import { n as i, t as a } from "./sphericalPolynomial.pure-DQ1oR6Od.js";
//#region node_modules/@babylonjs/core/Misc/HighDynamicRange/cubemapToSphericalPolynomial.js
var o = class {
	constructor(e, t, n, r) {
		this.name = e, this.worldAxisForNormal = t, this.worldAxisForFileX = n, this.worldAxisForFileY = r;
	}
}, s = class {
	static _NearestPow2Floor(e) {
		return e <= 1 ? 1 : 1 << Math.floor(Math.log2(e));
	}
	static ConvertCubeMapTextureToSphericalPolynomial(e) {
		if (!e.isCube) return null;
		e.getScene()?.getEngine().flushFramebuffer();
		let t = e.getSize().width, n = e._sphericalPolynomialTargetSize, r = n > 0 ? this._NearestPow2Floor(n) : 0, i = !e.noMipmap && e._texture?.generateMipMaps === !0, a = r > 0 && r < t && i, o = a ? Math.max(0, Math.round(Math.log2(t / r))) : 0, s = a ? Math.max(1, Math.floor(t / 2 ** o)) : t, c = e.readPixels(0, o, void 0, !1), l = e.readPixels(1, o, void 0, !1), u, d;
		e.isRenderTarget ? (u = e.readPixels(3, o, void 0, !1), d = e.readPixels(2, o, void 0, !1)) : (u = e.readPixels(2, o, void 0, !1), d = e.readPixels(3, o, void 0, !1));
		let f = e.readPixels(4, o, void 0, !1), p = e.readPixels(5, o, void 0, !1), m = e.gammaSpace, h = r > 0 && r < t && !a;
		return new Promise((e) => {
			Promise.all([
				l,
				c,
				u,
				d,
				f,
				p
			]).then(([n, i, a, o, c, l]) => {
				let u = s;
				h && (n = this._DownsampleFace(n, t, r, 4), i = this._DownsampleFace(i, t, r, 4), a = this._DownsampleFace(a, t, r, 4), o = this._DownsampleFace(o, t, r, 4), c = this._DownsampleFace(c, t, r, 4), l = this._DownsampleFace(l, t, r, 4), u = r);
				let d = {
					size: u,
					right: i,
					left: n,
					up: a,
					down: o,
					front: c,
					back: l,
					format: 5,
					type: +(n instanceof Float32Array),
					gammaSpace: m
				};
				e(this.ConvertCubeMapToSphericalPolynomial(d));
			});
		});
	}
	static _AreaElement(e, t) {
		return Math.atan2(e * t, Math.sqrt(e * e + t * t + 1));
	}
	static _DownsampleFace(e, t, n, r) {
		let i = e instanceof Float32Array ? e : Float32Array.from(e), a = n * n * r, o = new Float32Array(a), s = t / n, c = 1 / (s * s);
		for (let e = 0; e < n; e++) {
			let a = Math.floor(e * s), l = Math.floor((e + 1) * s);
			for (let u = 0; u < n; u++) {
				let d = Math.floor(u * s), f = Math.floor((u + 1) * s), p = (e * n + u) * r;
				for (let e = 0; e < r; e++) {
					let n = 0;
					for (let o = a; o < l; o++) for (let a = d; a < f; a++) n += i[(o * t + a) * r + e];
					o[p + e] = n * c;
				}
			}
		}
		if (e instanceof Float32Array) return o;
		let l = e.constructor, u = new l(a);
		for (let e = 0; e < a; e++) u[e] = o[e] + .5 | 0;
		return u;
	}
	static ConvertCubeMapToSphericalPolynomial(r, o = 0) {
		let s = o > 0 ? this._NearestPow2Floor(o) : 0;
		if (s > 0 && r.size > s) {
			let e = r.format === 5 ? 4 : 3, t = [
				"right",
				"left",
				"up",
				"down",
				"front",
				"back"
			], n = {};
			for (let i of t) n[i] = this._DownsampleFace(r[i], r.size, s, e);
			r = {
				...r,
				...n,
				size: s
			};
		}
		let c = new a(), l = 0, u = 2 / r.size, d = u, f = .5 * u, p = f - 1;
		for (let i = 0; i < 6; i++) {
			let a = this._FileFaces[i], o = r[a.name], s = p, m = r.format === 5 ? 4 : 3;
			for (let i = 0; i < r.size; i++) {
				let h = p;
				for (let d = 0; d < r.size; d++) {
					let p = a.worldAxisForFileX.scale(h).add(a.worldAxisForFileY.scale(s)).add(a.worldAxisForNormal);
					p.normalize();
					let g = this._AreaElement(h - f, s - f) - this._AreaElement(h - f, s + f) - this._AreaElement(h + f, s - f) + this._AreaElement(h + f, s + f), _ = o[i * r.size * m + d * m + 0], v = o[i * r.size * m + d * m + 1], y = o[i * r.size * m + d * m + 2];
					isNaN(_) && (_ = 0), isNaN(v) && (v = 0), isNaN(y) && (y = 0), r.type === 0 && (_ /= 255, v /= 255, y /= 255), r.gammaSpace && (_ = e(_) ** +t, v = e(v) ** +t, y = e(y) ** +t);
					let b = this.MAX_HDRI_VALUE;
					if (this.PRESERVE_CLAMPED_COLORS) {
						let e = Math.max(_, v, y);
						if (e > b) {
							let t = b / e;
							_ *= t, v *= t, y *= t;
						}
					} else _ = e(_, 0, b), v = e(v, 0, b), y = e(y, 0, b);
					let x = new n(_, v, y);
					c.addLight(p, x, g), l += g, h += u;
				}
				s += d;
			}
		}
		let m = 4 * Math.PI * 6 / 6 / l;
		return c.scaleInPlace(m), c.convertIncidentRadianceToIrradiance(), c.convertIrradianceToLambertianRadiance(), i.FromHarmonics(c);
	}
};
s._FileFaces = [
	new o("right", new r(1, 0, 0), new r(0, 0, -1), new r(0, -1, 0)),
	new o("left", new r(-1, 0, 0), new r(0, 0, 1), new r(0, -1, 0)),
	new o("up", new r(0, 1, 0), new r(1, 0, 0), new r(0, 0, 1)),
	new o("down", new r(0, -1, 0), new r(1, 0, 0), new r(0, 0, -1)),
	new o("front", new r(0, 0, 1), new r(1, 0, 0), new r(0, -1, 0)),
	new o("back", new r(0, 0, -1), new r(-1, 0, 0), new r(0, -1, 0))
], s.MAX_HDRI_VALUE = 4096, s.PRESERVE_CLAMPED_COLORS = !1;
//#endregion
export { s as t };
