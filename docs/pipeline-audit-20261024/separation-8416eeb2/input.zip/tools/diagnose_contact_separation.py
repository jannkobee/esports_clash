"""Colab-only, bounded rest-sign-guided shoulder contact separation hypothesis.

This evaluates a posed surface only. It never writes a production mesh or
declares an anatomical pass; every frozen baseline and failure is retained.
"""
from collections import defaultdict
import hashlib,json,math,os,sys,time
from pathlib import Path
import bpy
from mathutils import Vector
from review_generated_rig import load,surface
from mesh_validation import collision_summary,rest_keys
from candidate_animation import clear_imported_animation,bind_imported_clip
from diagnose_collision_influences import all_vertex_weights,collision_pairs
from diagnose_skinning_modes import seam_groups,seam_spread
from contact_patch_mask import mesh_ring_falloff
from review_shoulder_contact_candidate import verify_source
from asset_pipeline.edge_deformation import edge_deformation

ROLES=['UpperArmL','UpperArmR','ForearmL','ForearmR','ThighL','ThighR','CalfL','CalfR']
def center(points,face):return sum((points[i] for i in face),Vector())/3
def normal(points,face):
 a,b,c=(points[i] for i in face);n=(b-a).cross(c-a)
 return n.normalized() if n.length>1e-12 else None

def main(root):
 if not os.environ.get('COLAB_RELEASE_TAG') or not root.is_relative_to('/content/teamfight-preparation/reviews'):raise RuntimeError('Google Colab required')
 plan=json.loads((root/'plan.json').read_text());out=root/'output';out.mkdir(exist_ok=False)
 report={'id':plan['id'],'method':plan['method'],'compute':'google','source_sha256':plan['source_sha256'],
  'rig_sha256':plan['parent_candidate_sha256'],'parent_candidate_id':plan['parent_candidate_id'],'contact_map_id':plan['contact_map_id'],
  'qualification_complete':False,'publication_eligible':False,'config':plan['config'],'baseline_reproduction':[],'status':'running'}
 def save(): (out/'report.json').write_text(json.dumps(report,indent=2))
 try:
  for n,h in plan['files'].items():
   if hashlib.sha256((root/n).read_bytes()).hexdigest()!=h:raise ValueError('Frozen input mismatch: '+n)
  contact=json.loads((root/'contact-map.json').read_text());baseline=json.loads((root/'baseline-report.json').read_text())
  if contact['id']!=plan['contact_map_id'] or contact['rig_sha256']!=plan['parent_candidate_sha256']:raise ValueError('Contact lineage mismatch')
  if plan['config']!={'joint':'UpperArmL','region_pair':['bone_2','bone_26'],'max_added_height_fraction':0.003,'falloff_rings':3,'minimum_rest_side_height_fraction':0.00001}:
   raise ValueError('Unknown frozen separation hypothesis')
  rigs,meshes=load(root/'candidate.glb');clear_imported_animation(rigs[0],meshes);bpy.context.scene.frame_set(0)
  primary_rest,primary_faces,_=surface(meshes);primary_weights=all_vertex_weights(meshes)
  verify_source(meshes,primary_rest,contact)
  for label in ['native','corrected']:
   expected=json.loads((root/(label+'-report.json')).read_text());expected={(p['joint'],p['degrees']):p for p in expected.get('reloaded_poses',expected.get('poses',[]))}
   rigs,meshes=load(root/(label+'-stress.glb'));rig=rigs[0];clear_imported_animation(rig,meshes);bpy.context.scene.frame_set(0)
   rest,faces,regions=surface(meshes);keys=rest_keys(rest);entry={'label':label,'poses':[]};report['baseline_reproduction'].append(entry)
   if label=='corrected':
    clip_weights=all_vertex_weights(meshes)
    if (faces!=primary_faces or len(rest)!=len(primary_rest) or len(clip_weights)!=len(primary_weights)
        or max((a-b).length for a,b in zip(rest,primary_rest))>1e-6
        or any(set(a)!=set(b) or any(abs(a[k]-b[k])>1e-6 for k in a) for a,b in zip(primary_weights,clip_weights))):
     raise ValueError('Corrected clip topology, rest positions or weights differ from signed primary candidate')
   for role in ROLES:
    action,_=bind_imported_clip(rig,meshes,'Stress_'+role,label=='corrected');first,last=action.frame_range
    for phase,degrees in ((.25,45),(.5,90)):
     frame=first+(last-first)*phase;bpy.context.scene.frame_set(math.floor(first)-1);bpy.context.scene.frame_set(math.floor(frame),subframe=frame-math.floor(frame))
     points,posed_faces,_=surface(meshes)
     if posed_faces!=faces:raise ValueError('Clip topology differs')
     count=collision_summary(points,faces,keys,regions)['self_intersections'];row={'joint':role,'degrees':degrees,'self_intersections':count,'expected':expected[(role,degrees)]['self_intersections']};entry['poses'].append(row)
     report['stage']=label+'_'+role+'_'+str(degrees);save()
     if count!=row['expected']:raise ValueError('Frozen baseline not reproduced')
   entry['reproduced']=True
  # Signed indices refer to the primary import; clip correspondence was checked above.
  cohorts=seam_groups(rest)
  action,_=bind_imported_clip(rig,meshes,'Stress_UpperArmL',True);first,last=action.frame_range;frame=first+(last-first)*.5
  bpy.context.scene.frame_set(math.floor(first)-1);bpy.context.scene.frame_set(math.floor(frame),subframe=frame-math.floor(frame));posed,_,_=surface(meshes)
  ordered,reg,pairs,counts=collision_pairs(posed,faces,keys,regions);matching=[(a,b) for a,b in pairs if set((reg[a],reg[b]))==set(plan['config']['region_pair'])]
  if len(matching)!=31:raise ValueError('Signed shoulder pair set changed')
  height=max(p.z for p in rest)-min(p.z for p in rest);seeds=defaultdict(list);ambiguous=0
  for a,b in matching:
   torso,arm=(a,b) if reg[a]=='bone_2' else (b,a)
   nr=normal(rest,ordered[torso]);np=normal(posed,ordered[torso])
   if nr is None or np is None:ambiguous+=1;continue
   side=(center(rest,ordered[arm])-center(rest,ordered[torso])).dot(nr)
   if abs(side)<height*plan['config']['minimum_rest_side_height_fraction']:ambiguous+=1;continue
   direction=np*(1 if side>0 else -1)
   for vertex in ordered[arm]:seeds[vertex].append(direction)
  if not seeds:raise ValueError('No unambiguous rest-side shoulder seeds')
  if len(meshes)!=1:raise ValueError('Prototype requires one mesh')
  obj=meshes[0];adjacency=[set() for _ in obj.data.vertices]
  for edge in obj.data.edges:
   a,b=edge.vertices;adjacency[a].add(b);adjacency[b].add(a)
  falloff=mesh_ring_falloff(adjacency,cohorts,set(seeds),plan['config']['falloff_rings'])
  vectors={i:sum(values,Vector()).normalized() for i,values in seeds.items() if sum(values,Vector()).length>1e-10}
  if not vectors:raise ValueError('Shoulder normal directions cancel')
  for _ in range(3):
   prior=dict(vectors)
   for i in falloff:
    if i not in prior:
     candidates=[prior[j] for j in adjacency[i] if j in prior]
     if candidates:
      v=sum(candidates,Vector());vectors[i]=v.normalized() if v.length>1e-10 else Vector()
  # Duplicate seam vertices must share a single displacement.
  deltas=[vectors.get(i,Vector())*(height*plan['config']['max_added_height_fraction']*falloff.get(i,0)) for i in range(len(rest))]
  for group in cohorts:
   v=sum((deltas[i] for i in group),Vector())/len(group)
   for i in group:deltas[i]=v.copy()
  changed=[p+d for p,d in zip(posed,deltas)];result=collision_summary(changed,faces,keys,regions)
  report['separation']={'joint':'UpperArmL','degrees':90,'eligible_pairs':len(matching),'ambiguous_pairs':ambiguous,'seed_vertices':len(seeds),
   'falloff_vertices':len(falloff),'max_added_delta_m':max(v.length for v in deltas),'height_m':height,
   'before_intersections':31,'after_intersections':result['self_intersections'],'top_regions':result['top_regions'],
   'seam_spread_m':seam_spread(changed,cohorts),'edge_deformation':edge_deformation(rest,changed,faces)}
  save()
  if report['separation']['max_added_delta_m']>height*.0030001 or report['separation']['seam_spread_m']>1e-6 or report['separation']['edge_deformation']['severely_stretched_edges']:
   raise ValueError('Separation exceeded frozen seam/stretch/displacement bounds')
  report['status']='diagnostic_complete';report['scope']='Single left-shoulder posed-surface hypothesis based on signed rest-side contact normals. No exported GLB, visual pass, full motion or qualification.'
 except Exception as error:report.update(status='failed',error=f'{type(error).__name__}: {error}');raise
 finally:report['completed_unix']=time.time();save()
if __name__=='__main__':main(Path(sys.argv[1]).resolve())
