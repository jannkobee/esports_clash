"""Render exact candidate bind poses and verified diagnostic clips in the packaged Babylon inspector."""
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
import hashlib
import json
import os
from pathlib import Path
import sys
import threading

from playwright.sync_api import sync_playwright


def main(root):
    if not os.environ.get('COLAB_RELEASE_TAG') or not root.is_relative_to('/content/teamfight-preparation/reviews'):
        raise RuntimeError('Google Colab inspection environment required')
    plan = json.loads((root / 'plan.json').read_text())
    for name, expected in plan['files'].items():
        if hashlib.sha256((root / name).read_bytes()).hexdigest() != expected:
            raise ValueError('Frozen viewer input mismatch: ' + name)
    exported = json.loads((root / 'bend-export-report.json').read_text())
    for asset in exported['assets']:
        path = root / 'site' / (asset['label'] + '-stress.glb')
        if not asset['baseline_reproduced'] or hashlib.sha256(path.read_bytes()).hexdigest() != asset['stress_sha256']:
            raise ValueError('Diagnostic clip evidence mismatch')
    server = ThreadingHTTPServer(('127.0.0.1', 0), partial(SimpleHTTPRequestHandler, directory=str(root / 'site')))
    threading.Thread(target=server.serve_forever, daemon=True).start()
    screenshots = root / 'screenshots'
    screenshots.mkdir(exist_ok=False)
    report = {'id': plan['id'], 'compute': 'google', 'publication_eligible': False,
        'qualification_complete': False, 'views': [], 'errors': [], 'plan': plan}
    try:
        with sync_playwright() as pw:
            browser = pw.chromium.launch(headless=True, args=['--no-sandbox', '--disable-dev-shm-usage',
                '--use-angle=swiftshader', '--enable-unsafe-swiftshader'])
            page = browser.new_page(viewport={'width': 1000, 'height': 900})
            page.on('pageerror', lambda error: report['errors'].append(str(error)))
            page.goto(f'http://127.0.0.1:{server.server_port}/index.html')
            page.wait_for_selector('#base-inspection[data-ready="true"]', timeout=60000)
            def load(file, clips):
                page.evaluate('''file=>{document.dispatchEvent(new Event('livewire:navigating'));document.querySelector('#base-inspection').dataset.asset='/'+file;document.dispatchEvent(new Event('livewire:navigated'));}''', file)
                page.wait_for_selector('#base-inspection[data-ready="true"]', timeout=60000)
                names = json.loads(page.locator('#base-inspection').get_attribute('data-clips'))
                if len(names) != clips:
                    raise ValueError(f'Unexpected clip count: {file}: {names}')
            def capture(label, kind, role, degrees, view, skeleton=False):
                page.locator(f'[data-base-view="{view}"]').click()
                if skeleton:
                    page.locator('#base-skeleton').click()
                page.wait_for_timeout(180)
                name = f'{label}-{kind}-{role}-{degrees}-{view}' + ('-skeleton' if skeleton else '') + '.png'
                page.locator('#base-inspection').screenshot(path=str(screenshots / name))
                report['views'].append({'file': 'screenshots/' + name, 'asset': label, 'kind': kind,
                    'joint': role, 'degrees': degrees, 'view': view, 'skeleton': skeleton,
                    'sha256': hashlib.sha256((screenshots / name).read_bytes()).hexdigest()})
                if skeleton:
                    page.locator('#base-skeleton').click()
            for label in ('parent', 'current'):
                load(label + '.glb', 0)
                for view in ('front', 'side', 'back'):
                    capture(label, 'exact-bind', 'rest', 0, view)
                capture(label, 'exact-bind', 'rest', 0, 'front', skeleton=True)
                load(label + '-stress.glb', 8)
                for role in ('UpperArmL', 'UpperArmR', 'ThighL', 'ThighR'):
                    for degrees, phase in ((45, .25), (90, .5)):
                        page.evaluate('''x=>document.querySelector('#base-inspection').inspection.sample('Stress_'+x.role,x.phase)''', {'role': role, 'phase': phase})
                        for view in ('front', 'side'):
                            capture(label, 'verified-bend', role, degrees, view)
                    if role.startswith('UpperArm'):
                        capture(label, 'verified-bend', role, 90, 'back')
            if report['errors']:
                raise ValueError(str(report['errors']))
            browser.close()
            report['status'] = 'rendered_for_review'
    except Exception as error:
        report.update(status='failed', error=f'{type(error).__name__}: {error}')
        raise
    finally:
        server.shutdown()
        (root / 'visual-report.json').write_text(json.dumps(report, indent=2))


if __name__ == '__main__':
    main(Path(sys.argv[1]).resolve())
