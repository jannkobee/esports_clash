import fcntl,hashlib,json,os,pathlib,subprocess,time
r=pathlib.Path(__file__).parent;s={'id':r.name,'compute':'google','publication_eligible':False,'qualification_complete':False,'status':'queued'}
def save():
 p=r/'state.tmp.json';p.write_text(json.dumps(s,indent=2));p.replace(r/'state.json')
assert os.environ.get('COLAB_RELEASE_TAG');save()
lease=pathlib.Path('/content/esports-trellis2/gpu-lease/inference.lock');lease.parent.mkdir(parents=True,exist_ok=True)
with lease.open('a+') as lock:
 try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 except BlockingIOError:s.update(status='waiting_resources');save();raise SystemExit()
 try:
  i=json.loads(pathlib.Path('/content/teamfight-preparation/installation.json').read_text())
  assert i['runtime_id']=='ddb07188977acba2b815846c5f2ead92802114fe87200f49fa9f665e7d698e10' and i['status']=='installed_unqualified' and i['profile']=='t4-fp32' and i['environment_sha256']=='160e42e63b84d075df53fca9c416775671584a1ed926a9ea81ad71691ab2ebab'
  s.update(status='running',stage='contact-separation',runtime_id=i['runtime_id'],environment_sha256=i['environment_sha256'],started_unix=time.time());save()
  with (r/'contact-separation.log').open('ab') as log:
   p=subprocess.run(['/content/teamfight-preparation/venv/bin/python','-u',str(r/'tools/diagnose_contact_topology.py'),str(r)],stdout=log,stderr=subprocess.STDOUT,timeout=1200)
  s['exit_code']=p.returncode;save()
  if p.returncode:raise RuntimeError('Contact map exited '+str(p.returncode))
  report=r/'output/report.json';d=json.loads(report.read_text());assert d['status']=='diagnostic_complete'
  s.update(status='completed',report_sha256=hashlib.sha256(report.read_bytes()).hexdigest())
 except Exception as error:s.update(status='failed',error=f'{type(error).__name__}: {error}')
 finally:s['completed_unix']=time.time();save()
