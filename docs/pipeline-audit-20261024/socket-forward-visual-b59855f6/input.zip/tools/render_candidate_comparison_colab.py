"""Render exact candidate bind poses and verified diagnostic clips in the packaged Babylon inspector."""
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
import hashlib
import json
import os
from pathlib import Path
import sys
import threading

from playwright.sync_api import sync_playwright
from candidate_visual_contract import validate_diagnostic_sources


def main(root):
    if not os.environ.get('COLAB_RELEASE_TAG') or not root.is_relative_to('/content/teamfight-preparation/reviews'):
        raise RuntimeError('Google Colab inspection environment required')
    plan = json.loads((root / 'plan.json').read_text())
    for name, expected in plan['files'].items():
        if hashlib.sha256((root / name).read_bytes()).hexdigest() != expected:
            raise ValueError('Frozen viewer input mismatch: ' + name)
    exported = json.loads((root / 'bend-export-report.json').read_text())
    detail_only = plan.get('mode') == 'joint-details'
    validate_diagnostic_sources(root, plan, exported)
    mapping = json.loads((root / 'baseline-report.json').read_text())['bone_map']
    server = ThreadingHTTPServer(('127.0.0.1', 0), partial(SimpleHTTPRequestHandler, directory=str(root / 'site')))
    threading.Thread(target=server.serve_forever, daemon=True).start()
    screenshots = root / 'screenshots'
    screenshots.mkdir(exist_ok=False)
    report = {'id': plan['id'], 'compute': 'google', 'publication_eligible': False,
        'qualification_complete': False, 'views': [], 'errors': [], 'plan': plan,
        'frame_capture': 'Explicit Babylon renders of paused poses; continuous render loop stopped during screenshot capture.'}
    try:
        with sync_playwright() as pw:
            browser = pw.chromium.launch(headless=True, args=['--no-sandbox', '--disable-dev-shm-usage',
                '--use-angle=swiftshader', '--enable-unsafe-swiftshader'])
            page = browser.new_page(viewport={'width': 1000, 'height': 900})
            page.on('pageerror', lambda error: report['errors'].append(str(error)))
            page.goto(f'http://127.0.0.1:{server.server_port}/index.html')
            page.wait_for_selector('#base-inspection[data-ready="true"]', timeout=60000)
            def load(file, clips):
                page.evaluate('''file=>{document.dispatchEvent(new Event('livewire:navigating'));document.querySelector('#base-inspection').dataset.asset='/'+file;document.dispatchEvent(new Event('livewire:navigated'));}''', file)
                page.wait_for_selector('#base-inspection[data-ready="true"]', timeout=60000)
                names = json.loads(page.locator('#base-inspection').get_attribute('data-clips'))
                if len(names) != clips:
                    raise ValueError(f'Unexpected clip count: {file}: {names}')
                page.evaluate('''async()=>{const s=document.querySelector('#base-inspection').inspection.scene;
                    s.getEngine().stopRenderLoop();s.render();await s.whenReadyAsync();s.render();}''')
            def capture(label, kind, role, degrees, view, skeleton=False, detail=False):
                page.locator(f'[data-base-view="{"front" if view == "oblique" else view}"]').click()
                if detail:
                    page.evaluate('''x=>{const i=document.querySelector('#base-inspection').inspection;
                        const joint=i.container.transformNodes.find(node=>node.name===x.bone);
                        if(!joint)throw new Error('Inspection joint missing: '+x.bone);
                        const alpha=i.camera.alpha,beta=i.camera.beta;
                        joint.computeWorldMatrix(true);i.camera.setTarget(joint.getAbsolutePosition());
                        i.camera.alpha=alpha+(x.view==='oblique'?(x.left?Math.PI/4:-Math.PI/4):0);
                        i.camera.beta=x.view==='oblique'?Math.PI/2.15:beta;
                        i.camera.inertialAlphaOffset=0;i.camera.inertialBetaOffset=0;i.camera.inertialRadiusOffset=0;
                        i.camera.radius=Math.max(i.camera.lowerRadiusLimit,i.camera.radius*.3);
                        if(i.camera.minZ>i.camera.radius*.1)throw new Error('Near clipping plane prevents joint detail review');
                        i.scene.render();}''', {'bone': mapping[role], 'view': view, 'left': role.endswith('L')})
                if skeleton:
                    page.locator('#base-skeleton').click()
                page.evaluate('''async()=>{const s=document.querySelector('#base-inspection').inspection.scene;
                    s.render();await s.whenReadyAsync();s.render();}''')
                page.wait_for_timeout(180)
                name = f'{label}-{kind}-{role}-{degrees}-{view}' + ('-skeleton' if skeleton else '') + ('-detail' if detail else '') + '.png'
                page.locator('#base-inspection').screenshot(path=str(screenshots / name))
                report['views'].append({'file': 'screenshots/' + name, 'asset': label, 'kind': kind,
                    'joint': role, 'degrees': degrees, 'view': view, 'skeleton': skeleton, 'detail': detail,
                    'camera': page.evaluate('''()=>{const c=document.querySelector('#base-inspection').inspection.camera;return {alpha:c.alpha,beta:c.beta,radius:c.radius,minZ:c.minZ,target:c.target.asArray()}}'''),
                    'sha256': hashlib.sha256((screenshots / name).read_bytes()).hexdigest()})
                if skeleton:
                    page.locator('#base-skeleton').click()
            for label in ('parent', 'current'):
                if not detail_only:
                    load(label + '.glb', 0)
                    for view in ('front', 'side', 'back'):
                        capture(label, 'exact-bind', 'rest', 0, view)
                    capture(label, 'exact-bind', 'rest', 0, 'front', skeleton=True)
                load(label + '-stress.glb', 8)
                for role in ('UpperArmL', 'UpperArmR', 'ThighL', 'ThighR'):
                    for degrees, phase in (((90, .5),) if detail_only else ((45, .25), (90, .5))):
                        page.evaluate('''x=>document.querySelector('#base-inspection').inspection.sample('Stress_'+x.role,x.phase)''', {'role': role, 'phase': phase})
                        for view in (plan.get('detail_views', ['front', 'side']) if detail_only else ['front', 'side']):
                            capture(label, 'verified-bend', role, degrees, view, detail=detail_only)
                            if not detail_only and degrees == 90 and plan.get('include_joint_details'):
                                capture(label, 'verified-bend', role, degrees, view, detail=True)
                    if not detail_only and role.startswith('UpperArm'):
                        capture(label, 'verified-bend', role, 90, 'back')
                    if not detail_only and plan.get('include_joint_details') and 'oblique' in plan.get('detail_views', []):
                        capture(label, 'verified-bend', role, 90, 'oblique', detail=True)
            if report['errors']:
                raise ValueError(str(report['errors']))
            browser.close()
            report['status'] = 'rendered_for_review'
    except Exception as error:
        report.update(status='failed', error=f'{type(error).__name__}: {error}')
        raise
    finally:
        server.shutdown()
        (root / 'visual-report.json').write_text(json.dumps(report, indent=2))


if __name__ == '__main__':
    main(Path(sys.argv[1]).resolve())
