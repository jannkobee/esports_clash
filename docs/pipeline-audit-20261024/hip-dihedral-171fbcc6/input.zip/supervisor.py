import fcntl,hashlib,json,os,pathlib,subprocess,time
r=pathlib.Path(__file__).parent;s={'id':r.name,'compute':'google','publication_eligible':False,'qualification_complete':False,'status':'queued'}
def save():
 p=r/'state.tmp.json';p.write_text(json.dumps(s,indent=2));p.replace(r/'state.json')
assert os.environ.get('COLAB_RELEASE_TAG');save()
lease=pathlib.Path('/content/esports-trellis2/gpu-lease/inference.lock');lease.parent.mkdir(parents=True,exist_ok=True)
with lease.open('a+') as lock:
 try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 except BlockingIOError:s.update(status='waiting_resources');save();raise SystemExit()
 try:
  i=json.loads(pathlib.Path('/content/teamfight-preparation/installation.json').read_text())
  assert i['runtime_id']=='6e1278f427958d83715851a16946b047ce0be97f803d9c5c5fba8e4fbb5b4caa' and i['status']=='installed_unqualified' and i['profile']=='t4-fp32' and i['environment_sha256']=='f706010e83a63d36766b0a14b0bc12dce2ff2859a8a45aaec5b765296aa7e365'
  s.update(status='running',stage='hip-dihedral',runtime_id=i['runtime_id'],environment_sha256=i['environment_sha256'],started_unix=time.time());save()
  with (r/'hip-dihedral.log').open('ab') as log:
   p=subprocess.run(['/content/teamfight-preparation/venv/bin/python','-u',str(r/'tools/diagnose_contact_separation.py'),str(r)],stdout=log,stderr=subprocess.STDOUT,timeout=1200)
  s['exit_code']=p.returncode;save()
  if p.returncode:raise RuntimeError('Contact map exited '+str(p.returncode))
  report=r/'output/report.json';d=json.loads(report.read_text());assert d['status']=='diagnostic_complete'
  s.update(status='completed',report_sha256=hashlib.sha256(report.read_bytes()).hexdigest())
 except Exception as error:s.update(status='failed',error=f'{type(error).__name__}: {error}')
 finally:s['completed_unix']=time.time();save()
